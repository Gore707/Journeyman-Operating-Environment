"""Real host telemetry acquisition for JOE.

Values are collected from host APIs exposed through psutil/Python. Unsupported
measurements are represented as unavailable (None), never synthesized.
"""
from __future__ import annotations
from dataclasses import dataclass
from time import time, monotonic
from pathlib import Path
import os
import psutil
import shutil
import subprocess
from threading import RLock, Event, Thread


@dataclass(frozen=True)
class TemperatureReading:
    sensor: str
    label: str
    celsius: float


@dataclass(frozen=True)
class GPUReading:
    index: int
    name: str
    utilization_percent: float | None
    memory_used_bytes: int | None
    memory_total_bytes: int | None
    temperature_celsius: float | None
    source: str

@dataclass(frozen=True)
class HostTelemetrySample:
    timestamp: float
    cpu_percent: float
    cpu_logical_count: int | None
    cpu_physical_count: int | None
    memory_total_bytes: int
    memory_available_bytes: int
    memory_percent: float
    process_rss_bytes: int
    process_cpu_percent: float
    disk_total_bytes: int
    disk_free_bytes: int
    disk_percent: float
    temperatures: tuple[TemperatureReading, ...]
    temperature_available: bool
    gpus: tuple[GPUReading, ...]
    gpu_available: bool


class HostTelemetry:
    """Samples genuine host/process measurements available to this runtime."""
    def __init__(self, disk_path: Path | str):
        self.disk_path=Path(disk_path)
        self._process=psutil.Process(os.getpid())
        # Prime process CPU accounting; first public sample remains real but
        # process CPU may legitimately be 0 until an interval has elapsed.
        self._process.cpu_percent(interval=None)

    def _temperatures(self) -> tuple[TemperatureReading,...]:
        getter=getattr(psutil,"sensors_temperatures",None)
        if getter is None:
            return ()
        try:
            groups=getter(fahrenheit=False) or {}
        except (NotImplementedError,OSError,RuntimeError):
            return ()
        readings=[]
        for sensor,entries in groups.items():
            for entry in entries:
                current=getattr(entry,"current",None)
                if current is None:
                    continue
                try:
                    value=float(current)
                except (TypeError,ValueError):
                    continue
                readings.append(TemperatureReading(
                    sensor=str(sensor),
                    label=str(getattr(entry,"label","") or ""),
                    celsius=value,
                ))
        return tuple(readings)

    def _gpus(self) -> tuple[GPUReading,...]:
        executable=shutil.which("nvidia-smi")
        if not executable:
            return ()
        command=[
            executable,
            "--query-gpu=index,name,utilization.gpu,memory.used,memory.total,temperature.gpu",
            "--format=csv,noheader,nounits",
        ]
        try:
            result=subprocess.run(
                command,capture_output=True,text=True,timeout=2,check=False,
                creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0),
            )
        except (OSError,subprocess.SubprocessError):
            return ()
        if result.returncode != 0:
            return ()
        readings=[]
        for line in result.stdout.splitlines():
            parts=[part.strip() for part in line.split(",")]
            if len(parts) != 6:
                continue
            def number(text, kind=float):
                if text.lower() in {"n/a","na","not supported",""}:
                    return None
                try: return kind(text)
                except (TypeError,ValueError): return None
            index=number(parts[0],int)
            if index is None:
                continue
            used_mib=number(parts[3],float)
            total_mib=number(parts[4],float)
            readings.append(GPUReading(
                index=index,
                name=parts[1] or "NVIDIA GPU",
                utilization_percent=number(parts[2],float),
                memory_used_bytes=None if used_mib is None else int(used_mib*1024*1024),
                memory_total_bytes=None if total_mib is None else int(total_mib*1024*1024),
                temperature_celsius=number(parts[5],float),
                source="nvidia-smi",
            ))
        return tuple(readings)

    def sample(self) -> HostTelemetrySample:
        vm=psutil.virtual_memory()
        disk=psutil.disk_usage(str(self.disk_path))
        temps=self._temperatures()
        gpus=self._gpus()
        return HostTelemetrySample(
            timestamp=time(),
            cpu_percent=float(psutil.cpu_percent(interval=None)),
            cpu_logical_count=psutil.cpu_count(logical=True),
            cpu_physical_count=psutil.cpu_count(logical=False),
            memory_total_bytes=int(vm.total),
            memory_available_bytes=int(vm.available),
            memory_percent=float(vm.percent),
            process_rss_bytes=int(self._process.memory_info().rss),
            process_cpu_percent=float(self._process.cpu_percent(interval=None)),
            disk_total_bytes=int(disk.total),
            disk_free_bytes=int(disk.free),
            disk_percent=float(disk.percent),
            temperatures=temps,
            temperature_available=bool(temps),
            gpus=gpus,
            gpu_available=bool(gpus),
        )


@dataclass(frozen=True)
class TelemetryCallbackFailure:
    timestamp: float
    callback: str
    error: str


@dataclass(frozen=True)
class TelemetryAcquisitionFailure:
    timestamp: float
    error: str


@dataclass(frozen=True)
class TelemetryMonitorStatus:
    running: bool
    interval_seconds: float
    retained_samples: int
    callback_failures: int
    acquisition_failures: int
    latest_timestamp: float | None
    sample_age_seconds: float | None
    fresh: bool


class HostTelemetryMonitor:
    """Continuously samples genuine host telemetry at a controlled interval."""
    def __init__(self, telemetry: HostTelemetry, interval_seconds: float = 1.0,
                 history_limit: int = 300, failure_limit: int = 100):
        if not isinstance(interval_seconds,(int,float)) or isinstance(interval_seconds,bool) or interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")
        if not isinstance(history_limit,int) or isinstance(history_limit,bool) or history_limit < 1:
            raise ValueError("history_limit must be a positive integer")
        if not isinstance(failure_limit,int) or isinstance(failure_limit,bool) or failure_limit < 1:
            raise ValueError("failure_limit must be a positive integer")
        self.telemetry=telemetry
        self.interval_seconds=float(interval_seconds)
        self._history_limit=history_limit
        self._failure_limit=failure_limit
        self._history: list[HostTelemetrySample]=[]
        self._failures: list[TelemetryCallbackFailure]=[]
        self._acquisition_failures: list[TelemetryAcquisitionFailure]=[]
        self._subscribers: list[callable]=[]
        self._lock=RLock()
        self._stop=Event()
        self._thread: Thread | None=None

    @property
    def running(self) -> bool:
        with self._lock:
            return bool(self._thread and self._thread.is_alive())

    def subscribe(self, callback) -> None:
        if not callable(callback):
            raise TypeError("telemetry subscriber must be callable")
        with self._lock:
            if callback not in self._subscribers:
                self._subscribers.append(callback)

    def unsubscribe(self, callback) -> None:
        with self._lock:
            if callback in self._subscribers:
                self._subscribers.remove(callback)

    def history(self) -> tuple[HostTelemetrySample,...]:
        with self._lock:
            return tuple(self._history)

    def latest(self) -> HostTelemetrySample | None:
        with self._lock:
            return self._history[-1] if self._history else None

    def callback_failures(self) -> tuple[TelemetryCallbackFailure,...]:
        with self._lock:
            return tuple(self._failures)

    def acquisition_failures(self) -> tuple[TelemetryAcquisitionFailure,...]:
        with self._lock:
            return tuple(self._acquisition_failures)

    def status(self, stale_after_seconds: float | None = None) -> TelemetryMonitorStatus:
        if stale_after_seconds is None:
            stale_after_seconds=max(2.5*self.interval_seconds, self.interval_seconds+0.5)
        if stale_after_seconds <= 0:
            raise ValueError("stale_after_seconds must be positive")
        with self._lock:
            latest=self._history[-1] if self._history else None
            running=bool(self._thread and self._thread.is_alive())
            callback_count=len(self._failures)
            acquisition_count=len(self._acquisition_failures)
            retained=len(self._history)
        age=None if latest is None else max(0.0,time()-latest.timestamp)
        return TelemetryMonitorStatus(
            running=running,
            interval_seconds=self.interval_seconds,
            retained_samples=retained,
            callback_failures=callback_count,
            acquisition_failures=acquisition_count,
            latest_timestamp=None if latest is None else latest.timestamp,
            sample_age_seconds=age,
            fresh=bool(running and age is not None and age <= stale_after_seconds),
        )

    def sample_once(self) -> HostTelemetrySample:
        sample=self.telemetry.sample()
        with self._lock:
            self._history.append(sample)
            if len(self._history) > self._history_limit:
                del self._history[:-self._history_limit]
            subscribers=tuple(self._subscribers)
        for callback in subscribers:
            try:
                callback(sample)
            except Exception as exc:
                failure=TelemetryCallbackFailure(
                    timestamp=time(),
                    callback=getattr(callback,"__qualname__",repr(callback)),
                    error=f"{type(exc).__name__}: {exc}",
                )
                with self._lock:
                    self._failures.append(failure)
                    if len(self._failures) > self._failure_limit:
                        del self._failures[:-self._failure_limit]
        return sample

    def start(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop.clear()
            self._thread=Thread(target=self._run,name="JOE-HostTelemetry",daemon=True)
            self._thread.start()

    def _run(self) -> None:
        while not self._stop.is_set():
            started=monotonic()
            try:
                self.sample_once()
            except Exception as exc:
                failure=TelemetryAcquisitionFailure(
                    timestamp=time(),
                    error=f"{type(exc).__name__}: {exc}",
                )
                with self._lock:
                    self._acquisition_failures.append(failure)
                    if len(self._acquisition_failures) > self._failure_limit:
                        del self._acquisition_failures[:-self._failure_limit]
            remaining=max(0.0,self.interval_seconds-(monotonic()-started))
            if self._stop.wait(remaining):
                break

    def stop(self, timeout: float=2.0) -> None:
        self._stop.set()
        with self._lock:
            thread=self._thread
        if thread:
            thread.join(timeout)


@dataclass(frozen=True)
class HostTelemetryQualification:
    passed: bool
    failures: tuple[str, ...]
    monitor_running: bool
    retained_samples: int
    callback_failures: int
    temperature_available: bool
    gpu_available: bool


def qualify_host_telemetry(telemetry: HostTelemetry,
                           monitor: HostTelemetryMonitor) -> HostTelemetryQualification:
    failures: list[str]=[]
    try:
        sample=monitor.sample_once()
    except Exception as exc:
        return HostTelemetryQualification(
            passed=False,
            failures=(f"Host telemetry sampling failed: {type(exc).__name__}: {exc}",),
            monitor_running=monitor.running,
            retained_samples=len(monitor.history()),
            callback_failures=len(monitor.callback_failures()),
            temperature_available=False,
            gpu_available=False,
        )

    if not 0.0 <= sample.cpu_percent <= 100.0:
        failures.append(f"CPU utilization out of range: {sample.cpu_percent}")
    if not 0.0 <= sample.memory_percent <= 100.0:
        failures.append(f"Memory utilization out of range: {sample.memory_percent}")
    if not 0.0 <= sample.disk_percent <= 100.0:
        failures.append(f"Storage utilization out of range: {sample.disk_percent}")
    if sample.memory_total_bytes <= 0:
        failures.append("Host memory total is not positive.")
    if not 0 <= sample.memory_available_bytes <= sample.memory_total_bytes:
        failures.append("Host memory available bytes are inconsistent.")
    if sample.process_rss_bytes <= 0:
        failures.append("JOE process RSS is not positive.")
    if sample.disk_total_bytes <= 0:
        failures.append("Storage total is not positive.")
    if not 0 <= sample.disk_free_bytes <= sample.disk_total_bytes:
        failures.append("Storage free bytes are inconsistent.")
    if sample.timestamp <= 0:
        failures.append("Host telemetry timestamp is invalid.")

    for reading in sample.temperatures:
        if not isinstance(reading.celsius,(int,float)):
            failures.append(f"Temperature reading {reading.sensor!r} is non-numeric.")

    for gpu in sample.gpus:
        if gpu.utilization_percent is not None and not 0.0 <= gpu.utilization_percent <= 100.0:
            failures.append(f"GPU {gpu.index} utilization out of range.")
        if gpu.memory_used_bytes is not None and gpu.memory_used_bytes < 0:
            failures.append(f"GPU {gpu.index} used VRAM is negative.")
        if gpu.memory_total_bytes is not None and gpu.memory_total_bytes <= 0:
            failures.append(f"GPU {gpu.index} total VRAM is not positive.")
        if (gpu.memory_used_bytes is not None and gpu.memory_total_bytes is not None
                and gpu.memory_used_bytes > gpu.memory_total_bytes):
            failures.append(f"GPU {gpu.index} used VRAM exceeds total VRAM.")

    monitor_status=monitor.status()
    if not monitor_status.running:
        failures.append("Continuous host telemetry monitor is not running.")
    elif not monitor_status.fresh:
        failures.append("Continuous host telemetry monitor has no fresh retained sample.")
    if monitor_status.acquisition_failures:
        failures.append(
            f"Continuous host telemetry monitor recorded {monitor_status.acquisition_failures} acquisition failure(s)."
        )

    return HostTelemetryQualification(
        passed=not failures,
        failures=tuple(failures),
        monitor_running=monitor.running,
        retained_samples=len(monitor.history()),
        callback_failures=len(monitor.callback_failures()),
        temperature_available=sample.temperature_available,
        gpu_available=sample.gpu_available,
    )


@dataclass(frozen=True)
class HostTelemetryReleaseReadiness:
    passed: bool
    failures: tuple[str, ...]
    qualification: HostTelemetryQualification
    sample_intervals: tuple[float, ...]
    maximum_interval_seconds: float | None
    acquisition_failures: int
    callback_failures: int


def joe007_release_readiness(telemetry: HostTelemetry,
                             monitor: HostTelemetryMonitor) -> HostTelemetryReleaseReadiness:
    failures: list[str]=[]
    qualification=qualify_host_telemetry(telemetry,monitor)
    failures.extend(qualification.failures)

    history=monitor.history()
    intervals=tuple(
        max(0.0, history[index].timestamp-history[index-1].timestamp)
        for index in range(1,len(history))
    )
    maximum=max(intervals) if intervals else None
    status=monitor.status()

    if not status.running:
        failures.append("JOE-007 continuous monitor is not running.")
    if not status.fresh:
        failures.append("JOE-007 latest host sample is not fresh.")
    if status.retained_samples < 1:
        failures.append("JOE-007 has no retained real host sample.")
    if status.acquisition_failures:
        failures.append(
            f"JOE-007 monitor has {status.acquisition_failures} retained acquisition failure(s)."
        )

    # Cadence is intentionally a research/UI monitoring cadence, not a
    # deterministic real-time guarantee. Only flag gross starvation.
    gross_limit=max(5.0*monitor.interval_seconds, monitor.interval_seconds+2.0)
    if maximum is not None and maximum > gross_limit:
        failures.append(
            f"JOE-007 sampling cadence was grossly delayed: maximum interval {maximum:.3f}s."
        )

    return HostTelemetryReleaseReadiness(
        passed=not failures,
        failures=tuple(failures),
        qualification=qualification,
        sample_intervals=intervals,
        maximum_interval_seconds=maximum,
        acquisition_failures=status.acquisition_failures,
        callback_failures=status.callback_failures,
    )
