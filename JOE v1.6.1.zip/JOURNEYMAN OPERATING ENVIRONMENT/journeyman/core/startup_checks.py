from dataclasses import dataclass
from pathlib import Path
import os
import sys
from .paths import ROOT, DATA_DIR, LOG_DIR, CONFIG_DIR

@dataclass(frozen=True)
class CheckResult:
    name: str
    ok: bool
    detail: str


def _writable(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".joe_write_test"
        probe.write_text("JOE", encoding="utf-8")
        probe.unlink(missing_ok=True)
        return True
    except OSError:
        return False


def run_startup_checks() -> list[CheckResult]:
    results = []
    results.append(CheckResult("Python", sys.version_info >= (3, 10), f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"))
    results.append(CheckResult("Project root", ROOT.exists(), str(ROOT)))
    for label, path in (("Configuration storage", CONFIG_DIR), ("Data storage", DATA_DIR), ("Log storage", LOG_DIR)):
        ok = _writable(path)
        results.append(CheckResult(label, ok, f"Writable: {path}" if ok else f"NOT WRITABLE: {path}"))
    results.append(CheckResult("Working directory", True, os.getcwd()))
    return results


def all_critical_ok(results: list[CheckResult]) -> bool:
    return all(item.ok for item in results)
