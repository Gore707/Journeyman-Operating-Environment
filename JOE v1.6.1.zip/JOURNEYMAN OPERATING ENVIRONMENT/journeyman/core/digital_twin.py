"""Digital Twin + deterministic Source Simulator foundation."""
from __future__ import annotations
from dataclasses import dataclass, replace
from enum import Enum
import math, uuid
from .state_events import DataOrigin

class TwinStatus(str,Enum):
    PASS="PASS"
    DOMAIN_INVALID="DOMAIN_INVALID"
    INPUT_INCONSISTENT="INPUT_INCONSISTENT"
    MODEL_UNAVAILABLE="MODEL_UNAVAILABLE"
    UNKNOWN_PHYSICS="UNKNOWN_PHYSICS"

class TwinLifecycle(str,Enum):
    CONFIGURED="CONFIGURED"
    READY="READY"
    RUNNING="RUNNING"
    PAUSED="PAUSED"
    STOPPED="STOPPED"

class TwinObjectType(str,Enum):
    MOUTH_A="MOUTH_A"
    MOUTH_B="MOUTH_B"
    CLOCK="CLOCK"
    SENSOR="SENSOR"
    SPACECRAFT="SPACECRAFT"
    TEST_ARTICLE="TEST_ARTICLE"
    REFERENCE="REFERENCE"

@dataclass(frozen=True)
class SimulationClock:
    simulation_time_s:float=0.0
    step_index:int=0
    step_size_s:float=0.01
    epoch_id:str="SIM-EPOCH-0"
    time_scale:str="SIMULATION_TIME"
    def __post_init__(self):
        if not math.isfinite(self.simulation_time_s) or self.simulation_time_s<0:raise ValueError("simulation time must be finite and nonnegative")
        if self.step_index<0 or not math.isfinite(self.step_size_s) or self.step_size_s<=0:raise ValueError("valid step index and positive finite step size required")
        if not self.epoch_id.strip() or not self.time_scale.strip():raise ValueError("epoch/time scale required")
    def advance(self,steps:int=1):
        if int(steps)!=steps or steps<1:raise ValueError("steps must be positive integer")
        return replace(self,simulation_time_s=self.simulation_time_s+self.step_size_s*steps,step_index=self.step_index+steps)

@dataclass(frozen=True)
class TwinObject:
    object_id:str
    name:str
    object_type:TwinObjectType
    frame_id:str
    epoch_id:str
    position_m:tuple[float,float,float]
    velocity_m_s:tuple[float,float,float]
    position_standard_uncertainty_m:float
    provenance:str
    config_revision:int=1
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if self.origin!=DataOrigin.SIMULATION:raise ValueError("DT-001A twin objects are SIMULATION only")
        if not all(str(x).strip() for x in (self.object_id,self.name,self.frame_id,self.epoch_id,self.provenance)):raise ValueError("identity/frame/epoch/provenance required")
        if len(self.position_m)!=3 or len(self.velocity_m_s)!=3 or any(not math.isfinite(float(x)) for x in self.position_m+self.velocity_m_s):
            raise ValueError("finite 3-vectors required")
        if not math.isfinite(self.position_standard_uncertainty_m) or self.position_standard_uncertainty_m<0:raise ValueError("nonnegative position uncertainty required")
        if self.config_revision<1:raise ValueError("config revision must be >=1")

def create_twin_object(name:str,object_type:TwinObjectType,frame_id:str,epoch_id:str,position_m=(0.,0.,0.),
                       velocity_m_s=(0.,0.,0.),position_standard_uncertainty_m:float=0.,provenance:str="JOE Digital Twin")->TwinObject:
    return TwinObject(str(uuid.uuid4()),name,object_type,frame_id,epoch_id,tuple(map(float,position_m)),tuple(map(float,velocity_m_s)),
                      float(position_standard_uncertainty_m),provenance)

@dataclass(frozen=True)
class TwinSnapshot:
    simulation_time_s:float
    step_index:int
    objects:tuple[TwinObject,...]
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if self.origin!=DataOrigin.SIMULATION:raise ValueError("twin snapshot must be SIMULATION")
        ids=[x.object_id for x in self.objects]
        if len(ids)!=len(set(ids)):raise ValueError("duplicate twin object identity")
        if not self.provenance.strip():raise ValueError("snapshot provenance required")

def propagate_linear_state(obj:TwinObject,dt_s:float)->TwinObject:
    dt=float(dt_s)
    if not math.isfinite(dt) or dt<0:raise ValueError("finite nonnegative dt required")
    p=tuple(obj.position_m[i]+obj.velocity_m_s[i]*dt for i in range(3))
    return replace(obj,position_m=p)

@dataclass(frozen=True)
class DeterministicSource:
    source_id:str
    variable:str
    unit:str
    baseline:float
    amplitude:float
    angular_frequency_rad_s:float
    phase_rad:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if self.origin!=DataOrigin.SIMULATION:raise ValueError("source simulator output must be SIMULATION")
        if not all(str(x).strip() for x in (self.source_id,self.variable,self.unit,self.provenance)):raise ValueError("source identity/variable/unit/provenance required")
        if any(not math.isfinite(float(x)) for x in (self.baseline,self.amplitude,self.angular_frequency_rad_s,self.phase_rad)):raise ValueError("source parameters must be finite")

@dataclass(frozen=True)
class SourceSample:
    source_id:str
    variable:str
    unit:str
    simulation_time_s:float
    value:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def sample_source(source:DeterministicSource,simulation_time_s:float)->SourceSample:
    t=float(simulation_time_s)
    if not math.isfinite(t) or t<0:raise ValueError("simulation time must be finite and nonnegative")
    v=source.baseline+source.amplitude*math.sin(source.angular_frequency_rad_s*t+source.phase_rad)
    return SourceSample(source.source_id,source.variable,source.unit,t,v,source.provenance)

@dataclass(frozen=True)
class TwinState:
    lifecycle:TwinLifecycle
    clock:SimulationClock
    objects:tuple[TwinObject,...]
    sources:tuple[DeterministicSource,...]
    revision:int
    provenance:str

class DigitalTwinEngine:
    def __init__(self,*,step_size_s:float=.01,provenance:str="JOE Digital Twin"):
        self._state=TwinState(TwinLifecycle.CONFIGURED,SimulationClock(step_size_s=step_size_s),(),(),1,provenance)
    @property
    def state(self):return self._state
    def add_object(self,obj:TwinObject):
        if any(x.object_id==obj.object_id for x in self._state.objects):raise ValueError("duplicate object identity")
        self._state=replace(self._state,objects=self._state.objects+(obj,),revision=self._state.revision+1);return obj
    def add_source(self,source:DeterministicSource):
        if any(x.source_id==source.source_id for x in self._state.sources):raise ValueError("duplicate source identity")
        self._state=replace(self._state,sources=self._state.sources+(source,),revision=self._state.revision+1);return source
    def ready(self):
        self._state=replace(self._state,lifecycle=TwinLifecycle.READY,revision=self._state.revision+1)
    def start(self):
        if self._state.lifecycle not in (TwinLifecycle.READY,TwinLifecycle.PAUSED):raise ValueError("twin must be READY or PAUSED to start")
        self._state=replace(self._state,lifecycle=TwinLifecycle.RUNNING,revision=self._state.revision+1)
    def pause(self):
        if self._state.lifecycle!=TwinLifecycle.RUNNING:raise ValueError("twin must be RUNNING to pause")
        self._state=replace(self._state,lifecycle=TwinLifecycle.PAUSED,revision=self._state.revision+1)
    def stop(self):
        self._state=replace(self._state,lifecycle=TwinLifecycle.STOPPED,revision=self._state.revision+1)
    def step(self,steps:int=1):
        if self._state.lifecycle!=TwinLifecycle.RUNNING:raise ValueError("twin must be RUNNING to step")
        dt=self._state.clock.step_size_s*steps
        clock=self._state.clock.advance(steps)
        objs=tuple(propagate_linear_state(x,dt) for x in self._state.objects)
        self._state=replace(self._state,clock=clock,objects=objs,revision=self._state.revision+1)
        samples=tuple(sample_source(x,clock.simulation_time_s) for x in self._state.sources)
        return self.snapshot(),samples
    def snapshot(self):
        return TwinSnapshot(self._state.clock.simulation_time_s,self._state.clock.step_index,self._state.objects,self._state.provenance)

@dataclass(frozen=True)
class DigitalTwinGuardianContract:
    schema:str
    status:str
    facts:dict
    provenance:str
    authority:str

def digital_twin_guardian_contract(state:TwinState)->DigitalTwinGuardianContract:
    facts={"lifecycle":state.lifecycle.value,"simulation_time_s":state.clock.simulation_time_s,"step_index":state.clock.step_index,
           "step_size_s":state.clock.step_size_s,"epoch_id":state.clock.epoch_id,"time_scale":state.clock.time_scale,
           "revision":state.revision,"origin":"SIMULATION",
           "objects":[{"object_id":x.object_id,"name":x.name,"type":x.object_type.value,"frame_id":x.frame_id,"epoch_id":x.epoch_id,
                       "position_m":x.position_m,"velocity_m_s":x.velocity_m_s,"uncertainty_m":x.position_standard_uncertainty_m,
                       "config_revision":x.config_revision,"provenance":x.provenance} for x in state.objects],
           "sources":[{"source_id":x.source_id,"variable":x.variable,"unit":x.unit,"provenance":x.provenance} for x in state.sources]}
    return DigitalTwinGuardianContract("JOE-GUARDIAN-DIGITAL-TWIN/1",TwinStatus.PASS.value,facts,state.provenance,
        "READ_ONLY_ADVISORY; simulation evidence must never be represented as HOST/HARDWARE telemetry and Guardian cannot bypass BUS-SAFE/control authority")


class SampleQuality(str,Enum):
    GOOD="GOOD"
    DEGRADED="DEGRADED"
    STALE="STALE"
    INVALID="INVALID"

@dataclass(frozen=True)
class TelemetryChannel:
    channel_id:str
    object_id:str
    variable:str
    unit:str
    standard_uncertainty:float
    freshness_limit_s:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if self.origin!=DataOrigin.SIMULATION:raise ValueError("DT-001B channels are SIMULATION only")
        if not all(str(x).strip() for x in (self.channel_id,self.object_id,self.variable,self.unit,self.provenance)):
            raise ValueError("channel/object/variable/unit/provenance required")
        if not math.isfinite(self.standard_uncertainty) or self.standard_uncertainty<0:raise ValueError("nonnegative uncertainty required")
        if not math.isfinite(self.freshness_limit_s) or self.freshness_limit_s<=0:raise ValueError("positive freshness limit required")

@dataclass(frozen=True)
class TelemetrySample:
    channel_id:str
    object_id:str
    variable:str
    unit:str
    simulation_time_s:float
    value:float
    standard_uncertainty:float
    sequence:int
    quality:SampleQuality
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if self.origin!=DataOrigin.SIMULATION:raise ValueError("simulated telemetry must remain SIMULATION")
        if self.sequence<0 or not math.isfinite(self.simulation_time_s) or self.simulation_time_s<0:raise ValueError("valid sequence/time required")
        if not math.isfinite(self.value) or not math.isfinite(self.standard_uncertainty) or self.standard_uncertainty<0:raise ValueError("finite value/uncertainty required")

def telemetry_from_source(channel:TelemetryChannel,source:DeterministicSource,simulation_time_s:float,sequence:int)->TelemetrySample:
    if channel.variable!=source.variable or channel.unit!=source.unit:raise ValueError("channel/source variable or unit mismatch")
    raw=sample_source(source,simulation_time_s)
    return TelemetrySample(channel.channel_id,channel.object_id,channel.variable,channel.unit,raw.simulation_time_s,
                           raw.value,channel.standard_uncertainty,int(sequence),SampleQuality.GOOD,
                           f"{channel.provenance}; source={source.source_id}")

@dataclass(frozen=True)
class FreshnessAssessment:
    quality:SampleQuality
    age_s:float
    limit_s:float
    message:str

def assess_sample_freshness(sample:TelemetrySample,current_simulation_time_s:float,channel:TelemetryChannel)->FreshnessAssessment:
    now=float(current_simulation_time_s)
    if sample.channel_id!=channel.channel_id:raise ValueError("sample/channel identity mismatch")
    age=now-sample.simulation_time_s
    if age<0:return FreshnessAssessment(SampleQuality.INVALID,age,channel.freshness_limit_s,"Sample timestamp is in the simulation future.")
    stale=age>channel.freshness_limit_s
    return FreshnessAssessment(SampleQuality.STALE if stale else sample.quality,age,channel.freshness_limit_s,
        "Sample is stale relative to the declared simulation freshness limit." if stale else "Sample is within the declared simulation freshness limit.")

@dataclass(frozen=True)
class ModelObservationResidual:
    status:TwinStatus
    observed_value:float
    predicted_value:float
    residual:float
    combined_standard_uncertainty:float
    normalized_residual_sigma:float
    anomaly:bool
    sigma_threshold:float
    message:str

def model_observation_residual(observed:TelemetrySample,predicted_value:float,predicted_standard_uncertainty:float,
                               *,sigma_threshold:float=5.0)->ModelObservationResidual:
    pv=float(predicted_value);pu=float(predicted_standard_uncertainty);th=float(sigma_threshold)
    if not math.isfinite(pv) or not math.isfinite(pu) or pu<0 or not math.isfinite(th) or th<=0:raise ValueError("valid prediction uncertainty/threshold required")
    r=observed.value-pv;u=math.hypot(observed.standard_uncertainty,pu)
    z=abs(r)/u if u else (0.0 if r==0 else math.inf)
    anomaly=z>th
    return ModelObservationResidual(TwinStatus.PASS,pv+r,pv,r,u,z,anomaly,th,
        "SIMULATION anomaly: observation/model residual exceeds declared sigma threshold." if anomaly else
        "SIMULATION observation/model residual is within declared sigma threshold.")

@dataclass(frozen=True)
class MouthPairMonitor:
    status:TwinStatus
    mouth_a_id:str
    mouth_b_id:str
    separation_m:float
    relative_speed_m_s:float
    frame_id:str
    epoch_id:str
    combined_position_standard_uncertainty_m:float
    message:str

def monitor_simulated_mouth_pair(a:TwinObject,b:TwinObject)->MouthPairMonitor:
    if {a.object_type,b.object_type}!={TwinObjectType.MOUTH_A,TwinObjectType.MOUTH_B}:raise ValueError("one Mouth A and one Mouth B required")
    if a.frame_id!=b.frame_id or a.epoch_id!=b.epoch_id:
        return MouthPairMonitor(TwinStatus.INPUT_INCONSISTENT,a.object_id,b.object_id,math.nan,math.nan,
            f"{a.frame_id} / {b.frame_id}",f"{a.epoch_id} / {b.epoch_id}",math.hypot(a.position_standard_uncertainty_m,b.position_standard_uncertainty_m),
            "SIMULATION mouth states cannot be directly compared across mismatched frame/epoch.")
    dp=tuple(b.position_m[i]-a.position_m[i] for i in range(3));dv=tuple(b.velocity_m_s[i]-a.velocity_m_s[i] for i in range(3))
    return MouthPairMonitor(TwinStatus.PASS,a.object_id,b.object_id,math.sqrt(sum(x*x for x in dp)),math.sqrt(sum(x*x for x in dv)),
        a.frame_id,a.epoch_id,math.hypot(a.position_standard_uncertainty_m,b.position_standard_uncertainty_m),
        "SIMULATION Mouth A/B kinematic monitor; not physical wormhole telemetry.")

@dataclass(frozen=True)
class TelemetryFrame:
    simulation_time_s:float
    sequence:int
    samples:tuple[TelemetrySample,...]
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if self.origin!=DataOrigin.SIMULATION:raise ValueError("telemetry frame must be SIMULATION")
        ids=[x.channel_id for x in self.samples]
        if len(ids)!=len(set(ids)):raise ValueError("duplicate channel in synchronized telemetry frame")
        if any(abs(x.simulation_time_s-self.simulation_time_s)>1e-12 for x in self.samples):raise ValueError("telemetry frame samples are not time-synchronized")

def synchronized_telemetry_frame(channels:tuple[TelemetryChannel,...],sources:tuple[DeterministicSource,...],
                                 simulation_time_s:float,sequence:int,*,provenance:str)->TelemetryFrame:
    source_by_var={(x.variable,x.unit):x for x in sources}
    samples=[]
    for ch in channels:
        src=source_by_var.get((ch.variable,ch.unit))
        if src is None:raise ValueError(f"no deterministic source for channel {ch.channel_id}")
        samples.append(telemetry_from_source(ch,src,simulation_time_s,sequence))
    return TelemetryFrame(float(simulation_time_s),int(sequence),tuple(samples),provenance)

def digital_twin_monitor_guardian_contract(state:TwinState,*,mouth_monitor:MouthPairMonitor|None=None,
                                            freshness:tuple[FreshnessAssessment,...]=(),
                                            residuals:tuple[ModelObservationResidual,...]=())->DigitalTwinGuardianContract:
    facts=digital_twin_guardian_contract(state).facts.copy()
    facts["freshness"]=[{"quality":x.quality.value,"age_s":x.age_s,"limit_s":x.limit_s,"message":x.message} for x in freshness]
    facts["residuals"]=[{"residual":x.residual,"combined_standard_uncertainty":x.combined_standard_uncertainty,
                         "normalized_residual_sigma":x.normalized_residual_sigma,"anomaly":x.anomaly,
                         "sigma_threshold":x.sigma_threshold,"message":x.message} for x in residuals]
    if mouth_monitor:
        facts["mouth_pair"]={"status":mouth_monitor.status.value,"mouth_a_id":mouth_monitor.mouth_a_id,"mouth_b_id":mouth_monitor.mouth_b_id,
                             "separation_m":mouth_monitor.separation_m,"relative_speed_m_s":mouth_monitor.relative_speed_m_s,
                             "frame_id":mouth_monitor.frame_id,"epoch_id":mouth_monitor.epoch_id,
                             "combined_position_standard_uncertainty_m":mouth_monitor.combined_position_standard_uncertainty_m,
                             "message":mouth_monitor.message}
    status=TwinStatus.INPUT_INCONSISTENT.value if mouth_monitor and mouth_monitor.status!=TwinStatus.PASS else TwinStatus.PASS.value
    if any(x.quality in (SampleQuality.STALE,SampleQuality.INVALID) for x in freshness):status=TwinStatus.INPUT_INCONSISTENT.value
    return DigitalTwinGuardianContract("JOE-GUARDIAN-DIGITAL-TWIN/1",status,facts,state.provenance,
        "READ_ONLY_ADVISORY; may flag SIMULATION stale data, model residuals and mouth-state inconsistencies but cannot represent them as physical alarms or bypass BUS-SAFE/control authority")


@dataclass(frozen=True)
class TwinMouthTemporalState:
    object_id:str
    role:str
    coordinate_time_s:float
    proper_time_s:float
    proper_time_standard_uncertainty_s:float
    simulation_time_s:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

@dataclass(frozen=True)
class TwinMouthPairTemporalState:
    mouth_a:TwinMouthTemporalState
    mouth_b:TwinMouthTemporalState
    proper_time_offset_s:float
    combined_standard_uncertainty_s:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def twin_to_d1_mouth_state(obj:TwinObject,*,role,coordinate_time_s:float,proper_time_s:float,
                           proper_time_standard_uncertainty_s:float=0.0,time_scale:str="SIMULATION_TIME"):
    from .mouth_dynamics import MouthState,MouthRole
    expected=TwinObjectType.MOUTH_A if role==MouthRole.A else TwinObjectType.MOUTH_B
    if obj.object_type!=expected:raise ValueError("twin object type does not match requested D-1 mouth role")
    return MouthState(obj.object_id,role,float(coordinate_time_s),float(proper_time_s),obj.position_m,obj.velocity_m_s,
        obj.frame_id,obj.epoch_id,time_scale,obj.position_standard_uncertainty_m,float(proper_time_standard_uncertainty_s),
        f"{obj.provenance}; Digital Twin→D-1 coupling",DataOrigin.SIMULATION)

def mouth_pair_temporal_state(a:TwinMouthTemporalState,b:TwinMouthTemporalState,*,provenance:str)->TwinMouthPairTemporalState:
    if a.role!="A" or b.role!="B":raise ValueError("temporal pair requires role A then B")
    off=a.proper_time_s-b.proper_time_s
    u=math.hypot(a.proper_time_standard_uncertainty_s,b.proper_time_standard_uncertainty_s)
    return TwinMouthPairTemporalState(a,b,off,u,provenance)

@dataclass(frozen=True)
class TwinChronologyCoupling:
    status:TwinStatus
    separation_m:float|None
    mouth_time_offset_s:float
    chronology_margin_s:float|None
    chronology_margin_standard_uncertainty_s:float|None
    modeled_closed_causal_loop_condition:bool|None
    message:str
    provenance:str

def couple_twin_to_chronology(a:TwinObject,b:TwinObject,temporal:TwinMouthPairTemporalState,
                              *,external_return_speed_m_s:float,speed_standard_uncertainty_m_s:float=0.0)->TwinChronologyCoupling:
    from .chronology import ChronologyLoopRequest,assess_round_trip_loop_condition
    mon=monitor_simulated_mouth_pair(a,b)
    if mon.status!=TwinStatus.PASS:
        return TwinChronologyCoupling(mon.status,None,temporal.proper_time_offset_s,None,None,None,mon.message,temporal.provenance)
    req=ChronologyLoopRequest(mon.separation_m,temporal.proper_time_offset_s,float(external_return_speed_m_s),
        temporal.combined_standard_uncertainty_s,mon.combined_position_standard_uncertainty_m,float(speed_standard_uncertainty_m_s),
        temporal.provenance,DataOrigin.SIMULATION)
    q=assess_round_trip_loop_condition(req)
    return TwinChronologyCoupling(TwinStatus.PASS,mon.separation_m,temporal.proper_time_offset_s,q.chronology_margin_s,
        q.chronology_margin_standard_uncertainty_s,q.modeled_closed_causal_loop_condition,
        "SIMULATION C-1 kinematic coupling only; a positive modeled margin is not evidence of a physical CTC/wormhole.",temporal.provenance)

@dataclass(frozen=True)
class TwinWorldlinePoint:
    object_id:str
    simulation_time_s:float
    coordinate_time_s:float
    proper_time_s:float
    position_m:tuple[float,float,float]
    velocity_m_s:tuple[float,float,float]
    frame_id:str
    epoch_id:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

class TwinWorldlineHistory:
    def __init__(self):self._points={}
    def append(self,point:TwinWorldlinePoint):
        seq=self._points.setdefault(point.object_id,[])
        if seq and point.simulation_time_s<=seq[-1].simulation_time_s:raise ValueError("worldline simulation time must increase strictly")
        if seq and (point.frame_id!=seq[-1].frame_id or point.epoch_id!=seq[-1].epoch_id):
            raise ValueError("worldline frame/epoch cannot change without an explicit transform")
        seq.append(point)
    def points(self,object_id:str):return tuple(self._points.get(object_id,()))
    def object_ids(self):return tuple(sorted(self._points))

@dataclass(frozen=True)
class TwinSynchronizationResidual:
    status:TwinStatus
    object_id:str
    position_residual_m:float
    velocity_residual_m_s:float
    normalized_position_sigma:float
    anomaly:bool
    sigma_threshold:float
    message:str

def synchronize_twin_object(predicted:TwinObject,observed:TwinObject,*,sigma_threshold:float=5.0)->TwinSynchronizationResidual:
    if predicted.object_id!=observed.object_id:raise ValueError("prediction/observation object identity mismatch")
    if predicted.frame_id!=observed.frame_id or predicted.epoch_id!=observed.epoch_id:
        return TwinSynchronizationResidual(TwinStatus.INPUT_INCONSISTENT,predicted.object_id,math.nan,math.nan,math.nan,False,
            sigma_threshold,"Twin/model synchronization requires common frame and epoch.")
    dp=math.sqrt(sum((observed.position_m[i]-predicted.position_m[i])**2 for i in range(3)))
    dv=math.sqrt(sum((observed.velocity_m_s[i]-predicted.velocity_m_s[i])**2 for i in range(3)))
    u=math.hypot(predicted.position_standard_uncertainty_m,observed.position_standard_uncertainty_m)
    z=dp/u if u else (0.0 if dp==0 else math.inf);anom=z>sigma_threshold
    return TwinSynchronizationResidual(TwinStatus.PASS,predicted.object_id,dp,dv,z,anom,sigma_threshold,
        "SIMULATION twin/model state residual exceeds declared position sigma threshold." if anom else
        "SIMULATION twin/model state residual is within declared position sigma threshold.")

def chronology_coupled_guardian_contract(state:TwinState,coupling:TwinChronologyCoupling,
                                         synchronizations:tuple[TwinSynchronizationResidual,...]=())->DigitalTwinGuardianContract:
    facts=digital_twin_guardian_contract(state).facts.copy()
    facts["chronology_coupling"]={"status":coupling.status.value,"separation_m":coupling.separation_m,
        "mouth_time_offset_s":coupling.mouth_time_offset_s,"chronology_margin_s":coupling.chronology_margin_s,
        "chronology_margin_standard_uncertainty_s":coupling.chronology_margin_standard_uncertainty_s,
        "modeled_closed_causal_loop_condition":coupling.modeled_closed_causal_loop_condition,"message":coupling.message}
    facts["synchronization"]=[{"object_id":x.object_id,"status":x.status.value,"position_residual_m":x.position_residual_m,
        "velocity_residual_m_s":x.velocity_residual_m_s,"normalized_position_sigma":x.normalized_position_sigma,
        "anomaly":x.anomaly,"message":x.message} for x in synchronizations]
    status=coupling.status.value
    if any(x.status!=TwinStatus.PASS for x in synchronizations):status=TwinStatus.INPUT_INCONSISTENT.value
    return DigitalTwinGuardianContract("JOE-GUARDIAN-DIGITAL-TWIN/1",status,facts,state.provenance,
        "READ_ONLY_ADVISORY; C-1/D-1 coupling is SIMULATION/model evidence only. Guardian may flag chronology margins or synchronization anomalies but cannot assert physical CTCs or bypass BUS-SAFE/control authority")


class SceneScale(str,Enum):
    FACILITY="FACILITY"
    PLANETARY="PLANETARY"
    SYSTEM="SYSTEM"
    INTERPLANETARY="INTERPLANETARY"
    STELLAR="STELLAR"
    GALACTIC="GALACTIC"

@dataclass(frozen=True)
class SceneReference:
    reference_id:str
    name:str
    frame_id:str
    epoch_id:str
    origin_m:tuple[float,float,float]
    scale:SceneScale
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if self.origin!=DataOrigin.SIMULATION:raise ValueError("DT scene reference is SIMULATION only")
        if not all(str(x).strip() for x in (self.reference_id,self.name,self.frame_id,self.epoch_id,self.provenance)):
            raise ValueError("scene reference identity/frame/epoch/provenance required")
        if len(self.origin_m)!=3 or any(not math.isfinite(float(x)) for x in self.origin_m):raise ValueError("finite scene origin required")

@dataclass(frozen=True)
class SceneObject:
    object_id:str
    name:str
    object_type:TwinObjectType
    position_m:tuple[float,float,float]
    velocity_m_s:tuple[float,float,float]
    uncertainty_radius_m:float
    frame_id:str
    epoch_id:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

@dataclass(frozen=True)
class SceneVector:
    vector_id:str
    from_object_id:str
    to_object_id:str
    vector_m:tuple[float,float,float]
    magnitude_m:float
    frame_id:str
    epoch_id:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

@dataclass(frozen=True)
class SceneTrajectory:
    object_id:str
    points_m:tuple[tuple[float,float,float],...]
    simulation_times_s:tuple[float,...]
    frame_id:str
    epoch_id:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

@dataclass(frozen=True)
class SpatialScene:
    scene_id:str
    reference:SceneReference
    objects:tuple[SceneObject,...]
    vectors:tuple[SceneVector,...]
    trajectories:tuple[SceneTrajectory,...]
    simulation_time_s:float
    revision:int
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def scene_object_from_twin(obj:TwinObject)->SceneObject:
    return SceneObject(obj.object_id,obj.name,obj.object_type,obj.position_m,obj.velocity_m_s,
        obj.position_standard_uncertainty_m,obj.frame_id,obj.epoch_id,obj.provenance)

def separation_vector_scene(a:TwinObject,b:TwinObject,*,vector_id:str="mouth-separation")->SceneVector:
    if a.frame_id!=b.frame_id or a.epoch_id!=b.epoch_id:raise ValueError("scene vector requires common frame and epoch")
    v=tuple(b.position_m[i]-a.position_m[i] for i in range(3))
    return SceneVector(vector_id,a.object_id,b.object_id,v,math.sqrt(sum(x*x for x in v)),a.frame_id,a.epoch_id,
                       f"{a.provenance}; {b.provenance}; SIMULATION separation vector")

def trajectory_from_history(history:TwinWorldlineHistory,object_id:str)->SceneTrajectory:
    pts=history.points(object_id)
    if not pts:raise ValueError("worldline history has no points for object")
    return SceneTrajectory(object_id,tuple(x.position_m for x in pts),tuple(x.simulation_time_s for x in pts),
        pts[0].frame_id,pts[0].epoch_id,f"{pts[0].provenance}; map-ready trajectory")

def build_spatial_scene(reference:SceneReference,objects:tuple[TwinObject,...],*,simulation_time_s:float,
                        histories:TwinWorldlineHistory|None=None,revision:int=1,provenance:str="JOE Digital Twin spatial scene")->SpatialScene:
    if not math.isfinite(simulation_time_s) or simulation_time_s<0:raise ValueError("valid simulation time required")
    incompatible=[x.object_id for x in objects if x.frame_id!=reference.frame_id or x.epoch_id!=reference.epoch_id]
    if incompatible:raise ValueError("all scene objects require reference frame/epoch transform before placement")
    sobjs=tuple(scene_object_from_twin(x) for x in objects)
    mouths_a=[x for x in objects if x.object_type==TwinObjectType.MOUTH_A]
    mouths_b=[x for x in objects if x.object_type==TwinObjectType.MOUTH_B]
    vectors=()
    if len(mouths_a)==1 and len(mouths_b)==1:vectors=(separation_vector_scene(mouths_a[0],mouths_b[0]),)
    traj=[]
    if histories:
        for x in objects:
            if histories.points(x.object_id):traj.append(trajectory_from_history(histories,x.object_id))
    return SpatialScene(str(uuid.uuid4()),reference,sobjs,vectors,tuple(traj),float(simulation_time_s),int(revision),provenance)

def relocate_twin_object(obj:TwinObject,position_m:tuple[float,float,float],*,frame_id:str|None=None,
                         epoch_id:str|None=None,provenance:str|None=None)->TwinObject:
    pos=tuple(map(float,position_m))
    if len(pos)!=3 or any(not math.isfinite(x) for x in pos):raise ValueError("finite 3D position required")
    return replace(obj,position_m=pos,frame_id=frame_id or obj.frame_id,epoch_id=epoch_id or obj.epoch_id,
        config_revision=obj.config_revision+1,provenance=provenance or obj.provenance)

@dataclass(frozen=True)
class SceneBounds:
    minimum_m:tuple[float,float,float]
    maximum_m:tuple[float,float,float]
    center_m:tuple[float,float,float]
    span_m:tuple[float,float,float]

def scene_bounds(scene:SpatialScene,*,include_uncertainty:bool=True)->SceneBounds:
    if not scene.objects:return SceneBounds((0,0,0),(0,0,0),(0,0,0),(0,0,0))
    mins=[];maxs=[]
    for axis in range(3):
        mins.append(min(x.position_m[axis]-(x.uncertainty_radius_m if include_uncertainty else 0) for x in scene.objects))
        maxs.append(max(x.position_m[axis]+(x.uncertainty_radius_m if include_uncertainty else 0) for x in scene.objects))
    center=tuple((mins[i]+maxs[i])/2 for i in range(3));span=tuple(maxs[i]-mins[i] for i in range(3))
    return SceneBounds(tuple(mins),tuple(maxs),center,span)

def spatial_scene_guardian_contract(state:TwinState,scene:SpatialScene)->DigitalTwinGuardianContract:
    facts=digital_twin_guardian_contract(state).facts.copy()
    facts["spatial_scene"]={"scene_id":scene.scene_id,"scale":scene.reference.scale.value,"frame_id":scene.reference.frame_id,
        "epoch_id":scene.reference.epoch_id,"simulation_time_s":scene.simulation_time_s,"revision":scene.revision,
        "object_count":len(scene.objects),"trajectory_count":len(scene.trajectories),
        "objects":[{"object_id":x.object_id,"name":x.name,"type":x.object_type.value,"position_m":x.position_m,
                    "velocity_m_s":x.velocity_m_s,"uncertainty_radius_m":x.uncertainty_radius_m} for x in scene.objects],
        "vectors":[{"vector_id":x.vector_id,"from":x.from_object_id,"to":x.to_object_id,
                    "vector_m":x.vector_m,"magnitude_m":x.magnitude_m} for x in scene.vectors]}
    return DigitalTwinGuardianContract("JOE-GUARDIAN-DIGITAL-TWIN/1",TwinStatus.PASS.value,facts,state.provenance,
        "READ_ONLY_ADVISORY; spatial scene is SIMULATION/map-ready state. Guardian may detect frame/epoch/spatial inconsistencies but cannot reinterpret simulated placement as physical hardware location")


@dataclass(frozen=True)
class DigitalTwinReleaseReadiness:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    notes:tuple[str,...]

def digital_twin_release_readiness()->DigitalTwinReleaseReadiness:
    checks=[];fail=[]
    try:
        e=DigitalTwinEngine(step_size_s=.1,provenance="DT readiness")
        a=create_twin_object("Mouth A",TwinObjectType.MOUTH_A,"SIM-FRAME","SIM-EPOCH",(0,0,0),provenance="DT readiness")
        b=create_twin_object("Mouth B",TwinObjectType.MOUTH_B,"SIM-FRAME","SIM-EPOCH",(3,4,0),provenance="DT readiness")
        e.add_object(a);e.add_object(b);e.ready();e.start();snap,_=e.step()
        if snap.step_index==1:checks.append("deterministic simulation clock/state stepping passed")
        if monitor_simulated_mouth_pair(*snap.objects).separation_m==5:checks.append("Mouth A/B spatial monitor passed")
        ref=SceneReference("r","readiness","SIM-FRAME","SIM-EPOCH",(0,0,0),SceneScale.FACILITY,"DT readiness")
        scene=build_spatial_scene(ref,snap.objects,simulation_time_s=snap.simulation_time_s)
        if len(scene.vectors)==1:checks.append("map-ready spatial scene passed")
        g=spatial_scene_guardian_contract(e.state,scene)
        if g.facts["spatial_scene"]["object_count"]==2:checks.append("Guardian spatial contract passed")
    except Exception as exc:fail.append(f"readiness exception: {type(exc).__name__}: {exc}")
    return DigitalTwinReleaseReadiness(not fail,tuple(checks),tuple(fail),(
        "DT readiness qualifies simulation software only; no physical mouth/wormhole/hardware source is asserted.",
        "Interactive higher-fidelity 3D rendering and source-stream visualization continue in subsequent Digital Twin patches."))


@dataclass(frozen=True)
class DigitalTwinMonitorFrame:
    simulation_time_s:float
    step_index:int
    mouth_monitor:MouthPairMonitor|None
    telemetry:TelemetryFrame|None
    residuals:tuple[ModelObservationResidual,...]
    stale_channels:tuple[str,...]
    anomaly_channels:tuple[str,...]
    chronology:TwinChronologyCoupling|None
    scene:SpatialScene|None
    guardian:DigitalTwinGuardianContract
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

class DigitalTwinSession:
    """Operational deterministic simulation session. Never binds physical actuators."""
    def __init__(self,engine:DigitalTwinEngine,*,provenance:str="JOE Digital Twin session"):
        self.engine=engine;self.provenance=provenance;self.channels=[];self.sources=[];self.history=TwinWorldlineHistory()
        self.latest_samples={}
    def bind_source(self,channel:TelemetryChannel,source:DeterministicSource):
        if channel.origin!=DataOrigin.SIMULATION or source.origin!=DataOrigin.SIMULATION:raise ValueError("session accepts SIMULATION sources only")
        if channel.variable!=source.variable or channel.unit!=source.unit:raise ValueError("channel/source mismatch")
        if any(x.channel_id==channel.channel_id for x in self.channels):raise ValueError("duplicate channel")
        self.channels.append(channel);self.sources.append(source)
    def record_worldlines(self,proper_times:dict[str,float]|None=None):
        proper_times=proper_times or {}
        t=self.engine.state.clock.simulation_time_s
        for obj in self.engine.state.objects:
            pts=self.history.points(obj.object_id)
            if pts and t<=pts[-1].simulation_time_s:continue
            tau=float(proper_times.get(obj.object_id,t))
            self.history.append(TwinWorldlinePoint(obj.object_id,t,t,tau,obj.position_m,obj.velocity_m_s,obj.frame_id,obj.epoch_id,
                                                   f"{obj.provenance}; session worldline"))
    def monitor(self,*,predictions:dict[str,tuple[float,float]]|None=None,
                mouth_temporal_pair:TwinMouthPairTemporalState|None=None,external_return_speed_m_s:float|None=None)->DigitalTwinMonitorFrame:
        state=self.engine.state;t=state.clock.simulation_time_s;seq=state.clock.step_index
        telemetry=None;residuals=[];stale=[];anoms=[]
        if self.channels:
            telemetry=synchronized_telemetry_frame(tuple(self.channels),tuple(self.sources),t,seq,provenance=self.provenance)
            for sample,ch in zip(telemetry.samples,self.channels):
                self.latest_samples[ch.channel_id]=sample
                f=assess_sample_freshness(sample,t,ch)
                if f.quality in (SampleQuality.STALE,SampleQuality.INVALID):stale.append(ch.channel_id)
                if predictions and ch.channel_id in predictions:
                    pred,u=predictions[ch.channel_id];r=model_observation_residual(sample,pred,u);residuals.append(r)
                    if r.anomaly:anoms.append(ch.channel_id)
        mouths_a=[x for x in state.objects if x.object_type==TwinObjectType.MOUTH_A]
        mouths_b=[x for x in state.objects if x.object_type==TwinObjectType.MOUTH_B]
        mm=monitor_simulated_mouth_pair(mouths_a[0],mouths_b[0]) if len(mouths_a)==1 and len(mouths_b)==1 else None
        chrono=None
        if mm and mouth_temporal_pair and external_return_speed_m_s is not None:
            chrono=couple_twin_to_chronology(mouths_a[0],mouths_b[0],mouth_temporal_pair,
                                             external_return_speed_m_s=external_return_speed_m_s)
        scene=None
        if state.objects:
            first=state.objects[0]
            if all(x.frame_id==first.frame_id and x.epoch_id==first.epoch_id for x in state.objects):
                ref=SceneReference("session-scene","Digital Twin Session",first.frame_id,first.epoch_id,(0,0,0),SceneScale.FACILITY,self.provenance)
                scene=build_spatial_scene(ref,state.objects,simulation_time_s=t,histories=self.history,revision=state.revision,provenance=self.provenance)
        fresh=tuple(assess_sample_freshness(x,t,ch) for x,ch in zip(telemetry.samples,self.channels)) if telemetry else ()
        guardian=digital_twin_monitor_guardian_contract(state,mouth_monitor=mm,freshness=fresh,residuals=tuple(residuals))
        if chrono:
            guardian=chronology_coupled_guardian_contract(state,chrono)
            facts=guardian.facts.copy()
            facts["telemetry_monitor"]={"stale_channels":tuple(stale),"anomaly_channels":tuple(anoms),"sample_count":len(telemetry.samples) if telemetry else 0}
            guardian=DigitalTwinGuardianContract(guardian.schema,guardian.status,facts,guardian.provenance,guardian.authority)
        return DigitalTwinMonitorFrame(t,seq,mm,telemetry,tuple(residuals),tuple(stale),tuple(anoms),chrono,scene,guardian,self.provenance)

def digital_twin_v1_release_readiness()->DigitalTwinReleaseReadiness:
    base=digital_twin_release_readiness();checks=list(base.checks);fail=list(base.failures)
    try:
        e=DigitalTwinEngine(step_size_s=.1,provenance="DT-v1 readiness")
        a=create_twin_object("Mouth A",TwinObjectType.MOUTH_A,"SIM-FRAME","SIM-EPOCH",(0,0,0),provenance="DT-v1 readiness")
        b=create_twin_object("Mouth B",TwinObjectType.MOUTH_B,"SIM-FRAME","SIM-EPOCH",(100,0,0),provenance="DT-v1 readiness")
        e.add_object(a);e.add_object(b);e.ready();session=DigitalTwinSession(e,provenance="DT-v1 readiness")
        ch=TelemetryChannel("mouth-offset",a.object_id,"mouth_time_offset","s",.001,1,"DT-v1 readiness")
        src=DeterministicSource("offset-source","mouth_time_offset","s",1,0,0,0,"DT-v1 readiness");session.bind_source(ch,src)
        e.start();e.step();session.record_worldlines()
        ta=TwinMouthTemporalState(a.object_id,"A",.1,1,.001,.1,"DT-v1 readiness")
        tb=TwinMouthTemporalState(b.object_id,"B",.1,0,.001,.1,"DT-v1 readiness")
        pair=mouth_pair_temporal_state(ta,tb,provenance="DT-v1 readiness")
        frame=session.monitor(predictions={"mouth-offset":(1,.001)},mouth_temporal_pair=pair,external_return_speed_m_s=1000)
        if frame.telemetry and frame.telemetry.samples[0].origin==DataOrigin.SIMULATION:checks.append("synchronized SIMULATION telemetry session passed")
        if frame.scene and len(frame.scene.trajectories)==2:checks.append("worldline/scene trajectory integration passed")
        if frame.chronology is not None:checks.append("C-1 chronology coupling passed")
        if not frame.anomaly_channels:checks.append("uncertainty-normalized residual monitoring passed")
        if frame.guardian.schema=="JOE-GUARDIAN-DIGITAL-TWIN/1":checks.append("integrated Guardian evidence contract passed")
    except Exception as exc:fail.append(f"v1 readiness exception: {type(exc).__name__}: {exc}")
    return DigitalTwinReleaseReadiness(not fail,tuple(checks),tuple(fail),(
        "Digital Twin v1.0 qualifies deterministic simulation/source software only.",
        "No physical wormhole, mouth, CTC, exotic stress-energy source or hardware telemetry is asserted.",
        "Future physical sources must enter through authenticated hardware/telemetry contracts and remain distinguishable from SIMULATION."))
