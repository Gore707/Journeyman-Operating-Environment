JOURNEYMAN OPERATING ENVIRONMENT — JOE-002H
Version 0.2.0-alpha.8

DROP-IN PATCH TARGET
This build continues JOE-002 Window & Workspace System.

JOE-002H adds real runtime display discovery, moving the active workspace to a selected connected display, automatic detachment when an internal MDI workspace must cross monitor boundaries, and centering/recovery of the active workspace. Existing workspace identity, layout persistence, named layouts, Workspace Manager, logging, telemetry, settings, and launcher behavior are preserved.

No scientific module placeholders or fabricated telemetry are included.
