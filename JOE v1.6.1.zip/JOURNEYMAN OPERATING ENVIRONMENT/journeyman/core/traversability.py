"""T-1 human traversability analysis for static Morris-Thorne candidate geometries.

All outputs are MODEL/SIMULATION calculations. They are engineering constraints on a
declared geometry, not evidence that a traversable wormhole exists.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np
from .geometry import MetricModel, curvature
from .state_events import DataOrigin

C=299_792_458.0
G0=9.80665

@dataclass(frozen=True)
class HumanTolerance:
    body_length_m:float=2.0
    max_proper_acceleration_m_s2:float=G0
    max_tidal_acceleration_m_s2:float=G0
    def __post_init__(self):
        for x in (self.body_length_m,self.max_proper_acceleration_m_s2,self.max_tidal_acceleration_m_s2):
            if not math.isfinite(float(x)) or x<=0:raise ValueError("human tolerances must be positive finite values")

@dataclass(frozen=True)
class TraversabilityPoint:
    model_id:str
    model_revision:str
    radius_m:float
    speed_m_s:float
    lorentz_factor:float
    proper_acceleration_m_s2:float
    radial_tidal_acceleration_m_s2:float
    lateral_tidal_acceleration_m_s2:float
    acceleration_pass:bool
    radial_tidal_pass:bool
    lateral_tidal_pass:bool
    overall_pass:bool
    numerical_method:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

@dataclass(frozen=True)
class TransitEstimate:
    proper_distance_m:float
    coordinate_speed_m_s:float
    traveler_time_s:float
    static_frame_time_s:float
    lorentz_factor:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def lorentz_factor(speed_m_s:float)->float:
    v=float(speed_m_s)
    if not math.isfinite(v) or v<0 or v>=C:raise ValueError("speed must satisfy 0 <= v < c")
    return 1.0/math.sqrt(1.0-(v/C)**2)

def _metric_derivative_rr(model:MetricModel,q,relative_step):
    q=list(map(float,q));r=q[1];h=max(abs(r)*relative_step,1e-7)
    qm=q.copy();qp=q.copy();qm[1]-=h;qp[1]+=h
    try:gm=model.evaluate(qm).matrix();gp=model.evaluate(qp).matrix()
    except ValueError:
        # One-sided derivative close to a chart boundary.
        g0=model.evaluate(q).matrix();q2=q.copy();q2[1]+=h
        return (model.evaluate(q2).matrix()-g0)/h
    return (gp-gm)/(2*h)

def static_proper_acceleration(model:MetricModel,coordinates,relative_step=2e-5)->float:
    """Proper acceleration required to remain static at q, in m/s².

    For diagonal static coordinates with x0=ct:
      a = c² |∂r ln sqrt(-g00)| / sqrt(g_rr).
    """
    m=model.evaluate(coordinates);g=m.matrix()
    if g[0,0]>=0 or g[1,1]<=0:raise ValueError("expected static diagonal Lorentzian metric")
    dg=_metric_derivative_rr(model,coordinates,relative_step)
    dphi=0.5*dg[0,0]/g[0,0]
    return abs(C*C*dphi/math.sqrt(g[1,1]))

def _orthonormal_riemann_components(model:MetricModel,coordinates,relative_step):
    """Return R_hat{0 i 0 i} for diagonal static metric at a point."""
    cur=curvature(model,coordinates,relative_step=relative_step)
    g=model.evaluate(coordinates).matrix()
    if np.max(np.abs(g-np.diag(np.diag(g))))>1e-10:raise ValueError("T-1 v0.1 orthonormal projection requires diagonal metric")
    Rmix=np.asarray(cur.riemann,dtype=float) # R^rho_sigma_mu_nu
    Rcov=np.einsum("ar,rsuv->asuv",g,Rmix)
    scale=[1/math.sqrt(abs(g[i,i])) for i in range(4)]
    vals=[]
    for i in (1,2,3):
        vals.append(float(Rcov[0,i,0,i]*scale[0]*scale[i]*scale[0]*scale[i]))
    return tuple(vals)

def evaluate_human_traversability(model:MetricModel,coordinates,*,speed_m_s:float,
                                  tolerance:HumanTolerance=HumanTolerance(),relative_step:float=2e-5)->TraversabilityPoint:
    q=tuple(float(x) for x in coordinates);r=q[1];gamma=lorentz_factor(speed_m_s)
    proper=static_proper_acceleration(model,q,relative_step)
    rr,rt,rp=_orthonormal_riemann_components(model,q,relative_step)
    # Geodesic-deviation scale: Δa ≈ c² |R_hat{0i0i}| ξ.
    radial=C*C*abs(rr)*tolerance.body_length_m
    lateral=C*C*max(abs(rt),abs(rp))*tolerance.body_length_m
    ap=proper<=tolerance.max_proper_acceleration_m_s2
    rp_ok=radial<=tolerance.max_tidal_acceleration_m_s2
    lp_ok=lateral<=tolerance.max_tidal_acceleration_m_s2
    return TraversabilityPoint(model.model_id,model.model_revision,r,float(speed_m_s),gamma,proper,radial,lateral,
        ap,rp_ok,lp_ok,ap and rp_ok and lp_ok,
        f"finite-difference curvature; relative_step={relative_step:g}; static orthonormal frame",
        "T-1 model calculation using local static-frame acceleration and geodesic-deviation tidal scale.")

def proper_radial_distance(model:MetricModel,r_start_m:float,r_end_m:float,*,samples:int=2001,theta_rad:float=math.pi/2)->float:
    if samples<3 or samples%2==0:raise ValueError("samples must be odd and >= 3")
    a,b=map(float,(r_start_m,r_end_m))
    if not math.isfinite(a) or not math.isfinite(b) or a==b:raise ValueError("finite distinct radial bounds required")
    rs=np.linspace(min(a,b),max(a,b),samples)
    vals=[]
    for r in rs:
        g=model.evaluate((0.0,float(r),theta_rad,0.0)).matrix()
        vals.append(math.sqrt(g[1,1]))
    # Simpson rule
    h=(rs[-1]-rs[0])/(samples-1)
    integ=h/3*(vals[0]+vals[-1]+4*sum(vals[1:-1:2])+2*sum(vals[2:-2:2]))
    return float(integ)

def estimate_constant_speed_transit(proper_distance_m:float,speed_m_s:float)->TransitEstimate:
    d=float(proper_distance_m)
    if not math.isfinite(d) or d<0:raise ValueError("proper distance must be finite and nonnegative")
    gamma=lorentz_factor(speed_m_s)
    if speed_m_s==0:
        if d==0:return TransitEstimate(0,0,0,0,1,"zero-distance transit")
        raise ValueError("nonzero distance requires nonzero speed")
    static=d/speed_m_s
    return TransitEstimate(d,float(speed_m_s),static/gamma,static,gamma,
        "constant local speed estimate; acceleration/deceleration phases excluded")

@dataclass(frozen=True)
class TraversabilityGuardianContract:
    schema:str
    model_id:str
    model_revision:str
    origin:str
    criteria:tuple[str,...]
    result:dict
    authority:str

def traversability_guardian_contract(point:TraversabilityPoint):
    return TraversabilityGuardianContract("JOE-GUARDIAN-TRAVERSABILITY/1",point.model_id,point.model_revision,
        point.origin.value,("PROPER_ACCELERATION","RADIAL_TIDAL_ACCELERATION","LATERAL_TIDAL_ACCELERATION"),
        {"overall_pass":point.overall_pass,"proper_acceleration_m_s2":point.proper_acceleration_m_s2,
         "radial_tidal_acceleration_m_s2":point.radial_tidal_acceleration_m_s2,
         "lateral_tidal_acceleration_m_s2":point.lateral_tidal_acceleration_m_s2,
         "numerical_method":point.numerical_method,"provenance":point.provenance},
        "READ_ONLY_ADVISORY; T-1 PASS is a model constraint result, not permission to operate hardware")


@dataclass(frozen=True)
class TraversabilityMargin:
    acceleration_margin_m_s2:float
    radial_tidal_margin_m_s2:float
    lateral_tidal_margin_m_s2:float
    minimum_normalized_margin:float

def traversability_margin(point:TraversabilityPoint,tolerance:HumanTolerance)->TraversabilityMargin:
    vals=(tolerance.max_proper_acceleration_m_s2-point.proper_acceleration_m_s2,
          tolerance.max_tidal_acceleration_m_s2-point.radial_tidal_acceleration_m_s2,
          tolerance.max_tidal_acceleration_m_s2-point.lateral_tidal_acceleration_m_s2)
    norms=(vals[0]/tolerance.max_proper_acceleration_m_s2,
           vals[1]/tolerance.max_tidal_acceleration_m_s2,
           vals[2]/tolerance.max_tidal_acceleration_m_s2)
    return TraversabilityMargin(*vals,min(norms))

@dataclass(frozen=True)
class TraversabilityProfile:
    points:tuple[TraversabilityPoint,...]
    worst_index:int
    worst_radius_m:float
    worst_normalized_margin:float
    overall_pass:bool
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def radial_traversability_profile(model:MetricModel,radii_m,*,speed_m_s:float,
                                  tolerance:HumanTolerance=HumanTolerance(),relative_step:float=2e-5,
                                  theta_rad:float=math.pi/2,phi_rad:float=math.pi)->TraversabilityProfile:
    radii=tuple(float(x) for x in radii_m)
    if not radii or any(not math.isfinite(x) for x in radii):raise ValueError("finite nonempty radii required")
    pts=tuple(evaluate_human_traversability(model,(0.0,r,theta_rad,phi_rad),speed_m_s=speed_m_s,
              tolerance=tolerance,relative_step=relative_step) for r in radii)
    margins=tuple(traversability_margin(x,tolerance).minimum_normalized_margin for x in pts)
    idx=min(range(len(pts)),key=lambda i:margins[i])
    return TraversabilityProfile(pts,idx,pts[idx].radius_m,margins[idx],all(x.overall_pass for x in pts),
        "radial T-1 profile; worst point selected by minimum normalized tolerance margin")

def throat_approach_radii(throat_radius_m:float,outer_ratio:float=10.0,closest_fraction:float=1e-3,samples:int=25):
    r0=float(throat_radius_m);outer=float(outer_ratio);eps=float(closest_fraction)
    if not math.isfinite(r0) or r0<=0 or not math.isfinite(outer) or outer<=1 or not math.isfinite(eps) or eps<=0:
        raise ValueError("valid positive throat radius, outer_ratio>1 and closest_fraction>0 required")
    if samples<2:raise ValueError("samples must be >=2")
    # Log spacing in fractional distance above the curvature-chart throat.
    fractions=np.geomspace(eps,outer-1.0,samples)
    return tuple(float(r0*(1+x)) for x in fractions)

@dataclass(frozen=True)
class MotionSegment:
    duration_s:float
    initial_speed_m_s:float
    final_speed_m_s:float
    proper_acceleration_m_s2:float
    distance_m:float

@dataclass(frozen=True)
class TransitMotionProfile:
    segments:tuple[MotionSegment,...]
    total_distance_m:float
    total_static_time_s:float
    peak_speed_m_s:float
    peak_proper_acceleration_m_s2:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def symmetric_accel_cruise_profile(distance_m:float,proper_acceleration_m_s2:float,max_speed_m_s:float)->TransitMotionProfile:
    """1-D SR accelerate/cruise/decelerate estimate using constant proper acceleration.

    Acceleration and deceleration are symmetric. If distance is too short to reach max_speed,
    a triangular profile is returned with no cruise segment.
    """
    d=float(distance_m);a=float(proper_acceleration_m_s2);vmax=float(max_speed_m_s)
    if not math.isfinite(d) or d<0 or not math.isfinite(a) or a<=0:raise ValueError("distance>=0 and acceleration>0 required")
    lorentz_factor(vmax)
    if d==0:return TransitMotionProfile((),0,0,0,0,"zero-distance SR motion profile")
    gamma_max=lorentz_factor(vmax)
    x_acc=C*C/a*(gamma_max-1.0)
    if 2*x_acc<=d:
        t_acc=(gamma_max*vmax)/a
        cruise_d=d-2*x_acc;cruise_t=cruise_d/vmax
        seg=(MotionSegment(t_acc,0,vmax,a,x_acc),MotionSegment(cruise_t,vmax,vmax,0,cruise_d),
             MotionSegment(t_acc,vmax,0,a,x_acc))
        peak=vmax
    else:
        gamma_peak=1+a*d/(2*C*C)
        peak=C*math.sqrt(1-1/(gamma_peak*gamma_peak))
        t_acc=gamma_peak*peak/a
        seg=(MotionSegment(t_acc,0,peak,a,d/2),MotionSegment(t_acc,peak,0,a,d/2))
    return TransitMotionProfile(seg,d,sum(x.duration_s for x in seg),peak,a,
        "1-D special-relativistic symmetric constant-proper-acceleration/cruise estimate")

@dataclass(frozen=True)
class UncertainMargin:
    nominal:float
    standard_uncertainty:float
    conservative_margin:float
    sigma_multiplier:float
    provenance:str

def propagate_scalar_margin_uncertainty(evaluator,nominal_input:float,input_standard_uncertainty:float,
                                        *,limit:float,sigma_multiplier:float=3.0,relative_step:float=1e-5)->UncertainMargin:
    x=float(nominal_input);u=float(input_standard_uncertainty);limit=float(limit);k=float(sigma_multiplier)
    if not all(math.isfinite(v) for v in (x,u,limit,k)) or u<0 or k<0:raise ValueError("finite values and nonnegative uncertainty/sigma required")
    h=max(abs(x)*relative_step,1e-9)
    y=float(evaluator(x));yp=float(evaluator(x+h));ym=float(evaluator(x-h))
    derivative=(yp-ym)/(2*h);uy=abs(derivative)*u
    nominal=limit-y
    return UncertainMargin(nominal,uy,nominal-k*uy,k,
        "first-order centered finite-difference uncertainty propagation; conservative margin = nominal - k sigma")


@dataclass(frozen=True)
class TraversabilityConvergence:
    relative_steps:tuple[float,...]
    radial_tidal_m_s2:tuple[float,...]
    lateral_tidal_m_s2:tuple[float,...]
    terminal_relative_change:float
    converged:bool

def traversability_convergence(model:MetricModel,coordinates,*,speed_m_s:float,tolerance:HumanTolerance=HumanTolerance(),
                                relative_steps=(8e-5,4e-5,2e-5),relative_tolerance=0.08):
    steps=tuple(float(x) for x in relative_steps)
    if len(steps)<3 or any(x<=0 or not math.isfinite(x) for x in steps):raise ValueError("at least three positive finite steps required")
    pts=tuple(evaluate_human_traversability(model,coordinates,speed_m_s=speed_m_s,tolerance=tolerance,relative_step=h) for h in steps)
    rad=tuple(x.radial_tidal_acceleration_m_s2 for x in pts);lat=tuple(x.lateral_tidal_acceleration_m_s2 for x in pts)
    def rel(a,b):return abs(a-b)/max(abs(a),abs(b),1e-30)
    change=max(rel(rad[-1],rad[-2]),rel(lat[-1],lat[-2]))
    return TraversabilityConvergence(steps,rad,lat,change,change<=relative_tolerance)

@dataclass(frozen=True)
class TraversabilityReleaseReadiness:
    passed:bool;checks:tuple[str,...];failures:tuple[str,...];notes:tuple[str,...]

def traversability_release_readiness():
    from .geometry import minkowski_metric,morris_thorne_metric
    checks=[];fail=[];notes=[]
    try:
        tol=HumanTolerance()
        p=evaluate_human_traversability(minkowski_metric(),(0,2,math.pi/2,math.pi),speed_m_s=100,tolerance=tol)
        if p.overall_pass and max(p.proper_acceleration_m_s2,p.radial_tidal_acceleration_m_s2,p.lateral_tidal_acceleration_m_s2)<1e-5:
            checks.append("Minkowski zero-acceleration/zero-tidal reference passed")
        else:fail.append("Minkowski reference failed")
        m=morris_thorne_metric(throat_radius=1000)
        q=evaluate_human_traversability(m,(0,2000,math.pi/2,math.pi),speed_m_s=100,tolerance=tol,relative_step=4e-5)
        if abs(q.proper_acceleration_m_s2)<1e-5:checks.append("zero-redshift Morris-Thorne static acceleration reference passed")
        else:fail.append("Morris-Thorne zero-redshift acceleration reference failed")
        c=traversability_convergence(m,(0,2000,math.pi/2,math.pi),speed_m_s=100,tolerance=tol)
        if c.converged:checks.append("finite-difference tidal convergence passed")
        else:fail.append(f"finite-difference convergence failed: {c.terminal_relative_change:g}")
        rs=throat_approach_radii(1000,2,.05,4);prof=radial_traversability_profile(m,rs,speed_m_s=100,tolerance=tol,relative_step=2e-5)
        if len(prof.points)==4 and prof.worst_radius_m>1000:checks.append("throat-approach profile/worst-point extraction passed")
        else:fail.append("throat profile qualification failed")
        motion=symmetric_accel_cruise_profile(1000,tol.max_proper_acceleration_m_s2,100)
        if abs(sum(x.distance_m for x in motion.segments)-1000)<1e-7:checks.append("accel/cruise/decel distance closure passed")
        else:fail.append("motion-profile distance closure failed")
        gc=traversability_guardian_contract(q)
        if gc.schema=="JOE-GUARDIAN-TRAVERSABILITY/1" and gc.origin=="SIMULATION" and "not permission" in gc.authority:
            checks.append("Guardian provenance/authority contract passed")
        else:fail.append("Guardian T-1 contract failed")
    except Exception as exc:fail.append(f"release-readiness exception: {type(exc).__name__}: {exc}")
    notes.append("T-1 PASS is a model tolerance result, not evidence of a physical wormhole.")
    notes.append("Release qualification uses synthetic/model geometries only.")
    return TraversabilityReleaseReadiness(not fail,tuple(checks),tuple(fail),tuple(notes))
