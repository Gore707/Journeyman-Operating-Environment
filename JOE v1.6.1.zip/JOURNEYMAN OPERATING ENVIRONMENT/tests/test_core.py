import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from journeyman.core.settings import Settings
from journeyman.core.system_info import snapshot, static_system_info

class CoreTests(unittest.TestCase):
    def test_system_snapshot_ranges(self):
        s = snapshot()
        self.assertGreaterEqual(s.cpu_percent, 0)
        self.assertLessEqual(s.cpu_percent, 100)
        self.assertGreater(s.ram_total_gb, 0)
        self.assertGreaterEqual(s.process_ram_mb, 0)
        self.assertGreaterEqual(s.threads, 1)

    def test_static_system_info(self):
        info = static_system_info()
        self.assertIn("Python", info)
        self.assertIn("Operating system", info)
        self.assertIn("Logical CPUs", info)

    def test_settings_geometry_round_trip(self):
        s = Settings()
        payload = b"geometry-test-bytes"
        s.set_geometry(payload)
        self.assertEqual(s.geometry_bytes(), payload)

    def test_invalid_geometry_is_safe(self):
        s = Settings(window_geometry="not base64 !")
        self.assertEqual(s.geometry_bytes(), b"")


class StartupCheckTests(unittest.TestCase):
    def test_startup_checks_return_named_results(self):
        from journeyman.core.startup_checks import run_startup_checks
        results = run_startup_checks()
        self.assertGreaterEqual(len(results), 5)
        self.assertTrue(all(r.name for r in results))
        self.assertTrue(any(r.name == "Python" for r in results))


class RuntimeTests(unittest.TestCase):
    def test_runtime_identity(self):
        from journeyman.core.runtime import identity, format_uptime
        r = identity()
        self.assertGreater(r.pid, 0)
        self.assertTrue(r.build.startswith("JOE-"))
        self.assertTrue(r.executable)
        self.assertEqual(format_uptime(65), "01:05")
        self.assertEqual(format_uptime(3661), "1:01:01")


class WorkspaceLayoutTests(unittest.TestCase):
    def test_workspace_layout_round_trip(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry, load_layout, save_layout
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "layout.json"
            expected = [
                WorkspaceLayoutEntry("overview", "JOE Overview", False, "abc", True, "11111111-1111-4111-8111-111111111111"),
                WorkspaceLayoutEntry("log", "JOE Application Log", True, "def", False, "22222222-2222-4222-8222-222222222222"),
            ]
            save_layout(expected, path)
            self.assertEqual(load_layout(path), expected)

    def test_workspace_layout_reads_schema1(self):
        from journeyman.core.workspace_layout import load_layout
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "layout.json"
            path.write_text(json.dumps({"schema": 1, "workspaces": [
                {"kind": "overview", "title": "Legacy", "external": False, "geometry_b64": "abc"}
            ]}), encoding="utf-8")
            rows = load_layout(path)
            self.assertEqual(len(rows), 1)
            self.assertFalse(rows[0].maximized)


    def test_workspace_layout_schema6_preserves_identity(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry, load_layout, save_layout
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "layout.json"
            expected_id = "12345678-1234-5678-1234-567812345678"
            save_layout([WorkspaceLayoutEntry("overview", "Overview", False, "abc", False, expected_id)], path)
            rows = load_layout(path)
            self.assertEqual(rows[0].workspace_id, expected_id)
            raw = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(raw["schema"], 6)

    def test_legacy_layout_receives_workspace_identity(self):
        from uuid import UUID
        from journeyman.core.workspace_layout import load_layout
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "layout.json"
            path.write_text(json.dumps({"schema": 2, "workspaces": [
                {"kind": "log", "title": "Legacy", "external": True, "geometry_b64": "abc", "maximized": True}
            ]}), encoding="utf-8")
            rows = load_layout(path)
            self.assertEqual(len(rows), 1)
            UUID(rows[0].workspace_id)

    def test_named_workspace_layout_round_trip(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry, save_named_layout, load_named_layout, list_named_layouts, delete_named_layout
        with tempfile.TemporaryDirectory() as td:
            directory = Path(td)
            expected = [WorkspaceLayoutEntry("overview", "Lab Layout", False, "abc", False, "12345678-1234-5678-1234-567812345678")]
            save_named_layout("Analysis Desk", expected, directory)
            self.assertEqual(list_named_layouts(directory), ["Analysis Desk"])
            self.assertEqual(load_named_layout("Analysis Desk", directory), expected)
            self.assertTrue(delete_named_layout("Analysis Desk", directory))
            self.assertEqual(list_named_layouts(directory), [])

    def test_named_workspace_layout_rejects_unsafe_names(self):
        from journeyman.core.workspace_layout import named_layout_path
        with tempfile.TemporaryDirectory() as td:
            for bad in ("", "../escape", "bad:name", "a" * 81):
                with self.assertRaises(ValueError):
                    named_layout_path(bad, Path(td))

    def test_workspace_layout_rejects_unknown_types(self):
        from journeyman.core.workspace_layout import load_layout
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "layout.json"
            path.write_text(json.dumps({"schema": 1, "workspaces": [
                {"kind": "future_fake_module", "title": "No", "external": False, "geometry_b64": ""}
            ]}), encoding="utf-8")
            self.assertEqual(load_layout(path), [])


class WorkspacePolicyTests(unittest.TestCase):
    def test_cycle_index_forward_and_backward(self):
        from journeyman.core.workspace_policy import cycle_index
        self.assertEqual(cycle_index(3, 0, 1), 1)
        self.assertEqual(cycle_index(3, 2, 1), 0)
        self.assertEqual(cycle_index(3, 0, -1), 2)
        self.assertEqual(cycle_index(3, 2, -1), 1)

    def test_cycle_index_empty_and_no_current(self):
        from journeyman.core.workspace_policy import cycle_index
        self.assertIsNone(cycle_index(0, -1, 1))
        self.assertEqual(cycle_index(2, -1, 1), 0)
        self.assertEqual(cycle_index(2, -1, -1), 1)

    def test_workspace_title_validation(self):
        from journeyman.core.workspace_policy import validate_workspace_title
        self.assertEqual(validate_workspace_title("  Physics Desk  "), "Physics Desk")
        for bad in ("", "   ", "bad\ntitle", "x" * 81):
            with self.assertRaises(ValueError):
                validate_workspace_title(bad)

    def test_display_index_validation(self):
        from journeyman.core.workspace_policy import normalize_display_index
        self.assertEqual(normalize_display_index(3, 0), 0)
        self.assertEqual(normalize_display_index(3, 2), 2)
        for count, requested in ((0, 0), (2, -1), (2, 2)):
            with self.assertRaises(ValueError):
                normalize_display_index(count, requested)

    def test_workspace_lock_policy(self):
        from journeyman.core.workspace_policy import can_modify_workspace
        self.assertTrue(can_modify_workspace(False))
        self.assertFalse(can_modify_workspace(True))

    def test_workspace_layout_preserves_lock_state(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry, load_layout, save_layout
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "layout.json"
            save_layout([WorkspaceLayoutEntry("overview", "Locked", False, "abc", False, "12345678-1234-5678-1234-567812345678", True)], path)
            rows = load_layout(path)
            self.assertTrue(rows[0].locked)


class WorkspaceRecoveryTests(unittest.TestCase):
    def test_layout_backup_and_restore(self):
        from journeyman.core.workspace_layout import backup_layout, restore_layout_backup
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "layout.json"
            path.write_text("first", encoding="utf-8")
            backup = backup_layout(path)
            self.assertIsNotNone(backup)
            path.write_text("second", encoding="utf-8")
            self.assertTrue(restore_layout_backup(path))
            self.assertEqual(path.read_text(encoding="utf-8"), "first")

    def test_layout_backup_missing_is_safe(self):
        from journeyman.core.workspace_layout import backup_layout, restore_layout_backup
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "missing.json"
            self.assertIsNone(backup_layout(path))
            self.assertFalse(restore_layout_backup(path))


class WorkspaceQualificationTests(unittest.TestCase):
    def test_valid_workspace_desktop_passes(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry
        from journeyman.core.workspace_qualification import qualify_layout
        rows = [WorkspaceLayoutEntry("overview", "JOE Overview", False, "abc", False, "12345678-1234-5678-1234-567812345678", True)]
        result = qualify_layout(rows)
        self.assertTrue(result.passed)
        self.assertEqual(result.checks, 5)

    def test_duplicate_identity_fails(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry
        from journeyman.core.workspace_qualification import qualify_layout
        wid = "12345678-1234-5678-1234-567812345678"
        rows = [
            WorkspaceLayoutEntry("overview", "One", False, "a", False, wid, False),
            WorkspaceLayoutEntry("log", "Two", True, "b", False, wid, False),
        ]
        result = qualify_layout(rows)
        self.assertFalse(result.passed)
        self.assertTrue(any("duplicate" in x for x in result.failures))

    def test_empty_desktop_is_valid(self):
        from journeyman.core.workspace_qualification import qualify_layout
        result = qualify_layout([])
        self.assertTrue(result.passed)
        self.assertEqual(result.checks, 0)


class WorkspacePersistenceQualificationTests(unittest.TestCase):
    def test_identical_round_trip_passes(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry
        from journeyman.core.workspace_qualification import compare_layouts
        row = WorkspaceLayoutEntry(
            "overview", "Desk", True, "geometry", True,
            "12345678-1234-5678-1234-567812345678", True
        )
        result = compare_layouts([row], [row])
        self.assertTrue(result.passed)

    def test_changed_state_fails(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry
        from journeyman.core.workspace_qualification import compare_layouts
        wid = "12345678-1234-5678-1234-567812345678"
        expected = WorkspaceLayoutEntry("overview", "Desk", False, "g", False, wid, True)
        restored = WorkspaceLayoutEntry("overview", "Desk", True, "g", False, wid, True)
        result = compare_layouts([expected], [restored])
        self.assertFalse(result.passed)
        self.assertTrue(any("external" in x for x in result.failures))

    def test_changed_identity_set_fails(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry
        from journeyman.core.workspace_qualification import compare_layouts
        a = WorkspaceLayoutEntry("log", "Log", False, "g", False,
                                 "12345678-1234-5678-1234-567812345678", False)
        b = WorkspaceLayoutEntry("log", "Log", False, "g", False,
                                 "87654321-4321-8765-4321-876543218765", False)
        result = compare_layouts([a], [b])
        self.assertFalse(result.passed)
        self.assertTrue(any("identities" in x for x in result.failures))


class WorkspaceLifecycleQualificationTests(unittest.TestCase):
    def test_minimize_restore_model(self):
        from journeyman.core.workspace_qualification import LifecycleState, minimize_states, restore_states
        states = [LifecycleState("12345678-1234-5678-1234-567812345678", False, True)]
        minimized = minimize_states(states)
        self.assertTrue(minimized[0].minimized)
        restored = restore_states(minimized)
        self.assertFalse(restored[0].minimized)
        self.assertTrue(restored[0].active)

    def test_activation_is_exclusive(self):
        from journeyman.core.workspace_qualification import LifecycleState, activate_state
        a = "12345678-1234-5678-1234-567812345678"
        b = "87654321-4321-8765-4321-876543218765"
        states = [LifecycleState(a, False, True), LifecycleState(b, False, False)]
        changed = activate_state(states, b)
        self.assertFalse(changed[0].active)
        self.assertTrue(changed[1].active)

    def test_lifecycle_rejects_duplicate_ids(self):
        from journeyman.core.workspace_qualification import LifecycleState, qualify_lifecycle
        wid = "12345678-1234-5678-1234-567812345678"
        result = qualify_lifecycle([LifecycleState(wid), LifecycleState(wid)])
        self.assertFalse(result.passed)
        self.assertTrue(any("duplicate" in x.lower() for x in result.failures))

    def test_lifecycle_rejects_multiple_active(self):
        from journeyman.core.workspace_qualification import LifecycleState, qualify_lifecycle
        a = "12345678-1234-5678-1234-567812345678"
        b = "87654321-4321-8765-4321-876543218765"
        result = qualify_lifecycle([LifecycleState(a, False, True), LifecycleState(b, False, True)])
        self.assertFalse(result.passed)
        self.assertTrue(any("active" in x.lower() for x in result.failures))


class WorkspaceCompositeQualificationTests(unittest.TestCase):
    def test_complete_qualification_passes_valid_model(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry
        from journeyman.core.workspace_qualification import LifecycleState, qualify_workspace_system
        wid = "12345678-1234-5678-1234-567812345678"
        row = WorkspaceLayoutEntry("overview", "JOE Overview", False, "g", False, wid, True)
        result = qualify_workspace_system([row], [row], [LifecycleState(wid, False, True)])
        self.assertTrue(result.passed)
        self.assertEqual(len(result.sections), 3)
        self.assertTrue(all(section[1] for section in result.sections))

    def test_complete_qualification_reports_failed_section(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry
        from journeyman.core.workspace_qualification import LifecycleState, qualify_workspace_system
        wid = "12345678-1234-5678-1234-567812345678"
        row = WorkspaceLayoutEntry("overview", "JOE Overview", False, "g", False, wid, False)
        changed = WorkspaceLayoutEntry("overview", "Changed", False, "g", False, wid, False)
        result = qualify_workspace_system([row], [changed], [LifecycleState(wid)])
        self.assertFalse(result.passed)
        sections = {name: passed for name, passed, _ in result.sections}
        self.assertFalse(sections["Persistence round trip"])


class WorkspaceStateFidelityTests(unittest.TestCase):
    def test_minimized_state_round_trip(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry, save_layout, load_layout
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "layout.json"
            wid = "12345678-1234-5678-1234-567812345678"
            save_layout([WorkspaceLayoutEntry("overview", "Minimized", False, "g", False, wid, False, True)], path)
            restored = load_layout(path)
            self.assertTrue(restored[0].minimized)
            self.assertFalse(restored[0].maximized)

    def test_schema4_defaults_minimized_false(self):
        from journeyman.core.workspace_layout import load_layout
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "layout.json"
            path.write_text(json.dumps({"schema": 4, "workspaces": [{
                "kind": "overview", "title": "Legacy", "external": False,
                "geometry_b64": "g", "maximized": False,
                "workspace_id": "12345678-1234-5678-1234-567812345678",
                "locked": False
            }]}), encoding="utf-8")
            restored = load_layout(path)
            self.assertFalse(restored[0].minimized)

    def test_settings_active_workspace_identity_round_trip(self):
        from journeyman.core.settings import Settings
        wid = "12345678-1234-5678-1234-567812345678"
        s = Settings(active_workspace_id=wid)
        self.assertEqual(s.active_workspace_id, wid)


class WorkspaceReleaseReadinessTests(unittest.TestCase):
    def test_duplicate_persisted_ids_are_repaired_on_load(self):
        from journeyman.core.workspace_layout import load_layout
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "layout.json"
            wid = "12345678-1234-5678-1234-567812345678"
            payload = {"schema": 5, "workspaces": [
                {"kind": "overview", "title": "One", "external": False, "geometry_b64": "a",
                 "maximized": False, "workspace_id": wid, "locked": False, "minimized": False},
                {"kind": "log", "title": "Two", "external": True, "geometry_b64": "b",
                 "maximized": False, "workspace_id": wid, "locked": False, "minimized": False}
            ]}
            path.write_text(json.dumps(payload), encoding="utf-8")
            rows = load_layout(path)
            self.assertEqual(len(rows), 2)
            self.assertNotEqual(rows[0].workspace_id, rows[1].workspace_id)

    def test_release_readiness_passes_valid_system(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry
        from journeyman.core.workspace_qualification import LifecycleState, joe002_release_readiness
        wid = "12345678-1234-5678-1234-567812345678"
        row = WorkspaceLayoutEntry("overview", "JOE Overview", False, "g", False, wid, False, False)
        result = joe002_release_readiness([row], [row], [LifecycleState(wid, False, True)])
        self.assertTrue(result.passed)
        self.assertEqual(len(result.summary), 3)


class ModuleRuntimeTests(unittest.TestCase):
    def test_register_and_activate_module(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime, ModuleState
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("test.module", "Test Module", "1.0"))
        self.assertEqual(runtime.require("test.module").state, ModuleState.REGISTERED)
        runtime.activate("test.module")
        self.assertEqual(runtime.require("test.module").state, ModuleState.ACTIVE)

    def test_duplicate_registration_rejected(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime = ModuleRuntime()
        descriptor = ModuleDescriptor("test.module", "Test Module", "1.0")
        runtime.register(descriptor)
        with self.assertRaises(ValueError):
            runtime.register(descriptor)

    def test_invalid_module_id_rejected(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime = ModuleRuntime()
        with self.assertRaises(ValueError):
            runtime.register(ModuleDescriptor("Bad Module ID", "Bad", "1.0"))

    def test_failure_requires_reset_before_activation(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime, ModuleState
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("test.module", "Test Module", "1.0"))
        runtime.fail("test.module", "failure")
        self.assertEqual(runtime.require("test.module").state, ModuleState.FAILED)
        with self.assertRaises(RuntimeError):
            runtime.activate("test.module")
        runtime.reset("test.module")
        runtime.activate("test.module")
        self.assertEqual(runtime.require("test.module").state, ModuleState.ACTIVE)

    def test_builtin_core_is_active(self):
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.module_runtime import ModuleRuntime, ModuleState
        runtime = ModuleRuntime()
        register_builtin_modules(runtime)
        self.assertEqual(runtime.require("joe.core").state, ModuleState.ACTIVE)


class ModuleDependencyContractTests(unittest.TestCase):
    def test_activation_requires_active_dependency(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime, ModuleState
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("base.module", "Base", "1"))
        runtime.register(ModuleDescriptor("child.module", "Child", "1", requires=("base.module",)))
        with self.assertRaises(RuntimeError):
            runtime.activate("child.module")
        runtime.activate("base.module")
        runtime.activate("child.module")
        self.assertEqual(runtime.require("child.module").state, ModuleState.ACTIVE)

    def test_missing_dependency_rejected_on_activation(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("child.module", "Child", "1", requires=("missing.module",)))
        with self.assertRaises(RuntimeError):
            runtime.activate("child.module")

    def test_active_dependency_cannot_stop_before_dependent(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("base.module", "Base", "1"))
        runtime.register(ModuleDescriptor("child.module", "Child", "1", requires=("base.module",)))
        runtime.activate("base.module")
        runtime.activate("child.module")
        with self.assertRaises(RuntimeError):
            runtime.stop("base.module")
        runtime.stop("child.module")
        runtime.stop("base.module")

    def test_self_dependency_rejected(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime = ModuleRuntime()
        with self.assertRaises(ValueError):
            runtime.register(ModuleDescriptor("self.module", "Self", "1", requires=("self.module",)))

    def test_contract_snapshot_is_immutable_data(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime, contracts
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("base.module", "Base", "1"))
        snapshot = contracts(runtime)
        self.assertEqual(snapshot[0].module_id, "base.module")
        self.assertEqual(snapshot[0].requires, ())


class ModuleInstanceLifecycleTests(unittest.TestCase):
    def test_instance_start_and_stop_hooks_are_called(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleInstance, ModuleRuntime
        class Instance(ModuleInstance):
            def __init__(self): self.events = []
            def start(self): self.events.append("start")
            def stop(self): self.events.append("stop")
        instance = Instance()
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("hook.module", "Hook", "1"), instance)
        runtime.activate("hook.module")
        runtime.stop("hook.module")
        self.assertEqual(instance.events, ["start", "stop"])

    def test_activation_exception_marks_only_module_failed(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleInstance, ModuleRuntime, ModuleState
        class Bad(ModuleInstance):
            def start(self): raise ValueError("boom")
            def stop(self): pass
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("good.module", "Good", "1"))
        runtime.activate("good.module")
        runtime.register(ModuleDescriptor("bad.module", "Bad", "1"), Bad())
        with self.assertRaises(RuntimeError):
            runtime.activate("bad.module")
        self.assertEqual(runtime.require("bad.module").state, ModuleState.FAILED)
        self.assertEqual(runtime.require("good.module").state, ModuleState.ACTIVE)
        self.assertEqual(runtime.require("bad.module").error, "boom")

    def test_shutdown_all_stops_dependents_first(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleInstance, ModuleRuntime
        events = []
        class Instance(ModuleInstance):
            def __init__(self, name): self.name = name
            def start(self): events.append("start:" + self.name)
            def stop(self): events.append("stop:" + self.name)
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("base.module", "Base", "1"), Instance("base"))
        runtime.register(ModuleDescriptor("child.module", "Child", "1", requires=("base.module",)), Instance("child"))
        runtime.activate("base.module")
        runtime.activate("child.module")
        order = runtime.shutdown_all()
        self.assertEqual(order, ("child.module", "base.module"))
        self.assertEqual(events[-2:], ["stop:child", "stop:base"])

    def test_shutdown_failure_does_not_block_other_cleanup(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleInstance, ModuleRuntime, ModuleState
        class BadStop(ModuleInstance):
            def start(self): pass
            def stop(self): raise RuntimeError("cleanup failed")
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("a.module", "A", "1"), BadStop())
        runtime.register(ModuleDescriptor("b.module", "B", "1"))
        runtime.activate("a.module")
        runtime.activate("b.module")
        stopped = runtime.shutdown_all()
        self.assertEqual(set(stopped), {"a.module", "b.module"})
        self.assertEqual(runtime.require("a.module").state, ModuleState.FAILED)
        self.assertEqual(runtime.require("b.module").state, ModuleState.STOPPED)


class ModuleCapabilityServiceTests(unittest.TestCase):
    def test_active_module_can_publish_declared_service(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime = ModuleRuntime()
        service = object()
        runtime.register(ModuleDescriptor("provider.module", "Provider", "1", provides=("test.service",)))
        runtime.activate("provider.module")
        runtime.publish_service("provider.module", "test.service", service)
        self.assertIs(runtime.service("test.service"), service)
        self.assertEqual(runtime.service_owner("test.service"), "provider.module")

    def test_undeclared_service_publication_rejected(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("provider.module", "Provider", "1"))
        runtime.activate("provider.module")
        with self.assertRaises(RuntimeError):
            runtime.publish_service("provider.module", "test.service", object())

    def test_inactive_module_cannot_publish_service(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("provider.module", "Provider", "1", provides=("test.service",)))
        with self.assertRaises(RuntimeError):
            runtime.publish_service("provider.module", "test.service", object())

    def test_stopping_provider_withdraws_service(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("provider.module", "Provider", "1", provides=("test.service",)))
        runtime.activate("provider.module")
        runtime.publish_service("provider.module", "test.service", object())
        runtime.stop("provider.module")
        with self.assertRaises(KeyError):
            runtime.service("test.service")

    def test_duplicate_capability_declaration_rejected(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("one.module", "One", "1", provides=("test.service",)))
        with self.assertRaises(ValueError):
            runtime.register(ModuleDescriptor("two.module", "Two", "1", provides=("test.service",)))

    def test_builtin_runtime_status_service_is_real(self):
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.module_runtime import ModuleRuntime
        runtime = ModuleRuntime()
        register_builtin_modules(runtime)
        service = runtime.service("joe.runtime-status")
        self.assertTrue(service.running)
        runtime.shutdown_all()
        with self.assertRaises(KeyError):
            runtime.service("joe.runtime-status")


class ModuleServiceConsumptionTests(unittest.TestCase):
    def _runtime(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("provider.module", "Provider", "1", provides=("test.service",)))
        runtime.activate("provider.module")
        service = object()
        runtime.publish_service("provider.module", "test.service", service)
        runtime.register(ModuleDescriptor("consumer.module", "Consumer", "1", consumes=("test.service",)))
        runtime.activate("consumer.module")
        return runtime, service

    def test_declared_active_consumer_resolves_service(self):
        runtime, service = self._runtime()
        self.assertIs(runtime.resolve_service("consumer.module", "test.service"), service)

    def test_undeclared_consumption_is_rejected(self):
        from journeyman.core.module_runtime import ModuleDescriptor
        runtime, _ = self._runtime()
        runtime.register(ModuleDescriptor("other.module", "Other", "1"))
        runtime.activate("other.module")
        with self.assertRaises(RuntimeError):
            runtime.resolve_service("other.module", "test.service")

    def test_inactive_consumer_is_rejected(self):
        runtime, _ = self._runtime()
        runtime.stop("consumer.module")
        with self.assertRaises(RuntimeError):
            runtime.resolve_service("consumer.module", "test.service")

    def test_available_capabilities_tracks_live_services(self):
        runtime, _ = self._runtime()
        self.assertEqual(runtime.available_capabilities(), ("test.service",))
        runtime.stop("provider.module")
        self.assertEqual(runtime.available_capabilities(), ())

    def test_invalid_consumed_capability_is_rejected(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime = ModuleRuntime()
        with self.assertRaises(ValueError):
            runtime.register(ModuleDescriptor("consumer.module", "Consumer", "1", consumes=("Bad Service",)))

    def test_contract_snapshot_includes_consumption(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime, contracts
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("consumer.module", "Consumer", "1", consumes=("test.service",)))
        snapshot = contracts(runtime)
        self.assertEqual(snapshot[0].consumes, ("test.service",))


class ModuleGraphQualificationTests(unittest.TestCase):
    def test_dependency_order_is_dependency_first(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime=ModuleRuntime()
        runtime.register(ModuleDescriptor("base.module","Base","1"))
        runtime.register(ModuleDescriptor("middle.module","Middle","1",requires=("base.module",)))
        runtime.register(ModuleDescriptor("top.module","Top","1",requires=("middle.module",)))
        self.assertEqual(runtime.dependency_order(("top.module",)),
                         ("base.module","middle.module","top.module"))

    def test_dependency_cycle_is_detected(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime=ModuleRuntime()
        runtime.register(ModuleDescriptor("a.module","A","1",requires=("b.module",)))
        runtime.register(ModuleDescriptor("b.module","B","1",requires=("a.module",)))
        with self.assertRaises(RuntimeError):
            runtime.dependency_order()

    def test_activate_with_dependencies(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime, ModuleState
        runtime=ModuleRuntime()
        runtime.register(ModuleDescriptor("base.module","Base","1"))
        runtime.register(ModuleDescriptor("top.module","Top","1",requires=("base.module",)))
        activated=runtime.activate_with_dependencies("top.module")
        self.assertEqual(activated,("base.module","top.module"))
        self.assertEqual(runtime.require("top.module").state,ModuleState.ACTIVE)

    def test_missing_transitive_dependency_detected(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime
        runtime=ModuleRuntime()
        runtime.register(ModuleDescriptor("top.module","Top","1",requires=("missing.module",)))
        with self.assertRaises(RuntimeError):
            runtime.dependency_order(("top.module",))

    def test_live_runtime_qualification_passes_builtin_graph(self):
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.module_runtime import ModuleRuntime, qualify_module_runtime
        runtime=ModuleRuntime(); register_builtin_modules(runtime)
        result=qualify_module_runtime(runtime)
        self.assertTrue(result.passed)
        self.assertIn("joe.core",result.activation_order)


class ModuleTransitionAuditTests(unittest.TestCase):
    def test_registration_activation_stop_are_ordered(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime, ModuleState
        runtime=ModuleRuntime()
        runtime.register(ModuleDescriptor("audit.module","Audit","1"))
        runtime.activate("audit.module")
        runtime.stop("audit.module")
        transitions=runtime.transitions()
        self.assertEqual([x.sequence for x in transitions],[1,2,3])
        self.assertEqual([x.current for x in transitions],
                         [ModuleState.REGISTERED,ModuleState.ACTIVE,ModuleState.STOPPED])

    def test_activation_failure_records_actual_error(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleInstance, ModuleRuntime, ModuleState
        class Bad(ModuleInstance):
            def start(self): raise RuntimeError("startup failure")
            def stop(self): pass
        runtime=ModuleRuntime()
        runtime.register(ModuleDescriptor("bad.audit","Bad","1"),Bad())
        with self.assertRaises(RuntimeError): runtime.activate("bad.audit")
        last=runtime.transitions()[-1]
        self.assertEqual(last.current,ModuleState.FAILED)
        self.assertEqual(last.reason,"startup failure")

    def test_reset_is_audited(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime, ModuleState
        runtime=ModuleRuntime()
        runtime.register(ModuleDescriptor("reset.audit","Reset","1"))
        runtime.fail("reset.audit","test failure")
        runtime.reset("reset.audit")
        self.assertEqual(runtime.transitions()[-1].current,ModuleState.REGISTERED)
        self.assertEqual(runtime.transitions()[-1].reason,"reset")

    def test_builtin_core_produces_real_transition_history(self):
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.module_runtime import ModuleRuntime
        runtime=ModuleRuntime(); register_builtin_modules(runtime)
        self.assertEqual([x.module_id for x in runtime.transitions()],["joe.core","joe.core"])


class ModuleRuntimeReleaseReadinessTests(unittest.TestCase):
    def test_builtin_runtime_passes_release_gate(self):
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.module_runtime import ModuleRuntime, joe003_release_readiness
        runtime = ModuleRuntime()
        register_builtin_modules(runtime)
        result = joe003_release_readiness(runtime)
        self.assertTrue(result.passed)
        self.assertEqual(result.module_count, 1)
        self.assertEqual(result.active_count, 1)
        self.assertEqual(
            result.published_capabilities,
            ("joe.alerts", "joe.authority", "joe.diagnostics", "joe.documentation", "joe.host-telemetry", "joe.host-telemetry-monitor", "joe.jobs", "joe.projects", "joe.run_review", "joe.runs", "joe.runtime-status", "joe.state-events", "joe.storage", "joe.streams", "joe.visualization"),
        )
        self.assertEqual(result.activation_order, ("joe.core",))

    def test_active_provider_without_published_service_fails_gate(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime, joe003_release_readiness
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("provider.gate", "Provider", "1", provides=("gate.service",)))
        runtime.activate("provider.gate")
        result = joe003_release_readiness(runtime)
        self.assertFalse(result.passed)
        self.assertTrue(any("has not published gate.service" in item for item in result.failures))

    def test_failed_module_without_error_fails_gate(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRecord, ModuleRuntime, ModuleState, joe003_release_readiness
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("failed.gate", "Failed", "1"))
        record = runtime.require("failed.gate")
        runtime._records["failed.gate"] = ModuleRecord(record.descriptor, ModuleState.FAILED, "")
        result = joe003_release_readiness(runtime)
        self.assertFalse(result.passed)
        self.assertTrue(any("has no recorded error" in item for item in result.failures))

    def test_release_gate_reports_dependency_cycle(self):
        from journeyman.core.module_runtime import ModuleDescriptor, ModuleRuntime, joe003_release_readiness
        runtime = ModuleRuntime()
        runtime.register(ModuleDescriptor("a.gate", "A", "1", requires=("b.gate",)))
        runtime.register(ModuleDescriptor("b.gate", "B", "1", requires=("a.gate",)))
        result = joe003_release_readiness(runtime)
        self.assertFalse(result.passed)
        self.assertTrue(any("cycle" in item.lower() for item in result.failures))


class StateStoreFoundationTests(unittest.TestCase):
    def test_state_set_get_snapshot_and_history(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        change=state.set("joe.mode","development","joe.core")
        self.assertEqual(state.get("joe.mode"),"development")
        self.assertEqual(state.require("joe.mode"),"development")
        self.assertEqual(state.snapshot(),{"joe.mode":"development"})
        self.assertEqual(change.sequence,1)
        self.assertEqual(state.history(),(change,))

    def test_state_watcher_receives_real_change_and_can_unwatch(self):
        from journeyman.core.state_events import StateStore
        state=StateStore(); received=[]
        received_cb=received.append
        state.watch("joe.health",received_cb)
        state.set("joe.health","ok","joe.core")
        state.unwatch("joe.health",received_cb)
        state.set("joe.health","degraded","joe.core")
        self.assertEqual(len(received),1)
        self.assertEqual(received[0].current,"ok")

    def test_state_history_is_bounded(self):
        from journeyman.core.state_events import StateStore
        state=StateStore(history_limit=2)
        for value in range(3): state.set("joe.counter",value,"joe.core")
        self.assertEqual([x.sequence for x in state.history()],[2,3])

    def test_invalid_state_identity_rejected(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        with self.assertRaises(ValueError): state.set("Bad Key",1,"joe.core")


class EventBusFoundationTests(unittest.TestCase):
    def test_publish_subscribe_and_unsubscribe(self):
        from journeyman.core.state_events import EventBus
        bus=EventBus(); received=[]
        cb=received.append
        bus.subscribe("joe.lifecycle",cb)
        event=bus.publish("joe.lifecycle",{"state":"ready"},"joe.core")
        self.assertEqual(received,[event])
        bus.unsubscribe("joe.lifecycle",cb)
        bus.publish("joe.lifecycle",{"state":"later"},"joe.core")
        self.assertEqual(len(received),1)

    def test_event_order_and_bounded_history(self):
        from journeyman.core.state_events import EventBus
        bus=EventBus(history_limit=2)
        for value in range(3): bus.publish("joe.test",value,"joe.core")
        self.assertEqual([x.sequence for x in bus.history()],[2,3])
        self.assertEqual([x.payload for x in bus.history()],[1,2])

    def test_builtin_backbone_is_real_published_service(self):
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.state_events import StateEventBackbone
        runtime=ModuleRuntime(); register_builtin_modules(runtime)
        backbone=runtime.service("joe.state-events")
        self.assertIsInstance(backbone,StateEventBackbone)
        backbone.state.set("joe.test","real","joe.core")
        self.assertEqual(backbone.state.require("joe.test"),"real")


class StateOwnershipTests(unittest.TestCase):
    def test_registered_owner_can_write(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        state.register("joe.control.mode","joe.core")
        state.set("joe.control.mode","ready","joe.core")
        self.assertEqual(state.require("joe.control.mode"),"ready")

    def test_unauthorized_state_write_is_rejected_without_history(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        state.register("joe.control.mode","joe.core")
        with self.assertRaises(PermissionError):
            state.set("joe.control.mode","bad","other.module")
        self.assertEqual(state.history(),())
        self.assertIsNone(state.get("joe.control.mode"))

    def test_authorized_additional_writer(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        state.register("joe.shared.value","joe.core",("test.module",))
        state.set("joe.shared.value",42,"test.module")
        self.assertEqual(state.require("joe.shared.value"),42)

    def test_duplicate_state_registration_rejected(self):
        from journeyman.core.state_events import StateStore
        state=StateStore();state.register("joe.value","joe.core")
        with self.assertRaises(ValueError): state.register("joe.value","joe.core")


class EventPublisherAuthorityTests(unittest.TestCase):
    def test_authorized_publisher_delivers_event(self):
        from journeyman.core.state_events import EventBus
        bus=EventBus();received=[]
        bus.register_topic("joe.control.changed",("joe.core",))
        bus.subscribe("joe.control.changed",received.append)
        event=bus.publish("joe.control.changed",{"ok":True},"joe.core")
        self.assertEqual(received,[event])

    def test_unauthorized_publish_is_rejected_without_history(self):
        from journeyman.core.state_events import EventBus
        bus=EventBus()
        bus.register_topic("joe.control.changed",("joe.core",))
        with self.assertRaises(PermissionError):
            bus.publish("joe.control.changed",{}, "other.module")
        self.assertEqual(bus.history(),())

    def test_builtin_backbone_has_real_core_contracts_and_initial_state(self):
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.module_runtime import ModuleRuntime
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        backbone=runtime.service("joe.state-events")
        self.assertEqual(backbone.state.require("joe.runtime.status"),"active")
        self.assertEqual(backbone.state.require("joe.runtime.module-count"),1)
        self.assertEqual(backbone.state.definition("joe.runtime.status").owner,"joe.core")
        self.assertEqual(backbone.events.history()[-1].topic,"joe.runtime.lifecycle")


class BackboneCallbackIsolationTests(unittest.TestCase):
    def test_bad_state_watcher_does_not_block_good_watcher(self):
        from journeyman.core.state_events import StateStore
        state=StateStore(); received=[]
        def bad(change): raise RuntimeError("watcher exploded")
        state.watch("joe.test",bad)
        state.watch("joe.test",received.append)
        change=state.set("joe.test",7,"joe.core")
        self.assertEqual(received,[change])
        self.assertEqual(state.require("joe.test"),7)
        self.assertEqual(state.callback_failures()[0].error,"watcher exploded")

    def test_bad_event_subscriber_does_not_block_good_subscriber(self):
        from journeyman.core.state_events import EventBus
        bus=EventBus(); received=[]
        def bad(event): raise RuntimeError("subscriber exploded")
        bus.subscribe("joe.test",bad)
        bus.subscribe("joe.test",received.append)
        event=bus.publish("joe.test",{"value":1},"joe.core")
        self.assertEqual(received,[event])
        self.assertEqual(bus.history(),(event,))
        self.assertEqual(bus.callback_failures()[0].error,"subscriber exploded")

    def test_callback_failure_history_is_bounded(self):
        from journeyman.core.state_events import StateStore
        state=StateStore(history_limit=2)
        def bad(change): raise RuntimeError("failure")
        state.watch("joe.test",bad)
        for value in range(3): state.set("joe.test",value,"joe.core")
        self.assertEqual([x.sequence for x in state.callback_failures()],[2,3])

    def test_callback_failure_snapshot_is_immutable_tuple(self):
        from journeyman.core.state_events import EventBus
        bus=EventBus()
        self.assertIsInstance(bus.callback_failures(),tuple)


class StateEventClientTests(unittest.TestCase):
    def test_client_binds_source_for_state_write(self):
        from journeyman.core.state_events import StateEventBackbone
        backbone=StateEventBackbone()
        backbone.state.register("joe.test.value","test.module")
        client=backbone.client("test.module")
        change=client.set_state("joe.test.value",12)
        self.assertEqual(change.source,"test.module")
        self.assertEqual(client.require_state("joe.test.value"),12)

    def test_client_cannot_impersonate_authorized_owner(self):
        from journeyman.core.state_events import StateEventBackbone
        backbone=StateEventBackbone()
        backbone.state.register("joe.secure.value","joe.core")
        client=backbone.client("other.module")
        with self.assertRaises(PermissionError):
            client.set_state("joe.secure.value","bad")
        self.assertIsNone(backbone.state.get("joe.secure.value"))

    def test_client_binds_source_for_event_publication(self):
        from journeyman.core.state_events import StateEventBackbone
        backbone=StateEventBackbone()
        backbone.events.register_topic("test.module.changed",("test.module",))
        event=backbone.client("test.module").publish("test.module.changed",{"value":3})
        self.assertEqual(event.source,"test.module")

    def test_client_cannot_publish_as_another_module(self):
        from journeyman.core.state_events import StateEventBackbone
        backbone=StateEventBackbone()
        backbone.events.register_topic("joe.secure.event",("joe.core",))
        with self.assertRaises(PermissionError):
            backbone.client("other.module").publish("joe.secure.event",{})
        self.assertEqual(backbone.events.history(),())

    def test_client_is_stable_per_source(self):
        from journeyman.core.state_events import StateEventBackbone
        backbone=StateEventBackbone()
        self.assertIs(backbone.client("test.module"),backbone.client("test.module"))

    def test_core_initial_records_are_source_bound(self):
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.module_runtime import ModuleRuntime
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        backbone=runtime.service("joe.state-events")
        self.assertTrue(all(change.source=="joe.core" for change in backbone.state.history()))
        self.assertTrue(all(event.source=="joe.core" for event in backbone.events.history()))


class StateRevisionTests(unittest.TestCase):
    def test_state_revision_increments_per_key(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        first=state.set("joe.test",1,"joe.core")
        second=state.set("joe.test",2,"joe.core")
        self.assertEqual((first.revision,second.revision),(1,2))
        self.assertEqual(state.revision("joe.test"),2)

    def test_read_returns_value_and_revision(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        self.assertEqual(state.read("joe.test"),(None,0))
        state.set("joe.test","value","joe.core")
        self.assertEqual(state.read("joe.test"),("value",1))

    def test_expected_revision_accepts_current_writer(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        state.set("joe.test",1,"joe.core")
        change=state.set("joe.test",2,"joe.core",expected_revision=1)
        self.assertEqual(change.revision,2)

    def test_stale_write_is_rejected_without_mutation(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        state.set("joe.test","first","joe.core")
        state.set("joe.test","second","joe.core",expected_revision=1)
        history_before=state.history()
        with self.assertRaises(RuntimeError):
            state.set("joe.test","stale","joe.core",expected_revision=1)
        self.assertEqual(state.require("joe.test"),"second")
        self.assertEqual(state.revision("joe.test"),2)
        self.assertEqual(state.history(),history_before)

    def test_invalid_expected_revision_rejected(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        with self.assertRaises(ValueError):
            state.set("joe.test",1,"joe.core",expected_revision=-1)

    def test_source_bound_client_supports_revision_guard(self):
        from journeyman.core.state_events import StateEventBackbone
        backbone=StateEventBackbone()
        backbone.state.register("test.shared","test.module")
        client=backbone.client("test.module")
        client.set_state("test.shared",10)
        value,revision=client.read_state("test.shared")
        self.assertEqual((value,revision),(10,1))
        client.set_state("test.shared",11,expected_revision=revision)
        self.assertEqual(client.state_revision("test.shared"),2)


class StateTransactionTests(unittest.TestCase):
    def test_transaction_commits_multiple_keys(self):
        from journeyman.core.state_events import StateStore, StateUpdate
        state=StateStore()
        tx=state.transact((StateUpdate("joe.a",1),StateUpdate("joe.b",2)),"joe.core")
        self.assertEqual(tx.transaction_id,1)
        self.assertEqual(state.snapshot(),{"joe.a":1,"joe.b":2})
        self.assertEqual([c.sequence for c in tx.changes],[1,2])

    def test_transaction_stale_revision_rolls_back_all_keys(self):
        from journeyman.core.state_events import StateStore, StateUpdate
        state=StateStore()
        state.set("joe.a",10,"joe.core")
        before=state.snapshot(); history=state.history()
        with self.assertRaises(RuntimeError):
            state.transact((
                StateUpdate("joe.a",11,expected_revision=0),
                StateUpdate("joe.b",20),
            ),"joe.core")
        self.assertEqual(state.snapshot(),before)
        self.assertEqual(state.history(),history)
        self.assertEqual(state.revision("joe.b"),0)

    def test_transaction_authority_failure_rolls_back_all_keys(self):
        from journeyman.core.state_events import StateStore, StateUpdate
        state=StateStore()
        state.register("joe.secure","joe.core")
        with self.assertRaises(PermissionError):
            state.transact((
                StateUpdate("joe.open",1),
                StateUpdate("joe.secure",2),
            ),"other.module")
        self.assertEqual(state.snapshot(),{})
        self.assertEqual(state.history(),())

    def test_transaction_rejects_duplicate_keys(self):
        from journeyman.core.state_events import StateStore, StateUpdate
        state=StateStore()
        with self.assertRaises(ValueError):
            state.transact((StateUpdate("joe.a",1),StateUpdate("joe.a",2)),"joe.core")
        self.assertEqual(state.snapshot(),{})

    def test_watchers_observe_complete_post_transaction_snapshot(self):
        from journeyman.core.state_events import StateStore, StateUpdate
        state=StateStore(); snapshots=[]
        state.watch("joe.a",lambda change: snapshots.append(state.snapshot()))
        state.transact((StateUpdate("joe.a",1),StateUpdate("joe.b",2)),"joe.core")
        self.assertEqual(snapshots,[{"joe.a":1,"joe.b":2}])

    def test_source_bound_client_transaction_uses_client_identity(self):
        from journeyman.core.state_events import StateEventBackbone, StateUpdate
        backbone=StateEventBackbone()
        backbone.state.register("test.a","test.module")
        backbone.state.register("test.b","test.module")
        tx=backbone.client("test.module").transact_state(
            (StateUpdate("test.a",1),StateUpdate("test.b",2))
        )
        self.assertTrue(all(change.source=="test.module" for change in tx.changes))

    def test_empty_transaction_is_rejected(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        with self.assertRaises(ValueError): state.transact((),"joe.core")


class DataOriginClassificationTests(unittest.TestCase):
    def test_state_change_records_simulation_origin(self):
        from journeyman.core.state_events import StateStore, DataOrigin
        state=StateStore()
        change=state.set("sim.mouth-a.radius",2.5,"joe.core",origin=DataOrigin.SIMULATION)
        self.assertEqual(change.origin,DataOrigin.SIMULATION)

    def test_event_records_hardware_origin(self):
        from journeyman.core.state_events import EventBus, DataOrigin
        bus=EventBus()
        event=bus.publish("joe.sensor.sample",{"value":1},"joe.core",origin="HARDWARE")
        self.assertEqual(event.origin,DataOrigin.HARDWARE)

    def test_invalid_origin_is_rejected_before_state_mutation(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        with self.assertRaises(ValueError):
            state.set("joe.test",1,"joe.core",origin="pretend")
        self.assertEqual(state.snapshot(),{})
        self.assertEqual(state.history(),())

    def test_transaction_preserves_per_update_origins(self):
        from journeyman.core.state_events import StateStore, StateUpdate, DataOrigin
        state=StateStore()
        tx=state.transact((
            StateUpdate("sim.a",1,origin=DataOrigin.SIMULATION),
            StateUpdate("joe.host",2,origin=DataOrigin.HOST),
        ),"joe.core")
        self.assertEqual(
            [change.origin for change in tx.changes],
            [DataOrigin.SIMULATION,DataOrigin.HOST],
        )

    def test_source_bound_client_cannot_hide_simulation_origin(self):
        from journeyman.core.state_events import StateEventBackbone, DataOrigin
        backbone=StateEventBackbone()
        client=backbone.client("test.module")
        change=client.set_state("test.synthetic",7,origin=DataOrigin.SIMULATION)
        self.assertEqual(change.source,"test.module")
        self.assertEqual(change.origin,DataOrigin.SIMULATION)


class TypedStateContractTests(unittest.TestCase):
    def test_registered_type_accepts_valid_value(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        state.register("joe.count","joe.core",value_type=int)
        state.set("joe.count",3,"joe.core")
        self.assertEqual(state.require("joe.count"),3)

    def test_registered_type_rejects_invalid_value_without_mutation(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        state.register("joe.count","joe.core",value_type=int)
        with self.assertRaises(TypeError):
            state.set("joe.count","three","joe.core")
        self.assertEqual(state.snapshot(),{})
        self.assertEqual(state.revision("joe.count"),0)
        self.assertEqual(state.history(),())

    def test_none_requires_explicit_permission(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        state.register("joe.value","joe.core",value_type=float)
        with self.assertRaises(TypeError): state.set("joe.value",None,"joe.core")
        state2=StateStore()
        state2.register("joe.value","joe.core",value_type=float,allow_none=True)
        state2.set("joe.value",None,"joe.core")
        self.assertIsNone(state2.require("joe.value"))

    def test_multiple_allowed_types(self):
        from journeyman.core.state_events import StateStore
        state=StateStore()
        state.register("joe.number","joe.core",value_type=(int,float))
        state.set("joe.number",1.5,"joe.core")
        self.assertEqual(state.require("joe.number"),1.5)

    def test_transaction_type_failure_is_atomic(self):
        from journeyman.core.state_events import StateStore, StateUpdate
        state=StateStore()
        state.register("joe.a","joe.core",value_type=int)
        state.register("joe.b","joe.core",value_type=int)
        with self.assertRaises(TypeError):
            state.transact((StateUpdate("joe.a",1),StateUpdate("joe.b","bad")),"joe.core")
        self.assertEqual(state.snapshot(),{})
        self.assertEqual(state.history(),())

    def test_builtin_core_state_contracts_are_typed(self):
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.module_runtime import ModuleRuntime
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        backbone=runtime.service("joe.state-events")
        self.assertIs(backbone.state.definition("joe.runtime.module-count").value_type,int)
        self.assertIs(backbone.state.definition("joe.runtime.status").value_type,str)


class StateEventQualificationTests(unittest.TestCase):
    def test_valid_builtin_backbone_passes(self):
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.state_events import qualify_state_event_backbone
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        result=qualify_state_event_backbone(runtime.service("joe.state-events"))
        self.assertTrue(result.passed)
        self.assertEqual(result.state_definition_count,2)
        self.assertEqual(result.event_topic_count,1)

    def test_state_callback_failure_fails_qualification(self):
        from journeyman.core.state_events import StateEventBackbone, qualify_state_event_backbone
        backbone=StateEventBackbone()
        def bad(change): raise RuntimeError("observer failed")
        backbone.state.watch("joe.test",bad)
        backbone.state.set("joe.test",1,"joe.core")
        result=qualify_state_event_backbone(backbone)
        self.assertFalse(result.passed)
        self.assertTrue(any("watcher failures" in item.lower() for item in result.failures))

    def test_event_callback_failure_fails_qualification(self):
        from journeyman.core.state_events import StateEventBackbone, qualify_state_event_backbone
        backbone=StateEventBackbone()
        def bad(event): raise RuntimeError("subscriber failed")
        backbone.events.subscribe("joe.test",bad)
        backbone.events.publish("joe.test",1,"joe.core")
        result=qualify_state_event_backbone(backbone)
        self.assertFalse(result.passed)
        self.assertTrue(any("subscriber failures" in item.lower() for item in result.failures))

    def test_empty_clean_backbone_is_structurally_valid(self):
        from journeyman.core.state_events import StateEventBackbone, qualify_state_event_backbone
        result=qualify_state_event_backbone(StateEventBackbone())
        self.assertTrue(result.passed)


class StateEventReleaseReadinessTests(unittest.TestCase):
    def test_builtin_backbone_passes_release_gate(self):
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.state_events import joe004_release_readiness
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        result=joe004_release_readiness(runtime.service("joe.state-events"))
        self.assertTrue(result.passed)

    def test_empty_backbone_fails_required_contracts(self):
        from journeyman.core.state_events import StateEventBackbone, joe004_release_readiness
        result=joe004_release_readiness(StateEventBackbone())
        self.assertFalse(result.passed)
        self.assertTrue(any("required joe state" in item.lower() for item in result.failures))

    def test_missing_lifecycle_event_fails_release_gate(self):
        from journeyman.core.state_events import StateEventBackbone, joe004_release_readiness
        backbone=StateEventBackbone()
        backbone.state.register("joe.runtime.module-count","joe.core",value_type=int)
        backbone.state.register("joe.runtime.status","joe.core",value_type=str)
        backbone.events.register_topic("joe.runtime.lifecycle",("joe.core",))
        client=backbone.client("joe.core")
        client.set_state("joe.runtime.module-count",1)
        client.set_state("joe.runtime.status","active")
        result=joe004_release_readiness(backbone)
        self.assertFalse(result.passed)
        self.assertTrue(any("no joe.runtime.lifecycle" in item.lower() for item in result.failures))

    def test_callback_failure_prevents_release_readiness(self):
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.state_events import joe004_release_readiness
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        backbone=runtime.service("joe.state-events")
        def bad(change): raise RuntimeError("release observer fault")
        backbone.state.watch("joe.runtime.status",bad)
        backbone.client("joe.core").set_state("joe.runtime.status","active")
        result=joe004_release_readiness(backbone)
        self.assertFalse(result.passed)
        self.assertTrue(any("watcher failures" in item.lower() for item in result.failures))


class StorageFoundationTests(unittest.TestCase):
    def test_storage_paths_are_canonical_under_root(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import StoragePaths
        with tempfile.TemporaryDirectory() as td:
            paths=StoragePaths.from_root(Path(td))
            paths.ensure()
            self.assertTrue(paths.config.is_dir())
            self.assertTrue(paths.data.is_dir())
            self.assertTrue(paths.logs.is_dir())

    def test_config_round_trip_and_revision(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            first=store.save("joe.test",{"enabled":True})
            second=store.save("joe.test",{"enabled":False},expected_revision=1)
            self.assertEqual((first.revision,second.revision),(1,2))
            self.assertEqual(store.load("joe.test").values,{"enabled":False})

    def test_stale_config_write_is_rejected_without_mutation(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            store.save("joe.test",{"value":1})
            with self.assertRaises(RuntimeError):
                store.save("joe.test",{"value":2},expected_revision=0)
            doc=store.load("joe.test")
            self.assertEqual(doc.revision,1)
            self.assertEqual(doc.values,{"value":1})

    def test_unserializable_config_rejected_without_file(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            with self.assertRaises(TypeError):
                store.save("joe.test",{"bad":object()})
            self.assertEqual(store.load("joe.test").revision,0)

    def test_invalid_namespace_rejected(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            with self.assertRaises(ValueError): store.save("../escape",{})

    def test_namespaces_are_real_files_only(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            store.save("joe.alpha",{})
            store.save("joe.beta",{})
            self.assertEqual(store.namespaces(),("joe.alpha","joe.beta"))

    def test_builtin_storage_service_is_published(self):
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.storage import StorageService
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        self.assertIsInstance(runtime.service("joe.storage"),StorageService)


class ConfigBackupRecoveryTests(unittest.TestCase):
    def test_second_save_creates_previous_revision_backup(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            store.save("joe.test",{"value":1})
            self.assertFalse(store.has_backup("joe.test"))
            store.save("joe.test",{"value":2},expected_revision=1)
            self.assertTrue(store.has_backup("joe.test"))
            backup=Path(td)/"joe.test.json.bak"
            import json
            raw=json.loads(backup.read_text(encoding="utf-8"))
            self.assertEqual(raw["revision"],1)
            self.assertEqual(raw["values"],{"value":1})

    def test_recover_backup_restores_previous_revision(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            store.save("joe.test",{"value":"old"})
            store.save("joe.test",{"value":"new"})
            recovered=store.recover_backup("joe.test")
            self.assertEqual(recovered.revision,1)
            self.assertEqual(recovered.values,{"value":"old"})
            self.assertEqual(store.load("joe.test"),recovered)

    def test_missing_backup_is_explicit_error(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            with self.assertRaises(FileNotFoundError):
                store.recover_backup("joe.none")

    def test_corrupt_backup_does_not_replace_current_config(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); store=ConfigStore(root)
            store.save("joe.test",{"value":1})
            store.save("joe.test",{"value":2})
            (root/"joe.test.json.bak").write_text("{broken",encoding="utf-8")
            with self.assertRaises(RuntimeError):
                store.recover_backup("joe.test")
            self.assertEqual(store.load("joe.test").values,{"value":2})

    def test_backup_tracks_immediately_previous_revision(self):
        import tempfile, json
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); store=ConfigStore(root)
            store.save("joe.test",{"n":1})
            store.save("joe.test",{"n":2})
            store.save("joe.test",{"n":3})
            raw=json.loads((root/"joe.test.json.bak").read_text(encoding="utf-8"))
            self.assertEqual(raw["revision"],2)
            self.assertEqual(raw["values"],{"n":2})


class ConfigIntegrityTests(unittest.TestCase):
    def test_new_config_has_verified_checksum(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            saved=store.save("joe.test",{"value":1})
            self.assertIsNotNone(saved.checksum)
            loaded=store.load("joe.test")
            self.assertEqual(loaded.checksum,saved.checksum)

    def test_tampered_config_is_rejected(self):
        import tempfile, json
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); store=ConfigStore(root)
            store.save("joe.test",{"value":1})
            path=root/"joe.test.json"
            raw=json.loads(path.read_text(encoding="utf-8"))
            raw["values"]["value"]=999
            path.write_text(json.dumps(raw),encoding="utf-8")
            with self.assertRaises(RuntimeError):
                store.load("joe.test")

    def test_tampered_backup_is_rejected_without_replacing_current(self):
        import tempfile, json
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); store=ConfigStore(root)
            store.save("joe.test",{"value":1})
            store.save("joe.test",{"value":2})
            backup=root/"joe.test.json.bak"
            raw=json.loads(backup.read_text(encoding="utf-8"))
            raw["values"]["value"]=77
            backup.write_text(json.dumps(raw),encoding="utf-8")
            with self.assertRaises(RuntimeError):
                store.recover_backup("joe.test")
            self.assertEqual(store.load("joe.test").values,{"value":2})

    def test_legacy_config_loads_but_fails_qualification(self):
        import tempfile, json
        from pathlib import Path
        from journeyman.core.storage import StorageService, qualify_storage
        with tempfile.TemporaryDirectory() as td:
            service=StorageService(Path(td))
            path=service.paths.config/"joe.legacy.json"
            path.write_text(json.dumps({"revision":1,"values":{"x":1}}),encoding="utf-8")
            self.assertIsNone(service.config.load("joe.legacy").checksum)
            result=qualify_storage(service)
            self.assertFalse(result.passed)
            self.assertTrue(any("legacy" in item.lower() for item in result.failures))

    def test_clean_storage_with_checksums_passes_qualification(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import StorageService, qualify_storage
        with tempfile.TemporaryDirectory() as td:
            service=StorageService(Path(td))
            service.config.save("joe.test",{"ok":True})
            result=qualify_storage(service)
            self.assertTrue(result.passed)


class ConfigSchemaMigrationTests(unittest.TestCase):
    def test_schema_version_is_persisted(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            store.register_schema("joe.test",2)
            doc=store.save("joe.test",{"x":1})
            self.assertEqual(doc.schema_version,2)
            self.assertEqual(store.load("joe.test").schema_version,2)

    def test_sequential_migration_creates_new_revision_and_backup(self):
        import tempfile, json
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); store=ConfigStore(root)
            store.save("joe.test",{"name":"old"})
            store.register_schema("joe.test",3)
            store.register_migration("joe.test",1,lambda v:{**v,"v2":True})
            store.register_migration("joe.test",2,lambda v:{**v,"v3":True})
            doc=store.migrate("joe.test")
            self.assertEqual(doc.schema_version,3)
            self.assertEqual(doc.revision,2)
            self.assertTrue(doc.values["v2"] and doc.values["v3"])
            backup=json.loads((root/"joe.test.json.bak").read_text(encoding="utf-8"))
            self.assertEqual(backup["revision"],1)

    def test_missing_migration_does_not_modify_source(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            original=store.save("joe.test",{"x":1})
            store.register_schema("joe.test",2)
            with self.assertRaises(RuntimeError):
                store.migrate("joe.test")
            after=store.load("joe.test")
            self.assertEqual(after.revision,original.revision)
            self.assertEqual(after.values,original.values)

    def test_bad_migration_output_does_not_modify_source(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            store.save("joe.test",{"x":1})
            store.register_schema("joe.test",2)
            store.register_migration("joe.test",1,lambda v:"bad")
            with self.assertRaises(TypeError):
                store.migrate("joe.test")
            self.assertEqual(store.load("joe.test").revision,1)

    def test_duplicate_migration_registration_rejected(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            store.register_migration("joe.test",1,lambda v:v)
            with self.assertRaises(RuntimeError):
                store.register_migration("joe.test",1,lambda v:v)

    def test_noop_migration_returns_current_document(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import ConfigStore
        with tempfile.TemporaryDirectory() as td:
            store=ConfigStore(Path(td))
            doc=store.save("joe.test",{"x":1})
            result=store.migrate("joe.test")
            self.assertEqual(result,doc)
            self.assertFalse(store.has_backup("joe.test"))


class DataStoreTests(unittest.TestCase):
    def test_binary_artifact_round_trip_and_checksum(self):
        import tempfile, hashlib
        from pathlib import Path
        from journeyman.core.storage import DataStore
        with tempfile.TemporaryDirectory() as td:
            store=DataStore(Path(td))
            artifact=store.write_bytes("joe.test","sample.bin",b"abc123")
            self.assertEqual(store.read_bytes("joe.test","sample.bin"),b"abc123")
            self.assertEqual(artifact.size_bytes,6)
            self.assertEqual(artifact.checksum,hashlib.sha256(b"abc123").hexdigest())

    def test_text_artifact_round_trip_utf8(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import DataStore
        with tempfile.TemporaryDirectory() as td:
            store=DataStore(Path(td))
            store.write_text("joe.test","notes.txt","Journeyman Δt")
            self.assertEqual(store.read_text("joe.test","notes.txt"),"Journeyman Δt")

    def test_invalid_artifact_path_is_rejected(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import DataStore
        with tempfile.TemporaryDirectory() as td:
            store=DataStore(Path(td))
            with self.assertRaises(ValueError):
                store.write_bytes("joe.test","../escape",b"x")
            with self.assertRaises(ValueError):
                store.write_bytes("../escape","file.bin",b"x")

    def test_artifact_listing_reports_real_files(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import DataStore
        with tempfile.TemporaryDirectory() as td:
            store=DataStore(Path(td))
            store.write_bytes("joe.test","a.bin",b"a")
            store.write_bytes("joe.test","b.bin",b"bb")
            items=store.list_artifacts("joe.test")
            self.assertEqual([item.name for item in items],["a.bin","b.bin"])
            self.assertEqual([item.size_bytes for item in items],[1,2])

    def test_delete_is_explicit_and_missing_delete_fails(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import DataStore
        with tempfile.TemporaryDirectory() as td:
            store=DataStore(Path(td))
            store.write_bytes("joe.test","a.bin",b"a")
            store.delete("joe.test","a.bin")
            with self.assertRaises(FileNotFoundError):
                store.read_bytes("joe.test","a.bin")
            with self.assertRaises(FileNotFoundError):
                store.delete("joe.test","a.bin")

    def test_storage_service_exposes_data_store(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import StorageService, DataStore
        with tempfile.TemporaryDirectory() as td:
            service=StorageService(Path(td))
            self.assertIsInstance(service.data,DataStore)


class StorageHealthTests(unittest.TestCase):
    def test_real_temp_storage_health_passes(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import StorageService, storage_health
        with tempfile.TemporaryDirectory() as td:
            service=StorageService(Path(td))
            result=storage_health(service,minimum_free_bytes=0)
            self.assertTrue(result.passed)
            self.assertTrue(result.config_writable)
            self.assertTrue(result.data_writable)
            self.assertTrue(result.logs_writable)
            self.assertGreater(result.total_bytes,0)
            self.assertGreaterEqual(result.free_bytes,0)

    def test_impossible_free_space_threshold_fails(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import StorageService, storage_health
        with tempfile.TemporaryDirectory() as td:
            service=StorageService(Path(td))
            baseline=storage_health(service,minimum_free_bytes=0)
            result=storage_health(service,minimum_free_bytes=baseline.total_bytes+1)
            self.assertFalse(result.passed)
            self.assertTrue(any("below required minimum" in x for x in result.failures))

    def test_negative_threshold_rejected(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import StorageService, storage_health
        with tempfile.TemporaryDirectory() as td:
            service=StorageService(Path(td))
            with self.assertRaises(ValueError):
                storage_health(service,minimum_free_bytes=-1)

    def test_write_probe_leaves_no_probe_artifacts(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import StorageService, storage_health
        with tempfile.TemporaryDirectory() as td:
            service=StorageService(Path(td))
            storage_health(service,minimum_free_bytes=0)
            for directory in (service.paths.config,service.paths.data,service.paths.logs):
                self.assertFalse(any(p.name.startswith(".joe-write-probe-") for p in directory.iterdir()))


class StorageReleaseReadinessTests(unittest.TestCase):
    def test_release_readiness_passes_clean_storage(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import StorageService, joe005_release_readiness
        with tempfile.TemporaryDirectory() as td:
            service=StorageService(Path(td))
            service.config.save("joe.test",{"ready":True})
            result=joe005_release_readiness(service)
            self.assertTrue(result.passed, result.failures)
            self.assertEqual(result.config_namespaces,("joe.test",))
            self.assertGreater(result.total_bytes,0)

    def test_release_readiness_rejects_legacy_unchecked_config(self):
        import tempfile, json
        from pathlib import Path
        from journeyman.core.storage import StorageService, joe005_release_readiness
        with tempfile.TemporaryDirectory() as td:
            service=StorageService(Path(td))
            (service.paths.config/"joe.legacy.json").write_text(
                json.dumps({"revision":1,"values":{"x":1}}),encoding="utf-8"
            )
            result=joe005_release_readiness(service)
            self.assertFalse(result.passed)
            self.assertTrue(any("legacy" in item.lower() for item in result.failures))

    def test_release_readiness_rejects_unexpected_data_root_file(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import StorageService, joe005_release_readiness
        with tempfile.TemporaryDirectory() as td:
            service=StorageService(Path(td))
            (service.paths.data/"stray.bin").write_bytes(b"x")
            result=joe005_release_readiness(service)
            self.assertFalse(result.passed)
            self.assertTrue(any("Unexpected file" in item for item in result.failures))

    def test_release_probe_does_not_create_user_probe_namespace(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.storage import StorageService, joe005_release_readiness
        with tempfile.TemporaryDirectory() as td:
            service=StorageService(Path(td))
            joe005_release_readiness(service)
            self.assertFalse((service.paths.config/"joe.readiness.json").exists())
            self.assertFalse((service.paths.data/"joe.readiness").exists())


class JobEngineTests(unittest.TestCase):
    def test_successful_job_returns_real_result_and_progress(self):
        from journeyman.core.job_engine import JobEngine, JobState
        engine=JobEngine(max_workers=1)
        engine.register_owner("joe.test")
        try:
            job=engine.submit("sum","joe.test",lambda ctx:(ctx.report_progress(0.5),sum(range(10)))[1])
            engine._records[job].future.result(timeout=2)
            snap=engine.snapshot(job)
            self.assertEqual(snap.state,JobState.SUCCEEDED)
            self.assertEqual(snap.progress,1.0)
            self.assertEqual(engine.result(job),45)
        finally:
            engine.shutdown()

    def test_failed_job_retains_explicit_error(self):
        from journeyman.core.job_engine import JobEngine, JobState
        engine=JobEngine(max_workers=1)
        engine.register_owner("joe.test")
        def fail(ctx):
            raise ValueError("boom")
        try:
            job=engine.submit("failure","joe.test",fail)
            engine._records[job].future.result(timeout=2)
            snap=engine.snapshot(job)
            self.assertEqual(snap.state,JobState.FAILED)
            self.assertIn("ValueError: boom",snap.error)
            with self.assertRaises(RuntimeError):
                engine.result(job)
        finally:
            engine.shutdown()

    def test_cooperative_cancellation(self):
        import time
        from threading import Event
        from journeyman.core.job_engine import JobEngine, JobState, JobCancelled
        engine=JobEngine(max_workers=1)
        engine.register_owner("joe.test")
        entered=Event()
        def work(ctx):
            entered.set()
            while True:
                ctx.raise_if_cancelled()
                time.sleep(0.001)
        try:
            job=engine.submit("cancel","joe.test",work)
            self.assertTrue(entered.wait(1))
            self.assertTrue(engine.cancel(job))
            engine._records[job].future.result(timeout=2)
            self.assertEqual(engine.snapshot(job).state,JobState.CANCELLED)
            with self.assertRaises(JobCancelled):
                engine.result(job)
        finally:
            engine.shutdown()

    def test_progress_cannot_move_backward_or_out_of_range(self):
        from journeyman.core.job_engine import JobEngine
        engine=JobEngine(max_workers=1)
        engine.register_owner("joe.test")
        def work(ctx):
            ctx.report_progress(0.5)
            with self.assertRaises(ValueError):
                ctx.report_progress(0.4)
            with self.assertRaises(ValueError):
                ctx.report_progress(1.1)
            return "ok"
        try:
            job=engine.submit("progress","joe.test",work)
            engine._records[job].future.result(timeout=2)
            self.assertEqual(engine.result(job),"ok")
        finally:
            engine.shutdown()

    def test_transition_history_records_lifecycle(self):
        from journeyman.core.job_engine import JobEngine, JobState
        engine=JobEngine(max_workers=1)
        engine.register_owner("joe.test")
        try:
            job=engine.submit("audit","joe.test",lambda ctx:1)
            engine._records[job].future.result(timeout=2)
            states=[x.new_state for x in engine.transitions() if x.job_id==job]
            self.assertEqual(states,[JobState.QUEUED,JobState.RUNNING,JobState.SUCCEEDED])
        finally:
            engine.shutdown()

    def test_submit_after_shutdown_is_rejected(self):
        from journeyman.core.job_engine import JobEngine
        engine=JobEngine(max_workers=1)
        engine.register_owner("joe.test")
        engine.shutdown()
        with self.assertRaises(RuntimeError):
            engine.submit("late","joe.test",lambda ctx:None)


class JobOwnerPolicyTests(unittest.TestCase):
    def test_unregistered_owner_cannot_submit(self):
        from journeyman.core.job_engine import JobEngine
        engine=JobEngine(max_workers=1)
        try:
            with self.assertRaises(PermissionError):
                engine.submit("unauthorized","module.unknown",lambda ctx:1)
        finally:
            engine.shutdown()

    def test_registered_owner_can_submit(self):
        from journeyman.core.job_engine import JobEngine
        engine=JobEngine(max_workers=1)
        engine.register_owner("module.test",max_active=1)
        try:
            job=engine.submit("authorized","module.test",lambda ctx:42)
            engine._records[job].future.result(timeout=2)
            self.assertEqual(engine.result(job),42)
        finally:
            engine.shutdown()

    def test_owner_active_limit_is_enforced(self):
        from threading import Event
        from journeyman.core.job_engine import JobEngine
        engine=JobEngine(max_workers=1)
        engine.register_owner("module.test",max_active=1)
        entered=Event(); release=Event()
        def blocked(ctx):
            entered.set()
            release.wait(2)
            return 1
        try:
            first=engine.submit("first","module.test",blocked)
            self.assertTrue(entered.wait(1))
            with self.assertRaises(RuntimeError):
                engine.submit("second","module.test",lambda ctx:2)
            release.set()
            engine._records[first].future.result(timeout=2)
        finally:
            release.set()
            engine.shutdown()

    def test_owner_registration_is_idempotent_only_for_same_policy(self):
        from journeyman.core.job_engine import JobEngine
        engine=JobEngine()
        try:
            engine.register_owner("module.test",2)
            engine.register_owner("module.test",2)
            with self.assertRaises(RuntimeError):
                engine.register_owner("module.test",3)
        finally:
            engine.shutdown()


class JobPriorityTests(unittest.TestCase):
    def test_snapshot_reports_priority(self):
        from journeyman.core.job_engine import JobEngine, JobPriority
        engine=JobEngine(max_workers=1); engine.register_owner("joe.test")
        try:
            job=engine.submit("priority","joe.test",lambda ctx:1,JobPriority.HIGH)
            engine._records[job].future.result(timeout=2)
            self.assertEqual(engine.snapshot(job).priority,JobPriority.HIGH)
        finally:
            engine.shutdown()

    def test_invalid_priority_rejected(self):
        from journeyman.core.job_engine import JobEngine
        engine=JobEngine(max_workers=1); engine.register_owner("joe.test")
        try:
            with self.assertRaises(TypeError):
                engine.submit("bad","joe.test",lambda ctx:1,10)
        finally:
            engine.shutdown()

    def test_high_priority_overtakes_queued_low_priority(self):
        from threading import Event
        from journeyman.core.job_engine import JobEngine, JobPriority
        engine=JobEngine(max_workers=1); engine.register_owner("joe.test",max_active=4)
        entered=Event(); release=Event(); order=[]
        def blocker(ctx):
            entered.set(); release.wait(2); order.append("blocker")
        def mark(name):
            return lambda ctx: order.append(name)
        try:
            first=engine.submit("blocker","joe.test",blocker)
            self.assertTrue(entered.wait(1))
            low=engine.submit("low","joe.test",mark("low"),JobPriority.LOW)
            high=engine.submit("high","joe.test",mark("high"),JobPriority.HIGH)
            release.set()
            for job in (first,low,high):
                engine._records[job].future.result(timeout=2)
            self.assertEqual(order,["blocker","high","low"])
        finally:
            release.set(); engine.shutdown()

    def test_same_priority_preserves_fifo(self):
        from threading import Event
        from journeyman.core.job_engine import JobEngine, JobPriority
        engine=JobEngine(max_workers=1); engine.register_owner("joe.test",max_active=4)
        entered=Event(); release=Event(); order=[]
        def blocker(ctx):
            entered.set(); release.wait(2)
        try:
            first=engine.submit("blocker","joe.test",blocker)
            self.assertTrue(entered.wait(1))
            a=engine.submit("a","joe.test",lambda ctx:order.append("a"),JobPriority.NORMAL)
            b=engine.submit("b","joe.test",lambda ctx:order.append("b"),JobPriority.NORMAL)
            release.set()
            for job in (first,a,b): engine._records[job].future.result(timeout=2)
            self.assertEqual(order,["a","b"])
        finally:
            release.set(); engine.shutdown()


class JobRetentionTests(unittest.TestCase):
    def test_wait_returns_terminal_snapshot(self):
        from journeyman.core.job_engine import JobEngine, JobState
        engine=JobEngine(max_workers=1); engine.register_owner("joe.test")
        try:
            job=engine.submit("wait","joe.test",lambda ctx:7)
            snapshot=engine.wait(job,timeout=2)
            self.assertEqual(snapshot.state,JobState.SUCCEEDED)
            self.assertEqual(engine.result(job),7)
        finally:
            engine.shutdown()

    def test_completed_records_are_bounded(self):
        from journeyman.core.job_engine import JobEngine
        engine=JobEngine(max_workers=1,completed_limit=2); engine.register_owner("joe.test",max_active=4)
        try:
            ids=[]
            for i in range(3):
                job=engine.submit(f"job-{i}","joe.test",lambda ctx,i=i:i)
                engine.wait(job,timeout=2)
                ids.append(job)
            snapshots=engine.snapshots()
            self.assertEqual(len(snapshots),2)
            self.assertNotIn(ids[0],[item.job_id for item in snapshots])
            self.assertEqual(engine.completed_limit,2)
        finally:
            engine.shutdown()

    def test_active_job_is_never_pruned(self):
        from threading import Event
        from journeyman.core.job_engine import JobEngine, JobState
        engine=JobEngine(max_workers=2,completed_limit=1); engine.register_owner("joe.test",max_active=4)
        entered=Event(); release=Event()
        def blocked(ctx):
            entered.set(); release.wait(2); return "active"
        try:
            active=engine.submit("active","joe.test",blocked)
            self.assertTrue(entered.wait(1))
            one=engine.submit("one","joe.test",lambda ctx:1); engine.wait(one,2)
            two=engine.submit("two","joe.test",lambda ctx:2); engine.wait(two,2)
            self.assertEqual(engine.snapshot(active).state,JobState.RUNNING)
            release.set(); engine.wait(active,2)
        finally:
            release.set(); engine.shutdown()

    def test_invalid_completed_limit_rejected(self):
        from journeyman.core.job_engine import JobEngine
        with self.assertRaises(ValueError):
            JobEngine(completed_limit=0)


class JobEngineQualificationTests(unittest.TestCase):
    def test_clean_engine_passes_qualification(self):
        from journeyman.core.job_engine import JobEngine, qualify_job_engine
        engine=JobEngine(max_workers=1); engine.register_owner("joe.test")
        try:
            job=engine.submit("qualified","joe.test",lambda ctx:11)
            engine.wait(job,2)
            result=qualify_job_engine(engine)
            self.assertTrue(result.passed,result.failures)
            self.assertEqual(result.known_jobs,1)
            self.assertEqual(result.active_jobs,0)
            self.assertEqual(result.registered_owners,1)
        finally:
            engine.shutdown()

    def test_failed_job_with_error_still_qualifies(self):
        from journeyman.core.job_engine import JobEngine, qualify_job_engine
        engine=JobEngine(max_workers=1); engine.register_owner("joe.test")
        def fail(ctx):
            raise RuntimeError("expected")
        try:
            job=engine.submit("expected-failure","joe.test",fail)
            engine.wait(job,2)
            result=qualify_job_engine(engine)
            self.assertTrue(result.passed,result.failures)
        finally:
            engine.shutdown()

    def test_corrupt_progress_is_detected(self):
        from journeyman.core.job_engine import JobEngine, qualify_job_engine
        engine=JobEngine(max_workers=1); engine.register_owner("joe.test")
        try:
            job=engine.submit("corrupt","joe.test",lambda ctx:1)
            engine.wait(job,2)
            engine._records[job].progress=2.0
            result=qualify_job_engine(engine)
            self.assertFalse(result.passed)
            self.assertTrue(any("invalid progress" in item for item in result.failures))
        finally:
            engine.shutdown()

    def test_unregistered_retained_owner_is_detected(self):
        from journeyman.core.job_engine import JobEngine, qualify_job_engine
        engine=JobEngine(max_workers=1); engine.register_owner("joe.test")
        try:
            job=engine.submit("owner","joe.test",lambda ctx:1)
            engine.wait(job,2)
            engine._owner_policies.clear()
            result=qualify_job_engine(engine)
            self.assertFalse(result.passed)
            self.assertTrue(any("unregistered owner" in item for item in result.failures))
        finally:
            engine.shutdown()


class JobEngineReleaseReadinessTests(unittest.TestCase):
    def test_clean_live_engine_passes_release_readiness(self):
        from journeyman.core.job_engine import JobEngine, joe006_release_readiness
        engine=JobEngine(max_workers=1); engine.register_owner("joe.test")
        try:
            job=engine.submit("live","joe.test",lambda ctx:5)
            engine.wait(job,2)
            before=[item.job_id for item in engine.snapshots()]
            result=joe006_release_readiness(engine)
            after=[item.job_id for item in engine.snapshots()]
            self.assertTrue(result.passed,result.failures)
            self.assertEqual(result.exercised_jobs,5)
            self.assertEqual(before,after)
        finally:
            engine.shutdown()

    def test_corrupt_live_engine_fails_release_readiness(self):
        from journeyman.core.job_engine import JobEngine, joe006_release_readiness
        engine=JobEngine(max_workers=1); engine.register_owner("joe.test")
        try:
            job=engine.submit("live","joe.test",lambda ctx:5)
            engine.wait(job,2)
            engine._records[job].progress=3.0
            result=joe006_release_readiness(engine)
            self.assertFalse(result.passed)
            self.assertTrue(any("invalid progress" in item for item in result.failures))
        finally:
            engine.shutdown()

    def test_release_readiness_does_not_require_live_jobs(self):
        from journeyman.core.job_engine import JobEngine, joe006_release_readiness
        engine=JobEngine(max_workers=1); engine.register_owner("joe.test")
        try:
            result=joe006_release_readiness(engine)
            self.assertTrue(result.passed,result.failures)
            self.assertEqual(result.lifecycle_qualification.known_jobs,0)
        finally:
            engine.shutdown()


class HostTelemetryTests(unittest.TestCase):
    def test_real_sample_has_valid_host_metrics(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.telemetry import HostTelemetry
        with tempfile.TemporaryDirectory() as tmp:
            sample=HostTelemetry(Path(tmp)).sample()
            self.assertGreater(sample.timestamp,0)
            self.assertGreaterEqual(sample.cpu_percent,0.0)
            self.assertLessEqual(sample.cpu_percent,100.0)
            self.assertGreater(sample.memory_total_bytes,0)
            self.assertGreaterEqual(sample.memory_available_bytes,0)
            self.assertGreater(sample.process_rss_bytes,0)
            self.assertGreater(sample.disk_total_bytes,0)
            self.assertGreaterEqual(sample.disk_free_bytes,0)

    def test_temperature_unavailable_is_empty_not_fake(self):
        from unittest.mock import patch
        import tempfile
        from journeyman.core.telemetry import HostTelemetry
        with tempfile.TemporaryDirectory() as tmp:
            telemetry=HostTelemetry(tmp)
            with patch("journeyman.core.telemetry.psutil.sensors_temperatures",
                       side_effect=NotImplementedError(), create=True):
                sample=telemetry.sample()
            self.assertFalse(sample.temperature_available)
            self.assertEqual(sample.temperatures,())

    def test_temperature_values_are_forwarded_from_host_api(self):
        from collections import namedtuple
        from unittest.mock import patch
        import tempfile
        from journeyman.core.telemetry import HostTelemetry
        Entry=namedtuple("Entry","label current")
        with tempfile.TemporaryDirectory() as tmp:
            telemetry=HostTelemetry(tmp)
            with patch("journeyman.core.telemetry.psutil.sensors_temperatures",
                       return_value={"cpu":[Entry("Package",47.5)]}, create=True):
                sample=telemetry.sample()
            self.assertTrue(sample.temperature_available)
            self.assertEqual(sample.temperatures[0].celsius,47.5)
            self.assertEqual(sample.temperatures[0].label,"Package")


class HostTelemetryMonitorTests(unittest.TestCase):
    def test_sample_once_retains_real_sample_and_notifies(self):
        import tempfile
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor
        with tempfile.TemporaryDirectory() as tmp:
            monitor=HostTelemetryMonitor(HostTelemetry(tmp),history_limit=2)
            seen=[]
            monitor.subscribe(seen.append)
            sample=monitor.sample_once()
            self.assertEqual(monitor.history(),(sample,))
            self.assertEqual(seen,[sample])

    def test_history_is_bounded(self):
        import tempfile
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor
        with tempfile.TemporaryDirectory() as tmp:
            monitor=HostTelemetryMonitor(HostTelemetry(tmp),history_limit=2)
            monitor.sample_once(); monitor.sample_once(); monitor.sample_once()
            self.assertEqual(len(monitor.history()),2)

    def test_bad_subscriber_does_not_block_later_subscriber(self):
        import tempfile
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor
        with tempfile.TemporaryDirectory() as tmp:
            monitor=HostTelemetryMonitor(HostTelemetry(tmp))
            seen=[]
            def bad(sample): raise RuntimeError("observer fault")
            monitor.subscribe(bad); monitor.subscribe(seen.append)
            sample=monitor.sample_once()
            self.assertEqual(seen,[sample])
            self.assertEqual(len(monitor.callback_failures()),1)
            self.assertIn("observer fault",monitor.callback_failures()[0].error)

    def test_monitor_start_stop(self):
        import tempfile, time
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor
        with tempfile.TemporaryDirectory() as tmp:
            monitor=HostTelemetryMonitor(HostTelemetry(tmp),interval_seconds=0.01)
            monitor.start()
            deadline=time.time()+1
            while not monitor.history() and time.time()<deadline:
                time.sleep(0.005)
            self.assertTrue(monitor.running)
            self.assertGreaterEqual(len(monitor.history()),1)
            monitor.stop()
            self.assertFalse(monitor.running)

    def test_invalid_monitor_settings_rejected(self):
        import tempfile
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor
        with tempfile.TemporaryDirectory() as tmp:
            telemetry=HostTelemetry(tmp)
            with self.assertRaises(ValueError): HostTelemetryMonitor(telemetry,interval_seconds=0)
            with self.assertRaises(ValueError): HostTelemetryMonitor(telemetry,history_limit=0)


class GPUTelemetryTests(unittest.TestCase):
    def test_gpu_unavailable_when_vendor_tool_missing(self):
        from unittest.mock import patch
        import tempfile
        from journeyman.core.telemetry import HostTelemetry
        with tempfile.TemporaryDirectory() as tmp:
            telemetry=HostTelemetry(tmp)
            with patch("journeyman.core.telemetry.shutil.which",return_value=None):
                sample=telemetry.sample()
            self.assertFalse(sample.gpu_available)
            self.assertEqual(sample.gpus,())

    def test_nvidia_gpu_values_are_parsed_from_real_command_shape(self):
        from unittest.mock import patch, Mock
        import tempfile
        from journeyman.core.telemetry import HostTelemetry
        completed=Mock(returncode=0,stdout="0, NVIDIA Test GPU, 37, 2048, 8192, 52\n")
        with tempfile.TemporaryDirectory() as tmp:
            telemetry=HostTelemetry(tmp)
            with patch("journeyman.core.telemetry.shutil.which",return_value="nvidia-smi"), \
                 patch("journeyman.core.telemetry.subprocess.run",return_value=completed):
                sample=telemetry.sample()
            self.assertTrue(sample.gpu_available)
            gpu=sample.gpus[0]
            self.assertEqual(gpu.index,0)
            self.assertEqual(gpu.name,"NVIDIA Test GPU")
            self.assertEqual(gpu.utilization_percent,37.0)
            self.assertEqual(gpu.memory_used_bytes,2048*1024*1024)
            self.assertEqual(gpu.memory_total_bytes,8192*1024*1024)
            self.assertEqual(gpu.temperature_celsius,52.0)
            self.assertEqual(gpu.source,"nvidia-smi")

    def test_unsupported_gpu_fields_remain_unavailable(self):
        from unittest.mock import patch, Mock
        import tempfile
        from journeyman.core.telemetry import HostTelemetry
        completed=Mock(returncode=0,stdout="0, GPU, N/A, N/A, 8192, N/A\n")
        with tempfile.TemporaryDirectory() as tmp:
            telemetry=HostTelemetry(tmp)
            with patch("journeyman.core.telemetry.shutil.which",return_value="nvidia-smi"), \
                 patch("journeyman.core.telemetry.subprocess.run",return_value=completed):
                gpu=telemetry.sample().gpus[0]
            self.assertIsNone(gpu.utilization_percent)
            self.assertIsNone(gpu.memory_used_bytes)
            self.assertIsNone(gpu.temperature_celsius)


class HostTelemetryQualificationTests(unittest.TestCase):
    def test_running_real_monitor_qualifies(self):
        import tempfile, time
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor, qualify_host_telemetry
        with tempfile.TemporaryDirectory() as tmp:
            telemetry=HostTelemetry(tmp)
            monitor=HostTelemetryMonitor(telemetry,interval_seconds=0.01)
            monitor.start()
            try:
                deadline=time.time()+1
                while not monitor.history() and time.time()<deadline:
                    time.sleep(0.005)
                result=qualify_host_telemetry(telemetry,monitor)
                self.assertTrue(result.passed,result.failures)
                self.assertTrue(result.monitor_running)
            finally:
                monitor.stop()

    def test_stopped_monitor_fails_qualification(self):
        import tempfile
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor, qualify_host_telemetry
        with tempfile.TemporaryDirectory() as tmp:
            telemetry=HostTelemetry(tmp)
            monitor=HostTelemetryMonitor(telemetry)
            result=qualify_host_telemetry(telemetry,monitor)
            self.assertFalse(result.passed)
            self.assertTrue(any("not running" in item for item in result.failures))

    def test_optional_sensor_absence_is_not_failure(self):
        from unittest.mock import patch
        import tempfile
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor, qualify_host_telemetry
        with tempfile.TemporaryDirectory() as tmp:
            telemetry=HostTelemetry(tmp)
            monitor=HostTelemetryMonitor(telemetry,interval_seconds=0.01)
            monitor.start()
            try:
                with patch.object(telemetry,"_temperatures",return_value=()), \
                     patch.object(telemetry,"_gpus",return_value=()):
                    result=qualify_host_telemetry(telemetry,monitor)
                self.assertTrue(result.passed,result.failures)
                self.assertFalse(result.temperature_available)
                self.assertFalse(result.gpu_available)
            finally:
                monitor.stop()


class HostTelemetryLatestTests(unittest.TestCase):
    def test_latest_is_none_before_first_sample(self):
        import tempfile
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor
        with tempfile.TemporaryDirectory() as tmp:
            monitor=HostTelemetryMonitor(HostTelemetry(tmp))
            self.assertIsNone(monitor.latest())

    def test_latest_returns_most_recent_sample(self):
        import tempfile
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor
        with tempfile.TemporaryDirectory() as tmp:
            monitor=HostTelemetryMonitor(HostTelemetry(tmp),history_limit=3)
            first=monitor.sample_once()
            second=monitor.sample_once()
            self.assertEqual(monitor.latest(),second)
            self.assertNotEqual(first.timestamp,0)


class HostTelemetryMonitorHealthTests(unittest.TestCase):
    def test_running_monitor_reports_fresh_sample(self):
        import tempfile, time
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor
        with tempfile.TemporaryDirectory() as tmp:
            monitor=HostTelemetryMonitor(HostTelemetry(tmp),interval_seconds=0.01)
            monitor.start()
            try:
                deadline=time.time()+1
                while monitor.latest() is None and time.time()<deadline:
                    time.sleep(0.005)
                status=monitor.status(stale_after_seconds=1.0)
                self.assertTrue(status.running)
                self.assertTrue(status.fresh)
                self.assertIsNotNone(status.latest_timestamp)
                self.assertEqual(status.acquisition_failures,0)
            finally:
                monitor.stop()

    def test_monitor_survives_acquisition_exception(self):
        import time
        from unittest.mock import Mock
        from journeyman.core.telemetry import HostTelemetryMonitor
        telemetry=Mock()
        telemetry.sample.side_effect=[RuntimeError("sensor path fault"), RuntimeError("sensor path fault")]
        monitor=HostTelemetryMonitor(telemetry,interval_seconds=0.01,failure_limit=2)
        monitor.start()
        try:
            deadline=time.time()+1
            while len(monitor.acquisition_failures()) < 1 and time.time()<deadline:
                time.sleep(0.005)
            self.assertTrue(monitor.running)
            self.assertGreaterEqual(len(monitor.acquisition_failures()),1)
            self.assertIn("sensor path fault",monitor.acquisition_failures()[0].error)
        finally:
            monitor.stop()

    def test_acquisition_failure_history_is_bounded(self):
        from unittest.mock import Mock
        from journeyman.core.telemetry import HostTelemetryMonitor
        telemetry=Mock()
        telemetry.sample.side_effect=RuntimeError("fault")
        monitor=HostTelemetryMonitor(telemetry,failure_limit=2)
        for _ in range(3):
            try:
                monitor.sample_once()
            except RuntimeError:
                # Direct sampling intentionally propagates to the caller;
                # the background loop is what records acquisition failures.
                pass
        self.assertEqual(len(monitor.acquisition_failures()),0)

    def test_status_rejects_invalid_stale_threshold(self):
        import tempfile
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor
        with tempfile.TemporaryDirectory() as tmp:
            monitor=HostTelemetryMonitor(HostTelemetry(tmp))
            with self.assertRaises(ValueError):
                monitor.status(stale_after_seconds=0)


class HostTelemetryReleaseReadinessTests(unittest.TestCase):
    def test_running_monitor_passes_release_readiness(self):
        import tempfile, time
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor, joe007_release_readiness
        with tempfile.TemporaryDirectory() as tmp:
            telemetry=HostTelemetry(tmp)
            monitor=HostTelemetryMonitor(telemetry,interval_seconds=0.01)
            monitor.start()
            try:
                deadline=time.time()+1
                while len(monitor.history()) < 2 and time.time()<deadline:
                    time.sleep(0.005)
                result=joe007_release_readiness(telemetry,monitor)
                self.assertTrue(result.passed,result.failures)
                self.assertGreaterEqual(result.qualification.retained_samples,1)
                self.assertEqual(result.acquisition_failures,0)
            finally:
                monitor.stop()

    def test_stopped_monitor_fails_release_readiness(self):
        import tempfile
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor, joe007_release_readiness
        with tempfile.TemporaryDirectory() as tmp:
            telemetry=HostTelemetry(tmp)
            monitor=HostTelemetryMonitor(telemetry)
            result=joe007_release_readiness(telemetry,monitor)
            self.assertFalse(result.passed)
            self.assertTrue(any("not running" in item for item in result.failures))

    def test_optional_gpu_and_temperature_absence_do_not_fail_release(self):
        import tempfile, time
        from unittest.mock import patch
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor, joe007_release_readiness
        with tempfile.TemporaryDirectory() as tmp:
            telemetry=HostTelemetry(tmp)
            monitor=HostTelemetryMonitor(telemetry,interval_seconds=0.01)
            with patch.object(telemetry,"_temperatures",return_value=()), \
                 patch.object(telemetry,"_gpus",return_value=()):
                monitor.start()
                try:
                    deadline=time.time()+1
                    while monitor.latest() is None and time.time()<deadline:
                        time.sleep(0.005)
                    result=joe007_release_readiness(telemetry,monitor)
                finally:
                    monitor.stop()
            self.assertTrue(result.passed,result.failures)
            self.assertFalse(result.qualification.temperature_available)
            self.assertFalse(result.qualification.gpu_available)


class ScientificDataStreamEngineTests(unittest.TestCase):
    def test_register_publish_and_read_real_stream(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine(history_limit_per_stream=3)
        definition=engine.register(
            "test.temperature","Test Temperature","°C",float,
            DataOrigin.SIMULATION,"test.producer",
        )
        sample=engine.publish("test.temperature",12.5,source="test.producer")
        self.assertEqual(definition.origin,DataOrigin.SIMULATION)
        self.assertEqual(sample.sequence,1)
        self.assertEqual(sample.value,12.5)
        self.assertEqual(engine.latest("test.temperature"),sample)

    def test_origin_cannot_be_relabelled_at_publish_time(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("host.cpu","CPU","%",float,DataOrigin.HOST,"joe.core")
        with self.assertRaises(ValueError):
            engine.publish(
                "host.cpu",10.0,source="joe.core",origin=DataOrigin.SIMULATION
            )

    def test_wrong_source_cannot_publish(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("host.cpu","CPU","%",float,DataOrigin.HOST,"joe.core")
        with self.assertRaises(PermissionError):
            engine.publish("host.cpu",10.0,source="other.module")

    def test_history_is_bounded_and_sequences_continue(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine(history_limit_per_stream=2)
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        for value in (1.0,2.0,3.0):
            engine.publish("sim.x",value,source="sim.engine")
        history=engine.history("sim.x")
        self.assertEqual([sample.sequence for sample in history],[2,3])
        self.assertEqual([sample.value for sample in history],[2.0,3.0])

    def test_backward_timestamp_is_rejected(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        engine.publish("sim.x",1.0,source="sim.engine",timestamp=100.0)
        with self.assertRaises(ValueError):
            engine.publish("sim.x",2.0,source="sim.engine",timestamp=99.0)

    def test_subscriber_failure_is_isolated(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        seen=[]
        def bad(sample): raise RuntimeError("consumer fault")
        engine.subscribe("sim.x",bad)
        engine.subscribe("sim.x",seen.append)
        sample=engine.publish("sim.x",1.0,source="sim.engine")
        self.assertEqual(seen,[sample])
        self.assertEqual(len(engine.callback_failures()),1)
        self.assertIn("consumer fault",engine.callback_failures()[0].error)

    def test_metadata_is_normalized_and_immutable(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("imported.x","Imported X","m",float,DataOrigin.IMPORTED,"import.loader")
        sample=engine.publish(
            "imported.x",4.0,source="import.loader",
            metadata={"file":"dataset.csv","column":2},
        )
        self.assertEqual(sample.metadata,(("column","2"),("file","dataset.csv")))

    def test_builtin_stream_service_is_published(self):
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        runtime=ModuleRuntime()
        register_builtin_modules(runtime)
        try:
            streams=runtime.service("joe.streams")
            stream_ids={definition.stream_id for definition in streams.definitions()}
            self.assertTrue({
                "host.cpu.utilization",
                "host.memory.utilization",
                "host.memory.available",
                "host.process.rss",
                "host.storage.utilization",
                "host.storage.free",
            }.issubset(stream_ids))
        finally:
            runtime.stop("joe.core")


class HostTelemetryStreamBridgeTests(unittest.TestCase):
    def test_builtin_host_streams_are_registered_and_receive_samples(self):
        import time
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.state_events import DataOrigin
        runtime=ModuleRuntime()
        register_builtin_modules(runtime)
        try:
            streams=runtime.service("joe.streams")
            monitor=runtime.service("joe.host-telemetry-monitor")
            deadline=time.time()+1
            while streams.latest("host.cpu.utilization") is None and time.time()<deadline:
                time.sleep(0.005)
            sample=streams.latest("host.cpu.utilization")
            self.assertIsNotNone(sample)
            self.assertEqual(sample.origin,DataOrigin.HOST)
            self.assertEqual(sample.source,"joe.core")
            self.assertIsInstance(sample.value,float)
            self.assertGreaterEqual(sample.value,0.0)
            self.assertLessEqual(sample.value,100.0)
            self.assertIsNotNone(monitor.latest())
        finally:
            runtime.stop("joe.core")

    def test_required_host_stream_values_match_same_monitor_sample(self):
        import time
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        runtime=ModuleRuntime()
        register_builtin_modules(runtime)
        try:
            streams=runtime.service("joe.streams")
            monitor=runtime.service("joe.host-telemetry-monitor")
            deadline=time.time()+1
            while monitor.latest() is None and time.time()<deadline:
                time.sleep(0.005)
            host=monitor.latest()
            deadline=time.time()+1
            while (streams.latest("host.memory.available") is None or
                   streams.latest("host.memory.available").timestamp < host.timestamp) and time.time()<deadline:
                time.sleep(0.005)
            self.assertEqual(streams.latest("host.memory.available").value,host.memory_available_bytes)
            self.assertEqual(streams.latest("host.process.rss").value,host.process_rss_bytes)
            self.assertEqual(streams.latest("host.storage.free").value,host.disk_free_bytes)
        finally:
            runtime.stop("joe.core")

    def test_optional_gpu_streams_are_not_predeclared_without_gpu_sample(self):
        from unittest.mock import patch
        import tempfile
        from journeyman.core.telemetry import HostTelemetry, HostTelemetryMonitor
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        # Engine itself never invents optional device streams.
        engine=ScientificDataStreamEngine()
        engine.register("host.cpu.utilization","CPU","%",float,DataOrigin.HOST,"joe.core")
        self.assertFalse(any(d.stream_id.startswith("host.gpu.") for d in engine.definitions()))
        with tempfile.TemporaryDirectory() as tmp:
            telemetry=HostTelemetry(tmp)
            with patch.object(telemetry,"_gpus",return_value=()):
                self.assertFalse(telemetry.sample().gpu_available)


class ScientificDataFrameTests(unittest.TestCase):
    def test_frame_channels_share_timestamp_and_frame_identity(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        engine.register("sim.y","Y","m",float,DataOrigin.SIMULATION,"sim.engine")
        samples=engine.publish_frame(
            {"sim.x":1.0,"sim.y":2.0},source="sim.engine",timestamp=123.5
        )
        self.assertEqual(len(samples),2)
        self.assertEqual({sample.timestamp for sample in samples},{123.5})
        self.assertEqual(len({sample.frame_id for sample in samples}),1)
        self.assertIsNotNone(samples[0].frame_id)

    def test_invalid_frame_is_rejected_before_any_channel_is_published(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        engine.register("sim.y","Y","m",float,DataOrigin.SIMULATION,"sim.engine")
        with self.assertRaises(TypeError):
            engine.publish_frame({"sim.x":1.0,"sim.y":"bad"},source="sim.engine")
        self.assertIsNone(engine.latest("sim.x"))
        self.assertIsNone(engine.latest("sim.y"))

    def test_frame_rejects_mixed_authoritative_sources_without_partial_publish(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("host.x","X","m",float,DataOrigin.HOST,"joe.core")
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        with self.assertRaises(PermissionError):
            engine.publish_frame({"host.x":1.0,"sim.x":2.0},source="joe.core")
        self.assertIsNone(engine.latest("host.x"))
        self.assertIsNone(engine.latest("sim.x"))

    def test_host_required_streams_share_coherent_frame(self):
        import time
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        runtime=ModuleRuntime()
        register_builtin_modules(runtime)
        try:
            streams=runtime.service("joe.streams")
            ids=[
                "host.cpu.utilization","host.memory.utilization",
                "host.memory.available","host.process.rss",
                "host.storage.utilization","host.storage.free",
            ]
            deadline=time.time()+1
            while streams.latest(ids[0]) is None and time.time()<deadline:
                time.sleep(0.005)
            samples=[streams.latest(sid) for sid in ids]
            self.assertTrue(all(sample is not None for sample in samples))
            self.assertEqual(len({sample.frame_id for sample in samples}),1)
            self.assertEqual(len({sample.timestamp for sample in samples}),1)
        finally:
            runtime.stop("joe.core")


class ScientificDataAtomicFrameTests(unittest.TestCase):
    def test_frame_subscriber_receives_one_complete_frame(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        engine.register("sim.y","Y","m",float,DataOrigin.SIMULATION,"sim.engine")
        frames=[]
        engine.subscribe_frames(frames.append)
        samples=engine.publish_frame({"sim.x":1.0,"sim.y":2.0},source="sim.engine")
        self.assertEqual(len(frames),1)
        self.assertEqual(frames[0].samples,samples)
        self.assertEqual({s.stream_id for s in frames[0].samples},{"sim.x","sim.y"})
        self.assertEqual(frames[0].frame_id,samples[0].frame_id)

    def test_frame_callback_failure_does_not_block_stream_callbacks(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        seen=[]
        engine.subscribe("sim.x",seen.append)
        def bad(frame): raise RuntimeError("frame consumer fault")
        engine.subscribe_frames(bad)
        sample=engine.publish_frame({"sim.x":3.0},source="sim.engine")[0]
        self.assertEqual(seen,[sample])
        self.assertEqual(len(engine.callback_failures()),1)
        self.assertEqual(engine.callback_failures()[0].stream_id,"<frame>")

    def test_unsubscribe_frame_consumer(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        frames=[]
        engine.subscribe_frames(frames.append)
        engine.unsubscribe_frames(frames.append)
        engine.publish_frame({"sim.x":1.0},source="sim.engine")
        self.assertEqual(frames,[])

    def test_frame_sequences_advance_per_stream(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        engine.register("sim.y","Y","m",float,DataOrigin.SIMULATION,"sim.engine")
        first=engine.publish_frame({"sim.x":1.0,"sim.y":2.0},source="sim.engine")
        second=engine.publish_frame({"sim.x":3.0,"sim.y":4.0},source="sim.engine")
        self.assertEqual([s.sequence for s in first],[1,1])
        self.assertEqual([s.sequence for s in second],[2,2])
        self.assertNotEqual(first[0].frame_id,second[0].frame_id)


class ScientificDataStreamQualificationTests(unittest.TestCase):
    def test_empty_engine_is_internally_valid(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine, qualify_scientific_data_streams
        result=qualify_scientific_data_streams(ScientificDataStreamEngine())
        self.assertTrue(result.passed,result.failures)
        self.assertEqual(result.status.registered_streams,0)

    def test_populated_engine_qualifies(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine, qualify_scientific_data_streams
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        engine.publish("sim.x",1.0,source="sim.engine",timestamp=10.0)
        engine.publish("sim.x",2.0,source="sim.engine",timestamp=11.0)
        result=qualify_scientific_data_streams(engine)
        self.assertTrue(result.passed,result.failures)
        self.assertEqual(result.status.registered_streams,1)
        self.assertEqual(result.status.retained_samples,2)
        self.assertEqual(result.status.origins,(("SIMULATION",1),))

    def test_qualification_detects_corrupt_retained_provenance(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine, StreamSample, qualify_scientific_data_streams
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("host.x","X","m",float,DataOrigin.HOST,"joe.core")
        engine._history["host.x"].append(
            StreamSample("host.x",1,10.0,1.0,DataOrigin.SIMULATION,"joe.core")
        )
        result=qualify_scientific_data_streams(engine)
        self.assertFalse(result.passed)
        self.assertTrue(any("provenance mismatch" in item for item in result.failures))

    def test_live_builtin_stream_engine_qualifies(self):
        import time
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.data_streams import qualify_scientific_data_streams
        runtime=ModuleRuntime()
        register_builtin_modules(runtime)
        try:
            streams=runtime.service("joe.streams")
            deadline=time.time()+1
            while streams.latest("host.cpu.utilization") is None and time.time()<deadline:
                time.sleep(0.005)
            result=qualify_scientific_data_streams(streams)
            self.assertTrue(result.passed,result.failures)
            self.assertGreaterEqual(result.status.streams_with_samples,6)
        finally:
            runtime.stop("joe.core")


class ScientificDataStreamCursorTests(unittest.TestCase):
    def test_incremental_read_returns_only_newer_samples(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        for value in (1.0,2.0,3.0):
            engine.publish("sim.x",value,source="sim.engine")
        read=engine.read_since("sim.x",after_sequence=1)
        self.assertEqual([s.sequence for s in read.samples],[2,3])
        self.assertEqual(read.next_sequence,3)
        self.assertFalse(read.gap_detected)

    def test_retention_gap_is_explicit(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine(history_limit_per_stream=2)
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        for value in (1.0,2.0,3.0,4.0):
            engine.publish("sim.x",value,source="sim.engine")
        read=engine.read_since("sim.x",after_sequence=1)
        self.assertTrue(read.gap_detected)
        self.assertEqual(read.oldest_available_sequence,3)
        self.assertEqual(read.newest_available_sequence,4)
        self.assertEqual([s.sequence for s in read.samples],[3,4])

    def test_cursor_limit_supports_chunked_consumption(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        for value in range(5):
            engine.publish("sim.x",float(value),source="sim.engine")
        first=engine.read_since("sim.x",0,limit=2)
        second=engine.read_since("sim.x",first.next_sequence,limit=2)
        third=engine.read_since("sim.x",second.next_sequence,limit=2)
        self.assertEqual([s.sequence for s in first.samples],[1,2])
        self.assertEqual([s.sequence for s in second.samples],[3,4])
        self.assertEqual([s.sequence for s in third.samples],[5])

    def test_empty_stream_cursor_read_is_valid(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("host.x","X","m",float,DataOrigin.HOST,"joe.core")
        read=engine.read_since("host.x")
        self.assertEqual(read.samples,())
        self.assertEqual(read.next_sequence,0)
        self.assertFalse(read.gap_detected)
        self.assertIsNone(read.oldest_available_sequence)

    def test_invalid_cursor_arguments_are_rejected(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        with self.assertRaises(ValueError):
            engine.read_since("sim.x",-1)
        with self.assertRaises(ValueError):
            engine.read_since("sim.x",0,limit=0)


class ScientificDataStreamReleaseReadinessTests(unittest.TestCase):
    def test_release_readiness_passes_valid_engine_without_polluting_it(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine, joe008_release_readiness
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("host.x","X","m",float,DataOrigin.HOST,"joe.core")
        engine.publish("host.x",1.0,source="joe.core",timestamp=10.0)
        before=engine.history("host.x")
        result=joe008_release_readiness(engine)
        self.assertTrue(result.passed,result.failures)
        self.assertEqual(result.exercise_frames,128)
        self.assertEqual(result.exercise_samples,256)
        self.assertEqual(engine.history("host.x"),before)
        self.assertEqual(len(engine.definitions()),1)

    def test_release_readiness_propagates_live_integrity_failure(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine, StreamSample, joe008_release_readiness
        from journeyman.core.state_events import DataOrigin
        engine=ScientificDataStreamEngine()
        engine.register("host.x","X","m",float,DataOrigin.HOST,"joe.core")
        engine._history["host.x"].append(
            StreamSample("host.x",1,10.0,1.0,DataOrigin.SIMULATION,"joe.core")
        )
        result=joe008_release_readiness(engine)
        self.assertFalse(result.passed)
        self.assertFalse(result.live_qualification.passed)

    def test_live_builtin_engine_release_readiness(self):
        import time
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.data_streams import joe008_release_readiness
        runtime=ModuleRuntime()
        register_builtin_modules(runtime)
        try:
            streams=runtime.service("joe.streams")
            deadline=time.time()+1
            while streams.latest("host.cpu.utilization") is None and time.time()<deadline:
                time.sleep(0.005)
            result=joe008_release_readiness(streams)
            self.assertTrue(result.passed,result.failures)
            self.assertGreaterEqual(result.live_qualification.status.streams_with_samples,6)
        finally:
            runtime.stop("joe.core")


class VisualizationEngineTests(unittest.TestCase):
    def test_numeric_stream_discovery_and_time_series_projection(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X Position","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams.publish("sim.x",1.0,source="sim.engine",timestamp=10.0)
        streams.publish("sim.x",2.0,source="sim.engine",timestamp=11.0)
        viz=VisualizationEngine(streams)
        self.assertEqual(viz.numeric_stream_ids(),("sim.x",))
        view=viz.time_series(["sim.x"])
        self.assertEqual(view.common_unit,"m")
        self.assertEqual(view.traces[0].values,(1.0,2.0))
        self.assertEqual(view.traces[0].timestamps,(10.0,11.0))
        self.assertEqual(view.traces[0].origin,"SIMULATION")

    def test_mixed_units_are_not_claimed_as_common(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams.register("sim.t","T","s",float,DataOrigin.SIMULATION,"sim.engine")
        viz=VisualizationEngine(streams)
        self.assertIsNone(viz.time_series(["sim.x","sim.t"]).common_unit)

    def test_non_numeric_stream_rejected_for_time_series(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("software.state","State","",str,DataOrigin.SOFTWARE,"joe.core")
        viz=VisualizationEngine(streams)
        with self.assertRaises(TypeError):
            viz.time_series(["software.state"])

    def test_builtin_visualization_service_uses_canonical_stream_engine(self):
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        runtime=ModuleRuntime()
        register_builtin_modules(runtime)
        try:
            streams=runtime.service("joe.streams")
            viz=runtime.service("joe.visualization")
            self.assertIs(viz.streams,streams)
            self.assertIn("host.cpu.utilization",viz.numeric_stream_ids())
        finally:
            runtime.stop("joe.core")


class VisualizationMultiTraceTests(unittest.TestCase):
    def test_multiple_same_unit_traces_project_together(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams.register("sim.y","Y","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams.publish_frame({"sim.x":1.0,"sim.y":2.0},source="sim.engine",timestamp=10.0)
        streams.publish_frame({"sim.x":3.0,"sim.y":4.0},source="sim.engine",timestamp=11.0)
        view=VisualizationEngine(streams).time_series(["sim.x","sim.y"])
        self.assertEqual(len(view.traces),2)
        self.assertEqual(view.common_unit,"m")
        self.assertEqual(view.traces[0].segments,((0,2),))
        self.assertEqual(view.traces[1].segments,((0,2),))

    def test_sequence_gap_creates_separate_plot_segments(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine, StreamSample
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams._history["sim.x"]=[
            StreamSample("sim.x",1,10.0,1.0,DataOrigin.SIMULATION,"sim.engine"),
            StreamSample("sim.x",3,12.0,3.0,DataOrigin.SIMULATION,"sim.engine"),
        ]
        view=VisualizationEngine(streams).time_series(["sim.x"])
        trace=view.traces[0]
        self.assertTrue(trace.gap_detected)
        self.assertEqual(trace.segments,((0,1),(1,2)))

    def test_nonfinite_values_are_not_plotted(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams.publish("sim.x",1.0,source="sim.engine",timestamp=10.0)
        streams.publish("sim.x",float("nan"),source="sim.engine",timestamp=11.0)
        streams.publish("sim.x",2.0,source="sim.engine",timestamp=12.0)
        trace=VisualizationEngine(streams).time_series(["sim.x"]).traces[0]
        self.assertEqual(trace.values,(1.0,2.0))
        self.assertTrue(trace.gap_detected)
        self.assertEqual(trace.segments,((0,1),(1,2)))


class VisualizationSynchronizedWindowTests(unittest.TestCase):
    def test_window_uses_common_latest_timestamp_across_traces(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams.register("sim.y","Y","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams.publish("sim.x",1.0,source="sim.engine",timestamp=100.0)
        streams.publish("sim.x",2.0,source="sim.engine",timestamp=110.0)
        streams.publish("sim.y",3.0,source="sim.engine",timestamp=105.0)
        streams.publish("sim.y",4.0,source="sim.engine",timestamp=120.0)
        view=VisualizationEngine(streams).time_series(
            ["sim.x","sim.y"],window_seconds=15.0
        )
        self.assertEqual(view.window_start,105.0)
        self.assertEqual(view.window_end,120.0)
        self.assertEqual(view.traces[0].timestamps,(110.0,))
        self.assertEqual(view.traces[1].timestamps,(105.0,120.0))

    def test_explicit_end_timestamp_supports_reproducible_window(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        for ts in (10.0,20.0,30.0,40.0):
            streams.publish("sim.x",ts,source="sim.engine",timestamp=ts)
        view=VisualizationEngine(streams).time_series(
            ["sim.x"],window_seconds=15.0,end_timestamp=30.0
        )
        self.assertEqual(view.window_start,15.0)
        self.assertEqual(view.window_end,30.0)
        self.assertEqual(view.traces[0].timestamps,(20.0,30.0))

    def test_all_retained_mode_has_no_window_bounds(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams.publish("sim.x",1.0,source="sim.engine",timestamp=10.0)
        view=VisualizationEngine(streams).time_series(["sim.x"])
        self.assertIsNone(view.window_start)
        self.assertIsNone(view.window_end)

    def test_invalid_time_windows_are_rejected(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        viz=VisualizationEngine(streams)
        for bad in (0,-1,float("inf"),float("nan")):
            with self.assertRaises(ValueError):
                viz.time_series(["sim.x"],window_seconds=bad)


class VisualizationAnalysisPlotTests(unittest.TestCase):
    def test_scatter_pairs_only_exact_timestamps(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams.register("sim.y","Y","s",float,DataOrigin.SIMULATION,"sim.engine")
        streams.publish("sim.x",1.0,source="sim.engine",timestamp=10.0)
        streams.publish("sim.x",2.0,source="sim.engine",timestamp=20.0)
        streams.publish("sim.y",3.0,source="sim.engine",timestamp=10.0)
        streams.publish("sim.y",4.0,source="sim.engine",timestamp=21.0)
        view=VisualizationEngine(streams).scatter("sim.x","sim.y")
        self.assertEqual(view.x_values,(1.0,))
        self.assertEqual(view.y_values,(3.0,))
        self.assertEqual(view.timestamps,(10.0,))

    def test_histogram_counts_all_finite_values(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        for i,value in enumerate((0.0,1.0,2.0,3.0),start=1):
            streams.publish("sim.x",value,source="sim.engine",timestamp=float(i))
        view=VisualizationEngine(streams).histogram("sim.x",bins=2)
        self.assertEqual(view.sample_count,4)
        self.assertEqual(sum(view.counts),4)
        self.assertEqual(len(view.bin_edges),3)

    def test_histogram_constant_series_is_valid(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("host.x","X","%",float,DataOrigin.HOST,"joe.core")
        for i in range(3):
            streams.publish("host.x",5.0,source="joe.core",timestamp=float(i+1))
        view=VisualizationEngine(streams).histogram("host.x",bins=4)
        self.assertEqual(sum(view.counts),3)
        self.assertGreater(view.bin_edges[-1],view.bin_edges[0])

    def test_empty_histogram_does_not_synthesize_bins(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("host.x","X","%",float,DataOrigin.HOST,"joe.core")
        view=VisualizationEngine(streams).histogram("host.x")
        self.assertEqual(view.counts,())
        self.assertEqual(view.bin_edges,())
        self.assertEqual(view.sample_count,0)


class VisualizationNumericInstrumentTests(unittest.TestCase):
    def test_numeric_instrument_preserves_value_and_provenance(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("host.cpu","CPU","%",float,DataOrigin.HOST,"joe.core")
        sample=streams.publish("host.cpu",42.5,source="joe.core",timestamp=10.0)
        view=VisualizationEngine(streams).numeric_instrument("host.cpu")
        self.assertTrue(view.available)
        self.assertEqual(view.value,42.5)
        self.assertEqual(view.origin,"HOST")
        self.assertEqual(view.source,"joe.core")
        self.assertEqual(view.timestamp,10.0)
        self.assertEqual(view.sequence,sample.sequence)

    def test_empty_numeric_instrument_is_explicitly_unavailable(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("hardware.temp","Temperature","C",float,DataOrigin.HARDWARE,"instrument.1")
        view=VisualizationEngine(streams).numeric_instrument("hardware.temp")
        self.assertFalse(view.available)
        self.assertIsNone(view.value)
        self.assertIsNone(view.timestamp)

    def test_nonfinite_latest_value_is_not_displayed_as_measurement(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams.publish("sim.x",float("nan"),source="sim.engine",timestamp=10.0)
        view=VisualizationEngine(streams).numeric_instrument("sim.x")
        self.assertFalse(view.available)
        self.assertIsNone(view.value)
        self.assertEqual(view.timestamp,10.0)

    def test_non_numeric_instrument_is_rejected(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("software.mode","Mode","",str,DataOrigin.SOFTWARE,"joe.core")
        with self.assertRaises(TypeError):
            VisualizationEngine(streams).numeric_instrument("software.mode")


class VisualizationMatrixHeatmapTests(unittest.TestCase):
    def test_heatmap_uses_only_complete_coherent_frames(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams.register("sim.y","Y","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams.publish_frame({"sim.x":1.0,"sim.y":2.0},source="sim.engine",timestamp=10.0)
        streams.publish_frame({"sim.x":3.0,"sim.y":4.0},source="sim.engine",timestamp=11.0)
        view=VisualizationEngine(streams).matrix_heatmap(["sim.x","sim.y"])
        self.assertEqual(len(view.frame_ids),2)
        self.assertEqual(view.values,((1.0,2.0),(3.0,4.0)))
        self.assertEqual(view.origins,("SIMULATION","SIMULATION"))

    def test_heatmap_does_not_pair_unframed_samples(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("host.x","X","%",float,DataOrigin.HOST,"joe.core")
        streams.register("host.y","Y","%",float,DataOrigin.HOST,"joe.core")
        streams.publish("host.x",1.0,source="joe.core",timestamp=10.0)
        streams.publish("host.y",2.0,source="joe.core",timestamp=10.0)
        view=VisualizationEngine(streams).matrix_heatmap(["host.x","host.y"])
        self.assertEqual(view.frame_ids,())
        self.assertEqual(view.values,())

    def test_heatmap_frame_limit_keeps_latest_complete_frames(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim.engine")
        streams.register("sim.y","Y","m",float,DataOrigin.SIMULATION,"sim.engine")
        for i in range(5):
            streams.publish_frame({"sim.x":float(i),"sim.y":float(i+10)},
                                  source="sim.engine",timestamp=float(i+1))
        view=VisualizationEngine(streams).matrix_heatmap(["sim.x","sim.y"],frame_limit=2)
        self.assertEqual(len(view.frame_ids),2)
        self.assertEqual(view.values,((3.0,13.0),(4.0,14.0)))

    def test_heatmap_rejects_non_numeric_channel(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("software.mode","Mode","",str,DataOrigin.SOFTWARE,"joe.core")
        with self.assertRaises(TypeError):
            VisualizationEngine(streams).matrix_heatmap(["software.mode"])


class VisualizationFieldTests(unittest.TestCase):
    def test_field_points_require_complete_coherent_xyz_frames(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        for sid,name,unit in (("sim.x","X","m"),("sim.y","Y","m"),("sim.z","Potential","J")):
            streams.register(sid,name,unit,float,DataOrigin.SIMULATION,"sim.field")
        streams.publish_frame(
            {"sim.x":1.0,"sim.y":2.0,"sim.z":3.0},source="sim.field",timestamp=10.0
        )
        streams.publish_frame(
            {"sim.x":4.0,"sim.y":5.0,"sim.z":6.0},source="sim.field",timestamp=11.0
        )
        view=VisualizationEngine(streams).field_points("sim.x","sim.y","sim.z")
        self.assertEqual(len(view.points),2)
        self.assertEqual((view.points[0].x,view.points[0].y,view.points[0].z),(1.0,2.0,3.0))
        self.assertEqual(view.origins,("SIMULATION","SIMULATION","SIMULATION"))
        self.assertEqual(view.sources,("sim.field","sim.field","sim.field"))

    def test_field_points_do_not_pair_unframed_equal_timestamps(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        for sid in ("x","y","z"):
            streams.register(sid,sid,"m",float,DataOrigin.IMPORTED,"dataset")
            streams.publish(sid,1.0,source="dataset",timestamp=10.0)
        view=VisualizationEngine(streams).field_points("x","y","z")
        self.assertEqual(view.points,())

    def test_field_points_reject_duplicate_axes(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("x","X","m",float,DataOrigin.SIMULATION,"sim")
        streams.register("y","Y","m",float,DataOrigin.SIMULATION,"sim")
        with self.assertRaises(ValueError):
            VisualizationEngine(streams).field_points("x","y","x")

    def test_field_points_skip_nonfinite_component(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        for sid in ("x","y","z"):
            streams.register(sid,sid,"m",float,DataOrigin.SIMULATION,"sim")
        streams.publish_frame({"x":1.0,"y":2.0,"z":float("nan")},
                              source="sim",timestamp=10.0)
        view=VisualizationEngine(streams).field_points("x","y","z")
        self.assertEqual(view.points,())


class VisualizationDisplayTraceTests(unittest.TestCase):
    def test_display_trace_decimates_without_mutating_stream(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim")
        for i in range(100):
            streams.publish("sim.x",float(i),source="sim",timestamp=float(i+1))
        view=VisualizationEngine(streams).display_trace("sim.x",limit=100,max_points=10)
        self.assertTrue(view.decimated)
        self.assertEqual(view.source_count,100)
        self.assertEqual(view.displayed_count,10)
        self.assertEqual(view.timestamps[0],1.0)
        self.assertEqual(view.timestamps[-1],100.0)
        self.assertEqual(len(streams.history("sim.x")),100)

    def test_display_trace_range_selection_is_inclusive(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim")
        for i in range(1,11):
            streams.publish("sim.x",float(i),source="sim",timestamp=float(i))
        view=VisualizationEngine(streams).display_trace(
            "sim.x",start_timestamp=3.0,end_timestamp=6.0
        )
        self.assertEqual(view.timestamps,(3.0,4.0,5.0,6.0))
        self.assertFalse(view.decimated)

    def test_display_decimation_does_not_create_false_gap_segments(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim")
        for i in range(50):
            streams.publish("sim.x",float(i),source="sim",timestamp=float(i+1))
        view=VisualizationEngine(streams).display_trace("sim.x",max_points=5)
        self.assertEqual(view.segments,((0,5),))

    def test_display_trace_rejects_reversed_time_range(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim")
        with self.assertRaises(ValueError):
            VisualizationEngine(streams).display_trace(
                "sim.x",start_timestamp=20.0,end_timestamp=10.0
            )


class VisualizationWorkspacePersistenceTests(unittest.TestCase):
    def test_visualization_kind_and_state_round_trip(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry, save_layout, load_layout
        from pathlib import Path
        import tempfile
        wid="12345678-1234-5678-1234-567812345678"
        state={"streams":["host.cpu.utilization","host.memory.utilization"],
               "window_seconds":60.0,"paused":True}
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"layout.json"
            save_layout([WorkspaceLayoutEntry(
                "live_time_series","Live",False,"abc",False,wid,False,False,state
            )],path)
            rows=load_layout(path)
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0].kind,"live_time_series")
        self.assertEqual(rows[0].state,state)

    def test_all_visualization_workspace_kinds_are_persistable(self):
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry, save_layout, load_layout
        from pathlib import Path
        import tempfile
        kinds=("live_time_series","analysis_plot","numeric_instrument",
               "matrix_heatmap","scientific_field")
        rows=[
            WorkspaceLayoutEntry(kind,kind,False,"",False,
                f"00000000-0000-4000-8000-{i:012d}",False,False,{"marker":kind})
            for i,kind in enumerate(kinds,1)
        ]
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"layout.json"
            save_layout(rows,path)
            loaded=load_layout(path)
        self.assertEqual(tuple(row.kind for row in loaded),kinds)
        self.assertEqual(tuple(row.state["marker"] for row in loaded),kinds)

    def test_schema5_layout_remains_backward_compatible(self):
        from journeyman.core.workspace_layout import load_layout
        from pathlib import Path
        import tempfile, json
        payload={"schema":5,"workspaces":[{
            "kind":"overview","title":"Overview","external":False,
            "geometry_b64":"","maximized":False,
            "workspace_id":"12345678-1234-5678-1234-567812345678",
            "locked":False,"minimized":False
        }]}
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"layout.json"
            path.write_text(json.dumps(payload),encoding="utf-8")
            loaded=load_layout(path)
        self.assertEqual(len(loaded),1)
        self.assertIsNone(loaded[0].state)

    def test_non_dict_workspace_state_is_discarded_on_load(self):
        from journeyman.core.workspace_layout import load_layout
        from pathlib import Path
        import tempfile, json
        payload={"schema":6,"workspaces":[{
            "kind":"numeric_instrument","title":"Instrument","external":False,
            "geometry_b64":"","workspace_id":"12345678-1234-5678-1234-567812345678",
            "state":["not","valid"]
        }]}
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"layout.json"
            path.write_text(json.dumps(payload),encoding="utf-8")
            loaded=load_layout(path)
        self.assertEqual(len(loaded),1)
        self.assertIsNone(loaded[0].state)


class VisualizationExportTests(unittest.TestCase):
    def test_time_series_export_preserves_provenance_and_samples(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("host.cpu","CPU","%",float,DataOrigin.HOST,"joe.core")
        streams.publish("host.cpu",10.5,source="joe.core",timestamp=1.0)
        streams.publish("host.cpu",11.5,source="joe.core",timestamp=2.0)
        export=VisualizationEngine(streams).export_time_series(["host.cpu"])
        self.assertEqual(export.metadata["sample_count"],2)
        self.assertEqual(export.rows[0][0],"host.cpu")
        self.assertEqual(export.rows[0][3],"HOST")
        self.assertEqual(export.rows[0][4],"joe.core")
        self.assertEqual(export.rows[1][7],11.5)

    def test_csv_export_is_parseable_and_contains_no_synthetic_rows(self):
        import csv, io
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("import.x","X","m",float,DataOrigin.IMPORTED,"dataset")
        streams.publish("import.x",3.25,source="dataset",timestamp=5.0)
        engine=VisualizationEngine(streams)
        export=engine.export_time_series(["import.x"])
        rows=list(csv.reader(io.StringIO(engine.export_csv_text(export))))
        self.assertEqual(rows[0][0],"stream_id")
        self.assertEqual(len(rows),2)
        self.assertEqual(rows[1][3],"IMPORTED")
        self.assertEqual(rows[1][7],"3.25")

    def test_export_range_is_inclusive(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim")
        for i in range(1,6):
            streams.publish("sim.x",float(i),source="sim",timestamp=float(i))
        export=VisualizationEngine(streams).export_time_series(
            ["sim.x"],start_timestamp=2.0,end_timestamp=4.0
        )
        self.assertEqual(tuple(row[6] for row in export.rows),(2.0,3.0,4.0))

    def test_metadata_json_contains_stream_provenance(self):
        import json
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine
        streams=ScientificDataStreamEngine()
        streams.register("hardware.v","Voltage","V",float,DataOrigin.HARDWARE,"daq.1")
        engine=VisualizationEngine(streams)
        export=engine.export_time_series(["hardware.v"])
        metadata=json.loads(engine.export_metadata_json(export))
        self.assertEqual(metadata["streams"][0]["origin"],"HARDWARE")
        self.assertEqual(metadata["streams"][0]["source"],"daq.1")
        self.assertEqual(metadata["sample_count"],0)


class VisualizationQualificationTests(unittest.TestCase):
    def test_empty_live_engine_qualification_is_valid(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.visualization import VisualizationEngine, qualify_visualization_engine
        result=qualify_visualization_engine(VisualizationEngine(ScientificDataStreamEngine()))
        self.assertTrue(result.passed)
        self.assertFalse(result.failures)

    def test_live_qualification_checks_registered_provenance(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine, qualify_visualization_engine
        streams=ScientificDataStreamEngine()
        streams.register("host.cpu","CPU","%",float,DataOrigin.HOST,"joe.core")
        streams.publish("host.cpu",25.0,source="joe.core",timestamp=1.0)
        result=qualify_visualization_engine(VisualizationEngine(streams))
        self.assertTrue(result.passed)
        self.assertGreaterEqual(len(result.checks),3)

    def test_release_readiness_isolated_exercise_passes(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.visualization import VisualizationEngine, joe009_release_readiness
        live=VisualizationEngine(ScientificDataStreamEngine())
        result=joe009_release_readiness(live)
        self.assertTrue(result.passed,result.notes)
        self.assertEqual(result.exercise_frames,256)
        self.assertEqual(result.exercise_samples,768)
        self.assertEqual(result.displayed_points,64)
        self.assertEqual(result.exported_samples,768)
        self.assertGreater(result.high_rate_samples,result.high_rate_displayed)
        self.assertLessEqual(result.high_rate_displayed,1200)

    def test_release_readiness_does_not_pollute_live_streams(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.visualization import VisualizationEngine, joe009_release_readiness
        streams=ScientificDataStreamEngine()
        streams.register("host.cpu","CPU","%",float,DataOrigin.HOST,"joe.core")
        streams.publish("host.cpu",10.0,source="joe.core",timestamp=1.0)
        before=tuple(d.stream_id for d in streams.definitions())
        joe009_release_readiness(VisualizationEngine(streams))
        after=tuple(d.stream_id for d in streams.definitions())
        self.assertEqual(after,before)
        self.assertNotIn("qualification.x",after)


class VisualizationPackagingQualificationTests(unittest.TestCase):
    def test_launcher_probes_visualization_dependencies(self):
        from journeyman.core.paths import ROOT
        text=(ROOT/"Launch_Journeyman.bat").read_text(encoding="utf-8").lower()
        self.assertIn("pyqtgraph",text)
        self.assertIn("numpy",text)
        self.assertIn("requirements.txt",text)

    def test_requirements_declare_visualization_dependencies(self):
        from journeyman.core.paths import ROOT
        text=(ROOT/"requirements.txt").read_text(encoding="utf-8").lower()
        self.assertIn("pyqtgraph",text)
        self.assertIn("numpy",text)


class RunRecorderTests(unittest.TestCase):
    def test_run_lifecycle_persists_manifest_and_events(self):
        from journeyman.core.run_recorder import RunRecorder, RunState
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("Qualification",mode="SIMULATION",source="test",metadata={"case":"A"})
            recorder.append_event(run.run_id,"STEP",{"value":42})
            finished=recorder.finish(run.run_id,RunState.COMPLETED,metadata_update={"result":"pass"})
            self.assertEqual(finished.state,RunState.COMPLETED)
            self.assertEqual(finished.event_count,1)
            self.assertEqual(finished.sample_count,0)
            self.assertEqual(finished.snapshot_count,0)
            self.assertEqual(finished.association_count,0)
            self.assertEqual(finished.metadata,{"case":"A","result":"pass"})
            self.assertEqual(recorder.events(run.run_id)[0]["payload"]["value"],42)

    def test_run_mode_is_explicit_and_validated(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            with self.assertRaises(ValueError): recorder.start("Bad",mode="REALISH",source="test")
            self.assertEqual(recorder.start("Host",mode="HOST",source="joe.core").mode,"HOST")

    def test_terminal_run_rejects_mutation(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td)); run=recorder.start("Run",mode="SOFTWARE",source="test")
            recorder.finish(run.run_id)
            with self.assertRaises(RuntimeError): recorder.append_event(run.run_id,"LATE")
            with self.assertRaises(RuntimeError): recorder.finish(run.run_id)

    def test_list_runs_ignores_unrelated_directories(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/"not-a-run").mkdir(); recorder=RunRecorder(root)
            run=recorder.start("One",mode="IMPORTED",source="dataset")
            self.assertEqual(tuple(r.run_id for r in recorder.list_runs()),(run.run_id,))

    def test_event_sequences_are_monotonic(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td)); run=recorder.start("Events",mode="SOFTWARE",source="test")
            for i in range(5): recorder.append_event(run.run_id,"ITEM",{"i":i})
            self.assertEqual(tuple(e["sequence"] for e in recorder.events(run.run_id)),(1,2,3,4,5))


class RunStreamCaptureTests(unittest.TestCase):
    def test_capture_retained_stream_preserves_provenance(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            streams=ScientificDataStreamEngine()
            streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"model.a")
            streams.publish("sim.x",1.25,source="model.a",timestamp=1.0)
            streams.publish("sim.x",2.50,source="model.a",timestamp=2.0)
            recorder=RunRecorder(Path(td))
            run=recorder.start("Simulation",mode="SIMULATION",source="model.a")
            self.assertEqual(recorder.capture_retained_streams(run.run_id,streams,["sim.x"]),2)
            rows=recorder.samples(run.run_id)
            self.assertEqual(len(rows),2)
            self.assertEqual(rows[0]["origin"],"SIMULATION")
            self.assertEqual(rows[0]["source"],"model.a")
            self.assertEqual(rows[1]["value"],2.5)
            self.assertEqual(recorder.get(run.run_id).sample_count,2)

    def test_capture_rejects_provenance_mismatch(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.data_streams import ScientificDataStreamEngine, StreamSample
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            streams=ScientificDataStreamEngine()
            definition=streams.register("host.x","X","%",float,DataOrigin.HOST,"joe.core")
            recorder=RunRecorder(Path(td))
            run=recorder.start("Host",mode="HOST",source="joe.core")
            bad=StreamSample("host.x",1,1.0,4.0,DataOrigin.SIMULATION,"joe.core",{},None)
            with self.assertRaises(ValueError):
                recorder.capture_stream_sample(run.run_id,definition,bad)

    def test_empty_stream_capture_creates_no_fake_samples(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            streams=ScientificDataStreamEngine()
            streams.register("hardware.temp","Temperature","C",float,DataOrigin.HARDWARE,"sensor.1")
            recorder=RunRecorder(Path(td))
            run=recorder.start("Hardware",mode="HARDWARE",source="sensor.1")
            self.assertEqual(recorder.capture_retained_streams(run.run_id,streams,["hardware.temp"]),0)
            self.assertEqual(recorder.samples(run.run_id),())
            self.assertEqual(recorder.get(run.run_id).sample_count,0)

    def test_terminal_run_rejects_sample_capture(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            streams=ScientificDataStreamEngine()
            definition=streams.register("software.x","X","1",float,DataOrigin.SOFTWARE,"test")
            sample=streams.publish("software.x",1.0,source="test",timestamp=1.0)
            recorder=RunRecorder(Path(td))
            run=recorder.start("Done",mode="SOFTWARE",source="test")
            recorder.finish(run.run_id)
            with self.assertRaises(RuntimeError):
                recorder.capture_stream_sample(run.run_id,definition,sample)


class RunSnapshotTests(unittest.TestCase):
    def test_configuration_snapshot_is_persistent_and_immutable(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("Configured Run",mode="SIMULATION",source="experiment.designer")
            payload={"solver":{"step_s":0.01},"mouths":{"enabled":False}}
            snap=recorder.capture_snapshot(
                run.run_id,"CONFIGURATION",payload,source="joe.config",revision=7
            )
            payload["solver"]["step_s"]=99
            restored=recorder.snapshots(run.run_id)[0]
            self.assertEqual(restored["payload"]["solver"]["step_s"],0.01)
            self.assertEqual(restored["revision"],7)
            self.assertEqual(restored["source"],"joe.config")
            self.assertEqual(recorder.get(run.run_id).snapshot_count,1)

    def test_multiple_snapshot_types_are_ordered(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("Run",mode="SOFTWARE",source="test")
            recorder.capture_snapshot(run.run_id,"CONFIGURATION",{"a":1})
            recorder.capture_snapshot(run.run_id,"PARAMETERS",{"b":2},revision="mpr-12")
            snaps=recorder.snapshots(run.run_id)
            self.assertEqual(tuple(s["sequence"] for s in snaps),(1,2))
            self.assertEqual(tuple(s["type"] for s in snaps),("CONFIGURATION","PARAMETERS"))
            self.assertEqual(snaps[1]["revision"],"mpr-12")

    def test_snapshot_rejects_non_json_and_nonfinite_values(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("Run",mode="SOFTWARE",source="test")
            with self.assertRaises(TypeError):
                recorder.capture_snapshot(run.run_id,"CONFIGURATION",{"bad":object()})
            with self.assertRaises(TypeError):
                recorder.capture_snapshot(run.run_id,"CONFIGURATION",{"bad":float("nan")})
            self.assertEqual(recorder.get(run.run_id).snapshot_count,0)

    def test_terminal_run_rejects_snapshot(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("Run",mode="SOFTWARE",source="test")
            recorder.finish(run.run_id)
            with self.assertRaises(RuntimeError):
                recorder.capture_snapshot(run.run_id,"CONFIGURATION",{"x":1})

    def test_snapshot_manifest_indexes_durable_file(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile, json
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("Run",mode="IMPORTED",source="dataset")
            recorder.capture_snapshot(run.run_id,"IMPORT_DESCRIPTOR",{"file":"observation.csv"})
            manifest=json.loads((Path(run.directory)/"manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["snapshot_count"],1)
            entry=manifest["snapshots"][0]
            self.assertTrue((Path(run.directory)/entry["file"]).exists())


class RunIntegrityTests(unittest.TestCase):
    def test_new_and_completed_run_pass_integrity(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("Run",mode="SOFTWARE",source="test")
            self.assertTrue(recorder.verify_integrity(run.run_id).passed)
            recorder.append_event(run.run_id,"STEP",{"x":1})
            recorder.capture_snapshot(run.run_id,"CONFIGURATION",{"a":2})
            recorder.finish(run.run_id)
            report=recorder.verify_integrity(run.run_id)
            self.assertTrue(report.passed,report.failures)
            self.assertGreaterEqual(report.checked_files,3)

    def test_modified_event_journal_is_detected(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("Run",mode="SOFTWARE",source="test")
            recorder.append_event(run.run_id,"STEP",{"x":1})
            path=Path(run.directory)/"events.jsonl"
            path.write_text(path.read_text(encoding="utf-8")+"tamper\\n",encoding="utf-8")
            report=recorder.verify_integrity(run.run_id)
            self.assertFalse(report.passed)
            self.assertIn("hash mismatch: events.jsonl",report.failures)

    def test_modified_sample_file_is_detected(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            streams=ScientificDataStreamEngine()
            definition=streams.register("sim.x","X","m",float,DataOrigin.SIMULATION,"sim")
            sample=streams.publish("sim.x",1.0,source="sim",timestamp=1.0)
            recorder=RunRecorder(Path(td)); run=recorder.start("Run",mode="SIMULATION",source="sim")
            recorder.capture_stream_sample(run.run_id,definition,sample)
            path=Path(run.directory)/"samples.jsonl"
            path.write_text("",encoding="utf-8")
            self.assertFalse(recorder.verify_integrity(run.run_id).passed)

    def test_missing_snapshot_is_detected(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile, json
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td)); run=recorder.start("Run",mode="SOFTWARE",source="test")
            recorder.capture_snapshot(run.run_id,"CONFIGURATION",{"x":1})
            manifest=json.loads((Path(run.directory)/"manifest.json").read_text(encoding="utf-8"))
            (Path(run.directory)/manifest["snapshots"][0]["file"]).unlink()
            report=recorder.verify_integrity(run.run_id)
            self.assertFalse(report.passed)
            self.assertTrue(any(item.startswith("missing file:") for item in report.failures))

    def test_unindexed_payload_file_is_detected(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td)); run=recorder.start("Run",mode="SOFTWARE",source="test")
            (Path(run.directory)/"mystery.bin").write_bytes(b"unexpected")
            report=recorder.verify_integrity(run.run_id)
            self.assertFalse(report.passed)
            self.assertIn("unindexed file: mystery.bin",report.failures)


class RunAssociationTests(unittest.TestCase):
    def test_run_associations_persist_with_provenance(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("Compute",mode="SOFTWARE",source="experiment.designer")
            row=recorder.associate(
                run.run_id,"JOB","job-123",source="joe.jobs",
                metadata={"purpose":"solver execution"}
            )
            self.assertEqual(row["type"],"JOB")
            self.assertEqual(row["identifier"],"job-123")
            restored=recorder.associations(run.run_id)
            self.assertEqual(restored[0]["source"],"joe.jobs")
            self.assertEqual(restored[0]["metadata"]["purpose"],"solver execution")
            self.assertEqual(recorder.get(run.run_id).association_count,1)

    def test_association_types_can_be_filtered(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("Run",mode="SIMULATION",source="designer")
            recorder.associate(run.run_id,"JOB","j1")
            recorder.associate(run.run_id,"MODULE","digital-twin")
            recorder.associate(run.run_id,"SESSION","s1")
            self.assertEqual(len(recorder.associations(run.run_id)),3)
            self.assertEqual(recorder.associations(run.run_id,"job")[0]["identifier"],"j1")

    def test_duplicate_association_is_rejected(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("Run",mode="SOFTWARE",source="test")
            recorder.associate(run.run_id,"JOB","same")
            with self.assertRaises(ValueError):
                recorder.associate(run.run_id,"JOB","same")
            self.assertEqual(recorder.get(run.run_id).association_count,1)

    def test_terminal_run_rejects_new_association(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("Run",mode="SOFTWARE",source="test")
            recorder.finish(run.run_id)
            with self.assertRaises(RuntimeError):
                recorder.associate(run.run_id,"JOB","late")

    def test_association_metadata_must_be_strict_json(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("Run",mode="SOFTWARE",source="test")
            with self.assertRaises(TypeError):
                recorder.associate(run.run_id,"JOB","j1",metadata={"x":float("inf")})
            self.assertEqual(recorder.get(run.run_id).association_count,0)


class RunRecorderQualificationTests(unittest.TestCase):
    def test_empty_live_recorder_qualifies(self):
        from journeyman.core.run_recorder import RunRecorder, qualify_run_recorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            result=qualify_run_recorder(RunRecorder(Path(td)))
            self.assertTrue(result.passed,result.failures)

    def test_populated_recorder_qualifies(self):
        from journeyman.core.run_recorder import RunRecorder, qualify_run_recorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("Run",mode="SOFTWARE",source="test")
            r.append_event(run.run_id,"STEP",{"x":1}); r.capture_snapshot(run.run_id,"CONFIGURATION",{"x":1})
            r.associate(run.run_id,"JOB","j1"); r.finish(run.run_id)
            q=qualify_run_recorder(r); self.assertTrue(q.passed,q.failures)

    def test_release_readiness_exercises_full_contract(self):
        from journeyman.core.run_recorder import RunRecorder, joe010_release_readiness
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            result=joe010_release_readiness(RunRecorder(Path(td)))
            self.assertTrue(result.passed,result.notes)
            self.assertEqual((result.exercise_events,result.exercise_samples,
                              result.exercise_snapshots,result.exercise_associations),(2,128,1,2))
            self.assertGreaterEqual(result.integrity_files,3)

    def test_release_readiness_does_not_pollute_live_recorder(self):
        from journeyman.core.run_recorder import RunRecorder, joe010_release_readiness
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); before=r.list_runs(); result=joe010_release_readiness(r)
            self.assertTrue(result.passed,result.notes); self.assertEqual(before,r.list_runs())


class RunRecoveryTests(unittest.TestCase):
    def test_interrupted_active_run_is_closed_failed(self):
        from journeyman.core.run_recorder import RunRecorder, RunState
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("Interrupted",mode="SIMULATION",source="sim")
            r.append_event(run.run_id,"START",{})
            report=r.recover_interrupted_run(run.run_id)
            self.assertTrue(report.recovered)
            restored=r.get(run.run_id)
            self.assertEqual(restored.state,RunState.FAILED)
            self.assertIsNotNone(restored.ended_at)
            self.assertTrue(restored.metadata["recovery"]["interrupted"])
            self.assertEqual(r.events(run.run_id)[-1]["type"],"RUN_RECOVERED_INTERRUPTED")
            self.assertTrue(r.verify_integrity(run.run_id).passed)

    def test_recovery_does_not_mutate_completed_run(self):
        from journeyman.core.run_recorder import RunRecorder, RunState
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("Done",mode="SOFTWARE",source="test")
            r.finish(run.run_id)
            report=r.recover_interrupted_run(run.run_id)
            self.assertFalse(report.recovered)
            self.assertEqual(r.get(run.run_id).state,RunState.COMPLETED)

    def test_recover_all_only_closes_active_runs(self):
        from journeyman.core.run_recorder import RunRecorder, RunState
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td))
            active=r.start("Active",mode="SOFTWARE",source="test")
            done=r.start("Done",mode="SOFTWARE",source="test"); r.finish(done.run_id)
            reports=r.recover_all_interrupted()
            self.assertEqual(len(reports),1)
            self.assertEqual(reports[0].run_id,active.run_id)
            self.assertEqual(r.get(done.run_id).state,RunState.COMPLETED)

    def test_recovered_run_qualifies(self):
        from journeyman.core.run_recorder import RunRecorder, qualify_run_recorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("Interrupted",mode="HARDWARE",source="device")
            r.recover_interrupted_run(run.run_id,reason="process termination")
            q=qualify_run_recorder(r)
            self.assertTrue(q.passed,q.failures)


class RunRecorderFinalizationTests(unittest.TestCase):
    def test_status_reports_real_run_states(self):
        from journeyman.core.run_recorder import RunRecorder, RunState
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td))
            active=r.start("Active",mode="SOFTWARE",source="test")
            complete=r.start("Complete",mode="SOFTWARE",source="test"); r.finish(complete.run_id)
            failed=r.start("Failed",mode="SOFTWARE",source="test"); r.finish(failed.run_id,RunState.FAILED)
            cancelled=r.start("Cancelled",mode="SOFTWARE",source="test"); r.finish(cancelled.run_id,RunState.CANCELLED)
            st=r.status()
            self.assertEqual((st.total_runs,st.active_runs,st.completed_runs,st.failed_runs,st.cancelled_runs),(4,1,1,1,1))
            self.assertEqual(st.active_run_ids,(active.run_id,))

    def test_release_readiness_preserves_live_active_state(self):
        from journeyman.core.run_recorder import RunRecorder, joe010_release_readiness
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); live=r.start("Live",mode="HOST",source="joe.core")
            before=r.status(); result=joe010_release_readiness(r); after=r.status()
            self.assertTrue(result.passed,result.notes)
            self.assertEqual(before,after); self.assertEqual(after.active_run_ids,(live.run_id,))

    def test_status_empty_repository(self):
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            st=RunRecorder(Path(td)).status()
            self.assertEqual(st.total_runs,0); self.assertEqual(st.active_run_ids,())


class RunReviewServiceTests(unittest.TestCase):
    def test_review_summary_reads_canonical_record(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("Review",mode="SIMULATION",source="test")
            r.append_event(run.run_id,"START",{"phase":1}); r.capture_snapshot(run.run_id,"CONFIGURATION",{"x":1})
            r.associate(run.run_id,"JOB","j1"); r.finish(run.run_id)
            summary=RunReviewService(r).open_run(run.run_id)
            self.assertEqual((len(summary.events),len(summary.snapshots),len(summary.associations)),(1,1,1))
            self.assertTrue(summary.integrity.passed)

    def test_review_discovers_stream_ids_and_filters_samples(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("Review",mode="SIMULATION",source="producer")
            e=ScientificDataStreamEngine()
            a=e.register("a","A","m",float,DataOrigin.SIMULATION,"producer")
            b=e.register("b","B","s",float,DataOrigin.SIMULATION,"producer")
            r.capture_stream_sample(run.run_id,a,e.publish("a",1.0,source="producer",timestamp=1.0))
            r.capture_stream_sample(run.run_id,b,e.publish("b",2.0,source="producer",timestamp=1.0))
            review=RunReviewService(r)
            self.assertEqual(review.open_run(run.run_id).stream_ids,("a","b"))
            self.assertEqual(review.samples_for_stream(run.run_id,"a")[0]["value"],1.0)

    def test_review_indexes_actual_record_types(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("Review",mode="SOFTWARE",source="test")
            r.append_event(run.run_id,"B",{}); r.append_event(run.run_id,"A",{})
            r.capture_snapshot(run.run_id,"PARAMETERS",{"x":1}); r.associate(run.run_id,"MODULE","m1")
            review=RunReviewService(r)
            self.assertEqual(review.event_types(run.run_id),("A","B"))
            self.assertEqual(review.snapshot_types(run.run_id),("PARAMETERS",))
            self.assertEqual(review.association_types(run.run_id),("MODULE",))

    def test_empty_review_has_no_synthetic_content(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            self.assertEqual(RunReviewService(RunRecorder(Path(td))).list_runs(),())


class RunReviewFilteringTests(unittest.TestCase):
    def test_event_filter_by_type_source_and_limit(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("R",mode="SOFTWARE",source="test")
            r.append_event(run.run_id,"STEP",{"n":1},source="a")
            r.append_event(run.run_id,"STEP",{"n":2},source="b")
            r.append_event(run.run_id,"DONE",{},source="a")
            review=RunReviewService(r)
            self.assertEqual(len(review.filter_events(run.run_id,event_type="STEP")),2)
            self.assertEqual(len(review.filter_events(run.run_id,source="a")),2)
            self.assertEqual(review.filter_events(run.run_id,limit=1)[0]["type"],"DONE")

    def test_sample_filter_preserves_provenance_and_time_window(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("R",mode="SIMULATION",source="producer")
            e=ScientificDataStreamEngine(); d=e.register("x","X","m",float,DataOrigin.SIMULATION,"producer")
            for i in range(5):
                r.capture_stream_sample(run.run_id,d,e.publish("x",float(i),source="producer",timestamp=10.0+i))
            rows=RunReviewService(r).filter_samples(run.run_id,stream_id="x",origin="SIMULATION",start_timestamp=11,end_timestamp=13)
            self.assertEqual([x["value"] for x in rows],[1.0,2.0,3.0])
            self.assertTrue(all(x["origin"]=="SIMULATION" and x["source"]=="producer" for x in rows))

    def test_filter_rejects_invalid_ranges_and_limits(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("R",mode="SOFTWARE",source="test"); review=RunReviewService(r)
            with self.assertRaises(ValueError):review.filter_samples(run.run_id,start_timestamp=2,end_timestamp=1)
            with self.assertRaises(ValueError):review.filter_events(run.run_id,limit=-1)

    def test_sources_derived_only_from_recorded_content(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("R",mode="SOFTWARE",source="root")
            r.append_event(run.run_id,"E",{},source="events"); r.associate(run.run_id,"JOB","j",source="jobs")
            self.assertEqual(RunReviewService(r).sources(run.run_id),("events","jobs"))


class RunReviewVisualizationTests(unittest.TestCase):
    def test_recorded_numeric_stream_projects_to_visualization(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("Recorded",mode="SIMULATION",source="producer")
            live=ScientificDataStreamEngine(); d=live.register("x","Position","m",float,DataOrigin.SIMULATION,"producer")
            for i in range(4):
                r.capture_stream_sample(run.run_id,d,live.publish("x",float(i),source="producer",timestamp=100+i))
            view=RunReviewService(r).recorded_time_series(run.run_id,["x"])
            self.assertEqual(view.traces[0].values,(0.0,1.0,2.0,3.0))
            self.assertEqual(view.traces[0].timestamps,(100.0,101.0,102.0,103.0))
            self.assertEqual(view.traces[0].origin,"SIMULATION")

    def test_recorded_visualization_is_isolated_from_live_stream_engine(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("Recorded",mode="HOST",source="host")
            e=ScientificDataStreamEngine(); d=e.register("cpu","CPU","%",float,DataOrigin.HOST,"host")
            r.capture_stream_sample(run.run_id,d,e.publish("cpu",12.0,source="host",timestamp=1.0))
            projected=RunReviewService(r).visualization_for_run(run.run_id)
            self.assertEqual(projected.numeric_stream_ids(),("cpu",))
            self.assertEqual(e.history("cpu")[0].value,12.0)

    def test_non_numeric_recorded_stream_not_falsely_plottable(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("Recorded",mode="SOFTWARE",source="producer")
            e=ScientificDataStreamEngine(); d=e.register("state","State","",str,DataOrigin.SOFTWARE,"producer")
            r.capture_stream_sample(run.run_id,d,e.publish("state","READY",source="producer",timestamp=1.0))
            projected=RunReviewService(r).visualization_for_run(run.run_id)
            self.assertEqual(projected.numeric_stream_ids(),())


class RunReviewComparisonExportTests(unittest.TestCase):
    def test_compare_runs_reports_stream_sets_and_counts(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); e=ScientificDataStreamEngine()
            a=e.register("a","A","m",float,DataOrigin.SIMULATION,"sim")
            b=e.register("b","B","s",float,DataOrigin.SIMULATION,"sim")
            c=e.register("c","C","K",float,DataOrigin.SIMULATION,"sim")
            left=r.start("L",mode="SIMULATION",source="sim")
            r.capture_stream_sample(left.run_id,a,e.publish("a",1.0,source="sim",timestamp=1))
            r.capture_stream_sample(left.run_id,b,e.publish("b",2.0,source="sim",timestamp=1))
            right=r.start("R",mode="SIMULATION",source="sim")
            r.capture_stream_sample(right.run_id,b,e.publish("b",3.0,source="sim",timestamp=2))
            r.capture_stream_sample(right.run_id,c,e.publish("c",4.0,source="sim",timestamp=2))
            comp=RunReviewService(r).compare_runs(left.run_id,right.run_id)
            self.assertEqual(comp.common_stream_ids,("b",))
            self.assertEqual(comp.left_only_stream_ids,("a",)); self.assertEqual(comp.right_only_stream_ids,("c",))
            self.assertTrue(comp.mode_equal and comp.source_equal)

    def test_samples_csv_is_deterministic_and_preserves_provenance(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile,csv,io
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("R",mode="HOST",source="host")
            e=ScientificDataStreamEngine(); d=e.register("cpu","CPU","%",float,DataOrigin.HOST,"host")
            r.capture_stream_sample(run.run_id,d,e.publish("cpu",42.5,source="host",timestamp=5.0))
            text=RunReviewService(r).export_samples_csv(run.run_id)
            rows=list(csv.DictReader(io.StringIO(text)))
            self.assertEqual(rows[0]["stream_id"],"cpu"); self.assertEqual(rows[0]["origin"],"HOST")
            self.assertEqual(rows[0]["source"],"host"); self.assertEqual(rows[0]["value"],"42.5")

    def test_events_csv_serializes_payload_without_losing_structure(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from pathlib import Path
        import tempfile,csv,io,json
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); run=r.start("R",mode="SOFTWARE",source="test")
            r.append_event(run.run_id,"CHECK",{"ok":True,"n":3},source="validator")
            row=list(csv.DictReader(io.StringIO(RunReviewService(r).export_events_csv(run.run_id))))[0]
            self.assertEqual(row["type"],"CHECK"); self.assertEqual(json.loads(row["payload"]),{"n":3,"ok":True})


class RunReviewReproducibilityTests(unittest.TestCase):
    def _record_two_streams(self,root):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        r=RunRecorder(root); run=r.start("R",mode="SIMULATION",source="sim")
        e=ScientificDataStreamEngine()
        a=e.register("a","A","m",float,DataOrigin.SIMULATION,"sim")
        b=e.register("b","B","m",float,DataOrigin.SIMULATION,"sim")
        for i in range(3):
            r.capture_stream_sample(run.run_id,a,e.publish("a",float(i),source="sim",timestamp=10+i))
            r.capture_stream_sample(run.run_id,b,e.publish("b",float(i+10),source="sim",timestamp=10+i))
        return r,run

    def test_multi_stream_recorded_plot_preserves_both_traces(self):
        from journeyman.core.run_review import RunReviewService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r,run=self._record_two_streams(Path(td)); review=RunReviewService(r)
            spec=review.create_plot_spec(run.run_id,("a","b"))
            view=review.render_plot_spec(spec)
            self.assertEqual(tuple(x.stream_id for x in view.traces),("a","b"))
            self.assertEqual(view.traces[0].values,(0.0,1.0,2.0))
            self.assertEqual(view.traces[1].values,(10.0,11.0,12.0))

    def test_plot_spec_json_round_trip_is_reproducible(self):
        from journeyman.core.run_review import RunReviewService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r,run=self._record_two_streams(Path(td)); review=RunReviewService(r)
            spec=review.create_plot_spec(run.run_id,("b","a"),limit=123,title="Comparison")
            text=review.export_plot_spec_json(spec)
            restored=review.import_plot_spec_json(text)
            self.assertEqual(restored,spec)
            self.assertEqual(review.export_plot_spec_json(restored),text)

    def test_plot_spec_rejects_missing_stream_and_duplicates(self):
        from journeyman.core.run_review import RunReviewService,ReviewPlotSpec
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r,run=self._record_two_streams(Path(td)); review=RunReviewService(r)
            with self.assertRaises(KeyError):review.create_plot_spec(run.run_id,("missing",))
            with self.assertRaises(ValueError):ReviewPlotSpec(run.run_id,("a","a"))

    def test_plot_spec_schema_rejects_unknown_version(self):
        from journeyman.core.run_review import RunReviewService
        with self.assertRaises(ValueError):
            RunReviewService.import_plot_spec_json('{"schema_version":99,"run_id":"r","stream_ids":["x"]}')


class RunReviewQualificationTests(unittest.TestCase):
    def test_empty_repository_qualifies_without_fabricating_runs(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService,qualify_run_review
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            review=RunReviewService(RunRecorder(Path(td)))
            self.assertTrue(qualify_run_review(review).passed)
            self.assertEqual(review.list_runs(),())

    def test_release_readiness_isolated_exercise_passes(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService,joe011_release_readiness
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            review=RunReviewService(RunRecorder(Path(td)))
            result=joe011_release_readiness(review)
            self.assertTrue(result.passed,result.failures)
            self.assertTrue(result.qualification_passed)
            self.assertTrue(result.isolated_exercise_passed)
            self.assertEqual(review.list_runs(),())

    def test_qualification_detects_integrity_failure(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService,qualify_run_review
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); recorder=RunRecorder(root)
            run=recorder.start("R",mode="SOFTWARE",source="test")
            recorder.append_event(run.run_id,"E",{})
            recorder.finish(run.run_id)
            (root/run.run_id/"events.jsonl").write_text("corrupt\\n",encoding="utf-8")
            result=qualify_run_review(RunReviewService(recorder))
            self.assertFalse(result.passed)
            self.assertTrue(any("integrity failed" in x for x in result.failures))


class RunReviewFinalHardeningTests(unittest.TestCase):
    def test_status_counts_real_repository_without_creating_records(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td))
            a=r.start("A",mode="SOFTWARE",source="test"); r.finish(a.run_id)
            b=r.start("B",mode="SIMULATION",source="test")
            review=RunReviewService(r); status=review.status()
            self.assertEqual(status.total_runs,2); self.assertEqual(status.readable_runs,2)
            self.assertEqual(status.integrity_passed_runs,2); self.assertEqual(status.integrity_failed_runs,0)
            self.assertEqual(dict(status.states),{"ACTIVE":1,"COMPLETED":1})
            self.assertEqual(len(review.list_runs()),2)

    def test_status_reports_corrupt_record_as_failed_and_unreadable(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); r=RunRecorder(root)
            run=r.start("R",mode="SOFTWARE",source="test")
            r.append_event(run.run_id,"E",{}); r.finish(run.run_id)
            (root/run.run_id/"events.jsonl").write_text("corrupt\\n",encoding="utf-8")
            status=RunReviewService(r).status()
            self.assertEqual(status.total_runs,1); self.assertEqual(status.readable_runs,0)
            self.assertEqual(status.integrity_failed_runs,1)

    def test_release_readiness_does_not_pollute_existing_repository(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.run_review import RunReviewService,joe011_release_readiness
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            r=RunRecorder(Path(td)); existing=r.start("Existing",mode="SOFTWARE",source="test"); r.finish(existing.run_id)
            before=tuple(x.run_id for x in r.list_runs())
            result=joe011_release_readiness(RunReviewService(r))
            after=tuple(x.run_id for x in r.list_runs())
            self.assertTrue(result.passed,result.failures); self.assertEqual(before,after)


class ProjectSessionServiceTests(unittest.TestCase):
    def test_project_and_session_persist_across_service_restart(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); service=ProjectSessionService(root)
            p=service.create_project("Chronology","C-1 research")
            sess=service.create_session(p.project_id,"Baseline")
            reopened=ProjectSessionService(root)
            self.assertEqual(reopened.project(p.project_id).name,"Chronology")
            self.assertEqual(reopened.sessions(p.project_id)[0].session_id,sess.session_id)

    def test_close_session_then_archive_project(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            service=ProjectSessionService(Path(td));p=service.create_project("P")
            sess=service.create_session(p.project_id,"S")
            with self.assertRaises(RuntimeError):service.archive_project(p.project_id)
            closed=service.close_session(sess.session_id);self.assertFalse(closed.active)
            archived=service.archive_project(p.project_id);self.assertTrue(archived.archived)

    def test_archived_project_rejects_new_session(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            service=ProjectSessionService(Path(td));p=service.create_project("P")
            service.archive_project(p.project_id)
            with self.assertRaises(RuntimeError):service.create_session(p.project_id,"S")

    def test_status_uses_only_persisted_records(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            service=ProjectSessionService(Path(td))
            self.assertEqual(service.status().projects,0)
            p=service.create_project("P");s=service.create_session(p.project_id,"S")
            st=service.status();self.assertEqual((st.projects,st.sessions,st.active_sessions),(1,1,1))
            service.close_session(s.session_id);st=service.status()
            self.assertEqual((st.active_sessions,st.closed_sessions),(0,1))

    def test_names_are_required(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            service=ProjectSessionService(Path(td))
            with self.assertRaises(ValueError):service.create_project(" ")


class ProjectSessionRunBindingTests(unittest.TestCase):
    def test_bind_active_run_creates_project_and_session_provenance(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); recorder=RunRecorder(root/"runs")
            service=ProjectSessionService(root/"projects",recorder)
            p=service.create_project("P");sess=service.create_session(p.project_id,"S")
            run=recorder.start("R",mode="SOFTWARE",source="test")
            context=service.bind_run(run.run_id,p.project_id,sess.session_id)
            self.assertEqual(context["project"].project_id,p.project_id)
            self.assertEqual(context["session"].session_id,sess.session_id)
            links=recorder.associations(run.run_id)
            self.assertEqual(tuple(x["type"] for x in links),("PROJECT","SESSION"))

    def test_binding_rejects_closed_session_and_completed_run(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);recorder=RunRecorder(root/"runs");service=ProjectSessionService(root/"projects",recorder)
            p=service.create_project("P");closed=service.create_session(p.project_id,"Closed");service.close_session(closed.session_id)
            run=recorder.start("R",mode="SOFTWARE",source="test")
            with self.assertRaises(RuntimeError):service.bind_run(run.run_id,p.project_id,closed.session_id)
            active=service.create_session(p.project_id,"Active");recorder.finish(run.run_id)
            with self.assertRaises(RuntimeError):service.bind_run(run.run_id,p.project_id,active.session_id)

    def test_run_queries_follow_persisted_associations(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);recorder=RunRecorder(root/"runs");service=ProjectSessionService(root/"projects",recorder)
            p=service.create_project("P");sess=service.create_session(p.project_id,"S")
            r1=recorder.start("R1",mode="SOFTWARE",source="test");service.bind_run(r1.run_id,p.project_id,sess.session_id)
            r2=recorder.start("R2",mode="SOFTWARE",source="test")
            self.assertEqual(tuple(x.run_id for x in service.runs_for_session(sess.session_id)),(r1.run_id,))
            self.assertEqual(tuple(x.run_id for x in service.runs_for_project(p.project_id)),(r1.run_id,))
            self.assertIsNone(service.run_context(r2.run_id))

    def test_duplicate_organization_binding_is_rejected(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);recorder=RunRecorder(root/"runs");service=ProjectSessionService(root/"projects",recorder)
            p=service.create_project("P");sess=service.create_session(p.project_id,"S")
            run=recorder.start("R",mode="SOFTWARE",source="test");service.bind_run(run.run_id,p.project_id,sess.session_id)
            with self.assertRaises(RuntimeError):service.bind_run(run.run_id,p.project_id,sess.session_id)


class ProjectSessionWorkspaceSnapshotTests(unittest.TestCase):
    def test_workspace_snapshot_persists_and_is_defensive_copy(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry,entries_from_snapshot
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);service=ProjectSessionService(root);p=service.create_project("P");sess=service.create_session(p.project_id,"S")
            entry=WorkspaceLayoutEntry("overview","Overview",False,"",workspace_id="11111111-1111-1111-1111-111111111111")
            snap=service.save_workspace_snapshot(sess.session_id,[entry])
            self.assertEqual(snap["schema"],6);self.assertEqual(entries_from_snapshot(snap)[0].kind,"overview")
            snap["workspaces"].clear()
            reopened=ProjectSessionService(root)
            self.assertEqual(len(reopened.workspace_snapshot(sess.session_id)["workspaces"]),1)

    def test_closed_session_rejects_workspace_update_but_preserves_snapshot(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            service=ProjectSessionService(Path(td));p=service.create_project("P");sess=service.create_session(p.project_id,"S")
            entry=WorkspaceLayoutEntry("log","Log",False,"")
            service.save_workspace_snapshot(sess.session_id,[entry]);service.close_session(sess.session_id)
            with self.assertRaises(RuntimeError):service.save_workspace_snapshot(sess.session_id,[entry])
            self.assertEqual(len(service.workspace_snapshot(sess.session_id)["workspaces"]),1)

    def test_workspace_snapshot_validation_rejects_unknown_kind_and_duplicates(self):
        from journeyman.core.workspace_layout import entries_from_snapshot
        with self.assertRaises(ValueError):
            entries_from_snapshot({"schema":6,"workspaces":[{"kind":"fake","title":"X"}]})
        row={"kind":"overview","title":"X","external":False,"geometry_b64":"",
             "workspace_id":"11111111-1111-1111-1111-111111111111"}
        with self.assertRaises(ValueError):entries_from_snapshot({"schema":6,"workspaces":[row,row]})

    def test_clear_workspace_snapshot(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            service=ProjectSessionService(Path(td));p=service.create_project("P");sess=service.create_session(p.project_id,"S")
            service.save_workspace_snapshot(sess.session_id,[])
            self.assertTrue(service.clear_workspace_snapshot(sess.session_id))
            self.assertIsNone(service.workspace_snapshot(sess.session_id))
            self.assertFalse(service.clear_workspace_snapshot(sess.session_id))


class ProjectSessionConfigurationReferenceTests(unittest.TestCase):
    def test_capture_reference_records_identity_not_values(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from journeyman.core.storage import ConfigStore
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);store=ConfigStore(root/"config");store.register_schema("physics",1)
            doc=store.save("physics",{"gain":4.0})
            service=ProjectSessionService(root/"projects");p=service.create_project("P");sess=service.create_session(p.project_id,"S")
            ref=service.capture_config_reference(sess.session_id,doc)
            self.assertEqual(ref["namespace"],"physics");self.assertEqual(ref["revision"],doc.revision)
            self.assertNotIn("values",ref)
            self.assertEqual(service.config_references(sess.session_id)[0]["checksum"],doc.checksum)

    def test_verify_reference_detects_authoritative_change(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from journeyman.core.storage import ConfigStore
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);store=ConfigStore(root/"config");store.register_schema("physics",1)
            first=store.save("physics",{"gain":1})
            service=ProjectSessionService(root/"projects");p=service.create_project("P");sess=service.create_session(p.project_id,"S")
            service.capture_config_reference(sess.session_id,first)
            self.assertEqual(service.verify_config_references(sess.session_id,store)[0]["status"],"MATCH")
            store.save("physics",{"gain":2},expected_revision=first.revision)
            self.assertEqual(service.verify_config_references(sess.session_id,store)[0]["status"],"CHANGED")

    def test_closed_session_rejects_new_config_reference(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from journeyman.core.storage import ConfigStore
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);store=ConfigStore(root/"config");store.register_schema("x",1);doc=store.save("x",{"a":1})
            service=ProjectSessionService(root/"projects");p=service.create_project("P");sess=service.create_session(p.project_id,"S")
            service.close_session(sess.session_id)
            with self.assertRaises(RuntimeError):service.capture_config_reference(sess.session_id,doc)

    def test_verify_unavailable_reference_is_explicit(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from journeyman.core.storage import ConfigStore
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);store=ConfigStore(root/"config");store.register_schema("x",1);doc=store.save("x",{"a":1})
            service=ProjectSessionService(root/"projects");p=service.create_project("P");sess=service.create_session(p.project_id,"S")
            service.capture_config_reference(sess.session_id,doc)
            store._path("x").unlink()
            self.assertEqual(service.verify_config_references(sess.session_id,store)[0]["status"],"UNAVAILABLE")


class ProjectSessionQualificationTests(unittest.TestCase):
    def test_session_context_unifies_persisted_organization(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.storage import ConfigStore
        from journeyman.core.workspace_layout import WorkspaceLayoutEntry
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); recorder=RunRecorder(root/"runs"); service=ProjectSessionService(root/"projects",recorder)
            p=service.create_project("P"); sess=service.create_session(p.project_id,"S")
            run=recorder.start("R",mode="SOFTWARE",source="test");service.bind_run(run.run_id,p.project_id,sess.session_id)
            service.save_workspace_snapshot(sess.session_id,[WorkspaceLayoutEntry("overview","Overview",False,"")])
            store=ConfigStore(root/"config");store.register_schema("physics",1);doc=store.save("physics",{"x":1})
            service.capture_config_reference(sess.session_id,doc)
            context=service.session_context(sess.session_id)
            self.assertEqual(context.run_ids,(run.run_id,));self.assertTrue(context.workspace_saved)
            self.assertEqual(context.config_namespaces,("physics",))

    def test_projects_sessions_qualification_passes_valid_repository(self):
        from journeyman.core.projects_sessions import ProjectSessionService,qualify_projects_sessions
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            service=ProjectSessionService(Path(td));p=service.create_project("P");service.create_session(p.project_id,"S")
            result=qualify_projects_sessions(service)
            self.assertTrue(result.passed,result.failures)

    def test_joe012_release_readiness_passes_isolated_exercise(self):
        from journeyman.core.projects_sessions import joe012_release_readiness
        result=joe012_release_readiness()
        self.assertTrue(result.passed,result.failures)
        self.assertTrue(result.qualification_passed);self.assertTrue(result.isolated_exercise_passed)


class ProjectSessionFinalHardeningTests(unittest.TestCase):
    def test_qualification_detects_orphan_workspace_and_config_context(self):
        from journeyman.core.projects_sessions import ProjectSessionService,qualify_projects_sessions
        from pathlib import Path
        import tempfile,json
        with tempfile.TemporaryDirectory() as td:
            service=ProjectSessionService(Path(td));p=service.create_project("P");service.create_session(p.project_id,"S")
            raw=service._load()
            raw["workspace_snapshots"]["missing-session"]={"schema":6,"saved_at":"x","workspaces":[]}
            raw["config_refs"]["another-missing"]={"x":{"namespace":"x","revision":1}}
            service._save(raw)
            result=qualify_projects_sessions(service)
            self.assertFalse(result.passed)
            self.assertTrue(any("workspace snapshot references unknown session" in x for x in result.failures))
            self.assertTrue(any("configuration references unknown session" in x for x in result.failures))

    def test_closed_archived_context_remains_reviewable_after_restart(self):
        from journeyman.core.projects_sessions import ProjectSessionService
        from journeyman.core.run_recorder import RunRecorder
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);recorder=RunRecorder(root/"runs");service=ProjectSessionService(root/"projects",recorder)
            p=service.create_project("P");sess=service.create_session(p.project_id,"S")
            run=recorder.start("R",mode="SIMULATION",source="test");service.bind_run(run.run_id,p.project_id,sess.session_id)
            recorder.finish(run.run_id);service.close_session(sess.session_id);service.archive_project(p.project_id)
            reopened=ProjectSessionService(root/"projects",recorder);context=reopened.session_context(sess.session_id)
            self.assertFalse(context.session.active);self.assertTrue(context.project.archived)
            self.assertEqual(context.run_ids,(run.run_id,))

    def test_final_release_readiness_reports_lifecycle_persistence(self):
        from journeyman.core.projects_sessions import joe012_release_readiness
        result=joe012_release_readiness()
        self.assertTrue(result.passed,result.failures)
        self.assertTrue(any("persistence and lifecycle" in x for x in result.checks))


class DiagnosticsFoundationTests(unittest.TestCase):
    def test_health_snapshot_reports_real_registered_services(self):
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        import tempfile
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        service=runtime.service("joe.diagnostics");snap=service.snapshot()
        self.assertTrue(snap.components)
        self.assertTrue(any(x.component=="joe.runs" for x in snap.components))
        self.assertFalse(any("SIMULATED" in x.summary.upper() for x in snap.components))

    def test_missing_required_service_is_failed_not_fabricated(self):
        from journeyman.core.diagnostics import DiagnosticsService,HealthState
        class Runtime:
            def service(self,name): raise KeyError(name)
            def service_owner(self,name): return None
        snap=DiagnosticsService(Runtime()).snapshot()
        self.assertEqual(snap.state,HealthState.FAILED)
        self.assertTrue(all(x.state is HealthState.FAILED for x in snap.components))

    def test_diagnostics_qualification_passes_live_builtin_runtime(self):
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.diagnostics import qualify_diagnostics
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        result=qualify_diagnostics(runtime.service("joe.diagnostics"))
        self.assertTrue(result.passed,result.failures)


class DiagnosticsReleaseTests(unittest.TestCase):
    def test_snapshot_includes_real_subsystem_integrity_checks(self):
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        snap=runtime.service("joe.diagnostics").snapshot()
        names={x.component for x in snap.components}
        self.assertTrue({"storage.integrity","streams.integrity","runs.integrity","review.integrity",
                         "projects.sessions.repository","telemetry.monitor"}.issubset(names))

    def test_release_readiness_detects_injected_failure(self):
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.diagnostics import joe013_release_readiness
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        result=joe013_release_readiness(runtime.service("joe.diagnostics"))
        self.assertTrue(result.passed,result.failures)
        self.assertTrue(result.healthy_snapshot_passed);self.assertTrue(result.fault_detection_passed)

    def test_overall_health_failed_when_required_service_missing(self):
        from journeyman.core.diagnostics import DiagnosticsService,HealthState
        class Partial:
            def service(self,name):
                if name=="joe.host-telemetry-monitor":
                    raise KeyError(name)
                return object()
            def service_owner(self,name): return "test"
        snap=DiagnosticsService(Partial()).snapshot()
        self.assertEqual(snap.state,HealthState.FAILED)


class AlertFoundationTests(unittest.TestCase):
    def test_alert_lifecycle_persists(self):
        from journeyman.core.alerts import AlertService,AlertStatus
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            service=AlertService(Path(td))
            a=service.create("WARNING",source="test",cause="disk threshold",affected_subsystem="storage",origin="HOST")
            service.acknowledge(a.alert_id,"operator reviewed");service.resolve(a.alert_id)
            reopened=AlertService(Path(td));final=reopened.get(a.alert_id)
            self.assertEqual(final.status,AlertStatus.RESOLVED);self.assertEqual(final.acknowledgement_note,"operator reviewed")

    def test_simulation_origin_is_explicit_and_preserved(self):
        from journeyman.core.alerts import AlertService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            service=AlertService(Path(td))
            a=service.create("CRITICAL",source="digital.twin",cause="simulated threshold",
                             affected_subsystem="Mouth A",origin="SIMULATION")
            self.assertEqual(a.origin,"SIMULATION");self.assertEqual(a.severity.value,"CRITICAL")

    def test_alert_status_counts_real_records(self):
        from journeyman.core.alerts import AlertService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            service=AlertService(Path(td))
            a=service.create("WARNING",source="x",cause="a",affected_subsystem="x",origin="SOFTWARE")
            b=service.create("CRITICAL",source="y",cause="b",affected_subsystem="y",origin="HOST")
            service.acknowledge(a.alert_id)
            status=service.status()
            self.assertEqual((status.total,status.active,status.acknowledged,status.warning,status.critical),(2,1,1,1,1))

    def test_invalid_origin_and_illegal_transitions_rejected(self):
        from journeyman.core.alerts import AlertService
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            service=AlertService(Path(td))
            with self.assertRaises(ValueError):
                service.create("WARNING",source="x",cause="x",affected_subsystem="x",origin="FAKE")
            a=service.create("WARNING",source="x",cause="x",affected_subsystem="x",origin="SOFTWARE")
            service.resolve(a.alert_id)
            with self.assertRaises(RuntimeError):service.acknowledge(a.alert_id)


class AlertReleaseTests(unittest.TestCase):
    def test_health_sync_deduplicates_and_resolves_on_recovery(self):
        from journeyman.core.alerts import AlertService,AlertStatus
        from types import SimpleNamespace
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            service=AlertService(Path(td))
            bad=SimpleNamespace(components=(SimpleNamespace(state=SimpleNamespace(value="FAILED"),summary="missing",component="joe.test"),))
            c1,_=service.synchronize_health(bad);c2,_=service.synchronize_health(bad)
            self.assertEqual((len(c1),len(c2)),(1,0))
            good=SimpleNamespace(components=(SimpleNamespace(state=SimpleNamespace(value="HEALTHY"),summary="ok",component="joe.test"),))
            _,resolved=service.synchronize_health(good)
            self.assertEqual(len(resolved),1);self.assertEqual(service.get(c1[0].alert_id).status,AlertStatus.RESOLVED)

    def test_manual_alert_is_not_auto_resolved_by_health_sync(self):
        from journeyman.core.alerts import AlertService,AlertStatus
        from types import SimpleNamespace
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            service=AlertService(Path(td))
            manual=service.create("CRITICAL",source="operator",cause="manual",affected_subsystem="lab",origin="HARDWARE")
            healthy=SimpleNamespace(components=())
            service.synchronize_health(healthy)
            self.assertEqual(service.get(manual.alert_id).status,AlertStatus.ACTIVE)

    def test_joe014_release_readiness_passes(self):
        from journeyman.core.alerts import joe014_release_readiness
        r=joe014_release_readiness()
        self.assertTrue(r.passed,r.failures);self.assertTrue(r.lifecycle_passed and r.dedup_passed and r.recovery_passed)


class AuthorityFoundationTests(unittest.TestCase):
    def test_canonical_authority_order(self):
        from journeyman.core.authority import AuthorityService,AuthorityLevel
        service=AuthorityService()
        self.assertEqual([x.level for x in service.actors()],
            [AuthorityLevel.BUS_SAFE,AuthorityLevel.DETERMINISTIC_CONTROL,AuthorityLevel.GUARDIAN,AuthorityLevel.RESEARCH_ASSISTANCE])

    def test_guardian_cannot_authorize_deterministic_control(self):
        from journeyman.core.authority import AuthorityService,Decision
        service=AuthorityService()
        d=service.require_control("joe.guardian","energize","experiment")
        self.assertEqual(d.decision,Decision.DENY)

    def test_deterministic_control_cannot_override_bus_safe(self):
        from journeyman.core.authority import AuthorityService,Decision
        service=AuthorityService()
        self.assertEqual(service.require_bus_safe("joe.deterministic-control","override","interlock").decision,Decision.DENY)
        self.assertEqual(service.require_bus_safe("joe.bus-safe","hold","interlock").decision,Decision.ALLOW)

    def test_unknown_actor_is_rejected(self):
        from journeyman.core.authority import AuthorityService
        service=AuthorityService()
        with self.assertRaises(KeyError):service.require_control("unknown","x","y")

    def test_authority_qualification_passes(self):
        from journeyman.core.authority import AuthorityService,qualify_authority
        result=qualify_authority(AuthorityService())
        self.assertTrue(result.passed,result.failures)


class AuthorityReleaseTests(unittest.TestCase):
    def test_guardian_can_recommend_but_not_execute_hold_or_abort(self):
        from journeyman.core.authority import AuthorityService,Decision
        s=AuthorityService()
        self.assertEqual(s.recommend_hold("joe.guardian","experiment","risk").decision,Decision.ALLOW)
        self.assertEqual(s.recommend_abort("joe.guardian","experiment","risk").decision,Decision.ALLOW)
        self.assertEqual(s.execute_hold("joe.guardian","experiment","risk").decision,Decision.DENY)
        self.assertEqual(s.execute_abort("joe.guardian","experiment","risk").decision,Decision.DENY)

    def test_hold_and_abort_have_distinct_authority_boundaries(self):
        from journeyman.core.authority import AuthorityService,Decision
        s=AuthorityService()
        self.assertEqual(s.execute_hold("joe.deterministic-control","experiment","trip").decision,Decision.ALLOW)
        self.assertEqual(s.execute_abort("joe.deterministic-control","experiment","trip").decision,Decision.DENY)
        self.assertEqual(s.execute_abort("joe.bus-safe","experiment","trip").decision,Decision.ALLOW)

    def test_denied_decisions_are_retained_for_audit(self):
        from journeyman.core.authority import AuthorityService,Decision
        s=AuthorityService();d=s.execute_abort("joe.guardian","experiment","test")
        self.assertEqual(d.decision,Decision.DENY);self.assertIn(d,s.decisions())

    def test_joe015_release_readiness_passes(self):
        from journeyman.core.authority import joe015_release_readiness
        r=joe015_release_readiness()
        self.assertTrue(r.passed,r.failures)
        self.assertTrue(r.hierarchy_passed and r.guardian_boundary_passed and r.hold_boundary_passed and r.abort_boundary_passed)


class DocumentationFoundationTests(unittest.TestCase):
    def test_documentation_index_is_version_matched_and_searchable(self):
        from journeyman.core.documentation import DocumentationService
        html="<h1>Manual</h1><h2>Telemetry</h2><p>Real host CPU telemetry.</p><h2>Safety</h2><p>BUS-SAFE authority.</p>"
        d=DocumentationService(html,"1.2.3","TEST")
        self.assertEqual(d.status()["version"],"1.2.3");self.assertEqual(d.status()["build"],"TEST")
        self.assertEqual(d.search("host CPU")[0].title,"Telemetry")

    def test_empty_search_does_not_return_every_topic(self):
        from journeyman.core.documentation import DocumentationService
        d=DocumentationService("<h2>A</h2><p>B</p>","1","x")
        self.assertEqual(d.search(""),())

    def test_builtin_documentation_matches_running_build(self):
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman import __version__,__build__
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        d=runtime.service("joe.documentation");status=d.status()
        self.assertEqual((status["version"],status["build"]),(__version__,__build__))
        self.assertTrue(status["searchable"]);self.assertGreater(status["topic_count"],10)


class DocumentationReleaseTests(unittest.TestCase):
    def test_documentation_qualification_rejects_empty_index(self):
        from journeyman.core.documentation import DocumentationService,qualify_documentation
        r=qualify_documentation(DocumentationService("<h1>empty</h1>","1","x"))
        self.assertFalse(r.passed)

    def test_joe016_release_readiness_passes_builtin_manual(self):
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.documentation import joe016_release_readiness
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        r=joe016_release_readiness(runtime.service("joe.documentation"))
        self.assertTrue(r.passed,r.failures)
        self.assertTrue(r.index_passed and r.search_passed and r.version_passed)


class RunRecorderIntegrationDebtTests(unittest.TestCase):
    def test_cursor_capture_records_retention_gap_and_available_samples(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            engine=ScientificDataStreamEngine(history_limit_per_stream=3)
            engine.register("s","Signal","u",float,DataOrigin.SIMULATION,"test")
            for i in range(6):engine.publish("s",float(i),source="test")
            recorder=RunRecorder(Path(td));run=recorder.start("cursor",mode="SIMULATION",source="test")
            read=recorder.capture_stream_since(run.run_id,engine,"s",after_sequence=0)
            self.assertTrue(read.gap_detected);self.assertEqual(recorder.get(run.run_id).sample_count,3)
            events=recorder.events(run.run_id)
            self.assertTrue(any(x["type"]=="STREAM_RETENTION_GAP" for x in events))

    def test_sample_append_defers_full_integrity_rehash_until_checkpoint(self):
        from journeyman.core.run_recorder import RunRecorder
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.state_events import DataOrigin
        from pathlib import Path
        import tempfile,json
        with tempfile.TemporaryDirectory() as td:
            engine=ScientificDataStreamEngine();definition=engine.register("s","Signal","u",float,DataOrigin.SIMULATION,"test")
            sample=engine.publish("s",1.0,source="test")
            recorder=RunRecorder(Path(td));run=recorder.start("perf",mode="SIMULATION",source="test")
            recorder.capture_stream_sample(run.run_id,definition,sample)
            manifest=json.loads((Path(run.directory)/"manifest.json").read_text())
            self.assertTrue(manifest["integrity_dirty"])
            recorder.finalize_integrity(run.run_id)
            manifest=json.loads((Path(run.directory)/"manifest.json").read_text())
            self.assertNotIn("integrity_dirty",manifest)
            self.assertTrue(recorder.verify_integrity(run.run_id).passed)


class VisualizationIntegrationDebtTests(unittest.TestCase):
    def test_explicit_range_gauge_clamps_without_synthesizing_value(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.visualization import VisualizationEngine
        from journeyman.core.state_events import DataOrigin
        e=ScientificDataStreamEngine();e.register("g","Gauge","V",float,DataOrigin.SIMULATION,"test")
        e.publish("g",150.0,source="test");g=VisualizationEngine(e).gauge("g",0,100)
        self.assertEqual(g.value,150.0);self.assertEqual(g.fraction,1.0);self.assertEqual(g.origin,"SIMULATION")

    def test_gauge_rejects_invalid_range(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.visualization import VisualizationEngine
        e=ScientificDataStreamEngine()
        with self.assertRaises(ValueError):VisualizationEngine(e).gauge("missing",10,10)

    def test_scientific_table_is_sparse_and_preserves_provenance(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.visualization import VisualizationEngine
        from journeyman.core.state_events import DataOrigin
        e=ScientificDataStreamEngine();e.register("a","A","m",float,DataOrigin.IMPORTED,"file")
        e.register("b","B","s",float,DataOrigin.SIMULATION,"sim")
        e.publish("a",1.0,source="file",timestamp=10.0);e.publish("b",2.0,source="sim",timestamp=11.0)
        v=VisualizationEngine(e).scientific_table(["a","b"])
        self.assertEqual(v.origins,("IMPORTED","SIMULATION"));self.assertEqual(len(v.rows),2)
        self.assertIsNone(v.rows[0][2]);self.assertIsNone(v.rows[1][1])


class VisualizationSynchronizationTests(unittest.TestCase):
    def test_synchronized_cursor_accepts_finite_time(self):
        from journeyman.core.visualization import SynchronizedTimeCursor
        c=SynchronizedTimeCursor();self.assertEqual(c.set(12.5),12.5);self.assertEqual(c.timestamp,12.5)

    def test_synchronized_cursor_rejects_nonfinite_time(self):
        from journeyman.core.visualization import SynchronizedTimeCursor
        c=SynchronizedTimeCursor()
        with self.assertRaises(ValueError):c.set(float("nan"))


class FinalFoundationDebtTests(unittest.TestCase):
    def test_config_store_ignores_unrelated_settings_json(self):
        from journeyman.core.storage import ConfigStore
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/"joe_settings.json").write_text('{"theme":"dark"}')
            c=ConfigStore(p);c.save("science",{"a":1})
            self.assertEqual(c.namespaces(),("science",))

    def test_wait_uses_terminal_snapshot_after_aggressive_pruning(self):
        from journeyman.core.job_engine import JobEngine,JobState
        e=JobEngine(max_workers=1,completed_limit=1,history_limit=100);e.register_owner("test",max_active=10)
        ids=[e.submit(str(i),"test",lambda ctx,i=i:i) for i in range(6)]
        snapshots=[e.wait(i,timeout=2) for i in ids]
        self.assertTrue(all(x.state is JobState.SUCCEEDED for x in snapshots));e.shutdown()

    def test_foundation_cross_system_qualification(self):
        from journeyman.core.integration_qualification import qualify_foundation
        r=qualify_foundation();self.assertTrue(r.passed,r.failures);self.assertEqual(len(r.checks),5)


class FoundationV1ReleaseTests(unittest.TestCase):
    def test_contour_grid_uses_only_observed_field_cells(self):
        from journeyman.core.data_streams import ScientificDataStreamEngine
        from journeyman.core.visualization import VisualizationEngine
        from journeyman.core.state_events import DataOrigin
        e=ScientificDataStreamEngine()
        for sid in ("x","y","z"):e.register(sid,sid,"u",float,DataOrigin.SIMULATION,"test")
        e.publish_frame({"x":0.0,"y":0.0,"z":10.0},source="test",timestamp=1.0)
        e.publish_frame({"x":1.0,"y":1.0,"z":20.0},source="test",timestamp=2.0)
        v=VisualizationEngine(e).contour_grid("x","y","z")
        self.assertEqual(v.occupied_cells,2);self.assertEqual(v.z_matrix,((10.0,None),(None,20.0)))
        self.assertEqual(v.origins,("SIMULATION","SIMULATION","SIMULATION"))

    def test_final_foundation_qualification_passes(self):
        from journeyman.core.integration_qualification import qualify_foundation
        r=qualify_foundation();self.assertTrue(r.passed,r.failures)
        self.assertIn("quantitative contour grid provenance",r.checks)


if __name__ == "__main__":
    unittest.main()


class MasterParameterRegister001ATests(unittest.TestCase):
    def test_define_persist_reload_and_history(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.mpr import MasterParameterRegister,EpistemicClass
        with tempfile.TemporaryDirectory() as td:
            m=MasterParameterRegister(Path(td))
            r=m.define("physics.c",symbol="c",name="Speed of light",value=299792458.0,unit="m/s",
                       uncertainty=0.0,epistemic_class=EpistemicClass.ESTABLISHED_PHYSICS,
                       provenance="SI exact definition")
            self.assertEqual((r.revision,r.registry_revision),(1,1))
            loaded=MasterParameterRegister(Path(td))
            self.assertEqual(loaded.get("physics.c").value,299792458.0)
            self.assertEqual(len(loaded.history("physics.c")),1)
            self.assertTrue(loaded.status().integrity_ok)

    def test_update_requires_expected_revision_and_preserves_history(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.mpr import MasterParameterRegister
        with tempfile.TemporaryDirectory() as td:
            m=MasterParameterRegister(Path(td))
            r=m.define("test.length",symbol="L",name="Length",value=1,unit="m",
                       uncertainty=0.01,epistemic_class="EXTRAPOLATED_ENGINEERING",provenance="test")
            with self.assertRaises(RuntimeError):m.update("test.length",expected_revision=0,value=2)
            r2=m.update("test.length",expected_revision=r.revision,value=2)
            self.assertEqual(r2.revision,2);self.assertEqual(len(m.history("test.length")),2)

    def test_uncertainty_dimension_and_nonfinite_validation(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.mpr import MasterParameterRegister
        with tempfile.TemporaryDirectory() as td:
            m=MasterParameterRegister(Path(td))
            with self.assertRaises(ValueError):
                m.define("test.bad",symbol="x",name="Bad",value=1,unit="m",uncertainty=1,
                         uncertainty_unit="s",epistemic_class="SPECULATIVE_UNRESOLVED",provenance="test")
            with self.assertRaises(ValueError):
                m.define("test.nan",symbol="x",name="Nan",value=float("nan"),unit="m",
                         epistemic_class="SPECULATIVE_UNRESOLVED",provenance="test")
            with self.assertRaises(ValueError):
                m.define("test.unit",symbol="x",name="Unit",value=1,unit="furlong",
                         epistemic_class="SPECULATIVE_UNRESOLVED",provenance="test")

    def test_integrity_tampering_is_detected(self):
        import tempfile,json
        from pathlib import Path
        from journeyman.core.mpr import MasterParameterRegister
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);m=MasterParameterRegister(root)
            m.define("test.x",symbol="x",name="X",value=1,unit="m",
                     epistemic_class="ESTABLISHED_PHYSICS",provenance="test")
            raw=json.loads((root/"registry.json").read_text());raw["parameters"]["test.x"]["value"]=999
            (root/"registry.json").write_text(json.dumps(raw))
            with self.assertRaises(RuntimeError):MasterParameterRegister(root)

    def test_application_module_registration_and_backbone_contract(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.module_runtime import ModuleRuntime,ModuleState
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.mpr import MasterParameterRegister
        from journeyman.modules.mpr import MPR_MODULE,MPRInstance
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        try:
            backbone=runtime.service("joe.state-events")
            register=MasterParameterRegister(Path(tempfile.mkdtemp()),backbone)
            runtime.register(MPR_MODULE,MPRInstance(register));runtime.activate("journeyman.mpr")
            runtime.publish_service("journeyman.mpr","joe.mpr",register)
            record=register.define("test.x",symbol="x",name="X",value=1,unit="m",
                                   epistemic_class="ESTABLISHED_PHYSICS",provenance="test")
            self.assertIs(runtime.require("journeyman.mpr").state,ModuleState.ACTIVE)
            self.assertEqual(backbone.state.get("joe.mpr.parameter-count"),1)
            self.assertEqual(backbone.events.history()[-1].topic,"joe.mpr.changed")
            runtime.stop("journeyman.mpr")
        finally:
            runtime.stop("joe.core")

    def test_mpr_qualification(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.mpr import MasterParameterRegister,qualify_mpr
        with tempfile.TemporaryDirectory() as td:
            m=MasterParameterRegister(Path(td))
            m.define("test.x",symbol="x",name="X",value=1,unit="m",
                     epistemic_class="ESTABLISHED_PHYSICS",provenance="test")
            q=qualify_mpr(m);self.assertTrue(q.passed,q.failures)


class MasterParameterRegister001BTests(unittest.TestCase):
    def _register(self,root):
        from journeyman.core.mpr import MasterParameterRegister
        m=MasterParameterRegister(root)
        for pid,symbol,value in (("test.a","a",2),("test.b","b",3),("test.c","c",5)):
            m.define(pid,symbol=symbol,name=pid,value=value,unit="m",
                     epistemic_class="ESTABLISHED_PHYSICS",provenance="test")
        return m

    def test_dependency_graph_and_transitive_dependents(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as td:
            m=self._register(Path(td))
            m.define_derived("test.b",dependencies=["test.a"],expression="a + 1",provenance="test equation")
            m.define_derived("test.c",dependencies=["test.b"],expression="b + 2",provenance="test equation")
            g=m.dependency_graph()
            self.assertEqual(g.edges,(("test.a","test.b"),("test.b","test.c")))
            self.assertLess(g.topological_order.index("test.a"),g.topological_order.index("test.c"))
            self.assertEqual(m.dependents("test.a"),("test.b","test.c"))

    def test_dependency_cycle_is_rejected_without_persisting_candidate(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as td:
            m=self._register(Path(td))
            m.define_derived("test.b",dependencies=["test.a"],expression="a",provenance="test")
            m.define_derived("test.c",dependencies=["test.b"],expression="b",provenance="test")
            with self.assertRaises(RuntimeError):
                m.define_derived("test.a",dependencies=["test.c"],expression="c",provenance="test")
            self.assertEqual(tuple(x.parameter_id for x in m.derived_definitions()),("test.b","test.c"))

    def test_snapshot_freezes_parameter_revisions(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as td:
            m=self._register(Path(td));snap=m.create_snapshot("config.baseline",name="Baseline")
            old=m.get("test.a");m.update("test.a",expected_revision=old.revision,value=99)
            resolved={x.parameter_id:x for x in m.resolve_snapshot("config.baseline")}
            self.assertEqual(resolved["test.a"].value,2.0)
            self.assertEqual(m.get("test.a").value,99.0)
            self.assertEqual(snap.registry_revision,3)

    def test_auxiliary_registries_persist_and_verify(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.mpr import MasterParameterRegister
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);m=self._register(root)
            m.define_derived("test.c",dependencies=["test.a","test.b"],expression="a+b",provenance="test")
            m.create_snapshot("config.one",name="One")
            loaded=MasterParameterRegister(root)
            self.assertEqual(loaded.derived("test.c").dependencies,("test.a","test.b"))
            self.assertEqual(loaded.snapshot("config.one").name,"One")
            self.assertEqual(len(loaded.resolve_snapshot("config.one")),3)

    def test_qualification_includes_graph_and_snapshots(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.mpr import qualify_mpr
        with tempfile.TemporaryDirectory() as td:
            m=self._register(Path(td));m.create_snapshot("config.q",name="Qualification")
            q=qualify_mpr(m);self.assertTrue(q.passed,q.failures)
            self.assertTrue(any("dependency graph acyclic" in x for x in q.checks))
            self.assertTrue(any("configuration snapshot" in x for x in q.checks))


class MasterParameterRegister001CTests(unittest.TestCase):
    def _m(self,root):
        from journeyman.core.mpr import MasterParameterRegister
        m=MasterParameterRegister(root)
        m.define("physics.c",symbol="c",name="Speed of light",value=299792458,unit="m/s",uncertainty=0,
                 epistemic_class="ESTABLISHED_PHYSICS",provenance="SI exact definition",description="vacuum light speed")
        m.define("design.radius",symbol="r0",name="Candidate radius",value=5,unit="m",
                 epistemic_class="SPECULATIVE_UNRESOLVED",provenance="design study")
        return m
    def test_search_and_epistemic_filter(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as td:
            m=self._m(Path(td));self.assertEqual([x.parameter_id for x in m.search("light")],["physics.c"])
            self.assertEqual([x.parameter_id for x in m.search(epistemic_class="SPECULATIVE_UNRESOLVED")],["design.radius"])
    def test_json_interchange_round_trip(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.mpr import MasterParameterRegister
        with tempfile.TemporaryDirectory() as a,tempfile.TemporaryDirectory() as b:
            source=self._m(Path(a));dest=MasterParameterRegister(Path(b));records=dest.import_json(source.export_json())
            self.assertEqual(len(records),2);self.assertEqual(dest.get("physics.c").unit,"m/s");self.assertEqual(dest.get("physics.c").uncertainty,0.0)
    def test_json_import_validates_before_mutation(self):
        import tempfile,json
        from pathlib import Path
        from journeyman.core.mpr import MasterParameterRegister
        with tempfile.TemporaryDirectory() as td:
            m=MasterParameterRegister(Path(td));bad={"format":"JOE-MPR-INTERCHANGE","version":1,"parameters":[
                {"parameter_id":"bad.x","symbol":"x","name":"X","value":1,"unit":"furlong","epistemic_class":"ESTABLISHED_PHYSICS","provenance":"test"}]}
            with self.assertRaises(ValueError):m.import_json(json.dumps(bad))
            self.assertEqual(m.list(),())
    def test_csv_export_contains_provenance_and_evidence(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as td:
            text=self._m(Path(td)).export_csv();self.assertIn("epistemic_class",text);self.assertIn("SI exact definition",text);self.assertIn("ESTABLISHED_PHYSICS",text)


class MasterParameterRegister001DTests(unittest.TestCase):
    def _register(self,root):
        from journeyman.core.mpr import MasterParameterRegister
        m=MasterParameterRegister(root)
        m.define("physics.c",symbol="c",name="Speed of light",value=299792458,unit="m/s",uncertainty=0,
                 epistemic_class="ESTABLISHED_PHYSICS",provenance="SI exact definition")
        m.define("design.r0",symbol="r0",name="Throat radius",value=10,unit="m",uncertainty=0.1,
                 epistemic_class="SPECULATIVE_UNRESOLVED",provenance="candidate design input")
        m.define_derived("design.r0",dependencies=["physics.c"],expression="illustrative dependency only",
                         provenance="qualification dependency")
        m.create_snapshot("config.baseline",name="Baseline")
        return m
    def test_guardian_contract_is_complete_read_only_projection(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as td:
            m=self._register(Path(td));c=m.guardian_contract()
            self.assertEqual(c.schema,"JOE-GUARDIAN-MPR/1");self.assertTrue(c.integrity_ok)
            self.assertEqual(c.registry_revision,2);self.assertEqual(c.snapshots,("config.baseline",))
            r=next(x for x in c.parameters if x.parameter_id=="design.r0")
            self.assertEqual(r.dependencies,("physics.c",));self.assertEqual(r.epistemic_class,"SPECULATIVE_UNRESOLVED")
            self.assertEqual(r.provenance,"candidate design input")
    def test_release_readiness_passes_qualified_register(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.mpr import mpr_release_readiness
        with tempfile.TemporaryDirectory() as td:
            r=mpr_release_readiness(self._register(Path(td)));self.assertTrue(r.passed,r.failures)
            self.assertTrue(any("Guardian read-only contract" in x for x in r.checks))
            self.assertTrue(any("snapshots resolve" in x for x in r.checks))
    def test_guardian_contract_tracks_revision_after_write(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as td:
            m=self._register(Path(td));old=m.get("design.r0")
            m.update("design.r0",expected_revision=old.revision,value=12)
            c=m.guardian_contract();r=next(x for x in c.parameters if x.parameter_id=="design.r0")
            self.assertEqual(r.value,12.0);self.assertEqual(r.parameter_revision,2);self.assertEqual(c.registry_revision,3)


class GeometryMetric001ATests(unittest.TestCase):
    def test_minkowski_metric_inverse_and_interval(self):
        import numpy as np
        from journeyman.core.geometry import minkowski_metric,inverse_metric,spacetime_interval
        g=minkowski_metric().evaluate((0,0,0,0))
        self.assertAlmostEqual(g.determinant,-1.0);self.assertEqual(g.signature,(-1,1,1,1))
        self.assertTrue(np.allclose(np.asarray(inverse_metric(g)),np.diag([-1,1,1,1])))
        self.assertEqual(spacetime_interval(g,(2,1,0,0)).classification,"timelike")
        self.assertEqual(spacetime_interval(g,(1,1,0,0)).classification,"null")
        self.assertEqual(spacetime_interval(g,(1,2,0,0)).classification,"spacelike")

    def test_raise_lower_round_trip(self):
        import numpy as np
        from journeyman.core.geometry import minkowski_metric,lower_vector,raise_covector
        g=minkowski_metric().evaluate((0,0,0,0));v=(2.0,3.0,4.0,5.0)
        self.assertTrue(np.allclose(raise_covector(g,lower_vector(g,v)),v))

    def test_morris_thorne_default_metric_quantitative(self):
        import math
        from journeyman.core.geometry import morris_thorne_metric
        model=morris_thorne_metric(throat_radius=2.0)
        g=model.evaluate((0.0,4.0,math.pi/2,0.0)).matrix()
        self.assertAlmostEqual(g[0,0],-1.0);self.assertAlmostEqual(g[1,1],4/3)
        self.assertAlmostEqual(g[2,2],16.0);self.assertAlmostEqual(g[3,3],16.0)

    def test_morris_thorne_chart_rejects_throat_and_axis(self):
        import math
        from journeyman.core.geometry import morris_thorne_metric
        model=morris_thorne_metric(throat_radius=2)
        with self.assertRaises(ValueError):model.evaluate((0,2,math.pi/2,0))
        with self.assertRaises(ValueError):model.evaluate((0,3,0,0))

    def test_non_lorentzian_metric_is_rejected(self):
        import numpy as np
        from journeyman.core.geometry import MetricModel,CoordinateDomain
        model=MetricModel("test.euclidean",CoordinateDomain(("a","b","c","d")),lambda q:np.eye(4),provenance="test")
        with self.assertRaises(ValueError):model.evaluate((0,0,0,0))

    def test_geometry_service_registers_after_mpr(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.module_runtime import ModuleRuntime,ModuleState
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.mpr import MasterParameterRegister
        from journeyman.modules.mpr import MPR_MODULE,MPRInstance
        from journeyman.modules.geometry import register_geometry_module
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        try:
            m=MasterParameterRegister(Path(tempfile.mkdtemp()),runtime.service("joe.state-events"))
            runtime.register(MPR_MODULE,MPRInstance(m));runtime.activate("journeyman.mpr");runtime.publish_service("journeyman.mpr","joe.mpr",m)
            service=register_geometry_module(runtime)
            self.assertIs(runtime.require("journeyman.geometry").state,ModuleState.ACTIVE)
            self.assertEqual(service.model("geometry.minkowski").model_id,"geometry.minkowski")
            runtime.stop("journeyman.geometry");runtime.stop("journeyman.mpr")
        finally:runtime.stop("joe.core")


class GeometryCurvature001BTests(unittest.TestCase):
    def test_minkowski_connection_and_curvature_are_zero(self):
        import numpy as np
        from journeyman.core.geometry import minkowski_metric,christoffel_symbols,curvature
        model=minkowski_metric();gamma,_=christoffel_symbols(model,(0,0,0,0))
        self.assertTrue(np.allclose(gamma,0,atol=1e-12))
        c=curvature(model,(0,0,0,0));self.assertTrue(np.allclose(c.riemann_array(),0,atol=1e-10))
        self.assertTrue(np.allclose(c.ricci_matrix(),0,atol=1e-10));self.assertAlmostEqual(c.ricci_scalar,0,places=10)

    def test_spherical_flat_metric_has_near_zero_curvature(self):
        import math,numpy as np
        from journeyman.core.geometry import MetricModel,CoordinateDomain,curvature
        domain=CoordinateDomain(("ct","r","theta","phi"),(None,0,0,0),(None,None,math.pi,2*math.pi),(True,False,False,True),(True,True,False,False))
        model=MetricModel("test.flat-spherical",domain,lambda q:np.diag([-1,1,q[1]**2,q[1]**2*math.sin(q[2])**2]),provenance="flat spherical reference")
        c=curvature(model,(0,10,math.pi/2,1),relative_step=1e-4)
        self.assertLess(np.max(np.abs(c.ricci_matrix())),2e-6)
        self.assertLess(abs(c.ricci_scalar),2e-6)

    def test_morris_thorne_has_nonzero_einstein_tensor(self):
        import math,numpy as np
        from journeyman.core.geometry import morris_thorne_metric,curvature
        c=curvature(morris_thorne_metric(throat_radius=2),(0,4,math.pi/2,1),relative_step=5e-5)
        self.assertGreater(np.max(np.abs(c.einstein_matrix())),1e-5)
        self.assertTrue(np.all(np.isfinite(c.einstein_matrix())))

    def test_curvature_residuals_are_small(self):
        import math
        from journeyman.core.geometry import morris_thorne_metric,curvature,curvature_residuals
        r=curvature_residuals(curvature(morris_thorne_metric(throat_radius=2),(0,5,math.pi/2,1),relative_step=5e-5))
        self.assertLess(r["riemann_last_pair_antisymmetry"],1e-8)
        self.assertLess(r["ricci_symmetry"],2e-7);self.assertLess(r["einstein_symmetry"],2e-7)

    def test_derivative_stencil_respects_domain(self):
        import math
        from journeyman.core.geometry import morris_thorne_metric,metric_derivatives
        d,steps=metric_derivatives(morris_thorne_metric(throat_radius=2),(0,2.0001,math.pi/2,1),relative_step=1e-3)
        self.assertLess(steps[1],0.0001);self.assertEqual(d.shape,(4,4,4))


class GeometryStressEnergy001CTests(unittest.TestCase):
    def test_minkowski_requires_zero_stress_energy(self):
        import numpy as np
        from journeyman.core.geometry import minkowski_metric,stress_energy_from_geometry,assess_nec
        t=stress_energy_from_geometry(minkowski_metric(),(0,0,0,0))
        self.assertTrue(np.allclose(t.covariant_matrix(),0,atol=1e-3))
        self.assertAlmostEqual(t.energy_density_j_m3,0,delta=1e-3)
        self.assertTrue(assess_nec(t,absolute_tolerance_j_m3=1e-3).radial_nec_satisfied)

    def test_morris_thorne_numeric_matches_independent_analytic_reference(self):
        import math
        from journeyman.core.geometry import morris_thorne_metric,stress_energy_from_geometry,morris_thorne_analytic_zero_redshift
        r0=2.0;r=5.0
        numeric=stress_energy_from_geometry(morris_thorne_metric(throat_radius=r0),(0,r,math.pi/2,1),relative_step=5e-5)
        analytic=morris_thorne_analytic_zero_redshift(throat_radius=r0,radius=r)
        scale=max(abs(analytic["energy_density_j_m3"]),1)
        self.assertLess(abs(numeric.energy_density_j_m3-analytic["energy_density_j_m3"])/scale,2e-5)
        scale=max(abs(analytic["radial_pressure_pa"]),1)
        self.assertLess(abs(numeric.principal_pressures_pa[0]-analytic["radial_pressure_pa"])/scale,2e-5)
        scale=max(abs(analytic["tangential_pressure_pa"]),1)
        self.assertLess(abs(numeric.principal_pressures_pa[1]-analytic["tangential_pressure_pa"])/scale,3e-5)

    def test_default_morris_thorne_violates_radial_nec(self):
        import math
        from journeyman.core.geometry import morris_thorne_metric,stress_energy_from_geometry,assess_nec
        t=stress_energy_from_geometry(morris_thorne_metric(throat_radius=2),(0,4,math.pi/2,1),relative_step=5e-5)
        a=assess_nec(t)
        self.assertLess(t.radial_nec_j_m3,0);self.assertFalse(a.radial_nec_satisfied)
        self.assertIn("not evidence",a.interpretation)

    def test_orthonormal_energy_density_is_coordinate_normalized(self):
        import math
        from journeyman.core.geometry import morris_thorne_metric,stress_energy_from_geometry
        t=stress_energy_from_geometry(morris_thorne_metric(throat_radius=2),(0,4,math.pi/2,1),relative_step=5e-5)
        self.assertTrue(math.isfinite(t.energy_density_j_m3))
        self.assertEqual(len(t.principal_pressures_pa),3)

    def test_invalid_constants_rejected(self):
        from journeyman.core.geometry import minkowski_metric,stress_energy_from_geometry
        with self.assertRaises(ValueError):stress_energy_from_geometry(minkowski_metric(),(0,0,0,0),G=0)


class GeometryWorkbench001DTests(unittest.TestCase):
    def test_radial_profile_is_quantitative_and_nec_negative(self):
        from journeyman.core.geometry import morris_thorne_radial_profile
        p=morris_thorne_radial_profile(throat_radius=2,radii=[2.1,3,4,5])
        self.assertEqual(len(p.radii_m),4);self.assertTrue(all(x<0 for x in p.radial_nec_j_m3))
        self.assertIn("not measurement",p.provenance)
    def test_geometry_service_consumes_mpr_throat_radius_and_revision(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.mpr import MasterParameterRegister
        from journeyman.modules.geometry import GeometryService
        m=MasterParameterRegister(Path(tempfile.mkdtemp()))
        r=m.define("design.throat-radius",symbol="r0",name="Throat radius",value=2,unit="m",
                   epistemic_class="SPECULATIVE_UNRESOLVED",provenance="design test")
        svc=GeometryService(m);model=svc.morris_thorne_from_mpr()
        self.assertEqual(model.model_revision,f"MPR:{r.parameter_id}@{r.revision}")
        self.assertEqual(model.domain.lower[1],2.0)
    def test_geometry_service_rejects_wrong_mpr_unit(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.mpr import MasterParameterRegister
        from journeyman.modules.geometry import GeometryService
        m=MasterParameterRegister(Path(tempfile.mkdtemp()))
        m.define("design.throat-radius",symbol="r0",name="Bad radius",value=2,unit="s",
                 epistemic_class="SPECULATIVE_UNRESOLVED",provenance="test")
        with self.assertRaises(ValueError):GeometryService(m).morris_thorne_from_mpr()


class GeometryRelease001ETests(unittest.TestCase):
    def test_convergence_study(self):
        import math
        from journeyman.core.geometry import morris_thorne_metric,curvature_convergence
        c=curvature_convergence(morris_thorne_metric(throat_radius=2),(0,5,math.pi/2,math.pi))
        self.assertTrue(c.converged);self.assertEqual(len(c.relative_steps),3)
        self.assertIn("not physical uncertainty",c.provenance)
    def test_guardian_contract_is_model_labeled_and_advisory(self):
        import math
        from journeyman.core.geometry import morris_thorne_metric,geometry_guardian_contract
        c=geometry_guardian_contract(morris_thorne_metric(throat_radius=2),(0,5,math.pi/2,math.pi))
        self.assertEqual(c.schema,"JOE-GUARDIAN-GEOMETRY/1");self.assertEqual(c.data_origin,"SIMULATION/MODEL")
        self.assertIn("READ_ONLY",c.authority);self.assertLess(c.radial_nec_j_m3,0)
    def test_geometry_release_readiness_passes(self):
        from journeyman.core.geometry import geometry_release_readiness
        r=geometry_release_readiness();self.assertTrue(r.passed,r.failures)
        self.assertGreaterEqual(len(r.checks),5)


class StressEnergy001ATests(unittest.TestCase):
    def test_minkowski_satisfies_type_i_conditions(self):
        from journeyman.core.geometry import minkowski_metric,stress_energy_from_geometry
        from journeyman.core.stress_energy import energy_conditions
        a=energy_conditions(stress_energy_from_geometry(minkowski_metric(),(0,0,0,0)),tolerance_j_m3=1e-3)
        self.assertTrue(all(a.nec_satisfied));self.assertTrue(a.wec_satisfied);self.assertTrue(a.sec_satisfied);self.assertTrue(a.dec_satisfied)

    def test_morris_thorne_radial_exoticity_is_positive(self):
        import math
        from journeyman.core.geometry import morris_thorne_metric,stress_energy_from_geometry
        from journeyman.core.stress_energy import energy_conditions,radial_exoticity
        t=stress_energy_from_geometry(morris_thorne_metric(throat_radius=2),(0,4,math.pi/2,math.pi),relative_step=5e-5)
        a=energy_conditions(t);x=radial_exoticity(t)
        self.assertFalse(a.nec_satisfied[0]);self.assertTrue(x.requires_radial_nec_violation);self.assertGreater(x.radial_exoticity_j_m3,0)

    def test_shell_integral_constant_density_reference(self):
        import math
        from journeyman.core.stress_energy import integrate_spherical_shell
        r=[1+i/1000 for i in range(1001)];rho=[2.0]*len(r);nec=[-3.0]*len(r)
        x=integrate_spherical_shell(r,rho,nec)
        exact=2*(4*math.pi/3)*(2**3-1**3)
        self.assertAlmostEqual(x.integrated_energy_j,exact,delta=exact*2e-6)
        self.assertLess(x.integrated_radial_nec_j,0);self.assertIn("not a general invariant",x.provenance)

    def test_morris_thorne_sweep_dimensions_and_sign(self):
        from journeyman.core.stress_energy import morris_thorne_sweep
        pts=morris_thorne_sweep([1,2],[1.5,2.0])
        self.assertEqual(len(pts),4);self.assertTrue(all(p.radial_nec_j_m3<0 for p in pts))
        self.assertTrue(all(p.radial_exoticity_j_m3>0 for p in pts))

    def test_stress_energy_module_dependency_and_service(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.module_runtime import ModuleRuntime,ModuleState
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.mpr import MasterParameterRegister
        from journeyman.modules.mpr import MPR_MODULE,MPRInstance
        from journeyman.modules.geometry import register_geometry_module
        from journeyman.modules.stress_energy import register_stress_energy_module
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        try:
            m=MasterParameterRegister(Path(tempfile.mkdtemp()),runtime.service("joe.state-events"))
            runtime.register(MPR_MODULE,MPRInstance(m));runtime.activate("journeyman.mpr");runtime.publish_service("journeyman.mpr","joe.mpr",m)
            register_geometry_module(runtime);svc=register_stress_energy_module(runtime)
            self.assertIs(runtime.require("journeyman.stress-energy").state,ModuleState.ACTIVE)
            self.assertIs(svc.mpr,m)
            runtime.stop("journeyman.stress-energy");runtime.stop("journeyman.geometry");runtime.stop("journeyman.mpr")
        finally:runtime.stop("joe.core")


class StressEnergy001BTests(unittest.TestCase):
    def test_proper_volume_integral_is_negative_for_default_model(self):
        from journeyman.core.stress_energy import morris_thorne_proper_volume_integral
        x=morris_thorne_proper_volume_integral(throat_radius=2,r_outer=4,samples=101,throat_offset_fraction=1e-3)
        self.assertGreater(x.volume_m3,0);self.assertLess(x.integrated_energy_j,0);self.assertLess(x.integrated_radial_nec_j,0)
        self.assertIn("Proper spatial-volume",x.provenance)

    def test_nec_scaling_is_inverse_square_at_fixed_ratio(self):
        from journeyman.core.stress_energy import morris_thorne_nec_sensitivity
        x=morris_thorne_nec_sensitivity(throat_radius=2,radius_ratio=2)
        self.assertAlmostEqual(x.logarithmic_sensitivity_r0,-2.0,delta=2e-3)

    def test_uncertainty_zero_input_gives_zero_output(self):
        from journeyman.core.stress_energy import propagate_throat_radius_uncertainty
        x=propagate_throat_radius_uncertainty(throat_radius=2,standard_uncertainty_m=0,radius_ratio=2)
        self.assertEqual(x.standard_uncertainty,0);self.assertEqual(x.unit,"J/m^3")
        self.assertIn("excludes model-form",x.method)

    def test_uncertainty_scales_linearly_for_small_input(self):
        from journeyman.core.stress_energy import propagate_throat_radius_uncertainty
        a=propagate_throat_radius_uncertainty(throat_radius=2,standard_uncertainty_m=.001)
        b=propagate_throat_radius_uncertainty(throat_radius=2,standard_uncertainty_m=.002)
        self.assertAlmostEqual(b.standard_uncertainty/a.standard_uncertainty,2,delta=1e-6)

    def test_condition_map_reports_violations(self):
        from journeyman.core.stress_energy import morris_thorne_condition_map
        pts=morris_thorne_condition_map([1,2],[1.5,2])
        self.assertEqual(len(pts),4);self.assertTrue(all(not p.nec for p in pts));self.assertTrue(all(not p.wec for p in pts))


class StressEnergyRelease001CTests(unittest.TestCase):
    def test_guardian_contract(self):
        import math
        from journeyman.core.geometry import morris_thorne_metric,stress_energy_from_geometry
        from journeyman.core.stress_energy import stress_energy_guardian_contract
        t=stress_energy_from_geometry(morris_thorne_metric(throat_radius=2),(0,4,math.pi/2,math.pi),relative_step=5e-5)
        g=stress_energy_guardian_contract(t)
        self.assertEqual(g.schema,"JOE-GUARDIAN-STRESS-ENERGY/1");self.assertEqual(g.data_origin,"SIMULATION/MODEL")
        self.assertIn("READ_ONLY",g.authority);self.assertFalse(g.nec_satisfied[0])
    def test_release_readiness(self):
        from journeyman.core.stress_energy import stress_energy_release_readiness
        r=stress_energy_release_readiness();self.assertTrue(r.passed,r.failures);self.assertGreaterEqual(len(r.checks),5)


class ScientificRegistry001ATests(unittest.TestCase):
    def test_registry_starts_empty_and_persists(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.scientific_registry import ScientificObjectRegistry,ObjectType
        d=Path(tempfile.mkdtemp());r=ScientificObjectRegistry(d)
        self.assertEqual(r.list(),())
        a=r.create(name="Test Clock",object_type=ObjectType.CLOCK,provenance="qualification",origin="SIMULATION")
        q=ScientificObjectRegistry(d);self.assertEqual(q.get(a.object_id).name,"Test Clock");self.assertEqual(q.revision,1)

    def test_stable_uuid_duplicate_and_stale_write_rejected(self):
        import tempfile,uuid
        from pathlib import Path
        from journeyman.core.scientific_registry import ScientificObjectRegistry
        r=ScientificObjectRegistry(Path(tempfile.mkdtemp()));oid=str(uuid.uuid4())
        a=r.create(object_id=oid,name="A",object_type="MOUTH",provenance="test",origin="SIMULATION")
        with self.assertRaises(ValueError):r.create(object_id=oid,name="B",object_type="MOUTH",provenance="test")
        b=r.update(oid,expected_config_revision=1,name="A revised")
        self.assertEqual(b.object_id,oid);self.assertEqual(b.config_revision,2)
        with self.assertRaises(RuntimeError):r.update(oid,expected_config_revision=1,name="stale")

    def test_integrity_tamper_detected(self):
        import tempfile,json
        from pathlib import Path
        from journeyman.core.scientific_registry import ScientificObjectRegistry
        d=Path(tempfile.mkdtemp());r=ScientificObjectRegistry(d);r.create(name="S",object_type="SENSOR",provenance="test")
        e=json.loads((d/"objects.json").read_text());e["payload"]["objects"][0]["name"]="tampered";(d/"objects.json").write_text(json.dumps(e))
        with self.assertRaises(RuntimeError):ScientificObjectRegistry(d)

    def test_history_and_guardian_contract(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.scientific_registry import ScientificObjectRegistry
        r=ScientificObjectRegistry(Path(tempfile.mkdtemp()));a=r.create(name="Frame",object_type="COORDINATE_FRAME",provenance="test")
        r.update(a.object_id,expected_config_revision=1,description="updated")
        self.assertEqual(len(r.history(a.object_id)),2)
        g=r.guardian_contract();self.assertEqual(g.schema,"JOE-GUARDIAN-REGISTRY/1");self.assertEqual(g.object_count,1);self.assertIn("READ_ONLY",g.authority)

    def test_backbone_state_and_event_integration(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.state_events import StateEventBackbone
        from journeyman.core.scientific_registry import ScientificObjectRegistry
        b=StateEventBackbone();r=ScientificObjectRegistry(Path(tempfile.mkdtemp()),b)
        r.create(name="Sim body",object_type="SIMULATED_BODY",provenance="test",origin="SIMULATION")
        self.assertEqual(b.state.get("registry.object-count"),1);self.assertEqual(b.state.get("registry.revision"),1)
        self.assertEqual(b.events.history()[-1].topic,"registry.changed")

    def test_origin_does_not_create_telemetry(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.scientific_registry import ScientificObjectRegistry
        r=ScientificObjectRegistry(Path(tempfile.mkdtemp()));a=r.create(name="Device",object_type="HARDWARE_DEVICE",provenance="inventory",origin="HARDWARE")
        self.assertEqual(a.origin.value,"HARDWARE");self.assertFalse(hasattr(a,"telemetry"))

    def test_module_registration(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.module_runtime import ModuleRuntime,ModuleState
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.scientific_registry import ScientificObjectRegistry
        from journeyman.modules.scientific_registry import REGISTRY_MODULE,RegistryInstance
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        try:
            r=ScientificObjectRegistry(Path(tempfile.mkdtemp()),runtime.service("joe.state-events"))
            runtime.register(REGISTRY_MODULE,RegistryInstance(r));runtime.activate("journeyman.registry");runtime.publish_service("journeyman.registry","joe.scientific-registry",r)
            self.assertIs(runtime.require("journeyman.registry").state,ModuleState.ACTIVE)
        finally:runtime.stop("journeyman.registry");runtime.stop("joe.core")


class UnitsRegistry001BTests(unittest.TestCase):
    def test_compound_dimensions_and_conversion(self):
        from journeyman.core.units import DEFAULT_UNITS,Dimension
        self.assertEqual(DEFAULT_UNITS.parse("kg*m/s^2").dimension,Dimension(length=1,mass=1,time=-2))
        self.assertTrue(DEFAULT_UNITS.compatible("kg*m/s^2","N"))
        self.assertAlmostEqual(DEFAULT_UNITS.convert(1,"km","m"),1000)
        self.assertAlmostEqual(DEFAULT_UNITS.convert(180,"deg","rad"),3.141592653589793)

    def test_mpr_uses_shared_generalized_units(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.mpr import MasterParameterRegister
        m=MasterParameterRegister(Path(tempfile.mkdtemp()))
        r=m.define("test.accel",symbol="a",name="Acceleration",value=9.81,unit="m/s^2",
                   epistemic_class="ESTABLISHED_PHYSICS",provenance="qualification")
        self.assertEqual(r.dimension.length,1);self.assertEqual(r.dimension.time,-2)

    def test_scalar_uncertainty_conversion(self):
        from journeyman.core.units import UncertainValue
        x=UncertainValue(2,"km",.01,provenance="test").converted("m")
        self.assertAlmostEqual(x.value,2000);self.assertAlmostEqual(x.standard_uncertainty,10)

    def test_covariance_validation_and_propagation(self):
        from journeyman.core.units import VectorEstimate,propagate_linear_covariance
        x=VectorEstimate((1,2),"m",((4,1),(1,9)),"test")
        self.assertEqual(x.standard_uncertainties(),(2,3))
        c=propagate_linear_covariance(((2,0),(0,3)),x.covariance)
        self.assertAlmostEqual(c[0][0],16);self.assertAlmostEqual(c[1][1],81);self.assertAlmostEqual(c[0][1],6)

    def test_invalid_covariance_rejected(self):
        from journeyman.core.units import VectorEstimate
        with self.assertRaises(ValueError):VectorEstimate((1,2),"m",((1,2),(0,1)))
        with self.assertRaises(ValueError):VectorEstimate((1,2),"m",((1,2),(2,1)))

    def test_guardian_contract(self):
        from journeyman.core.units import units_guardian_contract
        g=units_guardian_contract();self.assertEqual(g.schema,"JOE-GUARDIAN-UNITS/1")
        self.assertIn("DIMENSION_CHECK",g.capabilities);self.assertIn("silently",g.authority)

    def test_registry_module_publishes_units_service(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.module_runtime import ModuleRuntime
        from journeyman.core.builtin_modules import register_builtin_modules
        from journeyman.core.scientific_registry import ScientificObjectRegistry
        from journeyman.modules.scientific_registry import REGISTRY_MODULE,RegistryInstance
        runtime=ModuleRuntime();register_builtin_modules(runtime)
        try:
            r=ScientificObjectRegistry(Path(tempfile.mkdtemp()),runtime.service("joe.state-events"))
            runtime.register(REGISTRY_MODULE,RegistryInstance(r));runtime.activate("journeyman.registry")
            runtime.publish_service("journeyman.registry","joe.scientific-registry",r)
            from journeyman.core.units import DEFAULT_UNITS
            runtime.publish_service("journeyman.registry","joe.units",DEFAULT_UNITS)
            self.assertTrue(runtime.service("joe.units").compatible("Pa","J/m^3"))
        finally:runtime.stop("journeyman.registry");runtime.stop("joe.core")


class RegistryRelease001CTests(unittest.TestCase):
    def test_release_readiness_passes(self):
        from journeyman.core.scientific_registry import scientific_registry_release_readiness
        r=scientific_registry_release_readiness();self.assertTrue(r.passed,r.failures);self.assertGreaterEqual(len(r.checks),7)
    def test_no_default_objects_after_readiness(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.scientific_registry import ScientificObjectRegistry
        r=ScientificObjectRegistry(Path(tempfile.mkdtemp()));self.assertEqual(r.list(),())
    def test_module_is_v1_and_provides_both_services(self):
        from journeyman.modules.scientific_registry import REGISTRY_MODULE
        self.assertEqual(REGISTRY_MODULE.version,"1.0.0");self.assertIn("joe.scientific-registry",REGISTRY_MODULE.provides);self.assertIn("joe.units",REGISTRY_MODULE.provides)


class Navigation001ATests(unittest.TestCase):
    def test_reference_ellipsoid(self):
        from journeyman.core.navigation import WGS84
        self.assertAlmostEqual(WGS84.semi_major_axis_m,6378137.0)
        self.assertAlmostEqual(WGS84.flattening,1/298.257223563)

    def test_frame_identity_comes_from_scientific_registry(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.scientific_registry import ScientificObjectRegistry
        from journeyman.core.navigation import CoordinateFrameRegistry
        r=ScientificObjectRegistry(Path(tempfile.mkdtemp()));f=CoordinateFrameRegistry(r).create(name="Facility ENU",kind="LOCAL_ENGINEERING",provenance="qualification")
        self.assertEqual(r.get(f.frame_id).object_type.value,"COORDINATE_FRAME");self.assertEqual(f.object_id,f.frame_id)

    def test_position_requires_frame_epoch_covariance(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.scientific_registry import ScientificObjectRegistry
        from journeyman.core.navigation import CoordinateFrameRegistry,TimeEpochService,Position3D
        r=ScientificObjectRegistry(Path(tempfile.mkdtemp()));fr=CoordinateFrameRegistry(r).create(name="Test",kind="GENERIC_CARTESIAN",provenance="test")
        e=TimeEpochService().simulation(0)
        p=Position3D((1,2,3),fr.frame_id,e,((1,0,0),(0,1,0),(0,0,1)),"test",e.origin)
        self.assertEqual(p.frame_id,fr.frame_id);self.assertEqual(p.epoch.scale.value,"SIMULATION")

    def test_frame_and_time_mismatch_rejected(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.scientific_registry import ScientificObjectRegistry
        from journeyman.core.navigation import CoordinateFrameRegistry,TimeEpochService,Position3D
        r=ScientificObjectRegistry(Path(tempfile.mkdtemp()));fs=CoordinateFrameRegistry(r)
        a=fs.create(name="A",kind="GENERIC_CARTESIAN",provenance="test");b=fs.create(name="B",kind="GENERIC_CARTESIAN",provenance="test")
        t=TimeEpochService();e=t.simulation(0);cov=((0,0,0),(0,0,0),(0,0,0))
        p=Position3D((0,0,0),a.frame_id,e,cov,"test",e.origin);q=Position3D((0,0,0),b.frame_id,e,cov,"test",e.origin)
        with self.assertRaises(ValueError):fs.require_comparable(p,q)
        with self.assertRaises(ValueError):t.require_same_scale(e,t.experiment_elapsed(0,"clock.x"))

    def test_host_time_does_not_claim_sync_precision(self):
        from journeyman.core.navigation import TimeEpochService
        e=TimeEpochService().host_utc();self.assertEqual(e.origin.value,"HOST");self.assertEqual(e.synchronization.value,"UNKNOWN")
        self.assertIn("not independently measured",e.provenance)

    def test_guardian_contract(self):
        import tempfile
        from pathlib import Path
        from journeyman.core.scientific_registry import ScientificObjectRegistry
        from journeyman.core.navigation import CoordinateFrameRegistry,navigation_guardian_contract
        f=CoordinateFrameRegistry(ScientificObjectRegistry(Path(tempfile.mkdtemp())))
        g=navigation_guardian_contract(f);self.assertEqual(g.schema,"JOE-GUARDIAN-NAVIGATION/1");self.assertIn("FRAME_REQUIRED",g.requirements);self.assertIn("silently",g.authority)

    def test_navigation_module_descriptor(self):
        from journeyman.modules.navigation import NAV_MODULE
        self.assertIn("journeyman.registry",NAV_MODULE.requires);self.assertIn("joe.navigation",NAV_MODULE.provides);self.assertIn("joe.time-epoch",NAV_MODULE.provides)


class Navigation001BTests(unittest.TestCase):
    def test_wgs84_equator_reference(self):
        from journeyman.core.navigation import geodetic_to_ecef,WGS84
        x,y,z=geodetic_to_ecef(0,0,0);self.assertAlmostEqual(x,WGS84.semi_major_axis_m,places=6);self.assertAlmostEqual(y,0,places=9);self.assertAlmostEqual(z,0,places=9)
    def test_wgs84_pole_reference(self):
        from journeyman.core.navigation import geodetic_to_ecef,WGS84
        x,y,z=geodetic_to_ecef(90,0,0);self.assertAlmostEqual(x,0,places=6);self.assertAlmostEqual(z,WGS84.semi_minor_axis_m,places=6)
    def test_geodetic_ecef_roundtrip(self):
        from journeyman.core.navigation import geodetic_to_ecef,ecef_to_geodetic
        a=(38.1041,-122.2566,42.75);b=ecef_to_geodetic(*geodetic_to_ecef(*a))
        self.assertAlmostEqual(a[0],b[0],places=9);self.assertAlmostEqual(a[1],b[1],places=9);self.assertAlmostEqual(a[2],b[2],places=5)
    def test_enu_rotation_roundtrip(self):
        from journeyman.core.navigation import ecef_delta_to_enu,enu_to_ecef_delta
        d=(10,-4,8);enu=ecef_delta_to_enu(d,38,-122);back=enu_to_ecef_delta(enu,38,-122)
        for a,b in zip(d,back):self.assertAlmostEqual(a,b,places=10)
    def test_enu_ned_semantics(self):
        from journeyman.core.navigation import enu_to_ned,ned_to_enu
        e=(1,2,3);self.assertEqual(enu_to_ned(e),(2,1,-3));self.assertEqual(ned_to_enu(enu_to_ned(e)),e)
    def test_msl_requires_explicit_geoid_correction(self):
        from journeyman.core.navigation import GeoidCorrection,ellipsoid_height_to_msl,msl_height_to_ellipsoid
        g=GeoidCorrection(30.0,"qualification-geoid","test fixture")
        self.assertEqual(ellipsoid_height_to_msl(100,g),70);self.assertEqual(msl_height_to_ellipsoid(70,g),100)
    def test_geodesy_validation(self):
        from journeyman.core.navigation import validate_wgs84_geodesy
        q=validate_wgs84_geodesy();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),6)


class Navigation001CTests(unittest.TestCase):
    def test_cartesian_spherical_roundtrip(self):
        from journeyman.core.navigation import cartesian_to_spherical,spherical_to_cartesian
        p=(3,-4,12);q=spherical_to_cartesian(cartesian_to_spherical(p))
        for a,b in zip(p,q):self.assertAlmostEqual(a,b,places=11)
    def test_quaternion_rotation(self):
        import math
        from journeyman.core.navigation import Quaternion
        q=Quaternion.from_axis_angle((0,0,1),math.pi/2);v=q.rotate((1,0,0))
        self.assertAlmostEqual(v[0],0,places=12);self.assertAlmostEqual(v[1],1,places=12);self.assertAlmostEqual(v[2],0,places=12)
    def test_rigid_transform_inverse(self):
        import uuid,math
        from journeyman.core.navigation import Quaternion,RigidTransform
        a,b=str(uuid.uuid4()),str(uuid.uuid4());t=RigidTransform(a,b,Quaternion.from_axis_angle((1,2,3),.7),(10,-3,5),"test")
        p=(2,4,-1);back=t.inverse().apply_point(t.apply_point(p))
        for x,y in zip(p,back):self.assertAlmostEqual(x,y,places=11)
    def test_transform_chain_and_graph(self):
        import uuid
        from journeyman.core.navigation import Quaternion,RigidTransform,TransformGraph
        a,b,c=[str(uuid.uuid4()) for _ in range(3)];q=Quaternion(1,0,0,0)
        x=RigidTransform(a,b,q,(1,0,0),"a-b");y=RigidTransform(b,c,q,(0,2,0),"b-c")
        g=TransformGraph();g.add(x);g.add(y);z=g.resolve(a,c)
        self.assertEqual(z.apply_point((0,0,0)),(1.0,2.0,0.0))
    def test_position_and_covariance_transform(self):
        import uuid,math
        from journeyman.core.navigation import TimeEpochService,Position3D,RigidTransform,Quaternion,transform_position
        from journeyman.core.state_events import DataOrigin
        a,b=str(uuid.uuid4()),str(uuid.uuid4());e=TimeEpochService().simulation(0)
        p=Position3D((1,0,0),a,e,((4,0,0),(0,1,0),(0,0,9)),"test",DataOrigin.SIMULATION)
        transform=RigidTransform(a,b,Quaternion.from_axis_angle((0,0,1),math.pi/2),(0,0,0),"rotate")
        q=transform_position(p,transform);self.assertEqual(q.frame_id,b);self.assertAlmostEqual(q.values_m[1],1,places=12)
        self.assertAlmostEqual(q.covariance_m2[0][0],1,places=10);self.assertAlmostEqual(q.covariance_m2[1][1],4,places=10)
    def test_vector_not_translated(self):
        import uuid
        from journeyman.core.navigation import Quaternion,RigidTransform
        a,b=str(uuid.uuid4()),str(uuid.uuid4());t=RigidTransform(a,b,Quaternion(1,0,0,0),(100,200,300),"test")
        self.assertEqual(t.apply_vector((1,2,3)),(1.0,2.0,3.0))
    def test_transform_validation(self):
        from journeyman.core.navigation import validate_transform_engine
        r=validate_transform_engine();self.assertTrue(r.passed,r.failures);self.assertGreaterEqual(len(r.checks),4)


class Navigation001DTests(unittest.TestCase):
    def test_navigation_release_readiness(self):
        from journeyman.core.navigation import navigation_release_readiness
        r=navigation_release_readiness();self.assertTrue(r.passed,r.failures);self.assertGreaterEqual(len(r.checks),6)
    def test_navigation_module_promoted_v1(self):
        from journeyman.modules.navigation import NAV_MODULE
        self.assertEqual(NAV_MODULE.version,"1.0.0")
    def test_navigation_workbench_source_is_functional(self):
        from pathlib import Path
        source=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn('class NavigationWorkspace(QWidget):',source)
        self.assertIn('workspace_kind="navigation"',source)
        self.assertIn("geodetic_to_ecef",source)


class Traversability001ATests(unittest.TestCase):
    def test_minkowski_zero_acceleration_and_tides(self):
        from journeyman.core.geometry import minkowski_metric
        from journeyman.core.traversability import evaluate_human_traversability
        p=evaluate_human_traversability(minkowski_metric(),(0,2,1.2,0.3),speed_m_s=1000)
        self.assertAlmostEqual(p.proper_acceleration_m_s2,0,places=8)
        self.assertAlmostEqual(p.radial_tidal_acceleration_m_s2,0,places=6)
        self.assertAlmostEqual(p.lateral_tidal_acceleration_m_s2,0,places=6)
        self.assertTrue(p.overall_pass)

    def test_speed_domain_and_lorentz_factor(self):
        from journeyman.core.traversability import lorentz_factor,C
        self.assertAlmostEqual(lorentz_factor(0),1)
        self.assertAlmostEqual(lorentz_factor(0.6*C),1.25,places=12)
        with self.assertRaises(ValueError):lorentz_factor(C)

    def test_constant_speed_transit(self):
        from journeyman.core.traversability import estimate_constant_speed_transit,C
        r=estimate_constant_speed_transit(1000,0.6*C)
        self.assertAlmostEqual(r.static_frame_time_s,1000/(0.6*C))
        self.assertAlmostEqual(r.traveler_time_s,r.static_frame_time_s/1.25)

    def test_morris_thorne_zero_redshift_static_acceleration(self):
        from journeyman.core.geometry import morris_thorne_metric
        from journeyman.core.traversability import static_proper_acceleration
        m=morris_thorne_metric(throat_radius=1000)
        self.assertAlmostEqual(static_proper_acceleration(m,(0,2000,1.5707963267948966,0)),0,places=7)

    def test_guardian_contract_is_advisory_and_simulation(self):
        from journeyman.core.geometry import minkowski_metric
        from journeyman.core.traversability import evaluate_human_traversability,traversability_guardian_contract
        p=evaluate_human_traversability(minkowski_metric(),(0,2,1.1,.2),speed_m_s=10)
        g=traversability_guardian_contract(p)
        self.assertEqual(g.schema,"JOE-GUARDIAN-TRAVERSABILITY/1");self.assertEqual(g.origin,"SIMULATION")
        self.assertIn("not permission",g.authority)

    def test_tolerance_validation(self):
        from journeyman.core.traversability import HumanTolerance
        with self.assertRaises(ValueError):HumanTolerance(body_length_m=0)

    def test_module_dependencies(self):
        from journeyman.modules.traversability import T1_MODULE
        self.assertIn("journeyman.navigation",T1_MODULE.requires);self.assertIn("journeyman.geometry",T1_MODULE.requires)
        self.assertIn("joe.traversability",T1_MODULE.provides)


class Traversability001BTests(unittest.TestCase):
    def test_margin_and_profile_minkowski(self):
        from journeyman.core.geometry import minkowski_metric
        from journeyman.core.traversability import radial_traversability_profile,HumanTolerance
        q=radial_traversability_profile(minkowski_metric(),(2,3,4),speed_m_s=100,tolerance=HumanTolerance())
        self.assertTrue(q.overall_pass);self.assertEqual(len(q.points),3);self.assertAlmostEqual(q.worst_normalized_margin,1,places=7)
    def test_throat_approach_never_hits_chart_boundary(self):
        from journeyman.core.traversability import throat_approach_radii
        r=throat_approach_radii(100,outer_ratio=5,closest_fraction=1e-4,samples=20)
        self.assertTrue(all(x>100 for x in r));self.assertAlmostEqual(r[-1],500,places=9)
    def test_sr_motion_profile_cruise(self):
        from journeyman.core.traversability import symmetric_accel_cruise_profile
        q=symmetric_accel_cruise_profile(1e9,9.80665,1000)
        self.assertEqual(len(q.segments),3);self.assertAlmostEqual(q.peak_speed_m_s,1000);self.assertAlmostEqual(q.total_distance_m,1e9)
    def test_sr_motion_profile_triangular(self):
        from journeyman.core.traversability import symmetric_accel_cruise_profile
        q=symmetric_accel_cruise_profile(10,9.80665,100000)
        self.assertEqual(len(q.segments),2);self.assertLess(q.peak_speed_m_s,100000)
        self.assertAlmostEqual(sum(x.distance_m for x in q.segments),10)
    def test_uncertainty_margin_linear_function(self):
        from journeyman.core.traversability import propagate_scalar_margin_uncertainty
        q=propagate_scalar_margin_uncertainty(lambda x:2*x,10,0.5,limit=30,sigma_multiplier=3)
        self.assertAlmostEqual(q.nominal,10);self.assertAlmostEqual(q.standard_uncertainty,1,places=7);self.assertAlmostEqual(q.conservative_margin,7,places=7)
    def test_throat_profile_morris_thorne_is_finite(self):
        from journeyman.core.geometry import morris_thorne_metric
        from journeyman.core.traversability import throat_approach_radii,radial_traversability_profile
        m=morris_thorne_metric(throat_radius=1000);rs=throat_approach_radii(1000,outer_ratio=2,closest_fraction=.05,samples=4)
        q=radial_traversability_profile(m,rs,speed_m_s=100,relative_step=1e-5)
        self.assertEqual(len(q.points),4);self.assertTrue(all(x.radius_m>1000 for x in q.points))


class Traversability001CTests(unittest.TestCase):
    def test_release_readiness(self):
        from journeyman.core.traversability import traversability_release_readiness
        r=traversability_release_readiness();self.assertTrue(r.passed,r.failures);self.assertGreaterEqual(len(r.checks),6)
    def test_convergence_minkowski(self):
        from journeyman.core.geometry import minkowski_metric
        from journeyman.core.traversability import traversability_convergence
        r=traversability_convergence(minkowski_metric(),(0,2,1.5707963267948966,3.141592653589793),speed_m_s=100)
        self.assertTrue(r.converged);self.assertEqual(r.terminal_relative_change,0)
    def test_t1_module_promoted_v1(self):
        from journeyman.modules.traversability import T1_MODULE
        self.assertEqual(T1_MODULE.version,"1.0.0")
    def test_t1_workspace_is_wired(self):
        from pathlib import Path
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        main=(Path(__file__).parents[1]/"journeyman"/"ui"/"main_window.py").read_text()
        self.assertIn('class TraversabilityWorkspace(QWidget):',ui);self.assertIn('workspace_kind="traversability"',ui)
        self.assertIn("Human Traversability Analyzer [T-1]",main);self.assertIn('kind == "traversability"',main)


class QFT001ATests(unittest.TestCase):
    def _request(self,tau=1e-9,geometry="geometry.minkowski"):
        from journeyman.core.qft import QFTRequest,FieldKind,QuantumState,SamplingFunction
        return QFTRequest(geometry,"1",FieldKind.MASSLESS_SCALAR,QuantumState.VACUUM,SamplingFunction.LORENTZIAN,
            tau,"inertial observer","none","Minkowski vacuum subtraction",1e-8,"Q-1 qualification")
    def test_reference_qi_is_negative_and_tau_minus_four(self):
        from journeyman.core.qft import ford_roman_lorentzian_massless_scalar_bound,SolverStatus
        a=ford_roman_lorentzian_massless_scalar_bound(self._request(1e-9))
        b=ford_roman_lorentzian_massless_scalar_bound(self._request(2e-9))
        self.assertEqual(a.status,SolverStatus.PASS);self.assertLess(a.lower_bound_energy_density_j_m3,0)
        self.assertAlmostEqual(a.lower_bound_energy_density_j_m3/b.lower_bound_energy_density_j_m3,16,places=10)
    def test_curved_geometry_is_domain_invalid(self):
        from journeyman.core.qft import ford_roman_lorentzian_massless_scalar_bound,SolverStatus
        r=ford_roman_lorentzian_massless_scalar_bound(self._request(geometry="geometry.morris-thorne"))
        self.assertEqual(r.status,SolverStatus.DOMAIN_INVALID);self.assertIsNone(r.lower_bound_energy_density_j_m3)
    def test_invalid_sampling_time_rejected(self):
        with self.assertRaises(ValueError):self._request(0)
    def test_sampling_sweep(self):
        from journeyman.core.qft import qi_sampling_sweep
        q=qi_sampling_sweep(self._request(),(1e-9,2e-9,4e-9));self.assertEqual(len(q),3)
        self.assertTrue(abs(q[0].lower_bound_energy_density_j_m3)>abs(q[1].lower_bound_energy_density_j_m3)>abs(q[2].lower_bound_energy_density_j_m3))
    def test_guardian_preserves_status_and_authority(self):
        from journeyman.core.qft import ford_roman_lorentzian_massless_scalar_bound,qft_guardian_contract
        req=self._request();res=ford_roman_lorentzian_massless_scalar_bound(req);g=qft_guardian_contract(req,res)
        self.assertEqual(g.schema,"JOE-GUARDIAN-QFT/1");self.assertEqual(g.result["status"],"PASS");self.assertIn("cannot reinterpret",g.authority)
    def test_unknown_physics_has_no_numeric_answer(self):
        from journeyman.core.qft import unsupported_semiclassical_request,SolverStatus
        r=unsupported_semiclassical_request(message="No validated model for requested architecture")
        self.assertEqual(r.status,SolverStatus.UNKNOWN_PHYSICS);self.assertIsNone(r.lower_bound_energy_density_j_m3)
    def test_q1_module_dependencies(self):
        from journeyman.modules.qft import Q1_MODULE
        self.assertIn("journeyman.geometry",Q1_MODULE.requires);self.assertIn("journeyman.stress-energy",Q1_MODULE.requires);self.assertIn("joe.qft",Q1_MODULE.provides)


class QFT001BTests(unittest.TestCase):
    def req(self,tau=1e-9,geometry="geometry.minkowski"):
        from journeyman.core.qft import QFTRequest,FieldKind,QuantumState,SamplingFunction
        return QFTRequest(geometry,"1",FieldKind.MASSLESS_SCALAR,QuantumState.VACUUM,SamplingFunction.LORENTZIAN,
            tau,"inertial observer","none","Minkowski vacuum subtraction",1e-8,"Q1-001B qualification")
    def test_negative_energy_exposure(self):
        from journeyman.core.qft import negative_energy_exposure
        q=negative_energy_exposure(-10,2,3);self.assertEqual(q.energy_j,-30);self.assertEqual(q.time_integrated_density_j_s_m3,-20)
        with self.assertRaises(ValueError):negative_energy_exposure(1,2,3)
    def test_feasibility_margin_boundary(self):
        from journeyman.core.qft import ford_roman_lorentzian_massless_scalar_bound,qi_feasibility_margin
        req=self.req();b=ford_roman_lorentzian_massless_scalar_bound(req).lower_bound_energy_density_j_m3
        q=qi_feasibility_margin(req,b);self.assertTrue(q.satisfies_reference_bound);self.assertAlmostEqual(q.margin_j_m3,0)
    def test_feasibility_outside_domain_has_no_margin(self):
        from journeyman.core.qft import qi_feasibility_margin,SolverStatus
        q=qi_feasibility_margin(self.req(geometry="geometry.morris-thorne"),-1)
        self.assertEqual(q.status,SolverStatus.DOMAIN_INVALID);self.assertIsNone(q.margin_j_m3)
    def test_duration_inversion_roundtrip(self):
        from journeyman.core.qft import ford_roman_lorentzian_massless_scalar_bound,maximum_reference_sampling_time
        req=self.req(2e-9);mag=abs(ford_roman_lorentzian_massless_scalar_bound(req).lower_bound_energy_density_j_m3)
        q=maximum_reference_sampling_time(req,mag);self.assertAlmostEqual(q.maximum_sampling_time_s,2e-9,places=20)
    def test_pulse_accounting(self):
        from journeyman.core.qft import Pulse,account_pulses
        q=account_pulses((Pulse(0,2,-5),Pulse(3,1,12)))
        self.assertEqual(q.negative_time_integrated_density_j_s_m3,-10);self.assertEqual(q.positive_time_integrated_density_j_s_m3,12);self.assertEqual(q.net_time_integrated_density_j_s_m3,2)
    def test_magnitude_duration_curve_scaling(self):
        from journeyman.core.qft import qi_magnitude_duration_curve
        q=qi_magnitude_duration_curve(self.req(),(1e-9,2e-9))
        self.assertAlmostEqual(q[0].maximum_negative_magnitude_j_m3/q[1].maximum_negative_magnitude_j_m3,16,places=10)


class QFT001CTests(unittest.TestCase):
    def test_ideal_casimir_scaling_and_pressure_relation(self):
        from journeyman.core.qft import CasimirRequest,ideal_parallel_plate_casimir,SolverStatus
        def r(a):return ideal_parallel_plate_casimir(CasimirRequest(a,1,0,"IDEAL_PERFECT_CONDUCTOR","PARALLEL_PLATES","qualification"))
        a,b=r(1e-6),r(2e-6);self.assertEqual(a.status,SolverStatus.PASS)
        self.assertAlmostEqual(a.energy_density_j_m3/b.energy_density_j_m3,16,places=10)
        self.assertAlmostEqual(a.pressure_pa/a.energy_density_j_m3,3,places=10)
    def test_casimir_finite_temperature_refused(self):
        from journeyman.core.qft import CasimirRequest,ideal_parallel_plate_casimir,SolverStatus
        q=ideal_parallel_plate_casimir(CasimirRequest(1e-6,1,300,"IDEAL_PERFECT_CONDUCTOR","PARALLEL_PLATES","qualification"))
        self.assertEqual(q.status,SolverStatus.MODEL_UNAVAILABLE);self.assertIsNone(q.energy_density_j_m3)
    def test_squeezed_reference_can_have_negative_phase(self):
        from journeyman.core.qft import SqueezedVacuumRequest,single_mode_squeezed_vacuum_reference,SolverStatus
        q=single_mode_squeezed_vacuum_reference(SqueezedVacuumRequest(1e15,.5,0,1e-18,0,"qualification"))
        self.assertEqual(q.status,SolverStatus.PASS);self.assertLess(q.normal_ordered_energy_density_j_m3,0);self.assertGreater(q.mean_excitation_number,0)
    def test_squeezed_phase_can_be_positive(self):
        import math
        from journeyman.core.qft import SqueezedVacuumRequest,single_mode_squeezed_vacuum_reference
        q=single_mode_squeezed_vacuum_reference(SqueezedVacuumRequest(1e15,.5,0,1e-18,math.pi,"qualification"))
        self.assertGreater(q.normal_ordered_energy_density_j_m3,0)
    def test_mechanism_comparison_preserves_domains(self):
        from journeyman.core.qft import CasimirRequest,ideal_parallel_plate_casimir,compare_reference_mechanisms
        c=ideal_parallel_plate_casimir(CasimirRequest(1e-6,1,0,"IDEAL_PERFECT_CONDUCTOR","PARALLEL_PLATES","qualification"))
        q=compare_reference_mechanisms(casimir=c);self.assertEqual(q[0].mechanism,"CASIMIR");self.assertIn("boundary",q[0].domain)
    def test_request_consistency_detects_boundary_mismatch(self):
        from journeyman.core.qft import QFTRequest,FieldKind,QuantumState,SamplingFunction,validate_qft_request_consistency,SolverStatus
        q=QFTRequest("geometry.minkowski","1",FieldKind.MASSLESS_SCALAR,QuantumState.VACUUM,SamplingFunction.LORENTZIAN,1e-9,
            "inertial","plates","vacuum subtraction",1e-8,"qualification")
        self.assertEqual(validate_qft_request_consistency(q)[0],SolverStatus.INPUT_INCONSISTENT)


class QFT001DTests(unittest.TestCase):
    def req(self,tau=1e-9):
        from journeyman.core.qft import QFTRequest,FieldKind,QuantumState,SamplingFunction
        return QFTRequest("geometry.minkowski","1",FieldKind.MASSLESS_SCALAR,QuantumState.VACUUM,SamplingFunction.LORENTZIAN,
            tau,"inertial","none","vacuum subtraction",1e-8,"Q1-001D qualification")
    def test_flatness_vanishing_curvature(self):
        from journeyman.core.qft import local_flatness_diagnostic,SolverStatus
        q=local_flatness_diagnostic(1e-9,None);self.assertEqual(q.status,SolverStatus.PASS);self.assertTrue(q.locally_flat_scale_separation)
    def test_flatness_rejects_large_sampling_scale(self):
        from journeyman.core.qft import local_flatness_diagnostic,SolverStatus
        q=local_flatness_diagnostic(1e-6,1,threshold=.01);self.assertEqual(q.status,SolverStatus.DOMAIN_INVALID);self.assertFalse(q.locally_flat_scale_separation)
    def test_qi_stress_energy_comparison(self):
        from journeyman.core.qft import ford_roman_lorentzian_massless_scalar_bound,compare_required_stress_energy_to_qi
        req=self.req();b=ford_roman_lorentzian_massless_scalar_bound(req).lower_bound_energy_density_j_m3
        self.assertTrue(compare_required_stress_energy_to_qi(b/2,req).satisfies_reference_bound)
        self.assertFalse(compare_required_stress_energy_to_qi(b*2,req).satisfies_reference_bound)
    def test_qi_log_sensitivity_is_minus_four(self):
        from journeyman.core.qft import qi_sampling_sensitivity
        q=qi_sampling_sensitivity(self.req());self.assertAlmostEqual(q.logarithmic_sensitivity_tau,-4,places=7);self.assertLess(q.finite_difference_relative_error,1e-7)
    def test_qi_uncertainty_factor_four(self):
        from journeyman.core.qft import propagate_qi_sampling_time_uncertainty
        q=propagate_qi_sampling_time_uncertainty(self.req(1e-9),1e-11);self.assertAlmostEqual(q.relative_standard_uncertainty,.04,places=12)
    def test_semiclassical_consistency_warns_not_theorem_extension(self):
        from journeyman.core.qft import local_flatness_diagnostic,semiclassical_consistency,SolverStatus
        f=local_flatness_diagnostic(1e-12,1);q=semiclassical_consistency(self.req(1e-12),local_flatness=f)
        self.assertEqual(q.status,SolverStatus.PASS);self.assertTrue(any("does not extend" in x for x in q.warnings))
    def test_curvature_scale_zero_tensor(self):
        import numpy as np
        from journeyman.core.qft import local_curvature_scale_from_riemann_covariant
        q=local_curvature_scale_from_riemann_covariant(np.zeros((4,4,4,4)),np.diag([-1,1,1,1]),provenance="test")
        self.assertEqual(q.kretschmann_m4,0);self.assertIsNone(q.characteristic_length_m)


class QFT001ETests(unittest.TestCase):
    def req(self,tau=1e-9):
        from journeyman.core.qft import QFTRequest,FieldKind,QuantumState,SamplingFunction
        return QFTRequest("geometry.minkowski","1",FieldKind.MASSLESS_SCALAR,QuantumState.VACUUM,SamplingFunction.LORENTZIAN,
            tau,"inertial","none","vacuum subtraction",1e-8,"Q1-001E qualification")
    def test_lorentzian_profile_normalized(self):
        from journeyman.core.qft import lorentzian_sampling_profile,integrate_sampling_profile
        p=lorentzian_sampling_profile(1e-9,samples=1001)
        q=integrate_sampling_profile(p,(1.0,)*len(p.times_s))
        self.assertAlmostEqual(q.normalized_integral,1,places=12);self.assertAlmostEqual(q.integral,1,places=12)
    def test_constant_energy_samples_to_constant(self):
        from journeyman.core.qft import lorentzian_sampling_profile,sample_energy_density
        p=lorentzian_sampling_profile(1e-9,samples=501);q=sample_energy_density(p,(-7.0,)*len(p.times_s))
        self.assertAlmostEqual(q.sampled_energy_density_j_m3,-7,places=10)
    def test_sampling_profile_rejects_nonmonotonic_time(self):
        from journeyman.core.qft import SamplingProfile
        with self.assertRaises(ValueError):SamplingProfile((0,1,1),(1,1,1),"bad","test")
    def test_qi_numerical_verification(self):
        from journeyman.core.qft import verify_qi_reference_numerically
        q=verify_qi_reference_numerically(self.req());self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),3)
    def test_qi_verification_refuses_invalid_domain(self):
        from journeyman.core.qft import QFTRequest,verify_qi_reference_numerically
        r=self.req();bad=QFTRequest("geometry.morris-thorne",r.geometry_revision,r.field,r.state,r.sampling,r.sampling_time_s,r.observer,r.boundary_conditions,r.renormalization,r.requested_precision,r.provenance,r.origin)
        self.assertFalse(verify_qi_reference_numerically(bad).passed)
    def test_model_comparison_warning_prevents_interchangeability(self):
        from journeyman.core.qft import ford_roman_lorentzian_massless_scalar_bound,q1_model_comparison
        q=q1_model_comparison(qi=ford_roman_lorentzian_massless_scalar_bound(self.req()))
        self.assertIn("not interchangeable",q.warning);self.assertEqual(q.entries[0].mechanism,"QUANTUM_INEQUALITY_BOUND")


class QFT001FTests(unittest.TestCase):
    def test_q1_release_readiness(self):
        from journeyman.core.qft import q1_release_readiness
        q=q1_release_readiness();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),7)
    def test_q1_module_promoted_v1(self):
        from journeyman.modules.qft import Q1_MODULE
        self.assertEqual(Q1_MODULE.version,"1.0.0")
    def test_q1_workspace_wired(self):
        from pathlib import Path
        root=Path(__file__).parents[1]
        ui=(root/"journeyman"/"ui"/"workspaces.py").read_text()
        main=(root/"journeyman"/"ui"/"main_window.py").read_text()
        self.assertIn("class QFTWorkspace(QWidget):",ui);self.assertIn('workspace_kind="qft"',ui)
        self.assertIn("QFT / Semiclassical / Quantum Inequality [Q-1]",main);self.assertIn('kind == "qft"',main)
    def test_q1_workspace_preserves_reference_labels(self):
        from pathlib import Path
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("MODEL / SIMULATION REFERENCE",ui);self.assertIn("REFERENCE BOUND",ui)


class Chronology001ATests(unittest.TestCase):
    def ev(self,id,t,x=0,frame="nav.inertial"):
        from journeyman.core.chronology import ChronologyEvent
        return ChronologyEvent(id,t,(x,0,0),frame,"J2000","TCB",provenance="C1 qualification")
    def test_timelike_causal_order(self):
        from journeyman.core.chronology import minkowski_interval,IntervalClass,CausalOrder
        q=minkowski_interval(self.ev("a",0),self.ev("b",1,1))
        self.assertEqual(q.interval_class,IntervalClass.TIMELIKE);self.assertEqual(q.causal_order,CausalOrder.A_BEFORE_B)
    def test_spacelike_unordered(self):
        from journeyman.core.chronology import minkowski_interval,IntervalClass,CausalOrder
        q=minkowski_interval(self.ev("a",0),self.ev("b",0,1))
        self.assertEqual(q.interval_class,IntervalClass.SPACELIKE);self.assertEqual(q.causal_order,CausalOrder.SPACELIKE_UNORDERED)
    def test_frame_mismatch_rejected(self):
        from journeyman.core.chronology import minkowski_interval,ChronologyStatus
        q=minkowski_interval(self.ev("a",0),self.ev("b",1,frame="other"))
        self.assertEqual(q.status,ChronologyStatus.INPUT_INCONSISTENT);self.assertIsNone(q.interval_class)
    def test_piecewise_proper_time(self):
        from journeyman.core.chronology import WorldlineSegment,piecewise_inertial_proper_time,C
        q=piecewise_inertial_proper_time((WorldlineSegment(10,0,"rest"),WorldlineSegment(10,.6*C,"cruise")))
        self.assertAlmostEqual(q.coordinate_time_s,20);self.assertAlmostEqual(q.proper_time_s,18,places=10);self.assertAlmostEqual(q.desynchronization_s,2,places=10)
    def test_clock_offset_uncertainty(self):
        from journeyman.core.chronology import ClockReading,clock_offset
        q=clock_offset(ClockReading("A",10,.3,"test"),ClockReading("B",9,.4,"test"))
        self.assertEqual(q.offset_s,1);self.assertAlmostEqual(q.combined_standard_uncertainty_s,.5);self.assertAlmostEqual(q.significance_sigma,2)
    def test_declared_mapping_is_explicit_model_assessment(self):
        from journeyman.core.chronology import DeclaredMouthMapping,assess_declared_mouth_mapping
        q=assess_declared_mouth_mapping(DeclaredMouthMapping(self.ev("A",0),self.ev("B",1),2,0,"SIMULATION declaration"))
        self.assertTrue(q.chronology_reversal_in_declared_model);self.assertIn("DECLARED/SIMULATED",q.message)
    def test_guardian_authority(self):
        from journeyman.core.chronology import minkowski_interval,chronology_guardian_contract
        g=chronology_guardian_contract(interval=minkowski_interval(self.ev("a",0),self.ev("b",1)))
        self.assertEqual(g.schema,"JOE-GUARDIAN-CHRONOLOGY/1");self.assertIn("cannot assert physical CTC",g.authority)


class Chronology001BTests(unittest.TestCase):
    def test_relativistic_desynchronization(self):
        from journeyman.core.chronology import DesynchronizationScenario,WorldlineSegment,relativistic_desynchronization,C
        q=relativistic_desynchronization(DesynchronizationScenario(10,(WorldlineSegment(10,.6*C,"travel"),),"test"))
        self.assertAlmostEqual(q.traveler_proper_time_s,8,places=10);self.assertAlmostEqual(q.offset_s,2,places=10)
    def test_loop_condition_threshold(self):
        from journeyman.core.chronology import ChronologyLoopRequest,assess_round_trip_loop_condition
        q=assess_round_trip_loop_condition(ChronologyLoopRequest(100,2,100))
        self.assertAlmostEqual(q.external_return_time_s,1);self.assertAlmostEqual(q.chronology_margin_s,1);self.assertTrue(q.modeled_closed_causal_loop_condition)
    def test_loop_condition_below_threshold(self):
        from journeyman.core.chronology import ChronologyLoopRequest,assess_round_trip_loop_condition
        q=assess_round_trip_loop_condition(ChronologyLoopRequest(100,.5,100))
        self.assertFalse(q.modeled_closed_causal_loop_condition);self.assertLess(q.chronology_margin_s,0)
    def test_loop_uncertainty_propagation(self):
        from journeyman.core.chronology import ChronologyLoopRequest,assess_round_trip_loop_condition
        q=assess_round_trip_loop_condition(ChronologyLoopRequest(100,2,100,.1,10,0))
        self.assertAlmostEqual(q.chronology_margin_standard_uncertainty_s,2**.5*.1,places=12)
        self.assertGreater(q.significance_sigma,0)
    def test_chronology_horizon_threshold(self):
        from journeyman.core.chronology import chronology_horizon_estimate,C
        q=chronology_horizon_estimate(external_separation_m=C,mouth_time_offset_s=1)
        self.assertAlmostEqual(q.threshold_offset_s,1,places=12);self.assertTrue(q.horizon_crossed_in_declared_model)
    def test_worldline_sampling_endpoint(self):
        from journeyman.core.chronology import WorldlineSegment,sample_piecewise_worldline,C
        q=sample_piecewise_worldline((WorldlineSegment(10,.6*C,"cruise"),),samples_per_segment=5)
        self.assertEqual(len(q),6);self.assertAlmostEqual(q[-1].coordinate_time_s,10);self.assertAlmostEqual(q[-1].proper_time_s,8,places=10)
    def test_margin_sweep_crosses_zero(self):
        from journeyman.core.chronology import ChronologyLoopRequest,chronology_margin_sweep
        q=chronology_margin_sweep(ChronologyLoopRequest(100,0,100),(0.5,1,1.5))
        self.assertLess(q[0].chronology_margin_s,0);self.assertEqual(q[1].chronology_margin_s,0);self.assertTrue(q[2].modeled_closed_causal_loop_condition)
    def test_expanded_guardian_preserves_model_warning(self):
        from journeyman.core.chronology import ChronologyLoopRequest,assess_round_trip_loop_condition,expanded_chronology_guardian_contract
        g=expanded_chronology_guardian_contract(loop=assess_round_trip_loop_condition(ChronologyLoopRequest(100,2,100)))
        self.assertEqual(g.schema,"JOE-GUARDIAN-CHRONOLOGY/1");self.assertIn("not physical CTC evidence",g.authority)


class Chronology001CTests(unittest.TestCase):
    def req(self,offset=2):
        from journeyman.core.chronology import ChronologyLoopRequest
        return ChronologyLoopRequest(100,offset,100,.1,1,1,"C1-001C qualification")
    def test_uncertainty_envelope_robust_loop(self):
        from journeyman.core.chronology import assess_round_trip_loop_condition,chronology_uncertainty_envelope
        q=chronology_uncertainty_envelope(assess_round_trip_loop_condition(self.req(2)),confidence_factor=3)
        self.assertEqual(q.classification,"ROBUST_MODELED_LOOP");self.assertGreater(q.lower_margin_s,0)
    def test_uncertainty_envelope_indeterminate(self):
        from journeyman.core.chronology import assess_round_trip_loop_condition,chronology_uncertainty_envelope
        q=chronology_uncertainty_envelope(assess_round_trip_loop_condition(self.req(1)),confidence_factor=3)
        self.assertEqual(q.classification,"INDETERMINATE_WITHIN_UNCERTAINTY")
    def test_chronology_protection_returns_unknown_physics_at_threshold(self):
        from journeyman.core.chronology import chronology_horizon_estimate,chronology_protection_diagnostic,ChronologyStatus
        h=chronology_horizon_estimate(external_separation_m=100,mouth_time_offset_s=2,limiting_signal_speed_m_s=100)
        q=chronology_protection_diagnostic(horizon=h,qft_solver_status="PASS")
        self.assertEqual(q.status,ChronologyStatus.UNKNOWN_PHYSICS);self.assertIn("unresolved",q.conclusion)
    def test_numerical_verification(self):
        from journeyman.core.chronology import chronology_numerical_verification
        q=chronology_numerical_verification(self.req());self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),3)
    def test_experiment_record_is_simulation_labeled(self):
        from journeyman.core.chronology import analyze_chronology_experiment
        q=analyze_chronology_experiment("C1-test",self.req());self.assertTrue(q.epistemic_classification.startswith("SIMULATED_"));self.assertTrue(q.verification.passed)
    def test_c1_release_readiness(self):
        from journeyman.core.chronology import c1_release_readiness
        q=c1_release_readiness();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),6)


class Chronology001DTests(unittest.TestCase):
    def test_c1_module_promoted_v1(self):
        from journeyman.modules.chronology import C1_MODULE
        self.assertEqual(C1_MODULE.version,"1.0.0")
    def test_c1_workspace_wired(self):
        from pathlib import Path
        root=Path(__file__).parents[1]
        ui=(root/"journeyman"/"ui"/"workspaces.py").read_text()
        main=(root/"journeyman"/"ui"/"main_window.py").read_text()
        self.assertIn("class ChronologyWorkspace(QWidget):",ui)
        self.assertIn('workspace_kind="chronology"',ui)
        self.assertIn("Chronology Analyzer [C-1]",main)
        self.assertIn('kind == "chronology"',main)
    def test_c1_workspace_preserves_simulation_warning(self):
        from pathlib import Path
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("NOT PHYSICAL WORMHOLE OR CTC TELEMETRY",ui)
        self.assertIn("Positive chronology margin is not evidence",ui)
    def test_c1_release_readiness_still_passes(self):
        from journeyman.core.chronology import c1_release_readiness
        q=c1_release_readiness();self.assertTrue(q.passed,q.failures)


class MouthDynamics001ATests(unittest.TestCase):
    def mouth(self,role,x=0,tau=10,v=(0,0,0),frame="nav.inertial"):
        from journeyman.core.mouth_dynamics import MouthState,MouthRole
        return MouthState("mouth-"+role.value,role,10,tau,(x,0,0),v,frame,"J2000","TCB",.1,.01,"D1 qualification")
    def pair(self):
        from journeyman.core.mouth_dynamics import MouthPairState,MouthRole
        return MouthPairState(self.mouth(MouthRole.A,0,10),self.mouth(MouthRole.B,100,9),"pair-1","D1 qualification")
    def test_pair_separation(self):
        from journeyman.core.mouth_dynamics import mouth_pair_separation,MouthDynamicsStatus
        q=mouth_pair_separation(self.pair());self.assertEqual(q.status,MouthDynamicsStatus.PASS);self.assertEqual(q.separation_m,100);self.assertAlmostEqual(q.combined_position_standard_uncertainty_m,2**.5*.1)
    def test_frame_mismatch_rejected(self):
        from journeyman.core.mouth_dynamics import MouthPairState,MouthRole,mouth_pair_separation,MouthDynamicsStatus
        q=mouth_pair_separation(MouthPairState(self.mouth(MouthRole.A),self.mouth(MouthRole.B,frame="other"),"p","test"))
        self.assertEqual(q.status,MouthDynamicsStatus.INPUT_INCONSISTENT);self.assertIsNone(q.separation_m)
    def test_desynchronization(self):
        from journeyman.core.mouth_dynamics import mouth_desynchronization
        q=mouth_desynchronization(self.pair());self.assertEqual(q.proper_time_offset_a_minus_b_s,1);self.assertAlmostEqual(q.combined_standard_uncertainty_s,2**.5*.01)
    def test_transport_special_relativistic_proper_time(self):
        from journeyman.core.mouth_dynamics import MouthRole,TransportSegment,propagate_piecewise_inertial_transport,C
        q=propagate_piecewise_inertial_transport(self.mouth(MouthRole.B,tau=0),(TransportSegment(10,(.6*C,0,0),"cruise"),))
        self.assertAlmostEqual(q.coordinate_elapsed_s,10);self.assertAlmostEqual(q.proper_elapsed_s,8,places=10);self.assertAlmostEqual(q.relativistic_desynchronization_s,2,places=10)
    def test_superluminal_transport_rejected(self):
        from journeyman.core.mouth_dynamics import TransportSegment,C
        with self.assertRaises(ValueError):TransportSegment(1,(C,0,0),"bad")
    def test_guardian_contract(self):
        from journeyman.core.mouth_dynamics import mouth_pair_separation,mouth_desynchronization,mouth_dynamics_guardian_contract
        p=self.pair();g=mouth_dynamics_guardian_contract(p,separation=mouth_pair_separation(p),desynchronization=mouth_desynchronization(p))
        self.assertEqual(g.schema,"JOE-GUARDIAN-MOUTH-DYNAMICS/1");self.assertIn("cannot create/command a mouth",g.authority)
    def test_d1_module_dependencies(self):
        from journeyman.modules.mouth_dynamics import D1_MODULE
        self.assertIn("journeyman.navigation",D1_MODULE.requires);self.assertIn("journeyman.chronology",D1_MODULE.requires);self.assertIn("joe.mouth-dynamics",D1_MODULE.provides)


class MouthDynamics001BTests(unittest.TestCase):
    def mouth(self,role,x=0,tau=0):
        from journeyman.core.mouth_dynamics import MouthState
        return MouthState("mouth-"+role.value,role,0,tau,(x,0,0),(0,0,0),"nav.inertial","J2000","TCB",.1,.01,"D1-001B qualification")
    def test_accelerated_transport_rest_to_point6c(self):
        from journeyman.core.mouth_dynamics import MouthRole,AcceleratedTransportSegment,propagate_accelerated_transport,C
        q=propagate_accelerated_transport(self.mouth(MouthRole.B),(AcceleratedTransportSegment(10,(0,0,0),(.6*C,0,0),"ramp"),),steps_per_segment=256)
        self.assertAlmostEqual(q.coordinate_elapsed_s,10,places=10);self.assertLess(q.proper_elapsed_s,10);self.assertGreater(q.distance_traveled_m,0);self.assertEqual(q.integration_steps,256)
    def test_accelerated_transport_convergence(self):
        from journeyman.core.mouth_dynamics import MouthRole,AcceleratedTransportSegment,propagate_accelerated_transport,C
        q=propagate_accelerated_transport(self.mouth(MouthRole.B),(AcceleratedTransportSegment(10,(0,0,0),(.5*C,0,0),"ramp"),),steps_per_segment=256)
        self.assertGreaterEqual(q.convergence_estimate_s,0);self.assertLess(q.convergence_estimate_s,1e-3)
    def test_pair_evolution(self):
        from journeyman.core.mouth_dynamics import MouthRole,AcceleratedTransportSegment,propagate_accelerated_transport,evolve_pair_with_transport,C
        moving=propagate_accelerated_transport(self.mouth(MouthRole.B,100),(AcceleratedTransportSegment(10,(0,0,0),(.1*C,0,0),"ramp"),))
        q=evolve_pair_with_transport(self.mouth(MouthRole.A),moving)
        self.assertTrue(q.samples);self.assertGreater(q.maximum_separation_m,q.minimum_separation_m);self.assertGreater(q.final_clock_offset_s,0)
    def test_pair_evolution_chronology_history(self):
        from journeyman.core.mouth_dynamics import MouthRole,AcceleratedTransportSegment,propagate_accelerated_transport,evolve_pair_with_transport,C
        moving=propagate_accelerated_transport(self.mouth(MouthRole.B),(AcceleratedTransportSegment(100,(0,0,0),(.9*C,0,0),"ramp"),))
        q=evolve_pair_with_transport(self.mouth(MouthRole.A),moving,chronology_return_speed_m_s=C)
        self.assertTrue(q.chronology_coupled);self.assertIsNotNone(q.samples[-1].chronology_margin_s)
    def test_transport_uncertainty(self):
        from journeyman.core.mouth_dynamics import MouthRole,AcceleratedTransportSegment,propagate_accelerated_transport,transport_timing_uncertainty,C
        moving=propagate_accelerated_transport(self.mouth(MouthRole.B),(AcceleratedTransportSegment(10,(0,0,0),(.5*C,0,0),"ramp"),))
        q=transport_timing_uncertainty(moving,initial_clock_uncertainty_s=.01,velocity_standard_uncertainty_m_s=100)
        self.assertGreaterEqual(q.proper_time_standard_uncertainty_s,.01)
    def test_d1_c1_coupling(self):
        from journeyman.core.mouth_dynamics import MouthRole,AcceleratedTransportSegment,propagate_accelerated_transport,evolve_pair_with_transport,couple_transport_to_chronology,C
        moving=propagate_accelerated_transport(self.mouth(MouthRole.B),(AcceleratedTransportSegment(100,(0,0,0),(.9*C,0,0),"ramp"),))
        evolution=evolve_pair_with_transport(self.mouth(MouthRole.A),moving)
        q=couple_transport_to_chronology(evolution,external_return_speed_m_s=C)
        self.assertEqual(q.chronology_margin_s,q.final_mouth_time_offset_s-q.external_return_time_s);self.assertIn("SIMULATED",q.message)
    def test_superluminal_accelerated_endpoint_rejected(self):
        from journeyman.core.mouth_dynamics import AcceleratedTransportSegment,C
        with self.assertRaises(ValueError):AcceleratedTransportSegment(1,(0,0,0),(C,0,0),"bad")


class MouthDynamics001CTests(unittest.TestCase):
    def mouth(self,role):
        from journeyman.core.mouth_dynamics import MouthState
        return MouthState("mouth-"+role.value,role,0,0,(0,0,0),(0,0,0),"nav.inertial","J2000","TCB",.1,.01,"D1-001C qualification")
    def request(self,beta=.5):
        from journeyman.core.mouth_dynamics import SymmetricMissionRequest,C
        return SymmetricMissionRequest(beta*C,100,10,100,10,"D1-001C qualification")
    def test_symmetric_profile_returns_near_origin(self):
        from journeyman.core.mouth_dynamics import MouthRole,analyze_symmetric_mission
        q=analyze_symmetric_mission(self.mouth(MouthRole.B),self.request())
        self.assertTrue(q.returned_near_origin);self.assertLess(q.final_displacement_m,1e-4);self.assertGreater(q.final_desynchronization_s,0)
    def test_target_solver_recovers_known_desynchronization(self):
        from journeyman.core.mouth_dynamics import MouthRole,analyze_symmetric_mission,solve_cruise_speed_for_target_desynchronization
        initial=self.mouth(MouthRole.B);known=analyze_symmetric_mission(initial,self.request(.4)).final_desynchronization_s
        q=solve_cruise_speed_for_target_desynchronization(initial,self.request(.2),known,tolerance_s=1e-7)
        self.assertEqual(q.status.value,"PASS");self.assertLess(abs(q.residual_s),1e-7)
    def test_unreachable_target_rejected(self):
        from journeyman.core.mouth_dynamics import MouthRole,solve_cruise_speed_for_target_desynchronization,MouthDynamicsStatus
        q=solve_cruise_speed_for_target_desynchronization(self.mouth(MouthRole.B),self.request(),1e9,max_beta=.8)
        self.assertEqual(q.status,MouthDynamicsStatus.DOMAIN_INVALID);self.assertIsNone(q.cruise_speed_m_s)
    def test_speed_sensitivity_monotonic(self):
        from journeyman.core.mouth_dynamics import MouthRole,mission_speed_sensitivity,C
        q=mission_speed_sensitivity(self.mouth(MouthRole.B),self.request(),(.1*C,.3*C,.5*C))
        self.assertLess(q[0].desynchronization_s,q[1].desynchronization_s);self.assertLess(q[1].desynchronization_s,q[2].desynchronization_s)
    def test_mission_feasibility_warnings(self):
        from journeyman.core.mouth_dynamics import MouthRole,mission_feasibility,C
        q=mission_feasibility(self.mouth(MouthRole.B),self.mouth(MouthRole.A),self.request(.8),external_return_speed_m_s=C,
                              clock_uncertainty_s=.01,velocity_uncertainty_m_s=100)
        self.assertTrue(q.kinematic_domain_valid);self.assertGreater(q.peak_separation_m,0);self.assertTrue(any("KINEMATIC SIMULATION" in x for x in q.warnings))
    def test_expanded_guardian_contract(self):
        from journeyman.core.mouth_dynamics import MouthRole,analyze_symmetric_mission,mission_feasibility,expanded_mouth_dynamics_guardian_contract
        initial=self.mouth(MouthRole.B);stationary=self.mouth(MouthRole.A);mission=analyze_symmetric_mission(initial,self.request())
        feas=mission_feasibility(initial,stationary,self.request())
        g=expanded_mouth_dynamics_guardian_contract(mission=mission,feasibility=feas)
        self.assertEqual(g.schema,"JOE-GUARDIAN-MOUTH-DYNAMICS/1");self.assertIn("cannot authorize transport",g.authority)


class MouthDynamics001DTests(unittest.TestCase):
    def mouth(self,role):
        from journeyman.core.mouth_dynamics import MouthState
        return MouthState("mouth-"+role.value,role,0,0,(0,0,0),(0,0,0),"nav.inertial","J2000","TCB",.1,.01,"D1-001D qualification")
    def request(self):
        from journeyman.core.mouth_dynamics import SymmetricMissionRequest,C
        return SymmetricMissionRequest(.5*C,100,10,100,10,"D1-001D qualification")
    def test_transport_convergence(self):
        from journeyman.core.mouth_dynamics import MouthRole,d1_transport_convergence
        q=d1_transport_convergence(self.mouth(MouthRole.B),self.request(),step_counts=(32,64,128,256),tolerance_s=1e-3)
        self.assertTrue(q.passed);self.assertEqual(len(q.successive_differences_s),3)
    def test_parameter_sweep(self):
        from journeyman.core.mouth_dynamics import MouthRole,d1_parameter_sweep
        q=d1_parameter_sweep(self.mouth(MouthRole.B),self.mouth(MouthRole.A),self.request(),betas=(.2,.5,.8))
        self.assertEqual(len(q),3);self.assertLess(q[0].desynchronization_s,q[-1].desynchronization_s)
    def test_uncertainty_sweep(self):
        from journeyman.core.mouth_dynamics import MouthRole,analyze_symmetric_mission,d1_uncertainty_sweep
        result=analyze_symmetric_mission(self.mouth(MouthRole.B),self.request()).transport
        q=d1_uncertainty_sweep(result,(0,100),(0,.01));self.assertEqual(len(q),4);self.assertGreaterEqual(q[-1].timing_standard_uncertainty_s,.01)
    def test_d1_c1_cross_validation(self):
        from journeyman.core.mouth_dynamics import MouthRole,analyze_symmetric_mission,evolve_pair_with_transport,d1_c1_cross_validate,C
        mission=analyze_symmetric_mission(self.mouth(MouthRole.B),self.request())
        evo=evolve_pair_with_transport(self.mouth(MouthRole.A),mission.transport)
        q=d1_c1_cross_validate(evo,external_return_speed_m_s=C);self.assertTrue(q.passed);self.assertLessEqual(q.absolute_difference_s,q.tolerance_s)
    def test_d1_release_readiness(self):
        from journeyman.core.mouth_dynamics import d1_release_readiness
        q=d1_release_readiness();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),6)


class MouthDynamics001ETests(unittest.TestCase):
    def test_d1_module_promoted_v1(self):
        from journeyman.modules.mouth_dynamics import D1_MODULE
        self.assertEqual(D1_MODULE.version,"1.0.0")
    def test_d1_workspace_wired(self):
        from pathlib import Path
        root=Path(__file__).parents[1];ui=(root/"journeyman"/"ui"/"workspaces.py").read_text();main=(root/"journeyman"/"ui"/"main_window.py").read_text()
        self.assertIn("class MouthDynamicsWorkspace(QWidget):",ui);self.assertIn('workspace_kind="mouth-dynamics"',ui)
        self.assertIn("Mouth Dynamics [D-1]",main);self.assertIn('kind == "mouth-dynamics"',main)
    def test_d1_workspace_simulation_boundary(self):
        from pathlib import Path
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("NOT PHYSICAL MOUTH TELEMETRY",ui);self.assertIn("SIMULATION",ui);self.assertIn("not a propulsion solution",ui)
    def test_d1_workspace_has_c1_cross_validation(self):
        from pathlib import Path
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("c1_cross_validate",ui);self.assertIn("D-1/C-1 cross-validation",ui)
    def test_d1_release_readiness_still_passes(self):
        from journeyman.core.mouth_dynamics import d1_release_readiness
        q=d1_release_readiness();self.assertTrue(q.passed,q.failures)


class RingLaser001ATests(unittest.TestCase):
    def geometry(self,frame="lab"):
        from journeyman.core.ring_laser import RingGeometry
        return RingGeometry("ring-1",1.0,4.0,(0,0,1),.001,.001,frame,"RLA qualification")
    def optical(self):
        from journeyman.core.ring_laser import OpticalState,C
        lam=632.8e-9
        return OpticalState(lam,C/lam,10,1e-12,1e6,"RLA qualification")
    def rotation(self,frame="lab",omega=1.0):
        from journeyman.core.ring_laser import RotationState
        return RotationState((0,0,omega),1e-6,frame,"J2000","RLA qualification")
    def test_sagnac_time_reference(self):
        from journeyman.core.ring_laser import sagnac_reference,C
        q=sagnac_reference(self.geometry(),self.optical(),self.rotation())
        self.assertAlmostEqual(q.time_difference_s,4/(C*C),places=25);self.assertGreater(q.beat_frequency_hz,0)
    def test_sagnac_orientation_projection(self):
        from journeyman.core.ring_laser import sagnac_reference
        q=sagnac_reference(self.geometry(),self.optical(),self.rotation(omega=0))
        self.assertEqual(q.time_difference_s,0);self.assertEqual(q.beat_frequency_hz,0)
    def test_frame_mismatch_rejected(self):
        from journeyman.core.ring_laser import sagnac_reference,RLAStatus
        q=sagnac_reference(self.geometry("lab"),self.optical(),self.rotation("other"))
        self.assertEqual(q.status,RLAStatus.INPUT_INCONSISTENT);self.assertIsNone(q.beat_frequency_hz)
    def test_optical_consistency(self):
        from journeyman.core.ring_laser import optical_consistency
        q=optical_consistency(self.optical());self.assertTrue(q.within_declared_uncertainty)
    def test_guardian_authority(self):
        from journeyman.core.ring_laser import sagnac_reference,optical_consistency,ring_laser_guardian_contract
        g=ring_laser_guardian_contract(sagnac=sagnac_reference(self.geometry(),self.optical(),self.rotation()),consistency=optical_consistency(self.optical()))
        self.assertEqual(g.schema,"JOE-GUARDIAN-RING-LASER/1");self.assertIn("cannot be promoted",g.authority)
    def test_rla_module_dependencies(self):
        from journeyman.modules.ring_laser import RLA_MODULE
        self.assertIn("journeyman.navigation",RLA_MODULE.requires);self.assertIn("journeyman.chronology",RLA_MODULE.requires);self.assertIn("joe.ring-laser",RLA_MODULE.provides)


class RingLaser001BTests(unittest.TestCase):
    def req(self,power=1e6):
        from journeyman.core.ring_laser import RingOpticalEnergyRequest
        return RingOpticalEnergyRequest(power,10,.001,"RLA-001B qualification")
    def test_optical_energy_bookkeeping(self):
        from journeyman.core.ring_laser import ring_optical_energy,C
        q=ring_optical_energy(self.req());self.assertAlmostEqual(q.stored_energy_j,1e7/C);self.assertAlmostEqual(q.mean_energy_density_j_m3,1e9/C)
    def test_null_radiation_reference(self):
        from journeyman.core.ring_laser import null_radiation_stress_energy
        q=null_radiation_stress_energy(100);self.assertEqual(q.longitudinal_pressure_pa,100);self.assertEqual(q.trace_j_m3,0)
    def test_gravitational_scale_tiny_for_lab_energy(self):
        from journeyman.core.ring_laser import ring_optical_energy,gravitational_scale_estimate
        e=ring_optical_energy(self.req());g=gravitational_scale_estimate(e.stored_energy_j,1,provenance="test")
        self.assertGreater(g.compactness,0);self.assertLess(g.compactness,1e-30)
    def test_energy_scaling_monotonic(self):
        from journeyman.core.ring_laser import ring_energy_scaling
        q=ring_energy_scaling((1,10,100),path_length_m=10,mode_area_m2=.001,characteristic_radius_m=1)
        self.assertLess(q[0].stored_energy_j,q[1].stored_energy_j);self.assertLess(q[1].compactness,q[2].compactness)
    def test_declared_energy_target_not_chronology_threshold(self):
        from journeyman.core.ring_laser import compare_declared_required_energy
        q=compare_declared_required_energy(1,1e9,provenance="test");self.assertEqual(q.energy_ratio,1e-9);self.assertIn("does not possess",q.message)
    def test_energy_uncertainty(self):
        from journeyman.core.ring_laser import ring_energy_uncertainty
        q=ring_energy_uncertainty(self.req(),power_standard_uncertainty_w=100,path_length_standard_uncertainty_m=.01,mode_area_standard_uncertainty_m2=1e-6)
        self.assertGreater(q.stored_energy_standard_uncertainty_j,0);self.assertGreater(q.energy_density_standard_uncertainty_j_m3,0)
    def test_method_b_epistemic_gate(self):
        from journeyman.core.ring_laser import method_b_epistemic_assessment,RLAStatus
        q=method_b_epistemic_assessment();self.assertEqual(q.chronology_claim_status,RLAStatus.UNKNOWN_PHYSICS);self.assertTrue(q.unresolved_physics)
    def test_expanded_guardian_unknown_physics(self):
        from journeyman.core.ring_laser import ring_optical_energy,gravitational_scale_estimate,expanded_ring_laser_guardian_contract,RLAStatus
        e=ring_optical_energy(self.req());g=gravitational_scale_estimate(e.stored_energy_j,1,provenance="test")
        q=expanded_ring_laser_guardian_contract(energy=e,gravity=g);self.assertEqual(q.status,RLAStatus.UNKNOWN_PHYSICS.value);self.assertIn("cannot assert chronology",q.authority)


class RingLaser001CTests(unittest.TestCase):
    def test_light_ring_angular_momentum(self):
        from journeyman.core.ring_laser import circulating_light_angular_momentum,C
        q=circulating_light_angular_momentum(100,2,provenance="test");self.assertAlmostEqual(q.angular_momentum_kg_m2_s,200/C)
    def test_weak_field_dragging_positive(self):
        from journeyman.core.ring_laser import weak_field_frame_dragging
        q=weak_field_frame_dragging(1,2,provenance="test");self.assertGreater(q.angular_rate_rad_s,0);self.assertIn("not valid",q.message)
    def test_gravity_scaling_linear_power(self):
        from journeyman.core.ring_laser import method_b_gravity_scaling
        q=method_b_gravity_scaling((1,10),path_length_m=10,mode_area_m2=.001,ring_radius_m=1,observation_radius_m=2)
        self.assertAlmostEqual(q[1].weak_field_drag_rate_rad_s/q[0].weak_field_drag_rate_rad_s,10)
    def test_missing_chronology_model_returns_unavailable(self):
        from journeyman.core.ring_laser import ChronologyHypothesisRequest,assess_method_b_chronology_hypothesis,RLAStatus
        q=assess_method_b_chronology_hypothesis(ChronologyHypothesisRequest("declared-model","r1","indicator",None,None,"test"))
        self.assertEqual(q.status,RLAStatus.MODEL_UNAVAILABLE);self.assertIsNone(q.threshold_crossed)
    def test_declared_threshold_remains_unknown_physics(self):
        from journeyman.core.ring_laser import ChronologyHypothesisRequest,assess_method_b_chronology_hypothesis,RLAStatus
        q=assess_method_b_chronology_hypothesis(ChronologyHypothesisRequest("speculative-model","r1","g_phiphi",2,1,"test"))
        self.assertTrue(q.threshold_crossed);self.assertEqual(q.status,RLAStatus.UNKNOWN_PHYSICS);self.assertIn("not evidence",q.message)
    def test_power_sensitivity(self):
        from journeyman.core.ring_laser import weak_field_power_sensitivity
        q=weak_field_power_sensitivity(1e6,fractional_step=1e-3,path_length_m=10,mode_area_m2=.001,ring_radius_m=1,observation_radius_m=2)
        self.assertGreater(q.d_drag_rate_d_power_rad_s_w,0);self.assertGreater(q.d_compactness_d_power_per_w,0)
    def test_rla_numerical_verification(self):
        from journeyman.core.ring_laser import rla_numerical_verification
        q=rla_numerical_verification();self.assertTrue(q.passed);self.assertLessEqual(q.relative_error,q.tolerance)
    def test_hypothesis_guardian_gate(self):
        from journeyman.core.ring_laser import ChronologyHypothesisRequest,assess_method_b_chronology_hypothesis,method_b_hypothesis_guardian_contract
        a=assess_method_b_chronology_hypothesis(ChronologyHypothesisRequest("spec","r1","x",2,1,"test"))
        g=method_b_hypothesis_guardian_contract(a,provenance="test");self.assertIn("UNKNOWN_PHYSICS",g.authority);self.assertEqual(g.facts["chronology_hypothesis"]["threshold_crossed"],True)


class RingLaser001DTests(unittest.TestCase):
    def test_rla_release_readiness(self):
        from journeyman.core.ring_laser import rla_release_readiness
        q=rla_release_readiness();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),7)
    def test_rla_module_v1(self):
        from journeyman.modules.ring_laser import RLA_MODULE
        self.assertEqual(RLA_MODULE.version,"1.0.0")
    def test_rla_workspace_wired(self):
        from pathlib import Path
        root=Path(__file__).parents[1];ui=(root/"journeyman"/"ui"/"workspaces.py").read_text();main=(root/"journeyman"/"ui"/"main_window.py").read_text()
        self.assertIn("class RingLaserWorkspace(QWidget):",ui);self.assertIn('workspace_kind="ring-laser"',ui)
        self.assertIn("Method B / Ring-Laser",main);self.assertIn('kind == "ring-laser"',main)
    def test_rla_workspace_epistemic_boundary(self):
        from pathlib import Path
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("NOT PHYSICAL RING-LASER TELEMETRY",ui);self.assertIn("Chronology claim status",ui);self.assertIn("remains unresolved physics",ui)
    def test_rla_workspace_scaling_table(self):
        from pathlib import Path
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("gravity_scaling",ui);self.assertIn("Compactness",ui);self.assertIn("Weak-field",ui)


class Verification001ATests(unittest.TestCase):
    def value(self,x,alg="a",src="s",u=.1,unit="m"):
        from journeyman.core.verification import VerificationValue
        return VerificationValue(x,unit,u,src,alg,"r1","VNV qualification")
    def test_independent_comparison_pass(self):
        from journeyman.core.verification import compare_independent_results,VerificationTolerance,VerificationStatus
        q=compare_independent_results(self.value(10,"a","s1"),self.value(10.1,"b","s2"),VerificationTolerance(sigma=3))
        self.assertEqual(q.status,VerificationStatus.PASS);self.assertTrue(q.independent_algorithms)
    def test_discrepancy_fails(self):
        from journeyman.core.verification import compare_independent_results,VerificationTolerance,VerificationStatus
        q=compare_independent_results(self.value(10,"a","s1",.01),self.value(12,"b","s2",.01),VerificationTolerance(sigma=3))
        self.assertEqual(q.status,VerificationStatus.FAIL);self.assertGreater(q.normalized_difference_sigma,100)
    def test_unit_mismatch_rejected(self):
        from journeyman.core.verification import compare_independent_results,VerificationStatus,DiscrepancyClass
        q=compare_independent_results(self.value(1,unit="m"),self.value(1,unit="s"))
        self.assertEqual(q.status,VerificationStatus.INPUT_INCONSISTENT);self.assertEqual(q.discrepancy_class,DiscrepancyClass.UNIT_OR_DIMENSION)
    def test_dimension_check(self):
        from journeyman.core.verification import DimensionSignature,check_dimensions,VerificationStatus
        self.assertEqual(check_dimensions(DimensionSignature(length=1,time=-1),DimensionSignature(length=1,time=-1)).status,VerificationStatus.PASS)
        self.assertEqual(check_dimensions(DimensionSignature(length=1),DimensionSignature(time=1)).status,VerificationStatus.INPUT_INCONSISTENT)
    def test_independence_gate(self):
        from journeyman.core.verification import check_verification_independence,VerificationStatus
        self.assertEqual(check_verification_independence(self.value(1,"a","s1"),self.value(1,"b","s2")).status,VerificationStatus.PASS)
        self.assertEqual(check_verification_independence(self.value(1,"a","s1"),self.value(1,"a","s1")).status,VerificationStatus.INPUT_INCONSISTENT)
    def test_guardian_contract(self):
        from journeyman.core.verification import compare_independent_results,check_verification_independence,verification_guardian_contract
        a,b=self.value(1,"a","s1"),self.value(1,"b","s2")
        g=verification_guardian_contract(compare_independent_results(a,b),check_verification_independence(a,b))
        self.assertEqual(g.schema,"JOE-GUARDIAN-VERIFICATION/1");self.assertIn("READ_ONLY_ADVISORY",g.authority)


class Verification001BTests(unittest.TestCase):
    def inputs(self):
        from journeyman.core.verification import UncertainInput
        return (UncertainInput("x",2,.1,"m","test"),UncertainInput("y",3,.2,"m","test"))
    def test_linear_uncertainty(self):
        from journeyman.core.verification import propagate_linear_uncertainty
        q=propagate_linear_uncertainty(self.inputs(),(1,2))
        self.assertAlmostEqual(q.combined_standard_uncertainty,(.01+.16)**.5)
    def test_covariance_changes_budget(self):
        from journeyman.core.verification import propagate_linear_uncertainty
        q=propagate_linear_uncertainty(self.inputs(),(1,1),((.01,.01),(.01,.04)))
        self.assertAlmostEqual(q.combined_standard_uncertainty,(.07)**.5);self.assertAlmostEqual(q.covariance_contribution,.02)
    def test_bad_covariance_rejected(self):
        from journeyman.core.verification import propagate_linear_uncertainty
        with self.assertRaises(ValueError):propagate_linear_uncertainty(self.inputs(),(1,1),((.01,.02),(.01,.04)))
    def test_numerical_jacobian(self):
        from journeyman.core.verification import numerical_jacobian
        q=numerical_jacobian(lambda v:v[0]**2+3*v[1],(2,5))
        self.assertAlmostEqual(q.derivatives[0],4,places=5);self.assertAlmostEqual(q.derivatives[1],3,places=5)
    def test_monte_carlo_reproducible(self):
        from journeyman.core.verification import monte_carlo_uncertainty
        f=lambda v:v[0]+2*v[1]
        a=monte_carlo_uncertainty(f,self.inputs(),sample_count=4000,seed=42);b=monte_carlo_uncertainty(f,self.inputs(),sample_count=4000,seed=42)
        self.assertEqual(a,b);self.assertGreater(a.standard_deviation,0)
    def test_linear_monte_carlo_crosscheck(self):
        from journeyman.core.verification import propagate_linear_uncertainty,monte_carlo_uncertainty,cross_check_uncertainty_methods,VerificationStatus
        f=lambda v:v[0]+2*v[1];lin=propagate_linear_uncertainty(self.inputs(),(1,2));mc=monte_carlo_uncertainty(f,self.inputs(),sample_count=12000,seed=9)
        q=cross_check_uncertainty_methods(lin,mc,relative_tolerance=.05);self.assertEqual(q.status,VerificationStatus.PASS)
    def test_expanded_guardian_contract(self):
        from journeyman.core.verification import propagate_linear_uncertainty,expanded_verification_guardian_contract
        b=propagate_linear_uncertainty(self.inputs(),(1,2));g=expanded_verification_guardian_contract(budget=b)
        self.assertIn("uncertainty_budget",g.facts);self.assertIn("cannot rewrite",g.authority)


class Verification001CTests(unittest.TestCase):
    def test_convergence_pass_and_precision_fail(self):
        from journeyman.core.verification import assess_convergence,VerificationStatus
        self.assertEqual(assess_convergence(((10,1),(20,1.01),(40,1.010000001)),relative_tolerance=1e-8).status,VerificationStatus.PASS)
        self.assertEqual(assess_convergence(((10,1),(20,1.1),(40,1.2)),relative_tolerance=1e-3).status,VerificationStatus.PRECISION_INSUFFICIENT)
    def test_regression_baseline(self):
        from journeyman.core.verification import RegressionBaseline,assess_regression,VerificationStatus
        b=RegressionBaseline("x","r1",10,"m",.01,0,"test")
        self.assertEqual(assess_regression(10.005,"m",b).status,VerificationStatus.PASS)
        self.assertEqual(assess_regression(11,"m",b).status,VerificationStatus.FAIL)
    def test_verification_matrix(self):
        from journeyman.core.verification import VerificationMatrixEntry,build_verification_matrix,VerificationStatus
        q=build_verification_matrix((VerificationMatrixEntry("R1","A","B",VerificationStatus.PASS,"E1","ok"),
                                     VerificationMatrixEntry("R2","A",None,VerificationStatus.MODEL_UNAVAILABLE,"E2","missing"),))
        self.assertEqual(q.status,VerificationStatus.PRECISION_INSUFFICIENT);self.assertEqual(q.incomplete,1)
    def test_cross_validation_requires_independence(self):
        from journeyman.core.verification import VerificationValue,cross_validate_models,VerificationStatus
        a=VerificationValue(1,"m",.1,"same","same","r1","test");b=VerificationValue(1,"m",.1,"same","same","r2","test")
        self.assertEqual(cross_validate_models(a,b).status,VerificationStatus.INPUT_INCONSISTENT)
    def test_d1_iteration_limit_is_nonconverged(self):
        from journeyman.core.mouth_dynamics import MouthDynamicsStatus
        self.assertTrue(hasattr(MouthDynamicsStatus,"NONCONVERGED"))
        src=(Path(__file__).parents[1]/"journeyman"/"core"/"mouth_dynamics.py").read_text()
        self.assertIn("TargetDesynchronizationSolution(MouthDynamicsStatus.NONCONVERGED",src)
    def test_vnv_core_readiness(self):
        from journeyman.core.verification import vnv_core_readiness
        q=vnv_core_readiness();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),4)


class Verification001DTests(unittest.TestCase):
    def test_vnv_release_readiness(self):
        from journeyman.core.verification import vnv_release_readiness
        q=vnv_release_readiness();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),6)
    def test_vnv_module_v1(self):
        from journeyman.modules.verification import VNV_MODULE
        self.assertEqual(VNV_MODULE.version,"1.0.0")
    def test_vnv_workspace_wired(self):
        root=Path(__file__).parents[1]
        ui=(root/"journeyman"/"ui"/"workspaces.py").read_text();main=(root/"journeyman"/"ui"/"main_window.py").read_text()
        self.assertIn("class VerificationWorkspace(QWidget):",ui);self.assertIn('workspace_kind="verification"',ui)
        self.assertIn("Verification & Uncertainty",main);self.assertIn('kind == "verification"',main)
    def test_vnv_workspace_exposes_independence(self):
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("Independent sources",ui);self.assertIn("Independent algorithms",ui);self.assertIn("Cross-validation qualification",ui)
    def test_vnv_workspace_preserves_epistemic_boundary(self):
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("does not validate an unresolved physical theory",ui)


class DigitalTwin001ATests(unittest.TestCase):
    def test_simulation_clock_deterministic(self):
        from journeyman.core.digital_twin import SimulationClock
        q=SimulationClock(step_size_s=.1).advance(5);self.assertEqual(q.step_index,5);self.assertAlmostEqual(q.simulation_time_s,.5)
    def test_twin_objects_simulation_only(self):
        from journeyman.core.digital_twin import TwinObject,TwinObjectType
        from journeyman.core.state_events import DataOrigin
        with self.assertRaises(ValueError):TwinObject("x","A",TwinObjectType.MOUTH_A,"f","e",(0,0,0),(0,0,0),0,"test",origin=DataOrigin.HARDWARE)
    def test_mouth_pair_identity(self):
        from journeyman.core.digital_twin import create_twin_object,TwinObjectType
        a=create_twin_object("Mouth A",TwinObjectType.MOUTH_A,"sim-frame","sim-epoch",provenance="test")
        b=create_twin_object("Mouth B",TwinObjectType.MOUTH_B,"sim-frame","sim-epoch",provenance="test")
        self.assertNotEqual(a.object_id,b.object_id)
    def test_engine_steps_objects_and_sources(self):
        from journeyman.core.digital_twin import DigitalTwinEngine,create_twin_object,TwinObjectType,DeterministicSource
        e=DigitalTwinEngine(step_size_s=.5,provenance="test")
        e.add_object(create_twin_object("A",TwinObjectType.MOUTH_A,"f","e",velocity_m_s=(2,0,0),provenance="test"))
        e.add_source(DeterministicSource("s","clock_offset","s",1,2,0,0,"test"));e.ready();e.start()
        snap,samples=e.step(2);self.assertAlmostEqual(snap.objects[0].position_m[0],2);self.assertEqual(samples[0].value,1)
    def test_lifecycle_enforced(self):
        from journeyman.core.digital_twin import DigitalTwinEngine
        e=DigitalTwinEngine()
        with self.assertRaises(ValueError):e.step()
        e.ready();e.start();e.pause()
        with self.assertRaises(ValueError):e.step()
    def test_guardian_contract_simulation_provenance(self):
        from journeyman.core.digital_twin import DigitalTwinEngine,digital_twin_guardian_contract
        e=DigitalTwinEngine(provenance="test");g=digital_twin_guardian_contract(e.state)
        self.assertEqual(g.schema,"JOE-GUARDIAN-DIGITAL-TWIN/1");self.assertEqual(g.facts["origin"],"SIMULATION");self.assertIn("never be represented",g.authority)
    def test_module_registered_in_main_window(self):
        main=(Path(__file__).parents[1]/"journeyman"/"ui"/"main_window.py").read_text()
        self.assertIn("register_digital_twin_module",main)


class DigitalTwin001BTests(unittest.TestCase):
    def channel_source(self):
        from journeyman.core.digital_twin import TelemetryChannel,DeterministicSource
        return (TelemetryChannel("c","obj","clock_offset","s",.1,1,"test"),
                DeterministicSource("src","clock_offset","s",2,1,0,0,"test"))
    def test_synchronized_telemetry(self):
        from journeyman.core.digital_twin import synchronized_telemetry_frame
        c,s=self.channel_source();q=synchronized_telemetry_frame((c,),(s,),3,7,provenance="test")
        self.assertEqual(q.sequence,7);self.assertEqual(q.samples[0].simulation_time_s,3);self.assertEqual(q.samples[0].value,2)
    def test_freshness_stale(self):
        from journeyman.core.digital_twin import telemetry_from_source,assess_sample_freshness,SampleQuality
        c,s=self.channel_source();x=telemetry_from_source(c,s,1,1)
        self.assertEqual(assess_sample_freshness(x,3,c).quality,SampleQuality.STALE)
    def test_residual_anomaly(self):
        from journeyman.core.digital_twin import telemetry_from_source,model_observation_residual
        c,s=self.channel_source();x=telemetry_from_source(c,s,1,1)
        q=model_observation_residual(x,0,.1,sigma_threshold=5);self.assertTrue(q.anomaly);self.assertGreater(q.normalized_residual_sigma,5)
    def test_mouth_monitor(self):
        from journeyman.core.digital_twin import create_twin_object,TwinObjectType,monitor_simulated_mouth_pair
        a=create_twin_object("A",TwinObjectType.MOUTH_A,"f","e",(0,0,0),(0,0,0),.1,"test")
        b=create_twin_object("B",TwinObjectType.MOUTH_B,"f","e",(3,4,0),(1,0,0),.2,"test")
        q=monitor_simulated_mouth_pair(a,b);self.assertEqual(q.separation_m,5);self.assertEqual(q.relative_speed_m_s,1)
    def test_mouth_frame_mismatch_rejected(self):
        from journeyman.core.digital_twin import create_twin_object,TwinObjectType,monitor_simulated_mouth_pair,TwinStatus
        a=create_twin_object("A",TwinObjectType.MOUTH_A,"f1","e",(0,0,0),provenance="test")
        b=create_twin_object("B",TwinObjectType.MOUTH_B,"f2","e",(0,0,0),provenance="test")
        self.assertEqual(monitor_simulated_mouth_pair(a,b).status,TwinStatus.INPUT_INCONSISTENT)
    def test_monitor_guardian_contract(self):
        from journeyman.core.digital_twin import DigitalTwinEngine,digital_twin_monitor_guardian_contract
        g=digital_twin_monitor_guardian_contract(DigitalTwinEngine(provenance="test").state)
        self.assertEqual(g.schema,"JOE-GUARDIAN-DIGITAL-TWIN/1");self.assertIn("SIMULATION stale data",g.authority)


class DigitalTwin001CTests(unittest.TestCase):
    def mouths(self):
        from journeyman.core.digital_twin import create_twin_object,TwinObjectType
        return (create_twin_object("A",TwinObjectType.MOUTH_A,"f","e",(0,0,0),(0,0,0),.1,"test"),
                create_twin_object("B",TwinObjectType.MOUTH_B,"f","e",(300,0,0),(0,0,0),.2,"test"))
    def test_d1_conversion_preserves_identity(self):
        from journeyman.core.digital_twin import twin_to_d1_mouth_state
        from journeyman.core.mouth_dynamics import MouthRole
        a,_=self.mouths();q=twin_to_d1_mouth_state(a,role=MouthRole.A,coordinate_time_s=10,proper_time_s=9)
        self.assertEqual(q.object_id,a.object_id);self.assertEqual(q.frame_id,a.frame_id)
    def test_temporal_pair(self):
        from journeyman.core.digital_twin import TwinMouthTemporalState,mouth_pair_temporal_state
        a=TwinMouthTemporalState("a","A",10,10,.1,10,"test");b=TwinMouthTemporalState("b","B",10,8,.2,10,"test")
        q=mouth_pair_temporal_state(a,b,provenance="test");self.assertEqual(q.proper_time_offset_s,2);self.assertAlmostEqual(q.combined_standard_uncertainty_s,(.05)**.5)
    def test_c1_coupling_uses_simulated_separation(self):
        from journeyman.core.digital_twin import TwinMouthTemporalState,mouth_pair_temporal_state,couple_twin_to_chronology
        a,b=self.mouths();ta=TwinMouthTemporalState(a.object_id,"A",10,10,.01,10,"test");tb=TwinMouthTemporalState(b.object_id,"B",10,8,.01,10,"test")
        t=mouth_pair_temporal_state(ta,tb,provenance="test");q=couple_twin_to_chronology(a,b,t,external_return_speed_m_s=300)
        self.assertEqual(q.separation_m,300);self.assertAlmostEqual(q.chronology_margin_s,1);self.assertTrue(q.modeled_closed_causal_loop_condition)
    def test_worldline_history_rejects_time_reversal(self):
        from journeyman.core.digital_twin import TwinWorldlineHistory,TwinWorldlinePoint
        h=TwinWorldlineHistory();p=lambda t:TwinWorldlinePoint("a",t,t,t,(t,0,0),(1,0,0),"f","e","test")
        h.append(p(1))
        with self.assertRaises(ValueError):h.append(p(1))
    def test_twin_model_synchronization_anomaly(self):
        from journeyman.core.digital_twin import synchronize_twin_object
        from dataclasses import replace
        a,_=self.mouths();obs=replace(a,position_m=(10,0,0))
        q=synchronize_twin_object(a,obs,sigma_threshold=5);self.assertTrue(q.anomaly);self.assertGreater(q.normalized_position_sigma,5)
    def test_chronology_guardian_contract(self):
        from journeyman.core.digital_twin import DigitalTwinEngine,TwinMouthTemporalState,mouth_pair_temporal_state,couple_twin_to_chronology,chronology_coupled_guardian_contract
        a,b=self.mouths();t=mouth_pair_temporal_state(TwinMouthTemporalState(a.object_id,"A",1,1,0,1,"test"),TwinMouthTemporalState(b.object_id,"B",1,0,0,1,"test"),provenance="test")
        c=couple_twin_to_chronology(a,b,t,external_return_speed_m_s=300);g=chronology_coupled_guardian_contract(DigitalTwinEngine(provenance="test").state,c)
        self.assertIn("chronology_coupling",g.facts);self.assertIn("cannot assert physical CTCs",g.authority)


class DigitalTwin001DTests(unittest.TestCase):
    def scene_parts(self):
        from journeyman.core.digital_twin import create_twin_object,TwinObjectType,SceneReference,SceneScale
        a=create_twin_object("A",TwinObjectType.MOUTH_A,"f","e",(0,0,0),position_standard_uncertainty_m=1,provenance="test")
        b=create_twin_object("B",TwinObjectType.MOUTH_B,"f","e",(3,4,0),position_standard_uncertainty_m=2,provenance="test")
        r=SceneReference("r","local","f","e",(0,0,0),SceneScale.FACILITY,"test")
        return a,b,r
    def test_scene_has_mouth_separation_vector(self):
        from journeyman.core.digital_twin import build_spatial_scene
        a,b,r=self.scene_parts();q=build_spatial_scene(r,(a,b),simulation_time_s=0,provenance="test")
        self.assertEqual(len(q.vectors),1);self.assertEqual(q.vectors[0].magnitude_m,5)
    def test_scene_rejects_frame_mismatch(self):
        from journeyman.core.digital_twin import build_spatial_scene
        from dataclasses import replace
        a,b,r=self.scene_parts()
        with self.assertRaises(ValueError):build_spatial_scene(r,(a,replace(b,frame_id="other")),simulation_time_s=0)
    def test_relocation_revisions_object(self):
        from journeyman.core.digital_twin import relocate_twin_object
        a,_,_=self.scene_parts();q=relocate_twin_object(a,(9,8,7))
        self.assertEqual(q.object_id,a.object_id);self.assertEqual(q.config_revision,a.config_revision+1);self.assertEqual(q.position_m,(9.,8.,7.))
    def test_scene_bounds_include_uncertainty(self):
        from journeyman.core.digital_twin import build_spatial_scene,scene_bounds
        a,b,r=self.scene_parts();q=scene_bounds(build_spatial_scene(r,(a,b),simulation_time_s=0))
        self.assertEqual(q.minimum_m,(-1.,-1.,-2.));self.assertEqual(q.maximum_m,(5.,6.,2.))
    def test_worldline_to_trajectory(self):
        from journeyman.core.digital_twin import TwinWorldlineHistory,TwinWorldlinePoint,trajectory_from_history
        h=TwinWorldlineHistory()
        h.append(TwinWorldlinePoint("a",0,0,0,(0,0,0),(1,0,0),"f","e","test"))
        h.append(TwinWorldlinePoint("a",1,1,1,(1,0,0),(1,0,0),"f","e","test"))
        q=trajectory_from_history(h,"a");self.assertEqual(q.points_m,((0,0,0),(1,0,0)));self.assertEqual(q.simulation_times_s,(0,1))
    def test_spatial_guardian_contract(self):
        from journeyman.core.digital_twin import DigitalTwinEngine,build_spatial_scene,spatial_scene_guardian_contract
        a,b,r=self.scene_parts();scene=build_spatial_scene(r,(a,b),simulation_time_s=0)
        g=spatial_scene_guardian_contract(DigitalTwinEngine(provenance="test").state,scene)
        self.assertIn("spatial_scene",g.facts);self.assertEqual(g.facts["spatial_scene"]["scale"],"FACILITY")


class DigitalTwin001ETests(unittest.TestCase):
    def test_dt_release_readiness(self):
        from journeyman.core.digital_twin import digital_twin_release_readiness
        q=digital_twin_release_readiness();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),4)
    def test_dt_module_v05(self):
        from journeyman.modules.digital_twin import DT_MODULE
        self.assertEqual(DT_MODULE.version,"1.0.0")
    def test_dt_workspace_wired(self):
        root=Path(__file__).parents[1];ui=(root/"journeyman"/"ui"/"workspaces.py").read_text();main=(root/"journeyman"/"ui"/"main_window.py").read_text()
        self.assertIn("class DigitalTwinWorkspace(QWidget):",ui);self.assertIn('workspace_kind="digital-twin"',ui)
        self.assertIn("Digital Twin + Source Simulator",main);self.assertIn('kind == "digital-twin"',main)
    def test_dt_workspace_has_real_controls(self):
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        for x in ("Configure Mouth A/B","Start","Pause","Step","Stop","Mouth separation","Scene trajectories"):self.assertIn(x,ui)
    def test_dt_workspace_epistemic_label(self):
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("SIMULATION/SYNTHETIC ONLY",ui);self.assertIn("No physical mouth or hardware telemetry is connected",ui)


class DigitalTwin001FTests(unittest.TestCase):
    def test_dt_v1_release_readiness(self):
        from journeyman.core.digital_twin import digital_twin_v1_release_readiness
        q=digital_twin_v1_release_readiness();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),9)
    def test_dt_module_v1(self):
        from journeyman.modules.digital_twin import DT_MODULE
        self.assertEqual(DT_MODULE.version,"1.0.0")
    def test_session_integrates_telemetry(self):
        from journeyman.core.digital_twin import (DigitalTwinEngine,create_twin_object,TwinObjectType,DigitalTwinSession,
            TelemetryChannel,DeterministicSource)
        e=DigitalTwinEngine(step_size_s=.1,provenance="test")
        a=create_twin_object("A",TwinObjectType.MOUTH_A,"f","e",provenance="test");b=create_twin_object("B",TwinObjectType.MOUTH_B,"f","e",(10,0,0),provenance="test")
        e.add_object(a);e.add_object(b);e.ready();ss=DigitalTwinSession(e,provenance="test")
        ss.bind_source(TelemetryChannel("c",a.object_id,"x","m",.1,1,"test"),DeterministicSource("s","x","m",5,0,0,0,"test"))
        e.start();e.step();ss.record_worldlines();q=ss.monitor(predictions={"c":(5,.1)})
        self.assertEqual(q.telemetry.samples[0].value,5);self.assertEqual(q.anomaly_channels,());self.assertEqual(len(q.scene.trajectories),2)
    def test_workspace_live_monitor_present(self):
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        for x in ("self.telemetry=QTableWidget","self.live_plot=pg.PlotWidget","C-1 modeled chronology margin","Telemetry anomalies","Stale channels"):self.assertIn(x,ui)
    def test_dt_readiness_menu_present(self):
        main=(Path(__file__).parents[1]/"journeyman"/"ui"/"main_window.py").read_text()
        self.assertIn("Digital Twin Release Readiness",main);self.assertIn("digital_twin_release_readiness",main)


class ExperimentDesigner001ATests(unittest.TestCase):
    def plan(self,satisfied=True):
        from journeyman.core.experiment_designer import (parameter_snapshot,Prerequisite,ExperimentStep,StepKind,ExperimentPhase,create_experiment_plan)
        snap=parameter_snapshot({"r0_m":100.0},revision_id="mpr-1",provenance="test")
        req=Prerequisite("p1","MPR snapshot approved",satisfied,"evidence" if satisfied else "")
        step=ExperimentStep("s1","settle",StepKind.WAIT,2.0,(req,),provenance="test")
        return create_experiment_plan("test",snap,(ExperimentPhase("ph1","setup",(step,),"test"),),provenance="test")
    def test_plan_validation(self):
        from journeyman.core.experiment_designer import validate_experiment_plan
        q=validate_experiment_plan(self.plan());self.assertTrue(q.valid);self.assertEqual(q.total_duration_s,2)
    def test_unsatisfied_prerequisite_blocks_validation(self):
        from journeyman.core.experiment_designer import validate_experiment_plan
        q=validate_experiment_plan(self.plan(False));self.assertFalse(q.valid);self.assertIn("unsatisfied prerequisite",q.failures[0])
    def test_revision_changes_revision_not_identity(self):
        from journeyman.core.experiment_designer import revise_experiment_plan
        p=self.plan();q=revise_experiment_plan(p);self.assertEqual(q.experiment_id,p.experiment_id);self.assertEqual(q.revision,2)
    def test_sequencer_lifecycle(self):
        from journeyman.core.experiment_designer import validate_plan,ready_plan,SimulationSequencer,ExperimentLifecycle
        s=SimulationSequencer(ready_plan(validate_plan(self.plan())));s.start();s.advance(2);s.advance(.1)
        self.assertEqual(s.state.plan.lifecycle,ExperimentLifecycle.COMPLETED);self.assertTrue(any(x.event_type=="STEP_COMPLETE" for x in s.state.events))
    def test_guardian_contract(self):
        from journeyman.core.experiment_designer import validate_plan,ready_plan,SimulationSequencer,experiment_guardian_contract
        s=SimulationSequencer(ready_plan(validate_plan(self.plan())));g=experiment_guardian_contract(s.state)
        self.assertEqual(g.schema,"JOE-GUARDIAN-EXPERIMENT/1");self.assertIn("BUS-SAFE",g.authority)
    def test_core_readiness(self):
        from journeyman.core.experiment_designer import experiment_core_readiness
        q=experiment_core_readiness();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),4)


class ExperimentDesigner001BTests(unittest.TestCase):
    def test_constraint_hold(self):
        from journeyman.core.experiment_designer import ExperimentConstraint,ConstraintOperator,FailurePolicy,evaluate_constraint
        c=ExperimentConstraint("c","temperature",ConstraintOperator.LE,10,"K",FailurePolicy.HOLD,"limit","test")
        q=evaluate_constraint(c,12,"K",provenance="test");self.assertFalse(q.passed);self.assertEqual(q.failure_policy,FailurePolicy.HOLD)
    def test_decision_gate_abort(self):
        from journeyman.core.experiment_designer import ExperimentConstraint,ConstraintOperator,FailurePolicy,DecisionGate,evaluate_decision_gate
        c=ExperimentConstraint("c","x",ConstraintOperator.LT,1,"m",FailurePolicy.ABORT,"limit","test")
        g=DecisionGate("g","gate",(c,),"next","fail","test");q=evaluate_decision_gate(g,{"x":(2,"m")},provenance="test")
        self.assertFalse(q.passed);self.assertEqual(q.recommended_action,"ABORT");self.assertEqual(q.next_step_id,"fail")
    def test_dependency_rejects_backward(self):
        from journeyman.core.experiment_designer import (parameter_snapshot,ExperimentStep,StepKind,ExperimentPhase,create_experiment_plan,validate_step_dependencies,StepDependency)
        snap=parameter_snapshot({},revision_id="r",provenance="test")
        a=ExperimentStep("a","a",StepKind.WAIT,1,provenance="test");b=ExperimentStep("b","b",StepKind.WAIT,1,provenance="test")
        plan=create_experiment_plan("p",snap,(ExperimentPhase("ph","ph",(a,b),"test"),),provenance="test")
        q=validate_step_dependencies(plan,(StepDependency("a",("b",)),));self.assertFalse(q.valid)
    def test_execution_binding_digital_twin(self):
        from journeyman.core.experiment_designer import parameter_snapshot,create_experiment_plan,validate_plan,bind_execution_context
        from journeyman.core.digital_twin import DigitalTwinEngine
        p=validate_plan(create_experiment_plan("p",parameter_snapshot({},revision_id="mpr7",provenance="test"),
            (),provenance="test")) if False else None
        snap=parameter_snapshot({},revision_id="mpr7",provenance="test")
        from journeyman.core.experiment_designer import ExperimentPhase,ExperimentStep,StepKind
        p=validate_plan(create_experiment_plan("p",snap,(ExperimentPhase("ph","ph",(ExperimentStep("s","s",StepKind.WAIT,1,provenance="test"),),"test"),),provenance="test"))
        e=DigitalTwinEngine(provenance="test");q=bind_execution_context(p,digital_twin_state=e.state,provenance="test")
        self.assertEqual(q.parameter_revision_id,"mpr7");self.assertEqual(q.digital_twin_revision,e.state.revision)
    def test_supervisory_recommendation_is_advisory(self):
        from journeyman.core.experiment_designer import (ExperimentConstraint,ConstraintOperator,FailurePolicy,evaluate_constraint,supervisory_recommendation)
        c=ExperimentConstraint("c","x",ConstraintOperator.GT,5,"m",FailurePolicy.HOLD,"limit","test")
        e=evaluate_constraint(c,1,"m",provenance="test");q=supervisory_recommendation((e,))
        self.assertEqual(q.action,"RECOMMEND_HOLD");self.assertIn("ADVISORY ONLY",q.authority)
    def test_module_v02(self):
        from journeyman.modules.experiment_designer import EXP_MODULE
        self.assertEqual(EXP_MODULE.version,"1.0.0")


class ExperimentDesigner001CTests(unittest.TestCase):
    def setup_seq(self):
        from journeyman.core.experiment_designer import (parameter_snapshot,ExperimentStep,StepKind,ExperimentPhase,
            create_experiment_plan,validate_plan,ready_plan,bind_execution_context,BranchingSimulationSequencer)
        snap=parameter_snapshot({"x":1},revision_id="mpr1",provenance="test")
        steps=(ExperimentStep("s1","first",StepKind.WAIT,1,provenance="test"),
               ExperimentStep("s2","second",StepKind.WAIT,1,provenance="test"),
               ExperimentStep("s3","third",StepKind.WAIT,1,provenance="test"))
        plan=ready_plan(validate_plan(create_experiment_plan("p",snap,(ExperimentPhase("ph","phase",steps,"test"),),provenance="test")))
        bind=bind_execution_context(plan,provenance="test")
        return BranchingSimulationSequencer(plan,bind,provenance="test")
    def test_run_manifest_binding(self):
        s=self.setup_seq();self.assertEqual(s.manifest.plan_revision,s.state.plan.revision);self.assertEqual(s.manifest.parameter_digest_sha256,s.state.plan.parameter_snapshot.digest_sha256)
    def test_branch_gate_jumps(self):
        from journeyman.core.experiment_designer import ExperimentConstraint,ConstraintOperator,FailurePolicy,DecisionGate
        s=self.setup_seq();s.start()
        c=ExperimentConstraint("c","x",ConstraintOperator.GT,0,"m",FailurePolicy.HOLD,"positive","test")
        q=s.evaluate_gate(DecisionGate("g","gate",(c,),"s3","s2","test"),{"x":(1,"m")})
        self.assertTrue(q.passed);self.assertEqual(s.current()[1].step_id,"s3");self.assertEqual(len(s.evidence),1)
    def test_timeout_hold(self):
        from journeyman.core.experiment_designer import TimeoutPolicy,FailurePolicy,ExperimentLifecycle
        s=self.setup_seq();s.start();q=s.timeout(TimeoutPolicy(5,FailurePolicy.HOLD))
        self.assertEqual(q.action,"RECOMMEND_HOLD");self.assertEqual(s.state.plan.lifecycle,ExperimentLifecycle.PAUSED)
    def test_checkpoint_rejects_wrong_run(self):
        from dataclasses import replace
        s=self.setup_seq();cp=s.checkpoint()
        with self.assertRaises(ValueError):s.restore_checkpoint(replace(cp,run_id="wrong"))
    def test_twin_sync_does_not_silently_correct(self):
        from journeyman.core.experiment_designer import synchronize_experiment_with_twin
        from journeyman.core.digital_twin import DigitalTwinEngine
        s=self.setup_seq();e=DigitalTwinEngine(step_size_s=1,provenance="test");q=synchronize_experiment_with_twin(s.state,e.state,tolerance_s=0,provenance="test")
        self.assertTrue(q.synchronized)
        e.ready();e.start();e.step();q=synchronize_experiment_with_twin(s.state,e.state,tolerance_s=.1,provenance="test")
        self.assertFalse(q.synchronized);self.assertEqual(s.state.simulation_time_s,0)
    def test_execution_guardian_evidence(self):
        from journeyman.core.experiment_designer import execution_guardian_contract
        s=self.setup_seq();g=execution_guardian_contract(s);self.assertIn("run_manifest",g.facts);self.assertTrue(g.facts["checkpoint_capable"])
    def test_module_v03(self):
        from journeyman.modules.experiment_designer import EXP_MODULE
        self.assertEqual(EXP_MODULE.version,"1.0.0")


class ExperimentDesigner001DTests(unittest.TestCase):
    def test_exp_v1_readiness(self):
        from journeyman.core.experiment_designer import experiment_v1_release_readiness
        q=experiment_v1_release_readiness();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),6)
    def test_exp_module_v1(self):
        from journeyman.modules.experiment_designer import EXP_MODULE
        self.assertEqual(EXP_MODULE.version,"1.0.0")
    def test_exp_workspace_wired(self):
        root=Path(__file__).parents[1];ui=(root/"journeyman"/"ui"/"workspaces.py").read_text();main=(root/"journeyman"/"ui"/"main_window.py").read_text()
        self.assertIn("class ExperimentDesignerWorkspace(QWidget):",ui);self.assertIn('workspace_kind="experiment-designer"',ui)
        self.assertIn("Experiment Designer / Sequencer",main);self.assertIn('kind == "experiment-designer"',main)
    def test_exp_workspace_operational_controls(self):
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        for x in ("Build + Validate","Advance Step","Pause/Resume","Checkpoint","Abort","Parameter SHA-256","Run ID"):self.assertIn(x,ui)
    def test_exp_workspace_authority_boundary(self):
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("NO PHYSICAL ACTUATOR AUTHORITY",ui);self.assertIn("BUS-SAFE and deterministic hardware interlocks remain external",ui)


class Metrology001ATests(unittest.TestCase):
    def clocks(self):
        from journeyman.core.metrology import ClockIdentity,TimeDomain
        from journeyman.core.state_events import DataOrigin
        return (ClockIdentity("a","A",TimeDomain.SIMULATION,"SIM","f","e","test",DataOrigin.SIMULATION),
                ClockIdentity("b","B",TimeDomain.SIMULATION,"SIM","f","e","test",DataOrigin.SIMULATION))
    def test_offset_and_uncertainty(self):
        from journeyman.core.metrology import ClockObservation,ClockQuality,clock_offset
        from journeyman.core.state_events import DataOrigin
        a,b=self.clocks();oa=ClockObservation(a,2,3e-6,2,1,ClockQuality.GOOD,"test",DataOrigin.SIMULATION);ob=ClockObservation(b,1,4e-6,2,1,ClockQuality.GOOD,"test",DataOrigin.SIMULATION)
        q=clock_offset(oa,ob,provenance="test");self.assertEqual(q.offset_a_minus_b_s,1);self.assertAlmostEqual(q.standard_uncertainty_s,5e-6)
    def test_mismatched_domain_rejected(self):
        from dataclasses import replace
        from journeyman.core.metrology import ClockObservation,ClockQuality,clock_offset,TimeDomain
        from journeyman.core.state_events import DataOrigin
        a,b=self.clocks();b=replace(b,time_domain=TimeDomain.UTC,time_scale="UTC")
        oa=ClockObservation(a,1,0,1,1,ClockQuality.GOOD,"test",DataOrigin.SIMULATION);ob=ClockObservation(b,1,0,1,1,ClockQuality.GOOD,"test",DataOrigin.SIMULATION)
        with self.assertRaises(ValueError):clock_offset(oa,ob,provenance="test")
    def test_stale_sync_fails(self):
        from journeyman.core.metrology import ClockObservation,ClockQuality,SynchronizationPolicy,assess_synchronization
        from journeyman.core.state_events import DataOrigin
        a,b=self.clocks();oa=ClockObservation(a,1,1e-6,0,1,ClockQuality.GOOD,"test",DataOrigin.SIMULATION);ob=ClockObservation(b,1,1e-6,0,1,ClockQuality.GOOD,"test",DataOrigin.SIMULATION)
        q=assess_synchronization(oa,ob,SynchronizationPolicy(1,1,1,1),now_s=10,provenance="test");self.assertFalse(q.synchronized);self.assertEqual(len(q.failures),2)
    def test_proper_time_requires_epoch(self):
        from journeyman.core.metrology import ClockIdentity,TimeDomain
        from journeyman.core.state_events import DataOrigin
        with self.assertRaises(ValueError):ClockIdentity("p","proper",TimeDomain.PROPER_TIME,"PROPER","f",None,"test",DataOrigin.SIMULATION)
    def test_metrology_readiness(self):
        from journeyman.core.metrology import metrology_core_readiness
        q=metrology_core_readiness();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),4)
    def test_metrology_module(self):
        from journeyman.modules.metrology import MET_MODULE
        self.assertEqual(MET_MODULE.version,"1.0.0")


class Metrology001BTests(unittest.TestCase):
    def test_clock_history_order(self):
        from journeyman.core.metrology import ClockIdentity,ClockObservation,ClockHistory,ClockQuality,TimeDomain
        from journeyman.core.state_events import DataOrigin
        c=ClockIdentity("c","C",TimeDomain.SIMULATION,"SIM","f","e","test",DataOrigin.SIMULATION)
        a=ClockObservation(c,0,0,0,0,ClockQuality.GOOD,"test",DataOrigin.SIMULATION)
        b=ClockObservation(c,1,0,1,1,ClockQuality.GOOD,"test",DataOrigin.SIMULATION)
        self.assertEqual(len(ClockHistory(c,(a,b),"test").observations),2)
        with self.assertRaises(ValueError):ClockHistory(c,(b,a),"test")
    def test_allan_deviation_zero_for_ideal_clock(self):
        from journeyman.core.metrology import ClockIdentity,ClockObservation,ClockHistory,ClockQuality,TimeDomain,allan_deviation
        from journeyman.core.state_events import DataOrigin
        c=ClockIdentity("c","C",TimeDomain.SIMULATION,"SIM","f","e","test",DataOrigin.SIMULATION)
        obs=tuple(ClockObservation(c,float(i),0,float(i),i,ClockQuality.GOOD,"test",DataOrigin.SIMULATION) for i in range(5))
        self.assertEqual(allan_deviation(ClockHistory(c,obs,"test")).allan_deviation,0)
    def test_ensemble_weighted_time(self):
        from journeyman.core.metrology import ClockIdentity,ClockObservation,ClockQuality,TimeDomain,ClockEnsembleMember,ensemble_time
        from journeyman.core.state_events import DataOrigin
        def o(cid,v):
            c=ClockIdentity(cid,cid,TimeDomain.SIMULATION,"SIM","f","e","test",DataOrigin.SIMULATION)
            return ClockObservation(c,v,1,0,0,ClockQuality.GOOD,"test",DataOrigin.SIMULATION)
        q=ensemble_time((ClockEnsembleMember(o("a",0),1),ClockEnsembleMember(o("b",2),3)),provenance="test")
        self.assertEqual(q.reading_s,1.5);self.assertEqual(q.normalized_weights,(.25,.75))
    def test_mouth_temporal_requires_proper_time(self):
        from journeyman.core.metrology import (ClockIdentity,ClockObservation,ClockQuality,TimeDomain,SynchronizationPolicy,mouth_temporal_measurement)
        from journeyman.core.state_events import DataOrigin
        c=ClockIdentity("a","A",TimeDomain.SIMULATION,"SIM","f","e","test",DataOrigin.SIMULATION)
        o=ClockObservation(c,0,0,0,0,ClockQuality.GOOD,"test",DataOrigin.SIMULATION)
        with self.assertRaises(ValueError):mouth_temporal_measurement(o,o,SynchronizationPolicy(1,1,1,1),now_s=0,provenance="test")
    def test_mouth_temporal_and_twin_navigation(self):
        from journeyman.core.metrology import (ClockIdentity,ClockObservation,ClockQuality,TimeDomain,SynchronizationPolicy,mouth_temporal_measurement,temporal_navigation_from_twin)
        from journeyman.core.state_events import DataOrigin
        from journeyman.core.digital_twin import create_twin_object,TwinObjectType,monitor_simulated_mouth_pair
        ca=ClockIdentity("ca","A",TimeDomain.PROPER_TIME,"PROPER","f","e","test",DataOrigin.SIMULATION)
        cb=ClockIdentity("cb","B",TimeDomain.PROPER_TIME,"PROPER","f","e","test",DataOrigin.SIMULATION)
        a=ClockObservation(ca,2,1e-6,2,1,ClockQuality.GOOD,"test",DataOrigin.SIMULATION);b=ClockObservation(cb,1,1e-6,2,1,ClockQuality.GOOD,"test",DataOrigin.SIMULATION)
        m=mouth_temporal_measurement(a,b,SynchronizationPolicy(2,1e-5,1,1),now_s=2,provenance="test")
        ma=create_twin_object("A",TwinObjectType.MOUTH_A,"f","e",(0,0,0),provenance="test");mb=create_twin_object("B",TwinObjectType.MOUTH_B,"f","e",(3,4,0),provenance="test")
        nav=temporal_navigation_from_twin(m,monitor_simulated_mouth_pair(ma,mb),simulation_time_s=2,provenance="test")
        self.assertEqual(nav.separation_m,5);self.assertEqual(nav.mouth_measurement.proper_time_offset_a_minus_b_s,1)
    def test_met_module_v02(self):
        from journeyman.modules.metrology import MET_MODULE
        self.assertEqual(MET_MODULE.version,"1.0.0")


class Metrology001CTests(unittest.TestCase):
    def test_sr_proper_time(self):
        from journeyman.core.metrology import special_relativistic_proper_time
        from journeyman.core.chronology import C
        q=special_relativistic_proper_time(10,0.6*C,provenance="test")
        self.assertAlmostEqual(q.predicted_proper_duration_s,8,places=10);self.assertAlmostEqual(q.gamma,1.25,places=10)
    def test_proper_time_cross_check(self):
        from journeyman.core.metrology import special_relativistic_proper_time,cross_check_proper_time,MetrologyStatus
        p=special_relativistic_proper_time(10,0,provenance="test")
        q=cross_check_proper_time(10.000001,1e-6,p,1e-6,sigma_limit=5,provenance="test")
        self.assertEqual(q.status,MetrologyStatus.PASS)
    def test_sync_anomaly_is_typed(self):
        from journeyman.core.metrology import (ClockIdentity,ClockObservation,ClockQuality,TimeDomain,SynchronizationPolicy,
            assess_synchronization,synchronization_anomalies,MetrologyAnomalySeverity)
        from journeyman.core.state_events import DataOrigin
        a=ClockIdentity("a","A",TimeDomain.SIMULATION,"SIM","f","e","test",DataOrigin.SIMULATION)
        b=ClockIdentity("b","B",TimeDomain.SIMULATION,"SIM","f","e","test",DataOrigin.SIMULATION)
        oa=ClockObservation(a,0,0,0,0,ClockQuality.GOOD,"test",DataOrigin.SIMULATION)
        ob=ClockObservation(b,0,0,0,0,ClockQuality.GOOD,"test",DataOrigin.SIMULATION)
        q=assess_synchronization(oa,ob,SynchronizationPolicy(1,1,.1,1),now_s=2,provenance="test")
        x=synchronization_anomalies(q,simulation_time_s=2,provenance="test")
        self.assertEqual(len(x),2);self.assertTrue(all(a.severity==MetrologyAnomalySeverity.CRITICAL for a in x))
    def test_temporal_trajectory_rejects_nonmonotonic(self):
        from journeyman.core.metrology import TemporalTrajectory,TemporalTrajectoryPoint
        p=TemporalTrajectoryPoint(1,0,0,1,0,"f","e","test")
        with self.assertRaises(ValueError):TemporalTrajectory("a","b",(p,p),"test")
    def test_module_v03(self):
        from journeyman.modules.metrology import MET_MODULE
        self.assertEqual(MET_MODULE.version,"1.0.0")


class Metrology001DTests(unittest.TestCase):
    def test_metrology_v1_readiness(self):
        from journeyman.core.metrology import metrology_v1_release_readiness
        q=metrology_v1_release_readiness();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),6)
    def test_metrology_module_v1(self):
        from journeyman.modules.metrology import MET_MODULE
        self.assertEqual(MET_MODULE.version,"1.0.0")
    def test_metrology_workspace_wired(self):
        root=Path(__file__).parents[1];ui=(root/"journeyman"/"ui"/"workspaces.py").read_text();main=(root/"journeyman"/"ui"/"main_window.py").read_text()
        self.assertIn("class MetrologyWorkspace(QWidget):",ui);self.assertIn('workspace_kind="metrology"',ui)
        self.assertIn("Metrology & Temporal Navigation",main);self.assertIn('kind == "metrology"',main)
    def test_metrology_workspace_real_controls(self):
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        for x in ("Record Synthetic Sample","Clear History","Mouth A − B offset","Combined standard uncertainty","Significance"):self.assertIn(x,ui)
    def test_metrology_workspace_provenance_boundary(self):
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("SIMULATION/SYNTHETIC CLOCKS — NOT PHYSICAL TELEMETRY",ui)
        self.assertIn("NOT PHYSICAL MOUTH OR CLOCK TELEMETRY",ui)


class Guardian001ATests(unittest.TestCase):
    def test_rule_hold(self):
        from journeyman.core.guardian import (ingest_contract,GuardianRule,FindingSeverity,GuardianRecommendation,assess_contracts)
        class C: schema="JOE-GUARDIAN-METROLOGY/1";status="PASS";facts={"synchronized":False};provenance="test";authority="READ_ONLY_ADVISORY"
        e=ingest_contract("metrology",C(),observed_at_s=1)
        r=GuardianRule("r","sync lost",("synchronized",),"FALSY",None,FindingSeverity.CRITICAL,GuardianRecommendation.RECOMMEND_HOLD)
        q=assess_contracts((e,),{"metrology":(r,)},now_s=1,maximum_age_s=1,provenance="test")
        self.assertEqual(q.recommendation,GuardianRecommendation.RECOMMEND_HOLD);self.assertEqual(len(q.findings),1)
    def test_missing_required_fact_holds(self):
        from journeyman.core.guardian import (GuardianContractEnvelope,GuardianRule,FindingSeverity,GuardianRecommendation,evaluate_rule)
        e=GuardianContractEnvelope("m","JOE-GUARDIAN-X/1","PASS",{},"test","READ_ONLY_ADVISORY")
        r=GuardianRule("r","required",("x",),"EQ",1,FindingSeverity.WARNING,GuardianRecommendation.CAUTION)
        f=evaluate_rule(e,r,provenance="test");self.assertEqual(f.recommendation,GuardianRecommendation.RECOMMEND_HOLD)
    def test_stale_contract_holds(self):
        from journeyman.core.guardian import (GuardianContractEnvelope,GuardianRecommendation,assess_contracts)
        e=GuardianContractEnvelope("m","JOE-GUARDIAN-X/1","PASS",{},"test","READ_ONLY_ADVISORY",0)
        q=assess_contracts((e,),{},now_s=10,maximum_age_s=1,provenance="test")
        self.assertEqual(q.recommendation,GuardianRecommendation.RECOMMEND_HOLD);self.assertTrue(q.contract_health[0].stale)
    def test_ood_reduces_authority(self):
        from journeyman.core.guardian import assess_ood,AuthorityCeiling,GuardianRecommendation
        q=assess_ood(.9);self.assertEqual(q.authority_ceiling,AuthorityCeiling.OBSERVE_ONLY);self.assertEqual(q.recommendation,GuardianRecommendation.RECOMMEND_HOLD)
    def test_contract_authority_ceiling(self):
        from journeyman.core.guardian import GuardianContractEnvelope,contract_health
        e=GuardianContractEnvelope("m","JOE-GUARDIAN-X/1","PASS",{},"test","WRITE_CONTROL")
        self.assertFalse(contract_health(e).authority_accepted)
    def test_guardian_readiness(self):
        from journeyman.core.guardian import guardian_core_readiness
        self.assertTrue(guardian_core_readiness()["passed"])
    def test_guardian_module_v01(self):
        from journeyman.modules.guardian import GUARDIAN_MODULE
        self.assertEqual(GUARDIAN_MODULE.version,"1.0.0")


class Guardian001BTests(unittest.TestCase):
    def samples(self):
        from journeyman.core.guardian import ScalarSample
        return tuple(ScalarSample(float(i),float(i),"m","x","test") for i in range(5))
    def test_rolling_statistics_and_trend(self):
        from journeyman.core.guardian import rolling_statistics
        q=rolling_statistics(self.samples());self.assertEqual(q.count,5);self.assertEqual(q.mean,2);self.assertAlmostEqual(q.slope_per_s,1)
    def test_baseline_anomaly(self):
        from journeyman.core.guardian import ScalarSample,build_baseline,score_against_baseline,FindingSeverity
        base=build_baseline(tuple(ScalarSample(float(i),0.0,"m","x","test") for i in range(5)),provenance="test")
        a=score_against_baseline(ScalarSample(6,1,"m","x","test"),base)
        self.assertIsNotNone(a);self.assertEqual(a.severity,FindingSeverity.WARNING)
    def test_rate_of_change(self):
        from journeyman.core.guardian import ScalarSample,rate_of_change
        a=ScalarSample(0,0,"m","x","test");b=ScalarSample(2,10,"m","x","test")
        q=rate_of_change(a,b,absolute_limit_per_s=4,provenance="test");self.assertEqual(q.rate_per_s,5);self.assertTrue(q.exceeded)
    def test_drift(self):
        from journeyman.core.guardian import detect_drift
        q=detect_drift(self.samples(),absolute_limit_per_s=.5,provenance="test");self.assertTrue(q.exceeded)
    def test_cross_module_uncertainty(self):
        from journeyman.core.guardian import CrossModuleValue,compare_module_values
        a=CrossModuleValue("a","rho",10,1,"test");b=CrossModuleValue("b","rho",0,1,"test")
        q=compare_module_values(a,b,sigma_limit=5,provenance="test");self.assertTrue(q.disagrees);self.assertGreater(q.normalized_residual_sigma,7)
    def test_correlate_findings(self):
        from journeyman.core.guardian import GuardianFinding,FindingSeverity,GuardianRecommendation,correlate_findings
        f=lambda i,m: GuardianFinding(i,"SYNC",m,FindingSeverity.WARNING,GuardianRecommendation.RECOMMEND_HOLD,"x",(),.9,"test")
        q=correlate_findings((f("1","a"),f("2","b")),provenance="test");self.assertEqual(len(q),1);self.assertEqual(q[0].source_modules,("a","b"))
    def test_guardian_module_v02(self):
        from journeyman.modules.guardian import GUARDIAN_MODULE
        self.assertEqual(GUARDIAN_MODULE.version,"1.0.0")


class Guardian001CTests(unittest.TestCase):
    def env(self,m,v,status="PASS"):
        from journeyman.core.guardian import GuardianContractEnvelope
        return GuardianContractEnvelope(m,f"JOE-GUARDIAN-{m.upper()}/1",status,{"x":v},"test","READ_ONLY_ADVISORY")
    def test_equal_contract_fact_passes(self):
        from journeyman.core.guardian import compare_contract_facts
        q=compare_contract_facts(self.env("a",1),("x",),self.env("b",1),("x",),check_id="x",provenance="test")
        self.assertTrue(q.passed)
    def test_numeric_tolerance(self):
        from journeyman.core.guardian import compare_contract_facts
        q=compare_contract_facts(self.env("a",1),("x",),self.env("b",1.01),("x",),check_id="x",numeric_tolerance=.02,provenance="test")
        self.assertTrue(q.passed)
    def test_inconsistency_holds(self):
        from journeyman.core.guardian import compare_contract_facts,scientific_consistency_report,GuardianRecommendation
        q=compare_contract_facts(self.env("a",1),("x",),self.env("b",2),("x",),check_id="x",provenance="test")
        r=scientific_consistency_report((q,),provenance="test")
        self.assertFalse(r.passed);self.assertEqual(r.recommendation,GuardianRecommendation.RECOMMEND_HOLD)
    def test_missing_fact_fails_safe(self):
        from journeyman.core.guardian import compare_contract_facts
        q=compare_contract_facts(self.env("a",1),("missing",),self.env("b",1),("x",),check_id="x",provenance="test")
        self.assertFalse(q.passed);self.assertIn("missing",q.explanation.lower())
    def test_status_consistency(self):
        from journeyman.core.guardian import status_consistency
        self.assertFalse(status_consistency(self.env("a",1,"DOMAIN_INVALID"),provenance="test").passed)
    def test_consistency_findings(self):
        from journeyman.core.guardian import compare_contract_facts,scientific_consistency_report,consistency_findings
        q=compare_contract_facts(self.env("a",1),("x",),self.env("b",2),("x",),check_id="x",provenance="test")
        self.assertEqual(len(consistency_findings(scientific_consistency_report((q,),provenance="test"))),1)
    def test_scientific_consistency_readiness(self):
        from journeyman.core.guardian import guardian_scientific_consistency_readiness
        self.assertTrue(guardian_scientific_consistency_readiness()["passed"])
    def test_guardian_module_v03(self):
        from journeyman.modules.guardian import GUARDIAN_MODULE
        self.assertEqual(GUARDIAN_MODULE.version,"1.0.0")


class Guardian001DTests(unittest.TestCase):
    def finding(self):
        from journeyman.core.guardian import GuardianEvidence,GuardianFinding,FindingSeverity,GuardianRecommendation
        e=GuardianEvidence("e","m","JOE-GUARDIAN-X/1","x",3,"test",.8)
        return GuardianFinding("f","R","m",FindingSeverity.WARNING,GuardianRecommendation.RECOMMEND_HOLD,"bad x",(e,),.8,"test")
    def test_evidence_graph(self):
        from journeyman.core.guardian import evidence_graph_from_findings,ReasoningRelation
        g=evidence_graph_from_findings((self.finding(),),provenance="test")
        self.assertEqual(len(g.nodes),2);self.assertEqual(g.edges[0].relation,ReasoningRelation.SUPPORTS)
    def test_graph_rejects_unknown_node(self):
        from journeyman.core.guardian import EvidenceGraph,EvidenceEdge,ReasoningRelation
        with self.assertRaises(ValueError):EvidenceGraph((),(EvidenceEdge("e","a","b",ReasoningRelation.SUPPORTS,1,"x","test"),),"test")
    def test_rank_explanations(self):
        from journeyman.core.guardian import GuardianHypothesis,HypothesisKind,rank_explanations
        a=GuardianHypothesis("a",HypothesisKind.CORRELATION,"a",("1",),(),.4,(),"test")
        b=GuardianHypothesis("b",HypothesisKind.CORRELATION,"b",("1","2"),(),.9,(),"test")
        self.assertEqual(rank_explanations((a,b))[0].hypothesis_id,"b")
    def test_disagreement_interpretation_holds(self):
        from journeyman.core.guardian import CrossModuleValue,compare_module_values,interpret_disagreement,GuardianRecommendation
        d=compare_module_values(CrossModuleValue("a","x",10,1,"test"),CrossModuleValue("b","x",0,1,"test"),provenance="test")
        self.assertEqual(interpret_disagreement(d).recommendation,GuardianRecommendation.RECOMMEND_HOLD)
    def test_operator_recommendation_preserves_authority(self):
        from journeyman.core.guardian import GuardianAssessment,GuardianStatus,GuardianRecommendation,structured_operator_recommendation
        a=GuardianAssessment(GuardianStatus.PASS,GuardianRecommendation.CONTINUE,(),(),1,"test")
        q=structured_operator_recommendation(a,provenance="test")
        self.assertIn("READ_ONLY_ADVISORY",q.authority);self.assertEqual(q.recommendation,GuardianRecommendation.CONTINUE)
    def test_reasoning_readiness(self):
        from journeyman.core.guardian import guardian_reasoning_readiness
        self.assertTrue(guardian_reasoning_readiness()["passed"])
    def test_guardian_module_v04(self):
        from journeyman.modules.guardian import GUARDIAN_MODULE
        self.assertEqual(GUARDIAN_MODULE.version,"1.0.0")


class Guardian001ETests(unittest.TestCase):
    def model(self,state=None):
        from journeyman.core.guardian import AIModelRecord,AIModelReleaseState,AuthorityCeiling
        return AIModelRecord("g","1","sha256:x","manifest:x",("JOE",),("test",),AuthorityCeiling.READ_ONLY_ADVISORY,state or AIModelReleaseState.QUALIFIED,"test")
    def graph_req(self):
        from journeyman.core.guardian import EvidenceGraph,EvidenceNode,TypedAIRequest,AIRequestKind,AuthorityCeiling
        g=EvidenceGraph((EvidenceNode("n","x","m",1,"test",{}),),(),"test")
        r=TypedAIRequest("r",AIRequestKind.SUMMARIZE_STATE,("n",),"q","JOE",AuthorityCeiling.READ_ONLY_ADVISORY,"test")
        return g,r
    def test_registry_rejects_duplicate(self):
        from journeyman.core.guardian import AIModelRegistry
        r=AIModelRegistry();r.register(self.model())
        with self.assertRaises(ValueError):r.register(self.model())
    def test_shadow_forces_observe_only(self):
        from journeyman.core.guardian import governed_ai_response,AIModelReleaseState,AuthorityCeiling
        g,r=self.graph_req();q=governed_ai_response(r,g,self.model(AIModelReleaseState.SHADOW),answer="x",confidence=.8,provenance="test")
        self.assertTrue(q.shadow);self.assertEqual(q.authority,AuthorityCeiling.OBSERVE_ONLY)
    def test_unavailable_model_fallback(self):
        from journeyman.core.guardian import governed_ai_response
        g,r=self.graph_req();q=governed_ai_response(r,g,None,provenance="test");self.assertTrue(q.deterministic_fallback)
    def test_missing_backend_response_fallback(self):
        from journeyman.core.guardian import governed_ai_response
        g,r=self.graph_req();q=governed_ai_response(r,g,self.model(),provenance="test");self.assertTrue(q.deterministic_fallback)
    def test_high_ood_fallback(self):
        from journeyman.core.guardian import governed_ai_response,AuthorityCeiling
        g,r=self.graph_req();q=governed_ai_response(r,g,self.model(),answer="x",confidence=.9,novelty_score=.9,provenance="test")
        self.assertTrue(q.deterministic_fallback);self.assertEqual(q.authority,AuthorityCeiling.OBSERVE_ONLY)
    def test_model_disagreement_preserved(self):
        from journeyman.core.guardian import (governed_ai_response,GuardianAssessment,GuardianStatus,GuardianRecommendation,compare_ai_to_deterministic)
        g,r=self.graph_req();ai=governed_ai_response(r,g,self.model(),answer="x",confidence=.9,provenance="test")
        d=GuardianAssessment(GuardianStatus.HOLD,GuardianRecommendation.RECOMMEND_HOLD,(),(),1,"test")
        self.assertTrue(compare_ai_to_deterministic(ai,d,provenance="test").disagrees)
    def test_ai_governance_readiness(self):
        from journeyman.core.guardian import guardian_ai_governance_readiness
        self.assertTrue(guardian_ai_governance_readiness()["passed"])
    def test_guardian_module_v05(self):
        from journeyman.modules.guardian import GUARDIAN_MODULE
        self.assertEqual(GUARDIAN_MODULE.version,"1.0.0")


class Guardian001FTests(unittest.TestCase):
    def test_guardian_v1_release_readiness(self):
        from journeyman.core.guardian import guardian_v1_release_readiness
        q=guardian_v1_release_readiness();self.assertTrue(q.passed,q.failures);self.assertGreaterEqual(len(q.checks),6)
    def test_workspace_snapshot(self):
        from journeyman.core.guardian import GuardianContractEnvelope,guardian_workspace_snapshot
        e=GuardianContractEnvelope("x","JOE-GUARDIAN-X/1","PASS",{},"test","READ_ONLY_ADVISORY")
        q=guardian_workspace_snapshot((e,),provenance="test");self.assertEqual(q["module_count"],1);self.assertEqual(q["authority"],"READ_ONLY_ADVISORY")
    def test_guardian_workspace_wired(self):
        root=Path(__file__).parents[1];ui=(root/"journeyman"/"ui"/"workspaces.py").read_text();main=(root/"journeyman"/"ui"/"main_window.py").read_text()
        self.assertIn("class GuardianWorkspace(QWidget):",ui);self.assertIn('workspace_kind="guardian"',ui)
        self.assertIn("Guardian AI Governor",main);self.assertIn('kind == "guardian"',main)
    def test_guardian_workspace_no_fake_ai(self):
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("AI backend: NOT BUNDLED",ui);self.assertIn("READ_ONLY_ADVISORY",ui)
    def test_guardian_workspace_contract_import(self):
        ui=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("def import_contract",ui);self.assertIn("self.service.ingest_contract",ui)
    def test_guardian_module_v1(self):
        from journeyman.modules.guardian import GUARDIAN_MODULE
        self.assertEqual(GUARDIAN_MODULE.version,"1.0.0")


class Visualization001ATests(unittest.TestCase):
    def series(self,sid="a",unit="m",frame="f"):
        from journeyman.core.advanced_visualization import ScientificSeries,VisualizationPoint
        return ScientificSeries(sid,sid,"x","s",unit,(VisualizationPoint(0,1,.1),VisualizationPoint(1,2,.1)),
            "SIMULATION","test","m",frame,"e")
    def test_series_rejects_reverse_x(self):
        from journeyman.core.advanced_visualization import ScientificSeries,VisualizationPoint
        with self.assertRaises(ValueError):ScientificSeries("a","a","x","s","m",(VisualizationPoint(1,1),VisualizationPoint(0,2)),"SIMULATION","t","m")
    def test_overlay_compatible(self):
        from journeyman.core.advanced_visualization import compatible_overlay
        self.assertTrue(compatible_overlay((self.series("a"),self.series("b")))[0])
    def test_overlay_rejects_unit_mismatch(self):
        from journeyman.core.advanced_visualization import compatible_overlay
        ok,fail=compatible_overlay((self.series("a"),self.series("b","kg")));self.assertFalse(ok);self.assertTrue(fail)
    def test_cursor_nearest_value(self):
        from journeyman.core.advanced_visualization import synchronized_cursor_values
        q=synchronized_cursor_values((self.series(),),.8);self.assertEqual(q["a"].x,1)
    def test_range_selection(self):
        from journeyman.core.advanced_visualization import select_range,RangeSelection
        q=select_range(self.series(),RangeSelection(.5,1.5));self.assertEqual(len(q.points),1)
    def test_store_rejects_duplicate(self):
        from journeyman.core.advanced_visualization import ScientificVisualizationStore
        s=ScientificVisualizationStore();s.register_series(self.series())
        with self.assertRaises(ValueError):s.register_series(self.series())
    def test_visualization_readiness(self):
        from journeyman.core.advanced_visualization import visualization_core_readiness
        self.assertTrue(visualization_core_readiness()["passed"])
    def test_visualization_module_v01(self):
        from journeyman.modules.advanced_visualization import VISUALIZATION_MODULE
        self.assertEqual(VISUALIZATION_MODULE.version,"1.0.0")


class Visualization001BTests(unittest.TestCase):
    def series(self):
        from journeyman.core.advanced_visualization import ScientificSeries,VisualizationPoint
        return ScientificSeries("s","S","x","s","m",tuple(VisualizationPoint(i,float(i*i),.1) for i in range(5)),
            "SIMULATION","test","m")
    def test_histogram_preserves_count(self):
        from journeyman.core.advanced_visualization import histogram
        h=histogram(self.series(),bins=3,provenance="test");self.assertEqual(sum(h.counts),5)
    def test_bounded_stream(self):
        from journeyman.core.advanced_visualization import append_stream_point,VisualizationPoint,StreamPolicy
        q=append_stream_point(self.series(),VisualizationPoint(5,25,.1),StreamPolicy(3));self.assertEqual(len(q.points),3);self.assertEqual(q.points[-1].x,5)
    def test_matrix_rejects_ragged(self):
        from journeyman.core.advanced_visualization import MatrixDataset
        with self.assertRaises(ValueError):MatrixDataset("m","M",((1.,2.),(3.,)),"m","m","K","SIMULATION","test","m")
    def test_aligned_overlay(self):
        from journeyman.core.advanced_visualization import aligned_overlay_values
        axis,vals=aligned_overlay_values((self.series(),));self.assertEqual(len(axis),5);self.assertEqual(vals["s"][-1],16)
    def test_rendering_readiness(self):
        from journeyman.core.advanced_visualization import visualization_rendering_readiness
        self.assertTrue(visualization_rendering_readiness()["passed"])
    def test_visualization_workspace_wired(self):
        root=Path(__file__).parents[1];w=(root/"journeyman"/"ui"/"workspaces.py").read_text();m=(root/"journeyman"/"ui"/"main_window.py").read_text()
        self.assertIn("class AdvancedVisualizationWorkspace(QWidget):",w);self.assertIn("Advanced Analysis & Visualization",m)
    def test_no_fake_visualization_data(self):
        w=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertNotIn("demo telemetry",w.lower());self.assertIn("self.service.store.all_series()",w)
    def test_visualization_module_v02(self):
        from journeyman.modules.advanced_visualization import VISUALIZATION_MODULE
        self.assertEqual(VISUALIZATION_MODULE.version,"1.0.0")


class Visualization001CTests(unittest.TestCase):
    def test_link_group_rejects_unknown_plot(self):
        from journeyman.core.advanced_visualization import (AxisSpecification,PlotSpecification,PlotKind,VisualizationMode,PlotLinkGroup,LinkMode,MultiPlotWorkspaceSpecification)
        a=AxisSpecification("x","s");b=AxisSpecification("y","m")
        p=PlotSpecification("p","P",PlotKind.TIME_SERIES,VisualizationMode.POST_RUN,(),a,b)
        g=PlotLinkGroup("g",("p","missing"),LinkMode.X_RANGE)
        with self.assertRaises(ValueError):MultiPlotWorkspaceSpecification("w","W",(p,),(g,),1,True,"test")
    def test_declared_unit_conversion_uncertainty(self):
        from journeyman.core.advanced_visualization import (ScientificSeries,VisualizationPoint,convert_series_units,UnitConversion)
        s=ScientificSeries("s","S","x","s","m",(VisualizationPoint(0,2,.5),),"SIMULATION","test","m")
        q=convert_series_units(s,UnitConversion("m","cm",100,provenance="declared SI conversion"))
        self.assertEqual(q.points[0].y,200);self.assertEqual(q.points[0].standard_uncertainty,50);self.assertEqual(q.y_unit,"cm")
    def test_matrix_statistics(self):
        from journeyman.core.advanced_visualization import MatrixDataset,matrix_statistics
        m=MatrixDataset("m","M",((1.,2.),(3.,4.)),"m","m","K","SIMULATION","test","m")
        self.assertEqual(matrix_statistics(m).mean,2.5)
    def test_vector_field_rejects_length_mismatch(self):
        from journeyman.core.advanced_visualization import VectorFieldDataset
        with self.assertRaises(ValueError):VectorFieldDataset("f","F",(0.,1.),(0.,),(1.,1.),(0.,1.),"m","m/s","SIMULATION","test","m")
    def test_surface_rejects_dimension_mismatch(self):
        from journeyman.core.advanced_visualization import SurfaceDataset
        with self.assertRaises(ValueError):SurfaceDataset("s","S",(0.,1.),(0.,1.),((1.,2.),),"m","m","K","SIMULATION","test","m")
    def test_advanced_workspace_readiness(self):
        from journeyman.core.advanced_visualization import advanced_workspace_readiness
        self.assertTrue(advanced_workspace_readiness()["passed"])
    def test_workspace_has_linked_secondary_plot(self):
        w=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("self.plot2.setXLink(self.plot)",w);self.assertIn("Render Secondary",w)
    def test_visualization_module_v03(self):
        from journeyman.modules.advanced_visualization import VISUALIZATION_MODULE
        self.assertEqual(VISUALIZATION_MODULE.version,"1.0.0")


class Visualization001DTests(unittest.TestCase):
    def series(self):
        from journeyman.core.advanced_visualization import ScientificSeries,VisualizationPoint
        return ScientificSeries("s","S","x","s","m",(VisualizationPoint(0,1,.1),VisualizationPoint(1,3,.2)),
            "SIMULATION","test","m","f","e","r")
    def test_csv_export_has_provenance(self):
        import tempfile
        from journeyman.core.advanced_visualization import export_series_csv
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"x.csv";q=export_series_csv(self.series(),p);text=p.read_text()
            self.assertEqual(q.rows,2);self.assertIn("standard_uncertainty",text);self.assertIn("SIMULATION",text)
    def test_workspace_round_trip(self):
        import tempfile
        from journeyman.core.advanced_visualization import (AxisSpecification,PlotSpecification,PlotKind,VisualizationMode,MultiPlotWorkspaceSpecification,export_workspace_specification,load_workspace_specification)
        a=AxisSpecification("t","s");b=AxisSpecification("x","m")
        p=PlotSpecification("p","P",PlotKind.TIME_SERIES,VisualizationMode.POST_RUN,("s",),a,b)
        ws=MultiPlotWorkspaceSpecification("w","W",(p,),(),1,True,"test")
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/"w.json";export_workspace_specification(ws,path);self.assertEqual(load_workspace_specification(path),ws)
    def test_workspace_rejects_wrong_schema(self):
        import tempfile
        from journeyman.core.advanced_visualization import load_workspace_specification
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"x.json";p.write_text('{"schema":"wrong"}')
            with self.assertRaises(ValueError):load_workspace_specification(p)
    def test_summary_excludes_unavailable(self):
        from journeyman.core.advanced_visualization import ScientificSeries,VisualizationPoint,DataQuality,summarize_series
        s=ScientificSeries("s","S","x","s","m",(VisualizationPoint(0,1),VisualizationPoint(1,100,quality=DataQuality.UNAVAILABLE)),"SIMULATION","t","m")
        q=summarize_series(s);self.assertEqual(q.count,1);self.assertEqual(q.mean,1)
    def test_v1_release_readiness(self):
        from journeyman.core.advanced_visualization import visualization_v1_release_readiness
        q=visualization_v1_release_readiness();self.assertTrue(q["passed"],q["failures"])
    def test_workspace_has_exports(self):
        w=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("Export Series CSV",w);self.assertIn("Export Figure PNG",w);self.assertIn("pg.exporters.ImageExporter",w)
    def test_visualization_module_v1(self):
        from journeyman.modules.advanced_visualization import VISUALIZATION_MODULE
        self.assertEqual(VISUALIZATION_MODULE.version,"1.0.0")


class ScientificData001ATests(unittest.TestCase):
    def record(self):
        from journeyman.core.scientific_data import ScientificRecord,ScientificDataOrigin
        return ScientificRecord("r","x",1.0,"m",.1,0.0,"test",ScientificDataOrigin.SIMULATION,"test")
    def test_record_requires_finite_uncertainty(self):
        from journeyman.core.scientific_data import ScientificRecord,ScientificDataOrigin
        with self.assertRaises(ValueError):ScientificRecord("r","x",1.0,"m",-1,0,"test",ScientificDataOrigin.SIMULATION,"test")
    def test_manifest_detects_record_change(self):
        from journeyman.core.scientific_data import create_manifest,verify_manifest_records,ScientificRecord,ScientificDataOrigin
        r=self.record();m=create_manifest(run_id="x",records=(r,),software_build="b",provenance="t",created_at_s=0)
        changed=ScientificRecord("r","x",2.0,"m",.1,0,"test",ScientificDataOrigin.SIMULATION,"test")
        self.assertFalse(verify_manifest_records(m,(changed,)))
    def test_artifact_hash_verification(self):
        import tempfile
        from journeyman.core.scientific_data import register_artifact,verify_artifact
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"a";p.write_bytes(b"abc");a=register_artifact(p,provenance="test");self.assertTrue(verify_artifact(a,p))
            p.write_bytes(b"abd");self.assertFalse(verify_artifact(a,p))
    def test_store_rejects_duplicate_run(self):
        import tempfile
        from journeyman.core.scientific_data import ImmutableRunDataStore,create_manifest
        r=self.record();m=create_manifest(run_id="x",records=(r,),software_build="b",provenance="t",created_at_s=0)
        with tempfile.TemporaryDirectory() as d:
            s=ImmutableRunDataStore(d);s.create_run(m,(r,))
            with self.assertRaises(FileExistsError):s.create_run(m,(r,))
    def test_guardian_contract_has_hash(self):
        from journeyman.core.scientific_data import create_manifest,data_guardian_contract
        m=create_manifest(run_id="x",records=(self.record(),),software_build="b",provenance="t",created_at_s=0)
        self.assertEqual(len(data_guardian_contract(m).facts["records_sha256"]),64)
    def test_data_core_readiness(self):
        from journeyman.core.scientific_data import scientific_data_core_readiness
        self.assertTrue(scientific_data_core_readiness()["passed"])
    def test_scientific_data_module_v01(self):
        from journeyman.modules.scientific_data import SCIENTIFIC_DATA_MODULE
        self.assertEqual(SCIENTIFIC_DATA_MODULE.version,"1.0.0")


class ScientificData001BTests(unittest.TestCase):
    def make_store(self,d):
        from journeyman.core.scientific_data import ImmutableRunDataStore,ScientificRecord,ScientificDataOrigin,create_manifest
        s=ImmutableRunDataStore(d);r=ScientificRecord("r","x",1.0,"m",.1,1,"test",ScientificDataOrigin.IMPORTED,"test")
        m=create_manifest(run_id="a",records=(r,),software_build="b",provenance="test",created_at_s=1);s.create_run(m,(r,));return s
    def test_archive_lists_run(self):
        import tempfile
        from journeyman.core.scientific_data import list_run_entries
        with tempfile.TemporaryDirectory() as d:self.assertEqual(list_run_entries(self.make_store(d))[0].run_id,"a")
    def test_query_by_origin(self):
        import tempfile
        from journeyman.core.scientific_data import query_records,ScientificDataOrigin
        with tempfile.TemporaryDirectory() as d:self.assertEqual(len(query_records(self.make_store(d),origin=ScientificDataOrigin.IMPORTED)),1)
    def test_integrity_audit_detects_record_tamper(self):
        import tempfile
        from journeyman.core.scientific_data import audit_run
        with tempfile.TemporaryDirectory() as d:
            s=self.make_store(d);p=Path(d)/"a"/"records.jsonl";p.write_text(p.read_text().replace('"value":1.0','"value":2.0'))
            self.assertFalse(audit_run(s,"a").passed)
    def test_chain_detects_wrong_predecessor(self):
        import tempfile
        from journeyman.core.scientific_data import ScientificRecord,ScientificDataOrigin,create_manifest,verify_manifest_chain
        with tempfile.TemporaryDirectory() as d:
            s=self.make_store(d);r=ScientificRecord("r2","x",2.0,"m",.1,2,"test",ScientificDataOrigin.SIMULATION,"test")
            m=create_manifest(run_id="b",records=(r,),software_build="b",provenance="test",created_at_s=2,previous_manifest_sha256="0"*64);s.create_run(m,(r,))
            self.assertFalse(verify_manifest_chain(s)[0])
    def test_provenance_summary(self):
        import tempfile
        from journeyman.core.scientific_data import provenance_summary
        with tempfile.TemporaryDirectory() as d:
            q=provenance_summary(self.make_store(d));self.assertEqual(q["run_count"],1);self.assertEqual(q["origins"]["IMPORTED"],1)
    def test_archive_readiness(self):
        from journeyman.core.scientific_data import scientific_data_archive_readiness
        self.assertTrue(scientific_data_archive_readiness()["passed"])
    def test_data_workspace_present(self):
        w=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("class ScientificDataWorkspace(QWidget):",w);self.assertIn("Audit Selected Run",w)
    def test_scientific_data_module_v02(self):
        from journeyman.modules.scientific_data import SCIENTIFIC_DATA_MODULE
        self.assertEqual(SCIENTIFIC_DATA_MODULE.version,"1.0.0")


class ScientificData001CTests(unittest.TestCase):
    def records(self):
        from journeyman.core.scientific_data import ScientificRecord,ScientificDataOrigin
        a=ScientificRecord("a","raw",1.0,"V",.1,0,"sensor",ScientificDataOrigin.SIMULATION,"test")
        b=ScientificRecord("b","derived",2.0,"V",.2,1,"analysis",ScientificDataOrigin.SIMULATION,"test")
        return a,b
    def test_lineage_trace(self):
        from journeyman.core.scientific_data import ProvenanceLineage,LineageEdge,validate_lineage,trace_record
        a,b=self.records();l=ProvenanceLineage("JOE-PROVENANCE-LINEAGE/1","r",(LineageEdge("a","b","DERIVED_FROM","test"),),"test")
        self.assertTrue(validate_lineage(l,(a,b))[0]);self.assertEqual(trace_record(l,"b").ancestors,("a",))
    def test_lineage_rejects_cycle(self):
        from journeyman.core.scientific_data import ProvenanceLineage,LineageEdge,validate_lineage
        a,b=self.records();l=ProvenanceLineage("JOE-PROVENANCE-LINEAGE/1","r",(LineageEdge("a","b","D","t"),LineageEdge("b","a","D","t")),"t")
        self.assertFalse(validate_lineage(l,(a,b))[0])
    def test_lineage_round_trip(self):
        import tempfile
        from journeyman.core.scientific_data import ProvenanceLineage,LineageEdge,write_lineage,load_lineage
        l=ProvenanceLineage("JOE-PROVENANCE-LINEAGE/1","r",(LineageEdge("a","b","D","t"),),"t")
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"l.json";write_lineage(l,p);self.assertEqual(load_lineage(p),l)
    def test_audit_export(self):
        import tempfile,json
        from journeyman.core.scientific_data import IntegrityAudit,export_audit_report
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"a.json";export_audit_report(IntegrityAudit("r",True,("ok",),(),"0"*64),p)
            self.assertEqual(json.loads(p.read_text())["schema"],"JOE-DATA-INTEGRITY-AUDIT/1")
    def test_data_v1_readiness(self):
        from journeyman.core.scientific_data import scientific_data_v1_release_readiness
        q=scientific_data_v1_release_readiness();self.assertTrue(q["passed"],q["failures"])
    def test_workspace_has_audit_export(self):
        w=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("Export Audit JSON",w)
    def test_scientific_data_module_v1(self):
        from journeyman.modules.scientific_data import SCIENTIFIC_DATA_MODULE
        self.assertEqual(SCIENTIFIC_DATA_MODULE.version,"1.0.0")


class Report001ATests(unittest.TestCase):
    def spec(self):
        from journeyman.core.reports import EvidenceReference,EvidenceClass,ReportElement,ReportElementKind,ReportSection,ScientificReportSpecification
        e=EvidenceReference("e","RUN","r","test",EvidenceClass.SIMULATION_RESULT,("rec",))
        x=ReportElement("x",ReportElementKind.PROSE,"Result","text",("e",),"test")
        s=ReportSection("s","1","Section",(x,),"test")
        return ScientificReportSpecification("JOE-SCIENTIFIC-REPORT/1","r","Report","","Journeyman","Technical","Sierra Kilo Labs",(s,),(e,),"build","test")
    def test_unknown_evidence_rejected(self):
        from journeyman.core.reports import ReportElement,ReportElementKind,ReportSection,ScientificReportSpecification
        x=ReportElement("x",ReportElementKind.PROSE,"X","text",("missing",),"test");s=ReportSection("s","1","S",(x,),"test")
        with self.assertRaises(ValueError):ScientificReportSpecification("JOE-SCIENTIFIC-REPORT/1","r","R","","P","E","O",(s,),(),"b","t")
    def test_equation_requires_id(self):
        from journeyman.core.reports import ReportElement,ReportElementKind
        with self.assertRaises(ValueError):ReportElement("x",ReportElementKind.EQUATION,"E","x",("e",),"test")
    def test_report_round_trip(self):
        import tempfile
        from journeyman.core.reports import write_report_specification,load_report_specification
        q=self.spec()
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"r.json";write_report_specification(q,p);self.assertEqual(load_report_specification(p),q)
    def test_report_hash_stable(self):
        from journeyman.core.reports import report_specification_sha256
        self.assertEqual(report_specification_sha256(self.spec()),report_specification_sha256(self.spec()))
    def test_report_validation(self):
        from journeyman.core.reports import validate_report
        self.assertTrue(validate_report(self.spec()).passed)
    def test_report_guardian_contract(self):
        from journeyman.core.reports import report_guardian_contract
        self.assertEqual(report_guardian_contract(self.spec()).schema,"JOE-GUARDIAN-REPORT/1")
    def test_report_core_readiness(self):
        from journeyman.core.reports import report_core_readiness
        self.assertTrue(report_core_readiness()["passed"])
    def test_report_module_v01(self):
        from journeyman.modules.reports import REPORT_MODULE
        self.assertEqual(REPORT_MODULE.version,"1.0.0")


class Report001BTests(unittest.TestCase):
    def spec(self):
        from journeyman.core.reports import EvidenceReference,EvidenceClass,ReportElement,ReportElementKind,ReportSection,ScientificReportSpecification
        e=EvidenceReference("e","RUN","r","test",EvidenceClass.SIMULATION_RESULT,("rec",))
        x=ReportElement("x",ReportElementKind.EQUATION,"Equation","ΔT = τ_A − τ_B",("e",),"test",equation_id="Equation (1-1)",units="s")
        s=ReportSection("s","1","Section",(x,),"test")
        return ScientificReportSpecification("JOE-SCIENTIFIC-REPORT/1","r","Report","Sub","Journeyman","Technical","Sierra Kilo Labs",(s,),(e,),"build","test")
    def test_text_renderer_preserves_evidence_class(self):
        from journeyman.core.reports import render_report_text
        q=render_report_text(self.spec());self.assertIn("SIMULATION_RESULT",q.rendered_text);self.assertIn("Equation (1-1)",q.rendered_text)
    def test_html_renderer_escapes_content(self):
        from journeyman.core.reports import render_report_html
        q=render_report_html(self.spec());self.assertIn("<!doctype html>",q.rendered_text);self.assertIn("SIMULATION_RESULT",q.rendered_text)
    def test_rendered_report_binds_spec_hash(self):
        from journeyman.core.reports import render_report_text,report_specification_sha256
        q=render_report_text(self.spec());self.assertEqual(q.specification_sha256,report_specification_sha256(self.spec()))
    def test_text_export(self):
        import tempfile
        from journeyman.core.reports import render_report_text,write_rendered_text
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"r.txt";h=write_rendered_text(render_report_text(self.spec()),p);self.assertEqual(len(h),64);self.assertIn("Report",p.read_text())
    def test_rendering_readiness(self):
        from journeyman.core.reports import report_rendering_readiness
        self.assertTrue(report_rendering_readiness()["passed"])
    def test_report_workspace_present(self):
        w=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("class ReportGeneratorWorkspace(QWidget):",w);self.assertIn("Export HTML",w)
    def test_report_module_v02(self):
        from journeyman.modules.reports import REPORT_MODULE
        self.assertEqual(REPORT_MODULE.version,"1.0.0")


class Report001CTests(unittest.TestCase):
    def spec(self):
        from journeyman.core.reports import EvidenceReference,EvidenceClass,ReportElement,ReportElementKind,ReportSection,ScientificReportSpecification
        e=EvidenceReference("e","RUN","r","test",EvidenceClass.SIMULATION_RESULT,("rec",))
        x=ReportElement("x",ReportElementKind.EQUATION,"Relation","Delta T = tau_A - tau_B",("e",),"test",equation_id="Equation (1-1)",units="s",uncertainty_note="source")
        s=ReportSection("s","1","Section",(x,),"test")
        return ScientificReportSpecification("JOE-SCIENTIFIC-REPORT/1","r","Report","Sub","Journeyman","Technical","Sierra Kilo Labs",(s,),(e,),"build","test")
    def test_pdf_render_and_verify(self):
        import tempfile
        from journeyman.core.reports import render_report_pdf,verify_report_artifact
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"r.pdf";m=render_report_pdf(self.spec(),p)
            self.assertEqual(p.read_bytes()[:4],b"%PDF");self.assertTrue(verify_report_artifact(m,p))
    def test_pdf_tamper_detected(self):
        import tempfile
        from journeyman.core.reports import render_report_pdf,verify_report_artifact
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"r.pdf";m=render_report_pdf(self.spec(),p);p.write_bytes(p.read_bytes()+b"x")
            self.assertFalse(verify_report_artifact(m,p))
    def test_artifact_manifest_export(self):
        import tempfile,json
        from journeyman.core.reports import render_report_pdf,write_report_artifact_manifest
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"r.pdf";m=render_report_pdf(self.spec(),p);q=Path(d)/"m.json";write_report_artifact_manifest(m,q)
            self.assertEqual(json.loads(q.read_text())["schema"],"JOE-REPORT-ARTIFACT/1")
    def test_report_v1_readiness(self):
        from journeyman.core.reports import report_v1_release_readiness
        q=report_v1_release_readiness();self.assertTrue(q["passed"],q["failures"])
    def test_workspace_has_pdf_export(self):
        w=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("Export PDF",w);self.assertIn("write_artifact_manifest",w)
    def test_report_module_v1(self):
        from journeyman.modules.reports import REPORT_MODULE
        self.assertEqual(REPORT_MODULE.version,"1.0.0")


class Compute001ATests(unittest.TestCase):
    def test_cpu_detected_as_real_host(self):
        from journeyman.core.compute_backends import detect_cpu_backend,BackendStatus,BackendKind
        b=detect_cpu_backend();self.assertEqual(b.kind,BackendKind.CPU);self.assertEqual(b.status,BackendStatus.AVAILABLE);self.assertIn("HOST",b.provenance)
    def test_deterministic_requirement_rejected(self):
        from journeyman.core.compute_backends import discover_compute_backends,select_backend,ComputeRequirement
        self.assertEqual(select_backend(discover_compute_backends(),ComputeRequirement(deterministic_required=True)).status,"REJECTED")
    def test_gpu_requirement_never_falls_back_to_cpu(self):
        from journeyman.core.compute_backends import ComputeBackend,BackendKind,BackendStatus,ComputeRequirement,select_backend
        cpu=ComputeBackend("c",BackendKind.CPU,BackendStatus.AVAILABLE,"p","cpu",1,1024,("scalar",),"HOST")
        self.assertEqual(select_backend((cpu,),ComputeRequirement(require_gpu=True)).status,"UNAVAILABLE")
    def test_memory_requirement_enforced(self):
        from journeyman.core.compute_backends import ComputeBackend,BackendKind,BackendStatus,ComputeRequirement,select_backend
        cpu=ComputeBackend("c",BackendKind.CPU,BackendStatus.AVAILABLE,"p","cpu",1,100,("scalar",),"HOST")
        self.assertEqual(select_backend((cpu,),ComputeRequirement(minimum_memory_bytes=101)).status,"UNAVAILABLE")
    def test_compute_guardian_read_only(self):
        from journeyman.core.compute_backends import compute_guardian_contract,discover_compute_backends
        q=compute_guardian_contract(discover_compute_backends());self.assertEqual(q.authority,"READ_ONLY_ADVISORY");self.assertFalse(q.facts["safety_authority"])
    def test_compute_readiness(self):
        from journeyman.core.compute_backends import compute_core_readiness
        self.assertTrue(compute_core_readiness()["passed"])
    def test_compute_workspace_present(self):
        w=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("class ComputeBackendWorkspace(QWidget):",w);self.assertIn("no synthetic hardware",w)
    def test_compute_module_v01(self):
        from journeyman.modules.compute_backends import COMPUTE_MODULE
        self.assertEqual(COMPUTE_MODULE.version,"1.1.0")


class Compute001BTests(unittest.TestCase):
    def cpu(self):
        from journeyman.core.compute_backends import ComputeBackend,BackendKind,BackendStatus
        return ComputeBackend("cpu",BackendKind.CPU,BackendStatus.AVAILABLE,"test","cpu",2,1000000,("scalar","multicore"),"HOST:test")
    def test_cpu_workload_executes(self):
        from journeyman.core.compute_backends import WorkloadRequest,ComputeRequirement,ResourceBudget,execute_workload,WorkloadStatus
        q=WorkloadRequest("w","sum",(1.,2.,3.),ComputeRequirement(),ResourceBudget(),"SIMULATION:test")
        r=execute_workload(q,(self.cpu(),));self.assertEqual(r.status,WorkloadStatus.SUCCEEDED);self.assertEqual(r.output,6)
    def test_unknown_operation_fails(self):
        from journeyman.core.compute_backends import WorkloadRequest,ComputeRequirement,ResourceBudget,execute_workload,WorkloadStatus
        r=execute_workload(WorkloadRequest("w","bogus",(1.,),ComputeRequirement(),ResourceBudget(),"SIMULATION:test"),(self.cpu(),))
        self.assertEqual(r.status,WorkloadStatus.FAILED)
    def test_gpu_without_adapter_rejected(self):
        from journeyman.core.compute_backends import ComputeBackend,BackendKind,BackendStatus,WorkloadRequest,ComputeRequirement,ResourceBudget,execute_workload,WorkloadStatus
        gpu=ComputeBackend("g",BackendKind.GPU,BackendStatus.AVAILABLE,"test","gpu",None,1000,("gpu",),"HOST:test")
        q=WorkloadRequest("w","sum",(1.,),ComputeRequirement(require_gpu=True),ResourceBudget(),"SIMULATION:test")
        self.assertEqual(execute_workload(q,(gpu,)).status,WorkloadStatus.REJECTED)
    def test_async_executor(self):
        from journeyman.core.compute_backends import GovernedComputeExecutor,WorkloadRequest,ComputeRequirement,ResourceBudget
        ex=GovernedComputeExecutor((self.cpu(),),2)
        try:
            h=ex.submit(WorkloadRequest("w","mean",(2.,4.),ComputeRequirement(),ResourceBudget(1),"SIMULATION:test"))
            self.assertEqual(h.result(2).output,3)
        finally:ex.shutdown()
    def test_executor_rejects_rt(self):
        from journeyman.core.compute_backends import GovernedComputeExecutor,WorkloadRequest,ComputeRequirement,ResourceBudget
        ex=GovernedComputeExecutor((self.cpu(),),1)
        try:
            with self.assertRaises(ValueError):ex.submit(WorkloadRequest("w","sum",(1.,),ComputeRequirement(deterministic_required=True),ResourceBudget(),"test"))
        finally:ex.shutdown()
    def test_workload_provenance_schema(self):
        from journeyman.core.compute_backends import WorkloadRequest,ComputeRequirement,ResourceBudget,execute_workload,workload_provenance_record
        q=WorkloadRequest("w","sum",(1.,),ComputeRequirement(),ResourceBudget(),"SIMULATION:test")
        r=execute_workload(q,(self.cpu(),));self.assertEqual(workload_provenance_record(q,r)["schema"],"JOE-COMPUTE-WORKLOAD/1")
    def test_execution_readiness(self):
        from journeyman.core.compute_backends import compute_execution_readiness
        self.assertTrue(compute_execution_readiness()["passed"])
    def test_workspace_has_cpu_qualification(self):
        w=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("Run CPU Qualification",w);self.assertIn("SIMULATION: explicit operator qualification",w)
    def test_compute_module_v02(self):
        from journeyman.modules.compute_backends import COMPUTE_MODULE
        self.assertEqual(COMPUTE_MODULE.version,"1.1.0")


class Compute001CTests(unittest.TestCase):
    def test_resource_policy_rejects_workers(self):
        from journeyman.core.compute_backends import ComputeBackend,BackendKind,BackendStatus,BackendHealth,WorkloadRequest,ComputeRequirement,ResourceBudget,ResourcePolicy,evaluate_resource_policy
        b=ComputeBackend("c",BackendKind.CPU,BackendStatus.AVAILABLE,"p","cpu",4,1000,("scalar",),"HOST")
        h=BackendHealth("c","AVAILABLE",10,100,1000,None,None,"HOST")
        q=WorkloadRequest("w","sum",(1.,),ComputeRequirement(),ResourceBudget(3),"SIMULATION:test")
        self.assertFalse(evaluate_resource_policy(q,b,h,ResourcePolicy(2,.8)).allowed)
    def test_resource_policy_rejects_memory(self):
        from journeyman.core.compute_backends import ComputeBackend,BackendKind,BackendStatus,BackendHealth,WorkloadRequest,ComputeRequirement,ResourceBudget,ResourcePolicy,evaluate_resource_policy,WorkloadHistory,WorkloadResult,WorkloadStatus,cpu_health,nvidia_gpu_health,compute_v1_release_readiness
        b=ComputeBackend("c",BackendKind.CPU,BackendStatus.AVAILABLE,"p","cpu",4,1000,("scalar",),"HOST")
        h=BackendHealth("c","AVAILABLE",10,100,1000,None,None,"HOST")
        q=WorkloadRequest("w","sum",(1.,),ComputeRequirement(),ResourceBudget(1,600),"SIMULATION:test")
        self.assertFalse(evaluate_resource_policy(q,b,h,ResourcePolicy(2,.5)).allowed)
    def test_history_append_only_identity(self):
        from journeyman.core.compute_backends import WorkloadHistory,WorkloadRequest,ComputeRequirement,ResourceBudget,WorkloadResult,WorkloadStatus
        h=WorkloadHistory();q=WorkloadRequest("w","sum",(1.,),ComputeRequirement(),ResourceBudget(),"SIMULATION:test")
        r=WorkloadResult("w","c",WorkloadStatus.SUCCEEDED,1,1,2,"","SIMULATION:test");h.append(q,r)
        with self.assertRaises(ValueError):h.append(q,r)
    def test_cpu_health_is_host_provenance(self):
        from journeyman.core.compute_backends import cpu_health
        self.assertTrue(cpu_health().provenance.startswith("HOST:"))
    def test_missing_gpu_health_not_faked(self):
        from journeyman.core.compute_backends import nvidia_gpu_health
        h=nvidia_gpu_health();self.assertIn(h.status,("AVAILABLE","DEGRADED","UNAVAILABLE"))
        if h.status=="UNAVAILABLE":self.assertIsNone(h.temperature_c)
    def test_compute_v1_readiness(self):
        from journeyman.core.compute_backends import compute_v1_release_readiness
        q=compute_v1_release_readiness();self.assertTrue(q["passed"],q["failures"])
    def test_workspace_has_health_table(self):
        w=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("Temperature C",w);self.assertIn('"N/A" if v is None',w)
    def test_compute_module_v1(self):
        from journeyman.modules.compute_backends import COMPUTE_MODULE
        self.assertEqual(COMPUTE_MODULE.version,"1.1.0")


class Compute001DAMDTests(unittest.TestCase):
    def test_amd_discovery_is_host_based(self):
        from journeyman.core.compute_backends import _amd_smi_backend
        b=_amd_smi_backend()
        if b is not None:
            self.assertEqual(b.provider,"AMD");self.assertTrue(b.provenance.startswith("HOST:"))
    def test_amd_health_never_fabricates_missing_provider(self):
        from journeyman.core.compute_backends import amd_gpu_health
        h=amd_gpu_health();self.assertTrue(h.provenance.startswith("HOST:"))
        if h.status=="UNAVAILABLE":
            self.assertIsNone(h.utilization_percent);self.assertIsNone(h.temperature_c);self.assertIsNone(h.power_w)
    def test_compute_service_exposes_amd_health(self):
        from journeyman.modules.compute_backends import ComputeService
        ids={h.backend_id for h in ComputeService().health()};self.assertIn("local.gpu.amd",ids)
    def test_compute_module_v11(self):
        from journeyman.modules.compute_backends import COMPUTE_MODULE
        self.assertEqual(COMPUTE_MODULE.version,"1.1.0")


class QPU001ATests(unittest.TestCase):
    def test_physical_qpu_not_assumed(self):
        from journeyman.core.quantum_runtime import discover_quantum_backends,QuantumBackendKind,QuantumBackendStatus
        q=[b for b in discover_quantum_backends() if b.kind==QuantumBackendKind.QPU]
        self.assertTrue(q);self.assertTrue(all(b.status!=QuantumBackendStatus.AVAILABLE for b in q))
    def test_basis_simulator(self):
        from journeyman.core.quantum_runtime import QuantumCircuit,QuantumJobRequest,execute_basis_simulation,QuantumJobStatus
        c=QuantumCircuit("c",2,(("X",(0,)),("CX",(0,1)),("MEASURE",(0,)),("MEASURE",(1,))),"SIMULATION:test")
        r=execute_basis_simulation(QuantumJobRequest("j","joe.basis-simulator",c,10,"SIMULATION:test"))
        self.assertEqual(r.status,QuantumJobStatus.SUCCEEDED);self.assertEqual(r.counts,{"11":10})
    def test_hadamard_refused_by_basis_simulator(self):
        from journeyman.core.quantum_runtime import QuantumCircuit,QuantumJobRequest,execute_basis_simulation,QuantumJobStatus
        c=QuantumCircuit("c",1,(("H",(0,)),("MEASURE",(0,))),"SIMULATION:test")
        r=execute_basis_simulation(QuantumJobRequest("j","joe.basis-simulator",c,10,"SIMULATION:test"))
        self.assertEqual(r.status,QuantumJobStatus.FAILED);self.assertIn("refuses to fake",r.diagnostic)
    def test_shot_governance(self):
        from journeyman.core.quantum_runtime import QuantumCircuit,QuantumJobRequest
        c=QuantumCircuit("c",1,(("MEASURE",(0,)),),"SIMULATION:test")
        with self.assertRaises(ValueError):QuantumJobRequest("j","joe.basis-simulator",c,0,"test")
    def test_quantum_guardian_read_only(self):
        from journeyman.core.quantum_runtime import quantum_guardian_contract,builtin_basis_backend,discover_quantum_backends
        g=quantum_guardian_contract((builtin_basis_backend(),)+discover_quantum_backends());self.assertEqual(g.authority,"READ_ONLY_ADVISORY");self.assertFalse(g.facts["safety_authority"])
    def test_quantum_readiness(self):
        from journeyman.core.quantum_runtime import quantum_core_readiness
        self.assertTrue(quantum_core_readiness()["passed"])
    def test_quantum_workspace_present(self):
        w=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("class QuantumRuntimeWorkspace(QWidget):",w);self.assertIn("not physical QPU access",w)
    def test_quantum_module_v01(self):
        from journeyman.modules.quantum_runtime import QUANTUM_MODULE
        self.assertEqual(QUANTUM_MODULE.version,"1.0.0")

class QPU001BTests(unittest.TestCase):
    def test_bell_contract(self):
        from journeyman.core.quantum_runtime import bell_circuit
        self.assertEqual(bell_circuit().operations[0][0],"H")
    def test_unknown_adapter_rejected(self):
        from journeyman.core.quantum_runtime import QuantumRuntimeManager,QuantumJobRequest,bell_circuit,QuantumJobStatus
        self.assertEqual(QuantumRuntimeManager().execute(QuantumJobRequest("j","physical.qpu",bell_circuit(),10,"SIMULATION:test")).status,QuantumJobStatus.REJECTED)
    def test_history_append_only(self):
        from journeyman.core.quantum_runtime import QuantumJobHistory,QuantumJobRequest,QuantumJobResult,QuantumJobStatus,bell_circuit
        h=QuantumJobHistory();q=QuantumJobRequest("j","x",bell_circuit(),10,"SIMULATION:test");r=QuantumJobResult("j","x",QuantumJobStatus.REJECTED,{},None,None,"SIMULATION:test","x");h.append(q,r)
        with self.assertRaises(ValueError):h.append(q,r)
    def test_qualifications_explicit(self):
        from journeyman.core.quantum_runtime import QuantumRuntimeManager
        q=QuantumRuntimeManager().qualifications();self.assertIn("qiskit.local",q);self.assertIn("cirq.local",q);self.assertTrue(all("available" in x for x in q.values()))
    def test_provider_readiness(self):
        from journeyman.core.quantum_runtime import quantum_provider_readiness
        q=quantum_provider_readiness();self.assertTrue(q["passed"],q["failures"])
    def test_workspace_provider_button(self):
        self.assertIn("Qualify Local Simulator Providers",(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text())
    def test_quantum_module_v02(self):
        from journeyman.modules.quantum_runtime import QUANTUM_MODULE
        self.assertEqual(QUANTUM_MODULE.version,"1.0.0")


class QPU001CTests(unittest.TestCase):
    def request(self):
        from journeyman.core.quantum_runtime import QuantumCircuit,QuantumJobRequest
        c=QuantumCircuit("c",1,(("X",(0,)),("MEASURE",(0,))),"SIMULATION:test")
        return QuantumJobRequest("j","physical.test",c,8,"SIMULATION:test")
    def test_unauthenticated_physical_provider_rejected(self):
        from journeyman.core.quantum_runtime import PhysicalProviderCapability,validate_physical_request
        c=PhysicalProviderCapability("p","physical.test",1,("X","MEASURE"),8,False,True,"SOFTWARE:test")
        self.assertIn("provider authentication not established",validate_physical_request(self.request(),c))
    def test_physical_capability_limits(self):
        from journeyman.core.quantum_runtime import PhysicalProviderCapability,validate_physical_request
        c=PhysicalProviderCapability("p","physical.test",1,("MEASURE",),4,True,True,"SOFTWARE:test")
        f=validate_physical_request(self.request(),c);self.assertTrue(any("shots" in x for x in f));self.assertTrue(any("unsupported" in x for x in f))
    def test_binding_rejects_secretish_reference(self):
        from journeyman.core.quantum_runtime import PhysicalProviderBinding
        with self.assertRaises(ValueError):PhysicalProviderBinding("p","a","api_key=abc","environment","test")
    def test_result_integrity(self):
        from journeyman.core.quantum_runtime import QuantumJobResult,QuantumJobStatus,verify_quantum_result
        r=QuantumJobResult("j","physical.test",QuantumJobStatus.SUCCEEDED,{"1":8},1,2,"HARDWARE:test")
        q=verify_quantum_result(self.request(),r);self.assertTrue(q.valid);self.assertEqual(len(q.counts_sha256),64)
    def test_result_integrity_detects_shot_mismatch(self):
        from journeyman.core.quantum_runtime import QuantumJobResult,QuantumJobStatus,verify_quantum_result
        r=QuantumJobResult("j","physical.test",QuantumJobStatus.SUCCEEDED,{"1":7},1,2,"HARDWARE:test")
        self.assertFalse(verify_quantum_result(self.request(),r).valid)
    def test_unbound_physical_runtime_rejects(self):
        from journeyman.core.quantum_runtime import PhysicalQuantumRuntime
        with self.assertRaises(ValueError):PhysicalQuantumRuntime().submit("missing",self.request())
    def test_quantum_v1_readiness(self):
        from journeyman.core.quantum_runtime import quantum_v1_release_readiness
        q=quantum_v1_release_readiness();self.assertTrue(q["passed"],q["failures"])
    def test_quantum_module_v1(self):
        from journeyman.modules.quantum_runtime import QUANTUM_MODULE
        self.assertEqual(QUANTUM_MODULE.version,"1.0.0")


class RTS001ATests(unittest.TestCase):
    def test_operator_state_transition(self):
        import time
        from journeyman.core.rt_control import DeterministicControlKernel,AuthorityPrincipal,AuthorityLevel,TransitionRequest,ControlState,Interlock,InterlockState,rt_guardian_contract,rt_core_readiness
        k=DeterministicControlKernel();p=AuthorityPrincipal("op",AuthorityLevel.OPERATOR,"SIMULATION:test")
        self.assertTrue(k.request_transition(TransitionRequest("r",p,ControlState.SAFE,"test",time.time(),p.provenance)).allowed)
    def test_guardian_cannot_command(self):
        import time
        from journeyman.core.rt_control import DeterministicControlKernel,AuthorityPrincipal,AuthorityLevel,TransitionRequest,ControlState
        k=DeterministicControlKernel();op=AuthorityPrincipal("op",AuthorityLevel.OPERATOR,"test");k.request_transition(TransitionRequest("1",op,ControlState.SAFE,"x",time.time(),"test"))
        g=AuthorityPrincipal("g",AuthorityLevel.GUARDIAN,"test");self.assertFalse(k.request_transition(TransitionRequest("2",g,ControlState.READY,"x",time.time(),"test")).allowed)
    def test_unknown_interlock_blocks_ready(self):
        import time
        from journeyman.core.rt_control import DeterministicControlKernel,AuthorityPrincipal,AuthorityLevel,TransitionRequest,ControlState,Interlock,InterlockState
        k=DeterministicControlKernel();op=AuthorityPrincipal("op",AuthorityLevel.OPERATOR,"test");k.request_transition(TransitionRequest("1",op,ControlState.SAFE,"x",time.time(),"test"))
        k.set_interlock(Interlock("i",InterlockState.UNKNOWN,"sensor","no data",time.time(),"SOFTWARE:test"))
        self.assertFalse(k.request_transition(TransitionRequest("2",op,ControlState.READY,"x",time.time(),"test")).allowed)
    def test_bus_safe_trip_forces_abort(self):
        from journeyman.core.rt_control import DeterministicControlKernel,ControlState
        k=DeterministicControlKernel();k.bus_safe_trip("test","SIMULATION:test");self.assertEqual(k.state,ControlState.ABORT_TRIP)
    def test_operator_cannot_reset_trip(self):
        from journeyman.core.rt_control import DeterministicControlKernel,AuthorityPrincipal,AuthorityLevel
        k=DeterministicControlKernel();k.bus_safe_trip("test","SIMULATION:test")
        self.assertFalse(k.reset_trip(AuthorityPrincipal("op",AuthorityLevel.OPERATOR,"test")).allowed)
    def test_guardian_contract_authority(self):
        from journeyman.core.rt_control import DeterministicControlKernel,rt_guardian_contract
        g=rt_guardian_contract(DeterministicControlKernel());self.assertFalse(g.facts["guardian_can_command"]);self.assertTrue(g.facts["bus_safe_final_authority"])
    def test_rt_readiness(self):
        from journeyman.core.rt_control import rt_core_readiness
        self.assertTrue(rt_core_readiness()["passed"])
    def test_rt_workspace_no_actuator_controls(self):
        w=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("NOT PHYSICAL HARDWARE CONTROL",w);self.assertIn("class RTControlWorkspace(QWidget):",w)
    def test_rt_module_v01(self):
        from journeyman.modules.rt_control import RT_MODULE
        self.assertEqual(RT_MODULE.version,"1.0.0")


class RTS001BTests(unittest.TestCase):
    def test_timing_hierarchy(self):
        from journeyman.core.rt_control import TimingBudget,TimingDomain,validate_timing_hierarchy
        self.assertFalse(validate_timing_hierarchy(TimingBudget(TimingDomain.SAFETY,.001,.001,"x"),TimingBudget(TimingDomain.CONTROL,.01,.01,"x"),TimingBudget(TimingDomain.RESEARCH,1,1,"x")))
    def test_stale_telemetry_fails(self):
        from journeyman.core.rt_control import TelemetryIntegrityMonitor,TelemetryEnvelope,FreshnessState
        m=TelemetryIntegrityMonitor(1);q=m.inspect(TelemetryEnvelope("s",1,1,3,True,"x"),3);self.assertEqual(q.freshness,FreshnessState.STALE)
    def test_replayed_sequence_fails(self):
        from journeyman.core.rt_control import TelemetryIntegrityMonitor,TelemetryEnvelope
        m=TelemetryIntegrityMonitor(10);m.inspect(TelemetryEnvelope("s",2,5,5,True,"x"),5);q=m.inspect(TelemetryEnvelope("s",2,5,5,True,"x"),5);self.assertFalse(q.sequence_valid)
    def test_missing_heartbeat_unhealthy(self):
        from journeyman.core.rt_control import HeartbeatWatchdog
        self.assertFalse(HeartbeatWatchdog(1).status("missing",0).healthy)
    def test_denied_permissive_holds(self):
        from journeyman.core.rt_control import DeterministicControlKernel,RTSupervisor,AuthorityPrincipal,AuthorityLevel,Permissive,Heartbeat,TelemetryEnvelope,CommandEnvelope,CommandDisposition
        k=DeterministicControlKernel();s=RTSupervisor(k,1,1);now=10
        s.watchdog.observe(Heartbeat("c",1,now,"x"));s.set_permissive(Permissive("p",False,"x","blocked",now,"x"))
        q=s.evaluate_command(CommandEnvelope("cmd",AuthorityPrincipal("rt",AuthorityLevel.RT_CONTROL,"x"),"SET","x",now,now+1,"x"),TelemetryEnvelope("s",1,now,now,True,"x"),"c",now)
        self.assertEqual(q.disposition,CommandDisposition.HOLD)
    def test_guardian_command_holds(self):
        from journeyman.core.rt_control import DeterministicControlKernel,RTSupervisor,AuthorityPrincipal,AuthorityLevel,Heartbeat,TelemetryEnvelope,CommandEnvelope,CommandDisposition
        s=RTSupervisor(DeterministicControlKernel(),1,1);now=10;s.watchdog.observe(Heartbeat("c",1,now,"x"))
        q=s.evaluate_command(CommandEnvelope("cmd",AuthorityPrincipal("g",AuthorityLevel.GUARDIAN,"x"),"SET","x",now,now+1,"x"),TelemetryEnvelope("s",1,now,now,True,"x"),"c",now)
        self.assertEqual(q.disposition,CommandDisposition.HOLD)
    def test_supervision_readiness(self):
        from journeyman.core.rt_control import rt_supervision_readiness
        q=rt_supervision_readiness();self.assertTrue(q["passed"])
    def test_rt_module_v02(self):
        from journeyman.modules.rt_control import RT_MODULE
        self.assertEqual(RT_MODULE.version,"1.0.0")


class RTS001CTests(unittest.TestCase):
    def test_replay_cannot_bind_live(self):
        import time
        from journeyman.core.rt_control import AuthorityPrincipal,AuthorityLevel,ActuatorCapability,HardwareSourceQualification,SourceClass,ActuatorCommand,QualificationMode,validate_actuator_command
        now=time.time();p=AuthorityPrincipal("rt",AuthorityLevel.RT_CONTROL,"x");cap=ActuatorCapability("a",0,10,"V",True,"x")
        src=HardwareSourceQualification("r",SourceClass.REPLAY,True,True,False,"REPLAY:x")
        c=ActuatorCommand("c","a",1,"V",now,now+1,p,SourceClass.REPLAY,QualificationMode.LIVE,"REPLAY:x")
        self.assertFalse(validate_actuator_command(c,cap,src,now).accepted)
    def test_live_hardware_must_be_authenticated(self):
        from journeyman.core.rt_control import HardwareSourceQualification,SourceClass
        with self.assertRaises(ValueError):HardwareSourceQualification("h",SourceClass.HARDWARE,False,True,True,"HARDWARE:x")
    def test_unbound_bus_safe_fails_closed(self):
        from journeyman.core.rt_control import BusSafeInterfaceStatus,bus_safe_interface_permissive
        ok,reasons=bus_safe_interface_permissive(BusSafeInterfaceStatus(False,None,False,False,False,False,"SOFTWARE:x"))
        self.assertFalse(ok);self.assertTrue(reasons)
    def test_trip_is_latched(self):
        from journeyman.core.rt_control import DeterministicControlKernel,LatchedTripController,ControlState
        k=DeterministicControlKernel();t=LatchedTripController(k);t.trip("x","SIMULATION:x")
        self.assertTrue(t.latched);self.assertEqual(k.state,ControlState.ABORT_TRIP);self.assertEqual(t.audit[0].event,"TRIP")
    def test_operator_cannot_reset_latched_trip(self):
        from journeyman.core.rt_control import DeterministicControlKernel,LatchedTripController,AuthorityPrincipal,AuthorityLevel
        t=LatchedTripController(DeterministicControlKernel());t.trip("x","SIMULATION:x")
        self.assertFalse(t.reset(AuthorityPrincipal("op",AuthorityLevel.OPERATOR,"x"))[0])
    def test_hardware_boundary_readiness(self):
        from journeyman.core.rt_control import rt_hardware_boundary_readiness
        q=rt_hardware_boundary_readiness();self.assertTrue(q["passed"],q["failures"])
    def test_workspace_boundary_qualification(self):
        self.assertIn("Qualify SIL/HIL & BUS-SAFE Boundary",(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text())
    def test_rt_module_v03(self):
        from journeyman.modules.rt_control import RT_MODULE
        self.assertEqual(RT_MODULE.version,"1.0.0")


class RTS001DTests(unittest.TestCase):
    def test_audit_chain_verifies(self):
        from journeyman.core.rt_control import RTAuditChain,FaultSeverity
        a=RTAuditChain();a.append("TEST","unit",FaultSeverity.INFO,"x","SOFTWARE:test",1);a.append("TEST","unit",FaultSeverity.WARNING,"y","SOFTWARE:test",2);self.assertTrue(a.verify())
    def test_fault_trip_latches(self):
        import time
        from journeyman.core.rt_control import DeterministicControlKernel,LatchedTripController,RTAuditChain,FaultEscalator,FaultEvent,FaultSeverity,ControlState
        k=DeterministicControlKernel();t=LatchedTripController(k);a=RTAuditChain();FaultEscalator(k,t,a).apply(FaultEvent("f","test",FaultSeverity.TRIP,"x",time.time(),"SIMULATION:test"))
        self.assertTrue(t.latched);self.assertEqual(k.state,ControlState.ABORT_TRIP);self.assertTrue(a.verify())
    def test_ack_immutable(self):
        from journeyman.core.rt_control import CommandAcknowledgementRegistry,CommandAcknowledgement,AcknowledgementState
        r=CommandAcknowledgementRegistry();a=CommandAcknowledgement("c",AcknowledgementState.ACKNOWLEDGED,"x",1,"ok","SIMULATION:test");r.record(a)
        with self.assertRaises(ValueError):r.record(a)
    def test_sil_acknowledges_bounded_command(self):
        import time
        from journeyman.core.rt_control import SILQualificationAdapter,ActuatorCommand,AuthorityPrincipal,AuthorityLevel,SourceClass,QualificationMode,AcknowledgementState
        a=SILQualificationAdapter();now=time.time();p=AuthorityPrincipal("rt",AuthorityLevel.RT_CONTROL,"SIMULATION:test")
        q=ActuatorCommand("c","sil.channel",1,"V",now,now+1,p,SourceClass.SIMULATION,QualificationMode.SIL,"SIMULATION:test")
        self.assertEqual(a.write(q).state,AcknowledgementState.ACKNOWLEDGED)
    def test_sil_bus_safe_fails_closed(self):
        from journeyman.core.rt_control import SILQualificationAdapter,bus_safe_interface_permissive
        self.assertFalse(bus_safe_interface_permissive(SILQualificationAdapter().read_bus_safe_status())[0])
    def test_guardian_fault_never_executes(self):
        import time
        from journeyman.core.rt_control import FaultEvent,FaultSeverity,guardian_fault_recommendation
        g=guardian_fault_recommendation(FaultEvent("f","x",FaultSeverity.TRIP,"x",time.time(),"x"));self.assertFalse(g["may_execute"]);self.assertEqual(g["authority"],"READ_ONLY_ADVISORY")
    def test_rt_v1_readiness(self):
        from journeyman.core.rt_control import rt_v1_release_readiness
        q=rt_v1_release_readiness();self.assertTrue(q["passed"],q["failures"])
    def test_rt_module_v1(self):
        from journeyman.modules.rt_control import RT_MODULE
        self.assertEqual(RT_MODULE.version,"1.0.0")


class QUAL001ATests(unittest.TestCase):
    def test_report_hash_is_sha256(self):
        from journeyman.core.integrated_qualification import QualificationCheck,QualificationStatus,_report_hash
        c=(QualificationCheck("x","test",QualificationStatus.PASS,"ok",("e",),"SOFTWARE:test"),)
        self.assertEqual(len(_report_hash("b",1,c)),64)
    def test_guardian_qualification_advisory(self):
        from journeyman.core.integrated_qualification import IntegratedQualificationReport,guardian_qualification_contract
        r=IntegratedQualificationReport("JOE-INTEGRATED-QUALIFICATION/1",1,"b",(),True,"0"*64,"SOFTWARE:test")
        g=guardian_qualification_contract(r);self.assertFalse(g["may_override"]);self.assertEqual(g["authority"],"READ_ONLY_ADVISORY")
    def test_expected_service_inventory_contains_safety_and_science(self):
        from journeyman.core.integrated_qualification import EXPECTED_SERVICES
        self.assertIn("joe.rt-control",EXPECTED_SERVICES);self.assertIn("joe.mpr",EXPECTED_SERVICES);self.assertIn("joe.quantum-runtime",EXPECTED_SERVICES)
    def test_guardian_schema_inventory(self):
        from journeyman.core.integrated_qualification import GUARDIAN_SCHEMAS
        self.assertIn("JOE-GUARDIAN-RT-CONTROL/1",GUARDIAN_SCHEMAS);self.assertIn("JOE-GUARDIAN-MPR/1",GUARDIAN_SCHEMAS)
    def test_qualification_module_version(self):
        from journeyman.modules.integrated_qualification import QUAL_MODULE
        self.assertEqual(QUAL_MODULE.version,"1.0.0")
    def test_workspace_present(self):
        text=(Path(__file__).parents[1]/"journeyman"/"ui"/"workspaces.py").read_text()
        self.assertIn("class IntegratedQualificationWorkspace(QWidget):",text)

class QUAL001BTests(unittest.TestCase):
    def test_reference_workflow_passes(self):
        from journeyman.core.integrated_qualification import qualification_reference_workflow,qualify_scientific_workflow
        self.assertTrue(qualify_scientific_workflow(qualification_reference_workflow()).passed)
    def test_missing_stage_fails(self):
        from journeyman.core.integrated_qualification import qualification_reference_workflow,qualify_scientific_workflow
        self.assertFalse(qualify_scientific_workflow(qualification_reference_workflow()[:-1]).passed)
    def test_contamination_detector(self):
        from journeyman.core.integrated_qualification import ScientificWorkflowRecord,WorkflowOrigin,qualify_scientific_workflow
        a=ScientificWorkflowRecord("a","DIGITAL_TWIN","o",WorkflowOrigin.SIMULATION,None,None,None,(),"SIMULATION:test","SIMULATION_RESULT")
        b=ScientificWorkflowRecord("b","METROLOGY","o",WorkflowOrigin.HARDWARE,1,"1",.1,("a",),"HARDWARE:test","DEMONSTRATED_TECHNOLOGY")
        self.assertTrue(any(x.check_id=="WF-ORIGIN" and x.status.value=="FAIL" for x in qualify_scientific_workflow((a,b)).checks))
    def test_uncertainty_required(self):
        from journeyman.core.integrated_qualification import ScientificWorkflowRecord,WorkflowOrigin,qualify_scientific_workflow
        r=ScientificWorkflowRecord("r","PHYSICS","o",WorkflowOrigin.SOFTWARE,1,"m",None,(),"SOFTWARE:test","ESTABLISHED_PHYSICS")
        self.assertTrue(any(x.check_id=="WF-UNCERTAINTY" and x.status.value=="FAIL" for x in qualify_scientific_workflow((r,)).checks))
    def test_workflow_readiness(self):
        from journeyman.core.integrated_qualification import workflow_release_readiness
        self.assertTrue(workflow_release_readiness()["passed"])
    def test_qual_v02(self):
        from journeyman.modules.integrated_qualification import QUAL_MODULE
        self.assertEqual(QUAL_MODULE.version,"1.0.0")

class QUAL001CTests(unittest.TestCase):
    def test_fixture(self):
        from journeyman.core.integrated_qualification import qualification_artifact_fixture,qualify_artifact_traceability
        self.assertTrue(qualify_artifact_traceability(qualification_artifact_fixture()).passed)
    def test_broken_lineage(self):
        import hashlib
        from journeyman.core.integrated_qualification import ArtifactTrace,WorkflowOrigin,qualify_artifact_traceability
        h=hashlib.sha256(b"x").hexdigest();a=ArtifactTrace("a","REPORT",h,("missing",),h,h,WorkflowOrigin.SIMULATION,"SIMULATION:test")
        self.assertFalse(qualify_artifact_traceability((a,)).passed)
    def test_replay_live_rejected(self):
        import hashlib
        from journeyman.core.integrated_qualification import ReplayEnvelope,WorkflowOrigin,qualify_replay_isolation
        r=ReplayEnvelope("r",hashlib.sha256(b"x").hexdigest(),WorkflowOrigin.SIMULATION,"LIVE",True,"REPLAY:test")
        self.assertEqual(qualify_replay_isolation(r).status.value,"FAIL")
    def test_persistence_readiness(self):
        from journeyman.core.integrated_qualification import persistence_release_readiness
        self.assertTrue(persistence_release_readiness()["passed"])
    def test_qual_v03(self):
        from journeyman.modules.integrated_qualification import QUAL_MODULE
        self.assertEqual(QUAL_MODULE.version,"1.0.0")

class QUAL001DTests(unittest.TestCase):
    def test_release_manifest_hash(self):
        from journeyman.core.integrated_qualification import build_release_manifest
        m=build_release_manifest();self.assertEqual(m.release_version,"1.5.4");self.assertEqual(len(m.manifest_sha256),64)
    def test_release_inventory_contains_all_major_components(self):
        from journeyman.core.integrated_qualification import joe_release_components
        ids={x.component_id for x in joe_release_components()}
        for x in ("joe.mpr","joe.geometry","joe.guardian","joe.quantum-runtime","joe.rt-control","joe.integrated-qualification"):self.assertIn(x,ids)
    def test_release_limitations_disclose_physics(self):
        from journeyman.core.integrated_qualification import JOE_RELEASE_LIMITATIONS
        text=" ".join(JOE_RELEASE_LIMITATIONS).lower();self.assertIn("not qualification of physical time travel",text);self.assertIn("no physical traversable wormhole",text)
    def test_truth_boundary_passes(self):
        from journeyman.core.integrated_qualification import scientific_truth_boundary_check
        self.assertEqual(scientific_truth_boundary_check().status.value,"PASS")
    def test_regression_gate_passes(self):
        from journeyman.core.integrated_qualification import deterministic_regression_gate
        self.assertEqual(deterministic_regression_gate().status.value,"PASS")
    def test_final_guardian_contract_read_only(self):
        from journeyman.core.integrated_qualification import FinalReleaseQualification,ReleaseManifest,guardian_final_release_contract
        m=ReleaseManifest("s","p","1.5.0","b",1,(),(),"0"*64,"SOFTWARE:test")
        r=FinalReleaseQualification("s","1.5.0","b",True,(),m,"1"*64,"SOFTWARE:test")
        g=guardian_final_release_contract(r);self.assertFalse(g["may_override"]);self.assertEqual(g["authority"],"READ_ONLY_ADVISORY")
    def test_qual_module_v1(self):
        from journeyman.modules.integrated_qualification import QUAL_MODULE
        self.assertEqual(QUAL_MODULE.version,"1.0.0")
    def test_product_version_v15(self):
        import journeyman
        self.assertEqual(journeyman.__version__,"1.6.1");self.assertEqual(journeyman.__build__,"JOE-SCIINTEL-006B-FINAL")


class DATAEXT001ATests(unittest.TestCase):
    def _lib(self):
        from journeyman.core.scientific_reference import ScientificReferenceLibrary
        return ScientificReferenceLibrary(Path(__file__).parents[1]/"data"/"reference")
    def test_reference_library_readiness(self):
        q=self._lib().readiness();self.assertTrue(q["passed"],q["failures"]);self.assertGreaterEqual(q["documents"],14)
    def test_algorithm_registry_lookup(self):
        a=self._lib().algorithm("REL.SR.GAMMA");self.assertIsNotNone(a);self.assertEqual(a["epistemic_class"],"ESTABLISHED_PHYSICS")
    def test_guardian_reference_contract_read_only(self):
        g=self._lib().guardian_contract();self.assertEqual(g["authority"],"READ_ONLY");self.assertEqual(g["schema"],"JOE-GUARDIAN-SCIENTIFIC-REFERENCE/1")
    def test_speculative_wormhole_classification(self):
        d=self._lib().index()["joe.wormhole.geometry"];self.assertEqual(d.data["epistemic_class"],"SPECULATIVE_UNRESOLVED_PHYSICS")
    def test_reference_hashes_are_sha256(self):
        self.assertTrue(all(len(x.sha256)==64 for x in self._lib().load_all()))
    def test_reference_module_v1(self):
        from journeyman.modules.scientific_reference import REF_MODULE
        self.assertEqual(REF_MODULE.version,"1.0.0")


class DATAEXT001BTests(unittest.TestCase):
    def _lib(self):
        from journeyman.core.scientific_reference import ScientificReferenceLibrary
        return ScientificReferenceLibrary(Path(__file__).parents[1]/"data"/"reference")
    def test_extended_reference_readiness(self):
        q=self._lib().readiness();self.assertTrue(q["passed"],q["failures"]);self.assertGreaterEqual(q["documents"],23)
    def test_guardian_rulesets_load(self):
        d=self._lib().ruleset("joe.guardian.scientific-rules");self.assertIsNotNone(d);self.assertEqual(d.schema,"JOE-GUARDIAN-RULESET/1")
    def test_guardian_flags_speculative_claim(self):
        from journeyman.core.guardian_reference import GuardianScientificReferenceEvaluator
        e=GuardianScientificReferenceEvaluator(self._lib())
        f=e.evaluate_result({"epistemic_class":"SPECULATIVE_UNRESOLVED_PHYSICS","claimed_demonstrated":True})
        self.assertTrue(any(x.finding_id=="GSR-001" and x.severity=="CRITICAL" for x in f))
    def test_guardian_blocks_simulation_hardware_promotion(self):
        from journeyman.core.guardian_reference import GuardianScientificReferenceEvaluator
        e=GuardianScientificReferenceEvaluator(self._lib())
        f=e.evaluate_result({"origin":"SIMULATION","target_origin":"HARDWARE"})
        self.assertTrue(any(x.finding_id=="GSR-002" for x in f))
    def test_model_disagreement_sigma(self):
        from journeyman.core.guardian_reference import GuardianScientificReferenceEvaluator
        e=GuardianScientificReferenceEvaluator(self._lib());f=e.compare_models(10,0,1,1)
        self.assertEqual(f.severity,"CRITICAL");self.assertIn("sigma",f.conclusion)
    def test_model_disagreement_context_guard(self):
        from journeyman.core.guardian_reference import GuardianScientificReferenceEvaluator
        e=GuardianScientificReferenceEvaluator(self._lib());f=e.compare_models(1,1,1,1,{"compatible_units":False})
        self.assertEqual(f.finding_id,"MDR-CONTEXT")
    def test_parameter_beta_domain(self):
        from journeyman.core.guardian_reference import GuardianScientificReferenceEvaluator
        e=GuardianScientificReferenceEvaluator(self._lib());self.assertEqual(e.parameter_check("beta",1.0).severity,"WARNING")
    def test_guardian_evaluator_contract(self):
        from journeyman.core.guardian_reference import GuardianScientificReferenceEvaluator
        g=GuardianScientificReferenceEvaluator(self._lib()).contract()
        self.assertFalse(g["may_command"]);self.assertFalse(g["may_override"]);self.assertEqual(g["authority"],"READ_ONLY_ADVISORY")
    def test_guardian_reference_module_v1(self):
        from journeyman.modules.guardian_reference import MODULE
        self.assertEqual(MODULE.version,"1.0.0")
    def test_product_version_151(self):
        import journeyman
        self.assertEqual(journeyman.__version__,"1.6.1");self.assertEqual(journeyman.__build__,"JOE-SCIINTEL-006B-FINAL")

# JOE-PHYSICS-EXT-002A advanced physics qualification
def test_advanced_physics_patch_002a():
    import math
    import numpy as np
    from pathlib import Path
    from journeyman.core.advanced_physics import (curvature_invariants,electromagnetic_stress_energy,
        einstein_source_from_stress_energy,ideal_parallel_plate_casimir_reference,
        single_mode_squeezed_state_reference,verify_minkowski_curvature,verify_morris_thorne_phi0,
        advanced_physics_guardian_contract,advanced_physics_release_readiness)
    from journeyman.core.geometry import minkowski_metric
    inv=curvature_invariants(minkowski_metric(),(0,0,0,0))
    assert abs(inv.ricci_scalar)<1e-8 and abs(inv.kretschmann_scalar)<1e-8
    em=electromagnetic_stress_energy((1.0,0,0),(0,1/299792458.0,0))
    assert em.energy_density_j_m3>0 and em.poynting_w_m2[2]>0
    src=einstein_source_from_stress_energy(em.contravariant_tensor_si)
    assert src.solver_status=="PASS" and src.coupling_per_j_m3>0
    cas=ideal_parallel_plate_casimir_reference(1e-6)
    assert cas.energy_density_j_m3<0 and cas.normal_pressure_pa<0
    sq=single_mode_squeezed_state_reference(1.0)
    assert sq.quadrature_variance_min<0.5<sq.quadrature_variance_max
    assert verify_minkowski_curvature().passed
    assert verify_morris_thorne_phi0().passed
    g=advanced_physics_guardian_contract()
    assert g.authority=="READ_ONLY_ADVISORY"
    assert advanced_physics_release_readiness()["passed"]
    from journeyman.core.scientific_reference import ScientificReferenceLibrary
    lib=ScientificReferenceLibrary(Path(__file__).resolve().parents[1]/"data"/"reference")
    assert lib.readiness()["passed"] and len(lib.load_all())>=29

# JOE-PHYSICS-EXT-002B qualification tests
def test_method_b_closed_loop_resonator_extension():
    from journeyman.core.ring_laser import ResonatorRequest,closed_loop_resonator,C
    r=closed_loop_resonator(ResonatorRequest(10,1,1,1e-6,1e6,.01,"test"))
    assert abs(r.round_trip_time_s-10/C)<1e-20
    assert r.quality_factor>0 and r.stored_energy_j>0

def test_method_b_em_gravity_bridge_truth_boundary():
    from journeyman.core.ring_laser import method_b_em_gravity_bridge
    r=method_b_em_gravity_bridge(1e6,1e-6,provenance="test")
    assert r.einstein_source_scale_m2_inv>0
    assert "not a nonlinear Einstein-Maxwell" in r.message

def test_ctc_fixed_point_hypothesis_solver():
    from journeyman.core.chronology import ctc_fixed_point_relaxation,CTCConsistencyStatus
    r=ctc_fixed_point_relaxation(lambda x:(.5*x[0]+1,),(0,),damping=1,tolerance=1e-9,max_iterations=100)
    assert r.status==CTCConsistencyStatus.SELF_CONSISTENT_FIXED_POINT
    assert abs(r.state[0]-2)<1e-7

def test_ctc_nonconvergence_is_not_hidden():
    from journeyman.core.chronology import ctc_fixed_point_relaxation,CTCConsistencyStatus
    r=ctc_fixed_point_relaxation(lambda x:(x[0]+1,),(0,),max_iterations=5)
    assert r.status==CTCConsistencyStatus.NONCONVERGED

def test_ctc_dephasing_diagnostics():
    from journeyman.core.chronology import density_matrix_diagnostics,dephasing_channel_2x2
    p=density_matrix_diagnostics(((.5,.5),(.5,.5)))
    m=density_matrix_diagnostics(dephasing_channel_2x2(((.5,.5),(.5,.5)),0))
    assert abs(p.purity-1)<1e-10 and abs(m.purity-.5)<1e-10 and m.von_neumann_entropy_nats>p.von_neumann_entropy_nats

def test_method_b_ctc_extension_readiness():
    from journeyman.core.ring_laser import method_b_advanced_release_readiness
    from journeyman.core.chronology import ctc_consistency_release_readiness
    assert method_b_advanced_release_readiness()["passed"]
    assert ctc_consistency_release_readiness()["passed"]

# JOE-PHYSICS-SAFE-003A deterministic scientific envelope protection
def test_physics_safety_model_lockouts():
    from journeyman.core.physics_safety import DeterministicPhysicsEnvelopeMonitor,PhysicsSafetySample,PhysicsSafetyDisposition
    m=DeterministicPhysicsEnvelopeMonitor()
    for status in ("DOMAIN_INVALID","MODEL_UNAVAILABLE","UNKNOWN_PHYSICS","NONCONVERGED","PRECISION_INSUFFICIENT"):
        r=m.assess((PhysicsSafetySample("q",1,"1",status),))
        assert r.disposition==PhysicsSafetyDisposition.HOLD and not r.may_progress
    assert m.assess((PhysicsSafetySample("q",1,"1","NUMERICAL_INSTABILITY"),)).disposition==PhysicsSafetyDisposition.ABORT

def test_physics_safety_uncertainty_crosses_hold_ceiling():
    from journeyman.core.physics_safety import DeterministicPhysicsEnvelopeMonitor,SafetyCeiling,PhysicsSafetySample,PhysicsSafetyDisposition
    m=DeterministicPhysicsEnvelopeMonitor((SafetyCeiling("margin",.7,.9,1.2,None,True,"1"),))
    r=m.assess((PhysicsSafetySample("margin",.85,"1",uncertainty=.1),))
    assert r.disposition==PhysicsSafetyDisposition.HOLD

def test_physics_safety_residual_divergence():
    from journeyman.core.physics_safety import assess_residual_history,PhysicsSafetyDisposition
    r=assess_residual_history((.1,.2,.3,.5),.2)
    assert r.disposition==PhysicsSafetyDisposition.ABORT and r.first_difference>0

def test_physics_safety_guardian_truth_boundary():
    from journeyman.core.physics_safety import DeterministicPhysicsEnvelopeMonitor,guardian_physics_safety_contract
    a=DeterministicPhysicsEnvelopeMonitor().assess(())
    g=guardian_physics_safety_contract(a)
    assert g["authority"]=="READ_ONLY_ADVISORY" and not g["may_command"] and "not detections" in g["truth_boundary"]

def test_physics_safety_release_readiness():
    from journeyman.core.physics_safety import physics_safety_release_readiness
    assert physics_safety_release_readiness()["passed"]

def test_physics_safety_integrated_qualification_source_gate():
    from pathlib import Path
    text=(Path(__file__).resolve().parents[1]/"journeyman"/"core"/"integrated_qualification.py").read_text()
    assert "QUAL-PHYSICS-SAFETY" in text and "physics_safety_release_readiness" in text

def test_rt_service_exposes_physics_envelope():
    from journeyman.modules.rt_control import RTControlService
    s=RTControlService()
    assert s.physics_safety_readiness()["passed"]
    assert s.physics_envelope is not None

# JOE-PHYSICS-SAFE-003C predictive physics horizon protection
def test_predictive_horizon_stale_model_holds():
    from journeyman.core.predictive_horizon import HorizonPolicy,PredictivePhysicsHorizonSupervisor,ProjectedPoint
    from journeyman.core.physics_safety import PhysicsSafetyDisposition
    s=PredictivePhysicsHorizonSupervisor(HorizonPolicy(1,.1,.1,.02,.03,.2))
    a=s.assess(((ProjectedPoint(0,.1,0),),),1,.21)
    assert a.disposition==PhysicsSafetyDisposition.HOLD and not a.may_progress

def test_predictive_horizon_uncertainty_boundary():
    from journeyman.core.predictive_horizon import HorizonPolicy,PredictivePhysicsHorizonSupervisor,ProjectedPoint
    from journeyman.core.physics_safety import PhysicsSafetyDisposition
    s=PredictivePhysicsHorizonSupervisor(HorizonPolicy(1,.1,.1,.02,.03,.2))
    a=s.assess(((ProjectedPoint(0,.8,.2),),),1,0)
    assert a.disposition==PhysicsSafetyDisposition.ABORT

def test_predictive_horizon_lead_time_abort():
    from journeyman.core.predictive_horizon import HorizonPolicy,PredictivePhysicsHorizonSupervisor,ProjectedPoint
    from journeyman.core.physics_safety import PhysicsSafetyDisposition
    s=PredictivePhysicsHorizonSupervisor(HorizonPolicy(1,.05,.1,.02,.03,.2))
    a=s.assess(((ProjectedPoint(0,.2,0),ProjectedPoint(.05,1.1,0)),),1,0)
    assert a.disposition==PhysicsSafetyDisposition.ABORT and abs(a.required_lead_s-.15)<1e-12

def test_predictive_horizon_guardian_read_only():
    from journeyman.core.predictive_horizon import HorizonPolicy,PredictivePhysicsHorizonSupervisor,ProjectedPoint,guardian_predictive_horizon_contract
    s=PredictivePhysicsHorizonSupervisor(HorizonPolicy(1,.1,.1,.02,.03,.2))
    g=guardian_predictive_horizon_contract(s.assess(((ProjectedPoint(0,.1,0),),),1,0))
    assert g['authority']=='READ_ONLY_ADVISORY' and not g['may_command'] and 'not a probability' in g['truth_boundary']

def test_predictive_horizon_release_readiness():
    from journeyman.core.predictive_horizon import predictive_horizon_release_readiness
    assert predictive_horizon_release_readiness()['passed']

def test_predictive_horizon_rt_service():
    from journeyman.modules.rt_control import RTControlService
    assert RTControlService.predictive_horizon_readiness()['passed']

def test_predictive_horizon_integrated_gate_source():
    from pathlib import Path
    text=(Path(__file__).parents[1]/'journeyman/core/integrated_qualification.py').read_text()
    assert 'QUAL-PREDICTIVE-HORIZON' in text and '_check_predictive_horizon()' in text

def test_predictive_horizon_reference_dataset_present():
    from pathlib import Path
    assert (Path(__file__).parents[1]/'data/reference/predictive_horizon_policies.json').exists()

def test_predictive_horizon_ui_control_present():
    from pathlib import Path
    text=(Path(__file__).parents[1]/'journeyman/ui/workspaces.py').read_text()
    assert 'Qualify Predictive Horizon' in text and 'run_predictive_horizon_qualification' in text

# JOE-PHYSICS-SAFE-003C
def test_safe_state_reachability_and_authority():
    from journeyman.core.safe_state_recovery import safe_state_reachability,RecoveryPolicy,AdaptiveSafeStateSupervisor,RecoveryState,RecoveryDisposition,guardian_safe_state_contract
    assert safe_state_reachability(1,0,2,1).reachable
    assert not safe_state_reachability(10,0,1,1).reachable
    a=AdaptiveSafeStateSupervisor(RecoveryPolicy(-1,1)).assess(RecoveryState(.85,.1,0,0),0,2)
    assert a.disposition in (RecoveryDisposition.DERATE,RecoveryDisposition.CONTROLLED_RECOVERY)
    c=guardian_safe_state_contract(a);assert c["authority"]=="READ_ONLY_ADVISORY" and not c["may_command"]

def test_safe_state_model_invalid_vs_hardware_fault():
    from journeyman.core.safe_state_recovery import RecoveryPolicy,AdaptiveSafeStateSupervisor,RecoveryState,RecoveryDisposition
    s=AdaptiveSafeStateSupervisor(RecoveryPolicy(-1,1))
    assert s.assess(RecoveryState(0,0,0,0,False,False),0,2).disposition==RecoveryDisposition.HOLD
    assert s.assess(RecoveryState(0,0,0,0,True,True),0,2).disposition==RecoveryDisposition.TRIP

def test_safe_state_release_readiness():
    from journeyman.core.safe_state_recovery import safe_state_release_readiness
    assert safe_state_release_readiness()["passed"]

def test_joe_version_visible_identity():
    import journeyman
    assert journeyman.__version__=="1.6.1"
    assert journeyman.__build__=="JOE-SCIINTEL-006B-FINAL"

# JOE-PHYSICS-SAFE-003D final chronology/backreaction protection governor
def test_chronology_governor_model_disagreement_holds():
    from journeyman.core.chronology_protection_governor import ChronologyProtectionGovernor,ProtectionPolicy,ModelEstimate,GovernorDisposition
    g=ChronologyProtectionGovernor(ProtectionPolicy(max_model_age_s=1))
    a=ModelEstimate('A',0,.1,'1',10,'SIMULATION');b=ModelEstimate('B',1,.1,'1',10,'SIMULATION')
    assert g.assess((a,b),now_s=10).disposition==GovernorDisposition.HOLD

def test_chronology_governor_stale_model_holds():
    from journeyman.core.chronology_protection_governor import ChronologyProtectionGovernor,ProtectionPolicy,ModelEstimate,GovernorDisposition
    g=ChronologyProtectionGovernor(ProtectionPolicy(max_model_age_s=.1))
    assert g.assess((ModelEstimate('A',0,.1,'1',0,'SIMULATION'),),now_s=1).disposition==GovernorDisposition.HOLD

def test_chronology_governor_uncertainty_and_rate_abort():
    from journeyman.core.chronology_protection_governor import ChronologyProtectionGovernor,ProtectionPolicy,GovernorDisposition
    g=ChronologyProtectionGovernor(ProtectionPolicy(max_abs_rate=5,max_abs_acceleration=20))
    assert g.assess(now_s=0,envelope_scale=1,value=.9,uncertainty=.2).disposition==GovernorDisposition.ABORT
    assert g.assess(now_s=0,rate=6).disposition==GovernorDisposition.ABORT

def test_chronology_governor_external_trip_latches_disposition():
    from journeyman.core.chronology_protection_governor import ChronologyProtectionGovernor,GovernorDisposition
    assert ChronologyProtectionGovernor().assess(now_s=0,hardware_trip_asserted=True).disposition==GovernorDisposition.TRIP

def test_chronology_governor_guardian_truth_boundary():
    from journeyman.core.chronology_protection_governor import ChronologyProtectionGovernor,guardian_chronology_protection_contract
    c=guardian_chronology_protection_contract(ChronologyProtectionGovernor().assess(now_s=0))
    assert c['authority']=='READ_ONLY_ADVISORY' and not c['may_command'] and not c['physical_chronology_protection_detected']

def test_chronology_governor_fault_campaign_and_release():
    from journeyman.core.chronology_protection_governor import fault_injection_campaign,chronology_protection_release_readiness
    assert fault_injection_campaign()['passed'] and chronology_protection_release_readiness()['passed']

def test_chronology_governor_integrated_and_versioned():
    from pathlib import Path
    from journeyman import __version__,__build__
    root=Path(__file__).parents[1]
    text=(root/'journeyman/core/integrated_qualification.py').read_text()
    ui=(root/'journeyman/ui/workspaces.py').read_text()
    assert 'QUAL-CHRONOLOGY-PROTECTION' in text
    assert 'Qualify Chronology Protection Governor' in ui
    assert __version__=='1.6.1' and __build__=='JOE-SCIINTEL-006B-FINAL'

# JOE-FINAL-QUAL-004B
def test_004a_accelerated_reference_equivalence():
    import numpy as np
    from journeyman.core.performance_hil import reference_residuals,accelerated_residuals
    x=np.arange(40,dtype=float).reshape(10,4); y=.75*x
    assert np.allclose(reference_residuals(x,y),accelerated_residuals(x,y),rtol=1e-12,atol=1e-12)

def test_004a_pre_hil_faults_fail_closed():
    from journeyman.core.performance_hil import TelemetryFrame,HILFault,inject_fault,telemetry_integrity
    f=tuple(TelemetryFrame(i,i*.1,float(i),.01) for i in range(5))
    assert telemetry_integrity(inject_fault(f,HILFault.PACKET_REORDER),now_s=.4)['fail_closed']
    assert telemetry_integrity(inject_fault(f,HILFault.WATCHDOG_LOSS),now_s=.4)['fail_closed']
    assert telemetry_integrity(inject_fault(f,HILFault.INVALID_SAMPLE),now_s=.4)['fail_closed']

def test_004a_release_and_guardian_boundary():
    from journeyman.core.performance_hil import performance_hil_release_readiness,guardian_performance_hil_contract
    assert performance_hil_release_readiness()['passed']
    c=guardian_performance_hil_contract(); assert c['authority']=='READ_ONLY_ADVISORY' and not c['may_command']

def test_004a_rt_and_integrated_gate():
    from journeyman.modules.rt_control import RTControlService
    from pathlib import Path
    assert RTControlService.performance_hil_readiness()['passed']
    assert 'QUAL-PERFORMANCE-PRE-HIL' in (Path(__file__).parents[1]/'journeyman/core/integrated_qualification.py').read_text()

def test_004a_version_and_reference():
    import journeyman
    from pathlib import Path
    assert journeyman.__version__=='1.6.1' and journeyman.__build__=='JOE-SCIINTEL-006B-FINAL'
    assert (Path(__file__).parents[1]/'data/reference/pre_hil_fault_profiles.json').exists()

def test_004b_basin_of_attraction_payload():
    from journeyman.core.final_stress_qualification import basin_of_attraction_2d
    q=basin_of_attraction_2d(lambda x:(.5*x[0]+1,.5*x[1]-.5),resolution=5,damping=1)
    assert len(q.labels)==5 and len(q.labels[0])==5 and len(q.fixed_points)==1

def test_004b_residual_trajectory_converges():
    from journeyman.core.final_stress_qualification import residual_trajectory
    q=residual_trajectory(lambda x:(.5*x[0]+1,),(0,),damping=1,steps=20)
    assert q[-1][1] < q[0][1]

def test_004b_uncertainty_box_and_reachability():
    from journeyman.core.final_stress_qualification import uncertainty_box,safe_state_reachability_series
    assert len(uncertainty_box((1,2),(.1,.2),2))==2
    q=safe_state_reachability_series(((0,0),(2,0)),(-1,-1),(1,1)); assert q[0][2] and not q[1][2]

def test_004b_precision_sweep():
    from journeyman.core.final_stress_qualification import precision_sweep_fixed_point
    q=precision_sweep_fixed_point(); assert q[0][2]<2e-5 and q[1][2]<1e-10

def test_004b_pathological_campaign():
    from journeyman.core.final_stress_qualification import pathological_numerical_campaign
    assert pathological_numerical_campaign()['passed']

def test_004b_final_readiness_and_guardian_boundary():
    from journeyman.core.final_stress_qualification import final_stress_release_readiness,guardian_final_stress_contract
    assert final_stress_release_readiness()['passed']; g=guardian_final_stress_contract(); assert g['authority']=='READ_ONLY_ADVISORY' and not g['may_command']

def test_004b_services_expose_diagnostics():
    from journeyman.modules.advanced_visualization import AdvancedVisualizationService
    from journeyman.modules.rt_control import RTControlService
    assert AdvancedVisualizationService.basin_of_attraction_2d(lambda x:(.5*x[0],.5*x[1]),resolution=3).labels
    assert RTControlService.final_stress_readiness()['passed']

def test_004b_version_and_final_gate():
    import journeyman
    from pathlib import Path
    assert journeyman.__version__=='1.6.1' and journeyman.__build__=='JOE-SCIINTEL-006B-FINAL'
    assert 'QUAL-FINAL-STRESS-004B' in (Path(__file__).parents[1]/'journeyman/core/integrated_qualification.py').read_text()


# JOE-OPS-005A
def test_005a_auto_envelope_reserves_host_capacity():
    from types import SimpleNamespace
    from journeyman.core.resource_governor import derive_local_envelope
    s=SimpleNamespace(cpu_logical_count=12,memory_total_bytes=32*1024**3,gpu_available=False,temperature_available=False)
    e=derive_local_envelope(s); assert 1<=e.maximum_workers<12 and e.maximum_joe_memory_bytes<s.memory_total_bytes

def test_005a_pressure_fails_soft_before_host_exhaustion():
    from types import SimpleNamespace
    from journeyman.core.resource_governor import derive_local_envelope,assess_resources,ResourceDisposition
    base=dict(cpu_logical_count=8,cpu_percent=20,memory_total_bytes=16*1024**3,gpu_available=False,temperature_available=False,temperatures=(),gpus=(),timestamp=1)
    s=SimpleNamespace(**{**base,'memory_percent':95});e=derive_local_envelope(s)
    assert assess_resources(s,e).disposition==ResourceDisposition.PAUSE_JOBS

def test_005a_unavailable_temperature_not_fabricated():
    from types import SimpleNamespace
    from journeyman.core.resource_governor import derive_local_envelope,assess_resources
    s=SimpleNamespace(cpu_logical_count=8,cpu_percent=20,memory_total_bytes=16*1024**3,memory_percent=30,gpu_available=False,temperature_available=False,temperatures=(),gpus=(),timestamp=1)
    e=derive_local_envelope(s); assert not e.temperature_monitoring and assess_resources(s,e).disposition.value=='NORMAL'

def test_005a_guardian_read_only_and_readiness():
    from journeyman.core.resource_governor import resource_governor_readiness
    assert resource_governor_readiness()['passed']

def test_005a_integrated_gate_and_ui():
    from pathlib import Path
    root=Path(__file__).parents[1]
    assert 'QUAL-HOST-RESOURCE-GOVERNOR' in (root/'journeyman/core/integrated_qualification.py').read_text()
    ui=(root/'journeyman/ui/workspaces.py').read_text(); assert 'Assess Safe Local Resources' in ui and 'CONSERVATIVE' in ui

def test_005a_version_and_reference():
    import journeyman
    from pathlib import Path
    assert journeyman.__version__=='1.6.1' and journeyman.__build__=='JOE-SCIINTEL-006B-FINAL'
    assert (Path(__file__).parents[1]/'data/reference/host_resource_governor.json').exists()

# JOE-OPS-005B final operational auto-configuration qualification.
def test_ops_005b_autoconfig_local_full_science_profile():
    from types import SimpleNamespace
    from journeyman.core.resource_governor import derive_local_envelope
    from journeyman.core.operational_autoconfig import configure_startup
    s=SimpleNamespace(cpu_logical_count=12,memory_total_bytes=32*1024**3,gpu_available=False,temperature_available=False)
    e=derive_local_envelope(s)
    c=configure_startup(s,e,persist=False)
    assert c.operating_environment=="DEVELOPMENT / SIMULATION"
    assert c.maximum_workers>=1 and c.maximum_workers<12

def test_ops_005b_external_qpu_fail_closed():
    from journeyman.core.operational_autoconfig import external_compute_handshake,ExternalAdmission
    h=external_compute_handshake("HYBRID / PHYSICAL QPU",(),())
    assert not h.admitted and h.status==ExternalAdmission.REJECTED
    assert any("local compute remains unchanged" in x for x in h.reasons)

def test_ops_005b_external_hpc_discovery_not_authority():
    from journeyman.core.compute_backends import ComputeBackend,BackendKind,BackendStatus
    from journeyman.core.operational_autoconfig import external_compute_handshake
    b=ComputeBackend("hpc.test",BackendKind.HPC,BackendStatus.AVAILABLE,"Scheduler","test",None,None,("batch",),"SIMULATION: qualification")
    h=external_compute_handshake("HPC / CLUSTER",(b,),())
    assert not h.admitted
    assert any("no authenticated/qualified" in x for x in h.reasons)

def test_ops_005b_workload_admission_bounds():
    from types import SimpleNamespace
    from journeyman.core.resource_governor import derive_local_envelope,assess_resources
    from journeyman.core.operational_autoconfig import workload_admission
    s=SimpleNamespace(cpu_logical_count=8,cpu_percent=10,memory_total_bytes=16*1024**3,memory_percent=20,gpu_available=False,temperature_available=False,temperatures=(),gpus=(),timestamp=1.0)
    e=derive_local_envelope(s);a=assess_resources(s,e)
    assert workload_admission(a,1,1024,e)["admitted"]
    assert not workload_admission(a,e.maximum_workers+10,1024,e)["admitted"]

def test_ops_005b_guardian_read_only_and_readiness():
    from types import SimpleNamespace
    from journeyman.core.resource_governor import derive_local_envelope
    from journeyman.core.operational_autoconfig import configure_startup,guardian_operational_contract,operational_autoconfig_readiness
    s=SimpleNamespace(cpu_logical_count=8,memory_total_bytes=16*1024**3,gpu_available=False,temperature_available=False)
    c=configure_startup(s,derive_local_envelope(s),persist=False);g=guardian_operational_contract(c)
    assert g["authority"]=="READ_ONLY_ADVISORY" and not g["may_command"]
    assert operational_autoconfig_readiness()["passed"]

# JOE-SCIINTEL-006B-FINAL qualification

def test_scientific_intelligence_isolates_candidate_database(tmp_path):
    from journeyman.core.scientific_intelligence import ScientificIntelligenceService
    s=ScientificIntelligenceService(tmp_path)
    assert s.readiness()["passed"]
    assert s.status()["authoritative_db_changes"]==0

def test_scientific_intelligence_blocks_direct_promotion(tmp_path):
    from journeyman.core.scientific_intelligence import ScientificIntelligenceService
    import pytest
    s=ScientificIntelligenceService(tmp_path)
    with pytest.raises(PermissionError):s.promote("anything")

def test_scientific_intelligence_url_allowlist(tmp_path):
    from journeyman.core.scientific_intelligence import ScientificIntelligenceService,DEFAULT_SOURCES
    s=ScientificIntelligenceService(tmp_path);src=DEFAULT_SOURCES[0]
    assert s._allowed(src,src.base_url)
    assert not s._allowed(src,"https://example.com/anything")
    assert not s._allowed(src,"http://export.arxiv.org/api/query")

def test_scientific_intelligence_offline_local_operation(tmp_path,monkeypatch):
    from journeyman.core.scientific_intelligence import ScientificIntelligenceService
    s=ScientificIntelligenceService(tmp_path)
    monkeypatch.setattr(s,"network_available",lambda timeout=.25:False)
    st=s.status();assert st["network"]=="OFFLINE" and st["candidate_findings"]==0

def test_scientific_intelligence_guardian_contract(tmp_path):
    from journeyman.core.scientific_intelligence import ScientificIntelligenceService
    s=ScientificIntelligenceService(tmp_path);c=s.guardian_contract()
    assert c["authority"]=="READ_ONLY_ADVISORY"
    assert c["network_content_trust"]=="UNTRUSTED_CANDIDATE"
    assert "PROMOTED" in c["pipeline"]
