"""JOE 005A automatic local-workstation resource governor.

Controls JOE's own research/simulation workload admission. It does not alter
BIOS, clocks, voltages, fans, OS power policy, RT authority, or BUS-SAFE.
Unavailable sensors remain unavailable; no telemetry is synthesized.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from enum import Enum
import os

class ComputeProfile(str,Enum):
    AUTO="AUTO"
    CONSERVATIVE="CONSERVATIVE"
    PERFORMANCE="PERFORMANCE"

class ResourceDisposition(str,Enum):
    NORMAL="NORMAL"
    THROTTLE="THROTTLE"
    REDUCE_CONCURRENCY="REDUCE_CONCURRENCY"
    PAUSE_JOBS="PAUSE_JOBS"
    CANCEL_JOBS="CANCEL_JOBS"

@dataclass(frozen=True)
class HostResourcePolicy:
    reserve_logical_cpus:int=2
    max_auto_cpu_fraction:float=.75
    max_performance_cpu_fraction:float=.90
    max_memory_fraction:float=.70
    minimum_free_memory_bytes:int=2*1024**3
    memory_caution_percent:float=82.0
    memory_pause_percent:float=90.0
    cpu_caution_percent:float=92.0
    cpu_pause_percent:float=98.0
    gpu_caution_percent:float=94.0
    temperature_caution_c:float=85.0
    temperature_pause_c:float=92.0
    def __post_init__(self):
        if self.reserve_logical_cpus<1: raise ValueError("at least one logical CPU must remain reserved")
        for x in (self.max_auto_cpu_fraction,self.max_performance_cpu_fraction,self.max_memory_fraction):
            if not 0<x<=1: raise ValueError("resource fractions must be in (0,1]")

@dataclass(frozen=True)
class LocalComputeEnvelope:
    profile:ComputeProfile
    detected_logical_cpus:int
    maximum_workers:int
    detected_memory_bytes:int
    maximum_joe_memory_bytes:int
    gpu_detected:bool
    temperature_monitoring:bool
    provenance:str

@dataclass(frozen=True)
class ResourceAssessment:
    disposition:ResourceDisposition
    recommended_workers:int
    reasons:tuple[str,...]
    telemetry_timestamp:float
    provenance:str="HOST: JOE resource governor using measured host telemetry"


def derive_local_envelope(sample,profile:ComputeProfile=ComputeProfile.AUTO,policy:HostResourcePolicy|None=None)->LocalComputeEnvelope:
    p=policy or HostResourcePolicy(); logical=max(1,int(sample.cpu_logical_count or os.cpu_count() or 1))
    fraction={ComputeProfile.CONSERVATIVE:.50,ComputeProfile.AUTO:p.max_auto_cpu_fraction,ComputeProfile.PERFORMANCE:p.max_performance_cpu_fraction}[profile]
    # Always reserve CPU capacity for the OS/interactive safety and UI paths.
    workers=max(1,min(logical-p.reserve_logical_cpus,max(1,int(logical*fraction))))
    mem=max(256*1024**2,min(int(sample.memory_total_bytes*p.max_memory_fraction),max(256*1024**2,int(sample.memory_total_bytes-p.minimum_free_memory_bytes))))
    return LocalComputeEnvelope(profile,logical,workers,int(sample.memory_total_bytes),mem,bool(sample.gpu_available),bool(sample.temperature_available),
        "HOST: psutil/provider telemetry; policy-derived limits; DEVELOPMENT/SIMULATION")


def assess_resources(sample,envelope:LocalComputeEnvelope,policy:HostResourcePolicy|None=None)->ResourceAssessment:
    p=policy or HostResourcePolicy(); reasons=[]; d=ResourceDisposition.NORMAL; workers=envelope.maximum_workers
    def escalate(x):
        nonlocal d
        order=list(ResourceDisposition)
        if order.index(x)>order.index(d): d=x
    if sample.memory_percent>=p.memory_pause_percent:
        escalate(ResourceDisposition.PAUSE_JOBS); reasons.append("host memory pressure exceeds pause threshold")
    elif sample.memory_percent>=p.memory_caution_percent:
        escalate(ResourceDisposition.REDUCE_CONCURRENCY); reasons.append("host memory pressure exceeds caution threshold")
    if sample.cpu_percent>=p.cpu_pause_percent:
        escalate(ResourceDisposition.REDUCE_CONCURRENCY); reasons.append("host CPU utilization is saturated")
    elif sample.cpu_percent>=p.cpu_caution_percent:
        escalate(ResourceDisposition.THROTTLE); reasons.append("host CPU utilization exceeds caution threshold")
    temps=[x.celsius for x in sample.temperatures]
    gpu_temps=[x.temperature_celsius for x in sample.gpus if x.temperature_celsius is not None]
    all_temps=temps+gpu_temps
    if all_temps and max(all_temps)>=p.temperature_pause_c:
        escalate(ResourceDisposition.PAUSE_JOBS); reasons.append("available host temperature telemetry exceeds pause threshold")
    elif all_temps and max(all_temps)>=p.temperature_caution_c:
        escalate(ResourceDisposition.REDUCE_CONCURRENCY); reasons.append("available host temperature telemetry exceeds caution threshold")
    gpu_utils=[x.utilization_percent for x in sample.gpus if x.utilization_percent is not None]
    if gpu_utils and max(gpu_utils)>=p.gpu_caution_percent:
        escalate(ResourceDisposition.THROTTLE); reasons.append("GPU utilization exceeds caution threshold")
    if d in (ResourceDisposition.REDUCE_CONCURRENCY,ResourceDisposition.PAUSE_JOBS,ResourceDisposition.CANCEL_JOBS): workers=max(1,envelope.maximum_workers//2)
    if not reasons: reasons.append("measured host resources remain inside the selected JOE workload envelope")
    return ResourceAssessment(d,workers,tuple(reasons),sample.timestamp)


def guardian_resource_contract(sample,envelope,assessment):
    return {"schema":"JOE-GUARDIAN-RESOURCE-GOVERNOR/1","authority":"READ_ONLY_ADVISORY","may_command":False,
            "operating_environment":"DEVELOPMENT/SIMULATION","envelope":asdict(envelope),"assessment":asdict(assessment),
            "temperature_available":sample.temperature_available,"gpu_available":sample.gpu_available,
            "truth_boundary":"JOE governs its own research workloads only; unavailable sensors are not inferred; BUS-SAFE/RT authority is unchanged."}


def resource_governor_readiness():
    from types import SimpleNamespace
    s=SimpleNamespace(cpu_logical_count=8,cpu_percent=20,memory_total_bytes=16*1024**3,memory_percent=40,gpu_available=False,temperature_available=False,temperatures=(),gpus=(),timestamp=1.0)
    e=derive_local_envelope(s); a=assess_resources(s,e)
    hot=SimpleNamespace(**{**s.__dict__,"memory_percent":95,"timestamp":2.0})
    b=assess_resources(hot,e)
    passed=e.maximum_workers<8 and a.disposition==ResourceDisposition.NORMAL and b.disposition==ResourceDisposition.PAUSE_JOBS
    return {"passed":passed,"checks":("automatic local envelope","OS CPU reserve","bounded memory budget","measured-pressure derating","unavailable-sensor truth boundary","Guardian read-only contract"),
            "failures":() if passed else ("resource governor deterministic qualification failed",),
            "notes":("Full scientific modules remain available; profile changes compute aggressiveness only.","No BIOS/fan/voltage control is performed.")}
