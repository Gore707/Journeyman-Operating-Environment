"""JOE v1.5 integrated qualification — QUAL-001A cross-module foundation."""
from __future__ import annotations
from dataclasses import dataclass,asdict
from enum import Enum
from typing import Any
import hashlib,json,time

class QualificationStatus(str,Enum):
    PASS="PASS"
    FAIL="FAIL"
    WARNING="WARNING"
    NOT_APPLICABLE="NOT_APPLICABLE"

@dataclass(frozen=True)
class QualificationCheck:
    check_id:str
    category:str
    status:QualificationStatus
    message:str
    evidence:tuple[str,...]
    provenance:str
    def __post_init__(self):
        if not all((self.check_id.strip(),self.category.strip(),self.message.strip(),self.provenance.strip())):
            raise ValueError("complete qualification check required")

@dataclass(frozen=True)
class IntegratedQualificationReport:
    schema:str
    generated_at_s:float
    software_build:str
    checks:tuple[QualificationCheck,...]
    passed:bool
    report_sha256:str
    provenance:str

def _report_hash(build,generated,checks):
    payload=json.dumps({"build":build,"generated_at_s":generated,"checks":[asdict(x) for x in checks]},
                       sort_keys=True,separators=(",",":"),default=str).encode()
    return hashlib.sha256(payload).hexdigest()

EXPECTED_SERVICES=(
"joe.runtime-status","joe.state-events","joe.storage","joe.jobs","joe.host-telemetry",
"joe.host-telemetry-monitor","joe.streams","joe.visualization","joe.projects","joe.runs",
"joe.run_review","joe.diagnostics","joe.alerts","joe.authority","joe.documentation",
"joe.mpr","joe.geometry","joe.stress-energy","joe.scientific-registry","joe.navigation",
"joe.traversability","joe.qft","joe.chronology","joe.mouth-dynamics","joe.ring-laser",
"joe.verification","joe.digital-twin","joe.experiment-designer","joe.metrology",
"joe.guardian","joe.advanced-visualization","joe.scientific-data","joe.report-generator",
"joe.compute-backends","joe.quantum-runtime","joe.rt-control","joe.scientific-reference","joe.guardian-reference")

GUARDIAN_SCHEMAS=(
"JOE-GUARDIAN-MPR/1","JOE-GUARDIAN-GEOMETRY/1","JOE-GUARDIAN-STRESS-ENERGY/1",
"JOE-GUARDIAN-REGISTRY/1","JOE-GUARDIAN-UNITS/1","JOE-GUARDIAN-NAVIGATION/1",
"JOE-GUARDIAN-QFT/1","JOE-GUARDIAN-CHRONOLOGY/1","JOE-GUARDIAN-METROLOGY/1",
"JOE-GUARDIAN-COMPUTE/1","JOE-GUARDIAN-QUANTUM/1","JOE-GUARDIAN-RT-CONTROL/1",
"JOE-GUARDIAN-SCIENTIFIC-DATA/1","JOE-GUARDIAN-REPORT/1","JOE-GUARDIAN-SCIENTIFIC-REFERENCE/1","JOE-GUARDIAN-SCIENTIFIC-EVALUATOR/1")


@dataclass(frozen=True)
class ArtifactTrace:
    artifact_id:str; artifact_type:str; sha256:str; upstream_artifact_ids:tuple[str,...]
    parameter_snapshot_sha256:str; config_snapshot_sha256:str; origin:WorkflowOrigin; provenance:str; immutable:bool=True
    def __post_init__(self):
        if not all((self.artifact_id.strip(),self.artifact_type.strip(),self.provenance.strip())):raise ValueError("artifact identity/type/provenance required")
        for h in (self.sha256,self.parameter_snapshot_sha256,self.config_snapshot_sha256):
            if len(h)!=64 or any(c not in "0123456789abcdef" for c in h.lower()):raise ValueError("SHA-256 hex required")

@dataclass(frozen=True)
class PersistenceQualification:
    schema:str; passed:bool; checks:tuple[QualificationCheck,...]; provenance:str

def qualify_artifact_traceability(artifacts):
    ids={a.artifact_id:a for a in artifacts};checks=[]
    duplicate=len(ids)!=len(artifacts)
    checks.append(QualificationCheck("DATA-IDENTITY","persistence",QualificationStatus.FAIL if duplicate else QualificationStatus.PASS,"Unique artifact identities." if not duplicate else "Duplicate artifact identity.",("unique IDs",),"SOFTWARE: persistence qualifier"))
    broken=tuple(a.artifact_id+"->"+u for a in artifacts for u in a.upstream_artifact_ids if u not in ids)
    checks.append(QualificationCheck("DATA-LINEAGE","persistence",QualificationStatus.PASS if not broken else QualificationStatus.FAIL,"Artifact lineage resolves." if not broken else "Broken artifact lineage.",broken or ("all upstream IDs resolve",),"SOFTWARE: persistence qualifier"))
    mutable=tuple(a.artifact_id for a in artifacts if not a.immutable)
    checks.append(QualificationCheck("DATA-IMMUTABILITY","persistence",QualificationStatus.PASS if not mutable else QualificationStatus.FAIL,"Artifacts immutable." if not mutable else "Mutable artifact detected.",mutable or ("immutable flags asserted",),"SOFTWARE: persistence qualifier"))
    contamination=tuple(a.artifact_id for a in artifacts if a.origin==WorkflowOrigin.HARDWARE and any(ids[u].origin==WorkflowOrigin.SIMULATION for u in a.upstream_artifact_ids if u in ids))
    checks.append(QualificationCheck("DATA-ORIGIN","origin",QualificationStatus.PASS if not contamination else QualificationStatus.FAIL,"Artifact origin isolation holds." if not contamination else "Artifact origin contamination.",contamination or ("simulation not promoted to hardware",),"SOFTWARE: persistence qualifier"))
    reports=tuple(a for a in artifacts if a.artifact_type=="REPORT");bad_reports=tuple(a.artifact_id for a in reports if not a.upstream_artifact_ids)
    checks.append(QualificationCheck("DATA-REPORT-TRACE","traceability",QualificationStatus.PASS if reports and not bad_reports else QualificationStatus.FAIL,"Reports trace upstream." if reports and not bad_reports else "Report traceability incomplete.",tuple(a.artifact_id for a in reports) if reports else ("no report",),"SOFTWARE: persistence qualifier"))
    zero="0"*64;snap=tuple(a.artifact_id for a in artifacts if a.parameter_snapshot_sha256==zero or a.config_snapshot_sha256==zero)
    checks.append(QualificationCheck("DATA-SNAPSHOTS","configuration",QualificationStatus.PASS if not snap else QualificationStatus.FAIL,"Snapshot hashes bound." if not snap else "Snapshot binding invalid.",snap or ("parameter/config hashes bound",),"SOFTWARE: persistence qualifier"))
    return PersistenceQualification("JOE-PERSISTENCE-QUALIFICATION/1",all(c.status!=QualificationStatus.FAIL for c in checks),tuple(checks),"SOFTWARE: JOE QUAL-001C")

def qualification_artifact_fixture():
    H=lambda x:hashlib.sha256(x.encode()).hexdigest();p=H("synthetic-mpr");c=H("synthetic-config")
    return (ArtifactTrace("run","RUN",H("run"),(),p,c,WorkflowOrigin.SIMULATION,"SIMULATION: qualification"),
            ArtifactTrace("data","DATA",H("data"),("run",),p,c,WorkflowOrigin.SIMULATION,"SIMULATION: qualification"),
            ArtifactTrace("analysis","ANALYSIS",H("analysis"),("data",),p,c,WorkflowOrigin.SIMULATION,"SIMULATION: qualification"),
            ArtifactTrace("report","REPORT",H("report"),("analysis",),p,c,WorkflowOrigin.SIMULATION,"SIMULATION: qualification"))

@dataclass(frozen=True)
class ReplayEnvelope:
    replay_id:str; source_run_sha256:str; source_origin:WorkflowOrigin; requested_mode:str; actuator_binding_requested:bool; provenance:str

def qualify_replay_isolation(r):
    f=[]
    if len(r.source_run_sha256)!=64:f.append("source run hash invalid")
    if r.actuator_binding_requested:f.append("replay may not bind actuators")
    if r.requested_mode.upper()=="LIVE":f.append("replay may not enter LIVE")
    if r.source_origin==WorkflowOrigin.HARDWARE and "REPLAY" not in r.provenance.upper():f.append("hardware source replay must be relabeled REPLAY")
    return QualificationCheck("DATA-REPLAY","replay",QualificationStatus.PASS if not f else QualificationStatus.FAIL,"Replay isolation holds." if not f else "Replay isolation failure.",tuple(f) or ("no LIVE actuator binding",),"SOFTWARE: persistence qualifier")

def persistence_release_readiness():
    good=qualify_artifact_traceability(qualification_artifact_fixture())
    replay=ReplayEnvelope("r",hashlib.sha256(b"run").hexdigest(),WorkflowOrigin.SIMULATION,"SIL",False,"REPLAY: qualification")
    rq=qualify_replay_isolation(replay);passed=good.passed and rq.status==QualificationStatus.PASS
    return {"passed":passed,"checks":tuple(c.check_id+" passed" for c in good.checks)+(rq.check_id+" passed",),"failures":() if passed else ("persistence qualification failed",),
            "notes":("Synthetic artifact hashes only.","Validates traceability/isolation, not scientific truth.")}

class IntegratedQualifier:
    def __init__(self,runtime,software_build):
        self.runtime=runtime;self.software_build=software_build
    def _check_services(self):
        missing=[]
        for sid in EXPECTED_SERVICES:
            try:self.runtime.service(sid)
            except Exception:missing.append(sid)
        return QualificationCheck("QUAL-SERVICES","integration",QualificationStatus.PASS if not missing else QualificationStatus.FAIL,
            "Expected JOE services are resolvable." if not missing else "Required JOE services are missing.",
            tuple("missing:"+x for x in missing) if missing else ("all expected services resolved",),"SOFTWARE: JOE integrated qualifier")
    def _check_authority(self):
        failures=[]
        try:
            rt=self.runtime.service("joe.rt-control")
            g=rt.guardian_contract()
            facts=g.facts
            if g.authority!="READ_ONLY_ADVISORY":failures.append("RT Guardian contract is not advisory")
            if facts.get("guardian_can_command") is not False:failures.append("Guardian command authority violation")
            if facts.get("guardian_can_clear_trip") is not False:failures.append("Guardian trip-clear authority violation")
            if facts.get("bus_safe_final_authority") is not True:failures.append("BUS-SAFE final authority not asserted")
        except Exception as exc:failures.append(type(exc).__name__+": "+str(exc))
        return QualificationCheck("QUAL-AUTHORITY","safety",QualificationStatus.PASS if not failures else QualificationStatus.FAIL,
            "Authority hierarchy is enforced." if not failures else "Authority boundary failure.",tuple(failures) or ("BUS-SAFE > RT control > Guardian > operator/research",),
            "SOFTWARE: JOE integrated qualifier")
    def _check_compute_quantum(self):
        evidence=[];failures=[]
        for sid,label in (("joe.compute-backends","compute"),("joe.quantum-runtime","quantum")):
            try:
                svc=self.runtime.service(sid);q=svc.release_readiness()
                if not q.get("passed"):failures.append(label+" release readiness failed")
                else:evidence.append(label+" readiness passed")
            except Exception as exc:failures.append(label+": "+type(exc).__name__+": "+str(exc))
        return QualificationCheck("QUAL-COMPUTE-QPU","compute",QualificationStatus.PASS if not failures else QualificationStatus.FAIL,
            "Compute and quantum research backends respect qualification gates." if not failures else "Compute/quantum qualification failure.",
            tuple(evidence+failures),"SOFTWARE: JOE integrated qualifier")
    def _check_rt(self):
        try:q=self.runtime.service("joe.rt-control").release_readiness();passed=bool(q.get("passed"))
        except Exception as exc:q={"checks":(),"failures":(type(exc).__name__+": "+str(exc),)};passed=False
        return QualificationCheck("QUAL-RT","safety",QualificationStatus.PASS if passed else QualificationStatus.FAIL,
            "RT software/SIL release gate passed." if passed else "RT software/SIL release gate failed.",
            tuple(q.get("checks",()))+tuple(q.get("failures",())),"SOFTWARE: JOE integrated qualifier")
    def _check_physics_safety(self):
        try:
            from journeyman.core.physics_safety import physics_safety_release_readiness
            q=physics_safety_release_readiness();passed=bool(q.get("passed"))
        except Exception as exc:q={"checks":(),"failures":(type(exc).__name__+": "+str(exc),)};passed=False
        return QualificationCheck("QUAL-PHYSICS-SAFETY","safety",QualificationStatus.PASS if passed else QualificationStatus.FAIL,
            "Deterministic scientific-envelope fail-closed gate passed." if passed else "Scientific-envelope gate failed.",
            tuple(q.get("checks",()))+tuple(q.get("failures",())),"SOFTWARE: JOE physics safety qualifier")
    def _check_predictive_horizon(self):
        try:
            from journeyman.core.predictive_horizon import predictive_horizon_release_readiness
            q=predictive_horizon_release_readiness();passed=bool(q.get("passed"))
        except Exception as exc:q={"checks":(),"failures":(type(exc).__name__+": "+str(exc),)};passed=False
        return QualificationCheck("QUAL-PREDICTIVE-HORIZON","safety",QualificationStatus.PASS if passed else QualificationStatus.FAIL,
            "Predictive physics horizon fail-closed gate passed." if passed else "Predictive physics horizon gate failed.",
            tuple(q.get("checks",()))+tuple(q.get("failures",())),"SOFTWARE: JOE predictive horizon qualifier")
    def _check_safe_state_recovery(self):
        try:
            from journeyman.core.safe_state_recovery import safe_state_release_readiness
            q=safe_state_release_readiness();passed=bool(q.get("passed"))
        except Exception as exc:q={"checks":(),"failures":(type(exc).__name__+": "+str(exc),)};passed=False
        return QualificationCheck("QUAL-SAFE-STATE-RECOVERY","safety",QualificationStatus.PASS if passed else QualificationStatus.FAIL,
            "Adaptive safe-state/recovery gate passed." if passed else "Safe-state/recovery gate failed.",
            tuple(q.get("checks",()))+tuple(q.get("failures",())),"SOFTWARE: JOE safe-state recovery qualifier")
    def _check_performance_hil(self):
        try:
            from journeyman.core.performance_hil import performance_hil_release_readiness
            q=performance_hil_release_readiness();passed=bool(q.get("passed"))
        except Exception as exc:q={"checks":(),"failures":(type(exc).__name__+": "+str(exc),)};passed=False
        return QualificationCheck("QUAL-PERFORMANCE-PRE-HIL","verification",QualificationStatus.PASS if passed else QualificationStatus.FAIL,
            "Performance/pre-HIL emulation gate passed." if passed else "Performance/pre-HIL emulation gate failed.",
            tuple(q.get("checks",()))+tuple(q.get("failures",())),"SOFTWARE/SIMULATION: JOE pre-HIL qualifier")
    def _check_final_stress(self):
        try:
            from journeyman.core.final_stress_qualification import final_stress_release_readiness
            q=final_stress_release_readiness();passed=bool(q.get("passed"))
        except Exception as exc:q={"checks":(),"failures":(type(exc).__name__+": "+str(exc),)};passed=False
        return QualificationCheck("QUAL-FINAL-STRESS-004B","verification",QualificationStatus.PASS if passed else QualificationStatus.FAIL,
            "Phase-space/numerical torture qualification passed." if passed else "Final stress qualification failed.",
            tuple(q.get("checks",()))+tuple(q.get("failures",())),"SOFTWARE/SIMULATION: JOE final stress qualifier")
    def _check_chronology_protection(self):
        try:
            from journeyman.core.chronology_protection_governor import chronology_protection_release_readiness
            q=chronology_protection_release_readiness();passed=bool(q.get("passed"))
        except Exception as exc:q={"checks":(),"failures":(type(exc).__name__+": "+str(exc),)};passed=False
        return QualificationCheck("QUAL-CHRONOLOGY-PROTECTION","safety",QualificationStatus.PASS if passed else QualificationStatus.FAIL,
            "Chronology/backreaction research protection governor gate passed." if passed else "Chronology/backreaction protection governor gate failed.",
            tuple(q.get("checks",()))+tuple(q.get("failures",())),"SOFTWARE: JOE chronology protection qualifier")
    def _check_resource_governor(self):
        try:
            from journeyman.core.resource_governor import resource_governor_readiness
            q=resource_governor_readiness();passed=bool(q.get("passed"))
        except Exception as exc:q={"checks":(),"failures":(type(exc).__name__+": "+str(exc),)};passed=False
        return QualificationCheck("QUAL-HOST-RESOURCE-GOVERNOR","operations",QualificationStatus.PASS if passed else QualificationStatus.FAIL,
            "Automatic local-workstation resource governor passed." if passed else "Host resource governor failed.",
            tuple(q.get("checks",()))+tuple(q.get("failures",())),"HOST/SOFTWARE: JOE resource governor qualifier")
    def _check_operational_autoconfig(self):
        try:
            from journeyman.core.operational_autoconfig import operational_autoconfig_readiness
            q=operational_autoconfig_readiness();passed=bool(q.get("passed"))
        except Exception as exc:q={"checks":(),"failures":(type(exc).__name__+": "+str(exc),)};passed=False
        return QualificationCheck("QUAL-OPERATIONAL-AUTOCONFIG-005B","operations",QualificationStatus.PASS if passed else QualificationStatus.FAIL,
            "Operational auto-configuration and external-compute admission passed." if passed else "Operational auto-configuration failed.",
            tuple(q.get("checks",()))+tuple(q.get("failures",())),"HOST/SOFTWARE: JOE final operational qualifier")
    def _check_no_live_claim(self):
        # The qualification baseline intentionally requires the physical boundary to remain fail-closed.
        try:
            from journeyman.core.rt_control import SILQualificationAdapter,bus_safe_interface_permissive
            ok,_=bus_safe_interface_permissive(SILQualificationAdapter().read_bus_safe_status())
            passed=not ok
        except Exception:passed=False
        return QualificationCheck("QUAL-LIVE-ISOLATION","safety",QualificationStatus.PASS if passed else QualificationStatus.FAIL,
            "SIL does not qualify physical BUS-SAFE/LIVE hardware." if passed else "SIL/LIVE isolation failed.",
            ("no physical BUS-SAFE hardware is claimed by the baseline",),"SOFTWARE: JOE integrated qualifier")
    def _check_guardian_schema_coverage(self):
        # Static schema inventory is an integration contract check, not proof that every producer is currently active.
        root=__import__("pathlib").Path(__file__).resolve().parents[1]
        text="\n".join(p.read_text(errors="ignore") for p in root.rglob("*.py"))
        missing=tuple(x for x in GUARDIAN_SCHEMAS if x not in text)
        return QualificationCheck("QUAL-GUARDIAN-SCHEMAS","guardian",QualificationStatus.PASS if not missing else QualificationStatus.FAIL,
            "Required Guardian contract schemas are present." if not missing else "Guardian contract schema coverage is incomplete.",
            tuple("missing:"+x for x in missing) if missing else tuple(GUARDIAN_SCHEMAS),"SOFTWARE: JOE integrated qualifier")
    def run(self):
        base_checks=(self._check_services(),self._check_authority(),self._check_compute_quantum(),self._check_rt(),self._check_physics_safety(),self._check_predictive_horizon(),self._check_safe_state_recovery(),self._check_chronology_protection(),self._check_performance_hil(),self._check_final_stress(),self._check_resource_governor(),self._check_operational_autoconfig(),
                self._check_no_live_claim(),self._check_guardian_schema_coverage())
        w=workflow_release_readiness()
        workflow_check=QualificationCheck("QUAL-WORKFLOW","workflow",QualificationStatus.PASS if w["passed"] else QualificationStatus.FAIL,
            "End-to-end scientific workflow qualification passed." if w["passed"] else "End-to-end scientific workflow qualification failed.",
            tuple(w["checks"])+tuple(w["failures"]),"SOFTWARE: JOE integrated qualifier")
        p=persistence_release_readiness()
        persistence_check=QualificationCheck("QUAL-PERSISTENCE","persistence",QualificationStatus.PASS if p["passed"] else QualificationStatus.FAIL,
            "Persistence/traceability qualification passed." if p["passed"] else "Persistence/traceability qualification failed.",
            tuple(p["checks"])+tuple(p["failures"]),"SOFTWARE: JOE integrated qualifier")
        checks=base_checks+(workflow_check,persistence_check)
        generated=time.time();passed=all(x.status!=QualificationStatus.FAIL for x in checks)
        h=_report_hash(self.software_build,generated,checks)
        return IntegratedQualificationReport("JOE-INTEGRATED-QUALIFICATION/1",generated,self.software_build,checks,passed,h,
                                             "SOFTWARE: JOE v1.6 final operational qualification")

def guardian_qualification_contract(report:IntegratedQualificationReport):
    return {"schema":"JOE-GUARDIAN-INTEGRATED-QUALIFICATION/1","status":"PASS" if report.passed else "FAIL",
            "report_sha256":report.report_sha256,"software_build":report.software_build,
            "failed_checks":tuple(x.check_id for x in report.checks if x.status==QualificationStatus.FAIL),
            "authority":"READ_ONLY_ADVISORY","may_override":False,"provenance":report.provenance}


class WorkflowOrigin(str,Enum):
    SOFTWARE="SOFTWARE"; IMPORTED="IMPORTED"; SIMULATION="SIMULATION"; HARDWARE="HARDWARE"

@dataclass(frozen=True)
class ScientificWorkflowRecord:
    record_id:str; stage:str; object_id:str; origin:WorkflowOrigin
    value:float|None; unit:str|None; uncertainty:float|None
    upstream_ids:tuple[str,...]; provenance:str; epistemic_status:str
    def __post_init__(self):
        if not all((self.record_id.strip(),self.stage.strip(),self.object_id.strip(),self.provenance.strip(),self.epistemic_status.strip())):raise ValueError("workflow identity/provenance required")
        if self.uncertainty is not None and self.uncertainty<0:raise ValueError("uncertainty cannot be negative")

WORKFLOW_STAGES=("MPR","PHYSICS","VERIFICATION","EXPERIMENT","DIGITAL_TWIN","METROLOGY","ANALYSIS","DATA","REPORT")

@dataclass(frozen=True)
class WorkflowQualification:
    schema:str; passed:bool; checks:tuple[QualificationCheck,...]; provenance:str

def qualify_scientific_workflow(records):
    ids={r.record_id:r for r in records};checks=[]
    missing=tuple(x for x in WORKFLOW_STAGES if not any(r.stage==x for r in records))
    checks.append(QualificationCheck("WF-STAGES","workflow",QualificationStatus.PASS if not missing else QualificationStatus.FAIL,
        "Required workflow stages represented." if not missing else "Workflow stages missing.",tuple("missing:"+x for x in missing) or WORKFLOW_STAGES,"SOFTWARE: workflow qualifier"))
    broken=tuple(r.record_id+"->"+u for r in records for u in r.upstream_ids if u not in ids)
    checks.append(QualificationCheck("WF-LINEAGE","provenance",QualificationStatus.PASS if not broken else QualificationStatus.FAIL,
        "Lineage resolves." if not broken else "Broken lineage.",broken or ("all upstream IDs resolve",),"SOFTWARE: workflow qualifier"))
    contamination=[]
    for r in records:
        ups=[ids[u] for u in r.upstream_ids if u in ids]
        if r.origin==WorkflowOrigin.HARDWARE and any(u.origin==WorkflowOrigin.SIMULATION for u in ups):contamination.append(r.record_id+": simulation upstream promoted to hardware")
        if r.origin==WorkflowOrigin.HARDWARE and "SIMULATION" in r.provenance.upper():contamination.append(r.record_id+": hardware record has simulation provenance")
    checks.append(QualificationCheck("WF-ORIGIN","origin",QualificationStatus.PASS if not contamination else QualificationStatus.FAIL,
        "Origin isolation holds." if not contamination else "Origin contamination detected.",tuple(contamination) or ("simulation not promoted to hardware",),"SOFTWARE: workflow qualifier"))
    missu=tuple(r.record_id for r in records if r.value is not None and r.stage in ("PHYSICS","VERIFICATION","METROLOGY","ANALYSIS") and r.uncertainty is None)
    checks.append(QualificationCheck("WF-UNCERTAINTY","uncertainty",QualificationStatus.PASS if not missu else QualificationStatus.FAIL,
        "Quantitative uncertainty present." if not missu else "Quantitative uncertainty missing.",missu or ("required uncertainty fields present",),"SOFTWARE: workflow qualifier"))
    mism=[]
    for r in records:
        for u in r.upstream_ids:
            if u in ids and r.stage not in ("DATA","REPORT") and r.object_id!=ids[u].object_id:mism.append(r.record_id+" object mismatch")
    checks.append(QualificationCheck("WF-OBJECT-ID","identity",QualificationStatus.PASS if not mism else QualificationStatus.FAIL,
        "Scientific object identity consistent." if not mism else "Scientific object identity mismatch.",tuple(mism) or ("object continuity passed",),"SOFTWARE: workflow qualifier"))
    bad_epi=tuple(r.record_id for r in records if r.epistemic_status.upper() in ("PROVEN","TRUE"))
    checks.append(QualificationCheck("WF-EPISTEMIC","epistemics",QualificationStatus.PASS if not bad_epi else QualificationStatus.FAIL,
        "Epistemic classifications are explicit and non-absolute." if not bad_epi else "Absolute epistemic claim detected.",bad_epi or ("epistemic classification passed",),"SOFTWARE: workflow qualifier"))
    return WorkflowQualification("JOE-SCIENTIFIC-WORKFLOW-QUALIFICATION/1",all(c.status!=QualificationStatus.FAIL for c in checks),tuple(checks),"SOFTWARE: JOE QUAL-001B")

def qualification_reference_workflow():
    obj="qualification.object";rows=[];prev=()
    for i,stage in enumerate(WORKFLOW_STAGES):
        rid=f"qual-{i+1}"; quantitative=stage in ("PHYSICS","VERIFICATION","METROLOGY","ANALYSIS")
        origin=WorkflowOrigin.SIMULATION if stage in ("DIGITAL_TWIN","METROLOGY","ANALYSIS","DATA","REPORT") else WorkflowOrigin.SOFTWARE
        rows.append(ScientificWorkflowRecord(rid,stage,obj,origin,float(i) if quantitative else None,"1" if quantitative else None,.01 if quantitative else None,prev,
            ("SIMULATION: integrated workflow qualification" if origin==WorkflowOrigin.SIMULATION else "SOFTWARE: integrated workflow qualification"),
            "SIMULATION_RESULT" if origin==WorkflowOrigin.SIMULATION else "EXTRAPOLATED_ENGINEERING"));prev=(rid,)
    return tuple(rows)

def workflow_release_readiness():
    good=qualify_scientific_workflow(qualification_reference_workflow())
    bad=list(qualification_reference_workflow());src=bad[4]
    bad[5]=ScientificWorkflowRecord("qual-6","METROLOGY",src.object_id,WorkflowOrigin.HARDWARE,1.0,"1",.01,(src.record_id,),"HARDWARE: qualification fixture","DEMONSTRATED_TECHNOLOGY")
    contaminated=qualify_scientific_workflow(tuple(bad))
    detected=any(c.check_id=="WF-ORIGIN" and c.status==QualificationStatus.FAIL for c in contaminated.checks)
    return {"passed":good.passed and detected,"checks":tuple(c.check_id+" passed" for c in good.checks)+("simulation-to-hardware contamination detector passed",),
            "failures":() if good.passed and detected else ("workflow qualification failed",),
            "notes":("Reference workflow is synthetic qualification data, not physical measurement.","This validates software contracts, not unresolved physics.")}


@dataclass(frozen=True)
class ReleaseComponent:
    component_id:str
    version:str
    status:str
    qualification:str
    limitations:tuple[str,...]
    provenance:str

@dataclass(frozen=True)
class ReleaseManifest:
    schema:str
    product:str
    release_version:str
    build:str
    generated_at_s:float
    components:tuple[ReleaseComponent,...]
    limitations:tuple[str,...]
    manifest_sha256:str
    provenance:str

def _release_manifest_hash(product,version,build,generated,components,limitations):
    payload=json.dumps({"product":product,"version":version,"build":build,"generated_at_s":generated,
                        "components":[asdict(x) for x in components],"limitations":limitations},
                       sort_keys=True,separators=(",",":"),default=str).encode()
    return hashlib.sha256(payload).hexdigest()

def joe_release_components():
    return (
      ReleaseComponent("joe.foundation","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",(),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.mpr","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",(),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.geometry","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",(),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.stress-energy","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",(),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.scientific-registry","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",(),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.navigation","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",("High-precision EOP/ITRF/GCRS/BCRS transforms not implemented.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.traversability","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",("Static-frame theoretical analysis; no physical wormhole evidence.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.qft","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",("No macroscopic negative-energy source or curved-spacetime QI solution is claimed.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.chronology","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",("Kinematic chronology conditions only; no CTC evidence.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.mouth-dynamics","1.0.0","COMPLETE","SIMULATION_QUALIFIED",("Mouth A/B are simulation objects only.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.ring-laser","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",("No validated circulating-light chronology metric or CTC threshold.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.verification","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",("PASS does not validate unresolved physics.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.digital-twin","1.0.0","COMPLETE","SIMULATION_QUALIFIED",("No physical mouth telemetry/hardware source.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.experiment-designer","1.0.0","COMPLETE","SIMULATION_QUALIFIED",("Sequencing is simulation/research workflow, not actuator control.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.metrology","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",("No real clock adapter or GR proper-time engine.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.guardian","1.0.0","COMPLETE","READ_ONLY_ADVISORY",("Guardian is not final safety authority.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.advanced-visualization","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",("Full 3D surface/field rendering remains limited.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.scientific-data","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",("Archive hardening remains an engineering improvement area.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.report-generator","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",("Rich verified figure-asset resolution/bibliography remain limited.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.compute-backends","1.1.0","COMPLETE","SOFTWARE_QUALIFIED",("GPU/HPC execution requires qualified adapters.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.quantum-runtime","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",("No physical QPU provider adapter is claimed.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.rt-control","1.0.0","COMPLETE","SIL_QUALIFIED",("No physical BUS-SAFE, PLC/FPGA, HIL rig, or actuator driver is claimed.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.scientific-reference","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",("Reference JSON is non-executable and read-only.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.guardian-reference","1.0.0","COMPLETE","READ_ONLY_ADVISORY",("Deterministic scientific evaluator cannot command or override.",),"SOFTWARE: JOE release inventory"),
      ReleaseComponent("joe.integrated-qualification","1.0.0","COMPLETE","SOFTWARE_QUALIFIED",(),"SOFTWARE: JOE release inventory"),
    )

JOE_RELEASE_LIMITATIONS=(
"JOE v1.5.0 is a scientific software/SIL release; it is not qualification of physical time travel.",
"No physical traversable wormhole, exotic stress-energy source, chronology violation, or circulating-light CTC is demonstrated.",
"BUS-SAFE remains conceptually external and final authority; no physical BUS-SAFE hardware is supplied.",
"Simulation, synthetic and replay data never constitute hardware telemetry.",
"Physical GPU/HPC/QPU/RT hardware capabilities require separately authenticated and qualified adapters where not already available.",
"Guardian remains supervisory/read-only advisory and cannot override deterministic interlocks or BUS-SAFE.",
)

def build_release_manifest():
    generated=time.time();components=joe_release_components()
    h=_release_manifest_hash("Journeyman Operating Environment","1.5.4","JOE-FINAL-QUAL-004B",generated,components,JOE_RELEASE_LIMITATIONS)
    return ReleaseManifest("JOE-RELEASE-MANIFEST/1","Journeyman Operating Environment","1.5.4","JOE-FINAL-QUAL-004B",generated,
                           components,JOE_RELEASE_LIMITATIONS,h,"SOFTWARE/SIL: JOE v1.5.4 final release")

def scientific_truth_boundary_check():
    forbidden=("PHYSICAL_TIME_TRAVEL_VALIDATED","WORMHOLE_DEMONSTRATED","CTC_DEMONSTRATED","MACROSCOPIC_NEGATIVE_ENERGY_DEMONSTRATED",
               "BUS_SAFE_PHYSICAL_CONNECTED","PHYSICAL_QPU_CONNECTED")
    manifest=build_release_manifest()
    corpus=" ".join([c.qualification+" "+" ".join(c.limitations) for c in manifest.components]+list(manifest.limitations)).upper()
    violations=tuple(x for x in forbidden if x in corpus)
    return QualificationCheck("REL-TRUTH-BOUNDARY","epistemics",QualificationStatus.PASS if not violations else QualificationStatus.FAIL,
        "Release makes no prohibited physical-capability truth claims." if not violations else "Prohibited physical-capability claim detected.",
        violations or ("unresolved physics remains explicitly unresolved","simulation remains distinct from hardware"),
        "SOFTWARE: JOE final release qualifier")

def final_guardian_authority_check(runtime):
    failures=[]
    try:
        rt=runtime.service("joe.rt-control").guardian_contract()
        if rt.authority!="READ_ONLY_ADVISORY":failures.append("RT Guardian authority not advisory")
        if rt.facts.get("guardian_can_command") is not False:failures.append("Guardian command capability violation")
        if rt.facts.get("guardian_can_clear_trip") is not False:failures.append("Guardian trip-clear capability violation")
    except Exception as exc:failures.append("RT Guardian contract unavailable: "+str(exc))
    try:
        q=runtime.service("joe.integrated-qualification").guardian_contract()
        if q.get("may_override") is not False:failures.append("Integrated qualification override exposed to Guardian")
    except Exception as exc:failures.append("Qualification Guardian contract unavailable: "+str(exc))
    return QualificationCheck("REL-GUARDIAN-AUTHORITY","authority",QualificationStatus.PASS if not failures else QualificationStatus.FAIL,
        "System-wide Guardian authority remains advisory." if not failures else "Guardian authority boundary failure.",
        tuple(failures) or ("Guardian cannot command RT","Guardian cannot clear trips","Guardian cannot override qualification"),
        "SOFTWARE: JOE final release qualifier")

def deterministic_regression_gate():
    # In-app deterministic regression covers pure qualification fixtures. The external unit suite is run by release engineering.
    checks=[]
    try:
        checks.append(("workflow",workflow_release_readiness()["passed"]))
        checks.append(("persistence",persistence_release_readiness()["passed"]))
        from journeyman.core.rt_control import rt_v1_release_readiness
        checks.append(("rt",rt_v1_release_readiness()["passed"]))
    except Exception as exc:return QualificationCheck("REL-REGRESSION","regression",QualificationStatus.FAIL,"Deterministic regression gate raised an exception.",(str(exc),),"SOFTWARE: JOE final release qualifier")
    failed=tuple(name for name,ok in checks if not ok)
    return QualificationCheck("REL-REGRESSION","regression",QualificationStatus.PASS if not failed else QualificationStatus.FAIL,
        "Deterministic integrated regression fixtures pass." if not failed else "Deterministic regression failure.",failed or tuple(name+" passed" for name,_ in checks),
        "SOFTWARE: JOE final release qualifier")

@dataclass(frozen=True)
class FinalReleaseQualification:
    schema:str
    release_version:str
    build:str
    passed:bool
    checks:tuple[QualificationCheck,...]
    manifest:ReleaseManifest
    release_sha256:str
    provenance:str

def scientific_reference_release_check(runtime):
    failures=[]
    try:
        lib=runtime.service("joe.scientific-reference");q=lib.readiness()
        if not q["passed"]:failures.extend(q["failures"])
        ev=runtime.service("joe.guardian-reference").contract()
        if ev.get("authority")!="READ_ONLY_ADVISORY" or ev.get("may_command") is not False or ev.get("may_override") is not False:
            failures.append("Guardian scientific evaluator authority violation")
    except Exception as exc:failures.append(type(exc).__name__+": "+str(exc))
    return QualificationCheck("REL-SCIENTIFIC-REFERENCE","guardian",QualificationStatus.PASS if not failures else QualificationStatus.FAIL,
        "Scientific reference library and Guardian evaluator are qualified." if not failures else "Scientific reference qualification failed.",
        tuple(failures) or ("reference library verified","Guardian evaluator read-only advisory"),"SOFTWARE: JOE final release qualifier")


def advanced_physics_release_check():
    failures=[]
    try:
        from journeyman.core.advanced_physics import advanced_physics_release_readiness,advanced_physics_guardian_contract
        q=advanced_physics_release_readiness()
        if not q["passed"]:failures.extend(q["failures"])
        g=advanced_physics_guardian_contract()
        if g.authority!="READ_ONLY_ADVISORY":failures.append("advanced physics Guardian authority violation")
    except Exception as exc:failures.append(type(exc).__name__+": "+str(exc))
    return QualificationCheck("REL-ADVANCED-PHYSICS","physics",QualificationStatus.PASS if not failures else QualificationStatus.FAIL,
        "Advanced geometry/QFT/EM physics extension is qualified." if not failures else "Advanced physics qualification failed.",
        tuple(failures) or ("tensor cross-verification passed","EM source model passed","Guardian remains advisory"),"SOFTWARE/MODEL: JOE advanced physics qualifier")


def method_b_ctc_extension_release_check():
    failures=[]
    try:
        from journeyman.core.ring_laser import method_b_advanced_release_readiness
        from journeyman.core.chronology import ctc_consistency_release_readiness
        a=method_b_advanced_release_readiness(); c=ctc_consistency_release_readiness()
        if not a["passed"]: failures.extend(a["failures"])
        if not c["passed"]: failures.extend(c["failures"])
    except Exception as exc: failures.append(type(exc).__name__+": "+str(exc))
    return QualificationCheck("REL-METHOD-B-CTC-EXT","physics",QualificationStatus.PASS if not failures else QualificationStatus.FAIL,
        "Advanced Method-B optics and CTC consistency laboratory are qualified." if not failures else "Method-B/CTC extension qualification failed.",
        tuple(failures) or ("resonator/dispersion benchmark passed","EM-gravity source scale passed","fixed-point/decoherence benchmarks passed","Guardian epistemic gates passed"),
        "SOFTWARE/MODEL: JOE Method-B/CTC extension qualifier")

def final_v15_release_qualification(runtime):
    base=IntegratedQualifier(runtime,"JOE-QUAL-001D").run()
    extra=(deterministic_regression_gate(),scientific_truth_boundary_check(),final_guardian_authority_check(runtime),scientific_reference_release_check(runtime),advanced_physics_release_check(),method_b_ctc_extension_release_check())
    checks=base.checks+extra
    manifest=build_release_manifest()
    passed=all(c.status!=QualificationStatus.FAIL for c in checks)
    payload=json.dumps({"manifest":manifest.manifest_sha256,"checks":[asdict(c) for c in checks],"passed":passed},sort_keys=True,separators=(",",":"),default=str).encode()
    release_hash=hashlib.sha256(payload).hexdigest()
    return FinalReleaseQualification("JOE-V1.5-FINAL-QUALIFICATION/1","1.5.4","JOE-FINAL-QUAL-004B",passed,checks,manifest,release_hash,"SOFTWARE/SIL: JOE v1.5.4 final integrated qualification")

def guardian_final_release_contract(result:FinalReleaseQualification):
    return {"schema":"JOE-GUARDIAN-FINAL-RELEASE/1","release_version":result.release_version,"build":result.build,
            "status":"PASS" if result.passed else "FAIL","release_sha256":result.release_sha256,
            "manifest_sha256":result.manifest.manifest_sha256,"authority":"READ_ONLY_ADVISORY","may_override":False,
            "limitations":result.manifest.limitations,"provenance":result.provenance}
