from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.guardian import (ingest_contract,evaluate_rule,assess_contracts,assess_ood,guardian_core_readiness,
 rolling_statistics,build_baseline,score_against_baseline,rate_of_change,detect_drift,compare_module_values,
 correlate_findings,statistical_finding,compare_contract_facts,status_consistency,scientific_consistency_report,
 consistency_findings,build_cross_module_scientific_state,standard_cross_module_checks,
 guardian_scientific_consistency_readiness,evidence_graph_from_findings,hypothesis_from_correlation,
 rank_explanations,interpret_disagreement,structured_operator_recommendation,guardian_reasoning_readiness,
 AIModelRegistry,validate_ai_request,deterministic_ai_fallback,governed_ai_response,
 compare_ai_to_deterministic,guardian_ai_governance_readiness,guardian_v1_release_readiness,
 guardian_workspace_snapshot)
GUARDIAN_MODULE=ModuleDescriptor(module_id="journeyman.guardian",name="Guardian AI Governor",version="1.0.0",
    requires=("joe.core",),provides=("joe.guardian",))
class GuardianService:
    ingest_contract=staticmethod(ingest_contract)
    evaluate_rule=staticmethod(evaluate_rule)
    assess_contracts=staticmethod(assess_contracts)
    assess_ood=staticmethod(assess_ood)
    release_readiness=staticmethod(guardian_v1_release_readiness)
    rolling_statistics=staticmethod(rolling_statistics)
    build_baseline=staticmethod(build_baseline)
    score_against_baseline=staticmethod(score_against_baseline)
    rate_of_change=staticmethod(rate_of_change)
    detect_drift=staticmethod(detect_drift)
    compare_module_values=staticmethod(compare_module_values)
    correlate_findings=staticmethod(correlate_findings)
    statistical_finding=staticmethod(statistical_finding)
    compare_contract_facts=staticmethod(compare_contract_facts)
    status_consistency=staticmethod(status_consistency)
    scientific_consistency_report=staticmethod(scientific_consistency_report)
    consistency_findings=staticmethod(consistency_findings)
    build_cross_module_scientific_state=staticmethod(build_cross_module_scientific_state)
    standard_cross_module_checks=staticmethod(standard_cross_module_checks)
    scientific_consistency_readiness=staticmethod(guardian_scientific_consistency_readiness)
    evidence_graph=staticmethod(evidence_graph_from_findings)
    hypothesis_from_correlation=staticmethod(hypothesis_from_correlation)
    rank_explanations=staticmethod(rank_explanations)
    interpret_disagreement=staticmethod(interpret_disagreement)
    operator_recommendation=staticmethod(structured_operator_recommendation)
    reasoning_readiness=staticmethod(guardian_reasoning_readiness)
    new_model_registry=staticmethod(AIModelRegistry)
    validate_ai_request=staticmethod(validate_ai_request)
    deterministic_ai_fallback=staticmethod(deterministic_ai_fallback)
    governed_ai_response=staticmethod(governed_ai_response)
    compare_ai_to_deterministic=staticmethod(compare_ai_to_deterministic)
    ai_governance_readiness=staticmethod(guardian_ai_governance_readiness)
    workspace_snapshot=staticmethod(guardian_workspace_snapshot)
class GuardianInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_guardian_module(runtime:ModuleRuntime):
    svc=GuardianService();runtime.register(GUARDIAN_MODULE,GuardianInstance(svc));runtime.activate("journeyman.guardian")
    runtime.publish_service("journeyman.guardian","joe.guardian",svc);return svc
