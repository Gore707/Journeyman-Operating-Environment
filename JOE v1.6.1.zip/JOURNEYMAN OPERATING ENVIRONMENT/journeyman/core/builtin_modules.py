"""Concrete modules shipped in this JOE build."""
from .module_runtime import ModuleDescriptor, ModuleInstance, ModuleRuntime
from .state_events import StateEventBackbone
from .storage import StorageService
from .job_engine import JobEngine
from .telemetry import HostTelemetry, HostTelemetryMonitor
from .data_streams import ScientificDataStreamEngine
from .visualization import VisualizationEngine
from .run_recorder import RunRecorder
from .run_review import RunReviewService
from .state_events import DataOrigin
from .projects_sessions import ProjectSessionService
from .diagnostics import DiagnosticsService
from .alerts import AlertService
from .authority import AuthorityService
from .documentation import DocumentationService
from .paths import ROOT, RUNS_DIR, PROJECTS_DIR, ALERTS_DIR

class JoeCoreInstance(ModuleInstance):
    def __init__(self) -> None:
        self.running = False
        self.telemetry_monitor = None

    def start(self) -> None:
        self.running = True

    def stop(self) -> None:
        if self.telemetry_monitor is not None:
            self.telemetry_monitor.stop()
        self.running = False

JOE_CORE = ModuleDescriptor(
    module_id="joe.core",
    name="JOE Core Environment",
    version="1.0.0",
    description="The running Journeyman Operating Environment core.",
    provides=("joe.runtime-status", "joe.state-events", "joe.storage", "joe.jobs", "joe.host-telemetry", "joe.host-telemetry-monitor", "joe.streams", "joe.visualization", "joe.projects", "joe.runs", "joe.run_review", "joe.diagnostics", "joe.alerts", "joe.authority", "joe.documentation"),
)

def register_builtin_modules(runtime: ModuleRuntime) -> None:
    instance = JoeCoreInstance()
    runtime.register(JOE_CORE, instance)
    runtime.activate(JOE_CORE.module_id)
    runtime.publish_service(JOE_CORE.module_id, "joe.runtime-status", instance)
    backbone = StateEventBackbone()
    backbone.state.register(
        "joe.runtime.module-count", "joe.core", value_type=int
    )
    backbone.state.register(
        "joe.runtime.status", "joe.core", value_type=str
    )
    backbone.events.register_topic("joe.runtime.lifecycle", ("joe.core",))
    core_client = backbone.client("joe.core")
    core_client.set_state("joe.runtime.module-count", len(runtime.records()))
    core_client.set_state("joe.runtime.status", "active")
    core_client.publish(
        "joe.runtime.lifecycle",
        {"module_id": "joe.core", "state": "active"},
    )
    runtime.publish_service(JOE_CORE.module_id, "joe.state-events", backbone)
    runtime.publish_service(JOE_CORE.module_id, "joe.storage", StorageService(ROOT))
    jobs=JobEngine()
    jobs.register_owner("joe.core",max_active=4)
    runtime.publish_service(JOE_CORE.module_id, "joe.jobs", jobs)
    telemetry=HostTelemetry(ROOT)
    monitor=HostTelemetryMonitor(telemetry,interval_seconds=1.0,history_limit=300)
    instance.telemetry_monitor=monitor
    runtime.publish_service(JOE_CORE.module_id, "joe.host-telemetry", telemetry)
    runtime.publish_service(JOE_CORE.module_id, "joe.host-telemetry-monitor", monitor)
    streams=ScientificDataStreamEngine(history_limit_per_stream=10000)
    runtime.publish_service(JOE_CORE.module_id, "joe.streams", streams)
    runtime.publish_service(JOE_CORE.module_id, "joe.visualization", VisualizationEngine(streams))
    recorder=RunRecorder(RUNS_DIR)
    runtime.publish_service(JOE_CORE.module_id, "joe.runs", recorder)
    runtime.publish_service(JOE_CORE.module_id, "joe.run_review", RunReviewService(recorder))
    runtime.publish_service(JOE_CORE.module_id, "joe.projects", ProjectSessionService(PROJECTS_DIR, recorder))
    runtime.publish_service(JOE_CORE.module_id, "joe.diagnostics", DiagnosticsService(runtime))
    runtime.publish_service(JOE_CORE.module_id, "joe.alerts", AlertService(ALERTS_DIR))
    runtime.publish_service(JOE_CORE.module_id, "joe.authority", AuthorityService())
    from journeyman.ui.manual import MANUAL_HTML
    from journeyman import __version__, __build__
    runtime.publish_service(JOE_CORE.module_id, "joe.documentation", DocumentationService(MANUAL_HTML, __version__, __build__))

    # Canonical real HOST streams. These are populated only from the genuine
    # HostTelemetry monitor; unavailable optional sensors are not synthesized.
    streams.register("host.cpu.utilization", "Host CPU Utilization", "%", float,
                     DataOrigin.HOST, JOE_CORE.module_id)
    streams.register("host.memory.utilization", "Host Memory Utilization", "%", float,
                     DataOrigin.HOST, JOE_CORE.module_id)
    streams.register("host.memory.available", "Host Available Memory", "bytes", int,
                     DataOrigin.HOST, JOE_CORE.module_id)
    streams.register("host.process.rss", "JOE Process Resident Memory", "bytes", int,
                     DataOrigin.HOST, JOE_CORE.module_id)
    streams.register("host.storage.utilization", "JOE Root Storage Utilization", "%", float,
                     DataOrigin.HOST, JOE_CORE.module_id)
    streams.register("host.storage.free", "JOE Root Storage Free", "bytes", int,
                     DataOrigin.HOST, JOE_CORE.module_id)

    gpu_streams: set[int]=set()
    temperature_streams: set[tuple[str,str]]=set()

    def publish_host_sample(sample):
        stamp=sample.timestamp
        source=JOE_CORE.module_id
        streams.publish_frame({
            "host.cpu.utilization": float(sample.cpu_percent),
            "host.memory.utilization": float(sample.memory_percent),
            "host.memory.available": int(sample.memory_available_bytes),
            "host.process.rss": int(sample.process_rss_bytes),
            "host.storage.utilization": float(sample.disk_percent),
            "host.storage.free": int(sample.disk_free_bytes),
        }, source=source, timestamp=stamp, metadata={"producer":"HostTelemetry"})

        # Optional real sensors become streams only when the host actually
        # exposes them. No placeholder GPU/temperature streams are created.
        for reading in sample.temperatures:
            key=(reading.sensor,reading.label)
            suffix=f"{reading.sensor}.{reading.label}".lower()
            import re
            suffix=re.sub(r"[^a-z0-9]+","-",suffix).strip("-") or "sensor"
            stream_id=f"host.temperature.{suffix}"
            if key not in temperature_streams:
                try:
                    streams.register(stream_id, f"Temperature {reading.sensor} {reading.label}".strip(),
                                     "°C", float, DataOrigin.HOST, source)
                    temperature_streams.add(key)
                except ValueError:
                    temperature_streams.add(key)
            streams.publish(stream_id,float(reading.celsius),source=source,timestamp=stamp)

        for gpu in sample.gpus:
            if gpu.index not in gpu_streams:
                streams.register(f"host.gpu.{gpu.index}.utilization", f"GPU {gpu.index} Utilization",
                                 "%", float, DataOrigin.HOST, source)
                streams.register(f"host.gpu.{gpu.index}.memory.used", f"GPU {gpu.index} VRAM Used",
                                 "bytes", int, DataOrigin.HOST, source)
                streams.register(f"host.gpu.{gpu.index}.temperature", f"GPU {gpu.index} Temperature",
                                 "°C", float, DataOrigin.HOST, source)
                gpu_streams.add(gpu.index)
            if gpu.utilization_percent is not None:
                streams.publish(f"host.gpu.{gpu.index}.utilization",float(gpu.utilization_percent),
                                source=source,timestamp=stamp,metadata={"device":gpu.name,"provider":gpu.source})
            if gpu.memory_used_bytes is not None:
                streams.publish(f"host.gpu.{gpu.index}.memory.used",int(gpu.memory_used_bytes),
                                source=source,timestamp=stamp,metadata={"device":gpu.name,"provider":gpu.source})
            if gpu.temperature_celsius is not None:
                streams.publish(f"host.gpu.{gpu.index}.temperature",float(gpu.temperature_celsius),
                                source=source,timestamp=stamp,metadata={"device":gpu.name,"provider":gpu.source})

    monitor.subscribe(publish_host_sample)
    monitor.start()
