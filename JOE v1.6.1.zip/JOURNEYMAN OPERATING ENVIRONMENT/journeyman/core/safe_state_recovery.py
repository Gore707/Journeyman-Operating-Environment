"""Adaptive safe-state and controlled-recovery supervision for JOE.

This is deterministic software/SIL policy logic. It can recommend/request only
bounded qualified control actions through RT; it does not directly drive hardware
and cannot replace BUS-SAFE.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import IntEnum
import math
from typing import Iterable
from journeyman.core.physics_safety import PhysicsSafetyDisposition

class RecoveryDisposition(IntEnum):
    NOMINAL=0
    DERATE=10
    HOLD=20
    CONTROLLED_RECOVERY=30
    ABORT=40
    TRIP=50

@dataclass(frozen=True)
class RecoveryPolicy:
    safe_low:float
    safe_high:float
    caution_fraction:float=.70
    derate_fraction:float=.80
    recovery_fraction:float=.90
    hysteresis_fraction:float=.05
    dwell_s:float=1.0
    max_control_rate:float=1.0
    control_latency_s:float=.02
    uncertainty_k:float=1.0
    def __post_init__(self):
        if not all(math.isfinite(x) for x in (self.safe_low,self.safe_high,self.caution_fraction,self.derate_fraction,self.recovery_fraction,self.hysteresis_fraction,self.dwell_s,self.max_control_rate,self.control_latency_s,self.uncertainty_k)):
            raise ValueError("finite recovery policy required")
        if self.safe_high<=self.safe_low or not (0<self.caution_fraction<self.derate_fraction<self.recovery_fraction<=1):raise ValueError("invalid safe envelope/fractions")
        if self.hysteresis_fraction<0 or self.dwell_s<0 or self.max_control_rate<=0 or self.control_latency_s<0 or self.uncertainty_k<0:raise ValueError("invalid recovery policy")

@dataclass(frozen=True)
class RecoveryState:
    value:float
    sigma:float
    rate:float
    acceleration:float
    model_valid:bool=True
    hardware_fault:bool=False
    provenance:str="SIMULATION"

@dataclass(frozen=True)
class ReachabilityResult:
    reachable:bool
    minimum_time_s:float|None
    reason:str

@dataclass(frozen=True)
class RecoveryAssessment:
    disposition:RecoveryDisposition
    may_progress:bool
    requested_derate_fraction:float
    safe_state_reachable:bool
    minimum_recovery_time_s:float|None
    reason:str
    provenance:str
    epistemic_status:str="MODEL_CONDITIONAL_CONTROL_POLICY"


def safe_state_reachability(value:float,target:float,max_control_rate:float,available_time_s:float,latency_s:float=0.0)->ReachabilityResult:
    vals=(value,target,max_control_rate,available_time_s,latency_s)
    if not all(math.isfinite(x) for x in vals) or max_control_rate<=0 or available_time_s<0 or latency_s<0:raise ValueError("invalid reachability inputs")
    t=abs(value-target)/max_control_rate+latency_s
    return ReachabilityResult(t<=available_time_s,t,"safe state is reachable within bounded control authority" if t<=available_time_s else "safe state is not reachable before available-time boundary")

class AdaptiveSafeStateSupervisor:
    """Stateful hysteretic policy supervisor; returns dispositions, never actuator commands."""
    def __init__(self,policy:RecoveryPolicy):
        self.policy=policy;self._last=RecoveryDisposition.NOMINAL;self._inside_since:float|None=None
    def assess(self,state:RecoveryState,now_s:float,available_recovery_time_s:float)->RecoveryAssessment:
        if not math.isfinite(now_s) or now_s<0 or not math.isfinite(available_recovery_time_s) or available_recovery_time_s<0:raise ValueError("valid time required")
        if not all(math.isfinite(x) for x in (state.value,state.sigma,state.rate,state.acceleration)) or state.sigma<0:
            return RecoveryAssessment(RecoveryDisposition.ABORT,False,0,False,None,"invalid/non-finite recovery state",state.provenance)
        if state.hardware_fault:
            return RecoveryAssessment(RecoveryDisposition.TRIP,False,0,False,None,"qualified hardware fault requires deterministic RT/BUS-SAFE trip path",state.provenance)
        if not state.model_valid:
            return RecoveryAssessment(RecoveryDisposition.HOLD,False,0,False,None,"model invalid: stop relying on predictive recovery and fail closed",state.provenance)
        lo,hi=self.policy.safe_low,self.policy.safe_high;span=hi-lo;center=(hi+lo)/2
        worst_hi=state.value+self.policy.uncertainty_k*state.sigma;worst_lo=state.value-self.policy.uncertainty_k*state.sigma
        frac=max(abs(worst_hi-center),abs(worst_lo-center))/(span/2)
        reach=safe_state_reachability(state.value,center,self.policy.max_control_rate,available_recovery_time_s,self.policy.control_latency_s)
        if not reach.reachable:
            disp=RecoveryDisposition.ABORT;reason=reach.reason
        elif frac>=1:
            disp=RecoveryDisposition.CONTROLLED_RECOVERY;reason="uncertainty envelope has reached/exceeded safe-state boundary; controlled recovery required"
        elif frac>=self.policy.recovery_fraction:
            disp=RecoveryDisposition.CONTROLLED_RECOVERY;reason="uncertainty envelope is inside recovery band"
        elif frac>=self.policy.derate_fraction:
            disp=RecoveryDisposition.DERATE;reason="uncertainty envelope entered deterministic derate band"
        elif frac>=self.policy.caution_fraction:
            disp=RecoveryDisposition.DERATE;reason="approaching safe-state boundary; bounded derate requested"
        else:
            disp=RecoveryDisposition.NOMINAL;reason="inside nominal recovery envelope"
        # Hysteresis/dwell: after intervention, NOMINAL is not restored until deeper inside and stable long enough.
        release_limit=max(0.0,self.policy.caution_fraction-self.policy.hysteresis_fraction)
        if self._last>=RecoveryDisposition.DERATE and disp==RecoveryDisposition.NOMINAL:
            if frac>release_limit:
                disp=RecoveryDisposition.HOLD;reason="hysteresis prevents premature return to nominal"
                self._inside_since=None
            else:
                if self._inside_since is None:self._inside_since=now_s
                if now_s-self._inside_since<self.policy.dwell_s:
                    disp=RecoveryDisposition.HOLD;reason="recovery dwell time not yet satisfied"
                else:self._inside_since=None
        else:
            if disp!=RecoveryDisposition.NOMINAL:self._inside_since=None
        self._last=disp
        # DERATE fraction is a bounded request to RT, not a direct actuator command.
        derate=0.0 if disp<RecoveryDisposition.DERATE else min(.5,max(.05,frac-self.policy.caution_fraction))
        return RecoveryAssessment(disp,disp<RecoveryDisposition.HOLD,derate,reach.reachable,reach.minimum_time_s,reason,state.provenance)

def map_physics_disposition(d:PhysicsSafetyDisposition)->RecoveryDisposition:
    return {PhysicsSafetyDisposition.NOMINAL:RecoveryDisposition.NOMINAL,PhysicsSafetyDisposition.CAUTION:RecoveryDisposition.DERATE,
            PhysicsSafetyDisposition.HOLD:RecoveryDisposition.HOLD,PhysicsSafetyDisposition.ABORT:RecoveryDisposition.ABORT,
            PhysicsSafetyDisposition.TRIP:RecoveryDisposition.TRIP}[d]

def guardian_safe_state_contract(a:RecoveryAssessment)->dict:
    return {"schema":"JOE-GUARDIAN-SAFE-STATE/1","authority":"READ_ONLY_ADVISORY","may_command":False,"may_override":False,
            "disposition":a.disposition.name,"may_progress":a.may_progress,"requested_derate_fraction":a.requested_derate_fraction,
            "safe_state_reachable":a.safe_state_reachable,"minimum_recovery_time_s":a.minimum_recovery_time_s,"reason":a.reason,
            "provenance":a.provenance,"epistemic_status":a.epistemic_status,
            "truth_boundary":"Recovery is model-conditional until qualified physical sensors/actuators and measured shutdown dynamics exist."}

def safe_state_release_readiness()->dict:
    checks=[];failures=[]
    try:
        p=RecoveryPolicy(-1,1,dwell_s=.5,max_control_rate=2)
        s=AdaptiveSafeStateSupervisor(p)
        if s.assess(RecoveryState(0,.01,0,0),0,2).disposition==RecoveryDisposition.NOMINAL:checks.append("nominal safe-state assessment passed")
        s=AdaptiveSafeStateSupervisor(p)
        if s.assess(RecoveryState(.75,.1,.1,.1),0,2).disposition==RecoveryDisposition.DERATE:checks.append("uncertainty-aware DERATE passed")
        s=AdaptiveSafeStateSupervisor(p)
        if s.assess(RecoveryState(.95,.02,.1,.1),0,2).disposition==RecoveryDisposition.CONTROLLED_RECOVERY:checks.append("controlled recovery band passed")
        if s.assess(RecoveryState(0,0,0,0,False),1,2).disposition==RecoveryDisposition.HOLD:checks.append("model-invalid HOLD passed")
        if s.assess(RecoveryState(0,0,0,0,True,True),1,2).disposition==RecoveryDisposition.TRIP:checks.append("hardware-fault TRIP separation passed")
        if not safe_state_reachability(10,0,1,1).reachable:checks.append("safe-state reachability lockout passed")
        a=AdaptiveSafeStateSupervisor(p).assess(RecoveryState(0,0,0,0),0,2)
        if guardian_safe_state_contract(a)["authority"]=="READ_ONLY_ADVISORY":checks.append("Guardian authority boundary passed")
    except Exception as exc:failures.append(f"{type(exc).__name__}: {exc}")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),"notes":(
        "DERATE/RECOVERY are bounded RT policy requests, not direct hardware commands.",
        "Model-invalid conditions HOLD; independently qualified hardware faults use the deterministic TRIP path.",
        "No physical actuator, energy dump, shutter, PLC/FPGA, or BUS-SAFE timing is claimed.")}
