from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.integrated_qualification import IntegratedQualifier,guardian_qualification_contract,workflow_release_readiness,qualification_reference_workflow,qualify_scientific_workflow,persistence_release_readiness,qualify_artifact_traceability,qualification_artifact_fixture,final_v15_release_qualification,guardian_final_release_contract,build_release_manifest
QUAL_MODULE=ModuleDescriptor(module_id="journeyman.integrated-qualification",name="JOE Integrated Qualification",version="1.0.0",
 requires=("joe.core",),provides=("joe.integrated-qualification",),consumes=("joe.guardian","joe.rt-control","joe.quantum-runtime","joe.compute-backends"))
class IntegratedQualificationService:
    def __init__(self,runtime,build):self.runtime=runtime;self.build=build;self.last_report=None
    def run(self):self.last_report=IntegratedQualifier(self.runtime,self.build).run();return self.last_report
    def workflow_readiness(self):return workflow_release_readiness()
    def qualify_reference_workflow(self):return qualify_scientific_workflow(qualification_reference_workflow())
    def persistence_readiness(self):return persistence_release_readiness()
    def qualify_reference_artifacts(self):return qualify_artifact_traceability(qualification_artifact_fixture())
    def final_release(self):return final_v15_release_qualification(self.runtime)
    def release_manifest(self):return build_release_manifest()
    def final_guardian_contract(self):return guardian_final_release_contract(self.final_release())
    def guardian_contract(self):
        if self.last_report is None:self.run()
        return guardian_qualification_contract(self.last_report)
class QualificationInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_integrated_qualification_module(runtime:ModuleRuntime,build):
    svc=IntegratedQualificationService(runtime,build);runtime.register(QUAL_MODULE,QualificationInstance(svc))
    runtime.activate("journeyman.integrated-qualification");runtime.publish_service("journeyman.integrated-qualification","joe.integrated-qualification",svc);return svc
