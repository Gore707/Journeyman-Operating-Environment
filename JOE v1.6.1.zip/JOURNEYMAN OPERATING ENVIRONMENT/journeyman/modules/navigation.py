"""Coordinate, Time & 3D Navigation Engine module."""
from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.navigation import CoordinateFrameRegistry,TimeEpochService,TransformGraph
NAV_MODULE=ModuleDescriptor(module_id="journeyman.navigation",name="Coordinate, Time & 3D Navigation Engine",version="1.0.0",
 description="Typed coordinate-frame, epoch/time, uncertainty and state-vector contracts.",
 requires=("joe.core","journeyman.registry"),provides=("joe.navigation","joe.time-epoch"),
 consumes=("joe.scientific-registry","joe.units","joe.state-events"))
class NavigationService:
    def __init__(self,objects):self.frames=CoordinateFrameRegistry(objects);self.time=TimeEpochService();self.transforms=TransformGraph()
class NavigationInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_navigation_module(runtime:ModuleRuntime):
    svc=NavigationService(runtime.service("joe.scientific-registry"))
    runtime.register(NAV_MODULE,NavigationInstance(svc));runtime.activate("journeyman.navigation")
    runtime.publish_service("journeyman.navigation","joe.navigation",svc)
    runtime.publish_service("journeyman.navigation","joe.time-epoch",svc.time)
    return svc
