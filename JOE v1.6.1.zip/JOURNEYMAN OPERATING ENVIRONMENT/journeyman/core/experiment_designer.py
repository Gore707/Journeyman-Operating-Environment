"""Experiment Designer / Sequencer core — EXP-001A.

Versioned, deterministic experiment definitions for research/SIMULATION execution.
This is not the BUS-SAFE or deterministic hardware-control state machine.
"""
from __future__ import annotations
from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Any
from uuid import uuid4
import hashlib, json, math

from .state_events import DataOrigin

class ExperimentStatus(str,Enum):
    PASS="PASS"
    DOMAIN_INVALID="DOMAIN_INVALID"
    INPUT_INCONSISTENT="INPUT_INCONSISTENT"
    MODEL_UNAVAILABLE="MODEL_UNAVAILABLE"
    UNKNOWN_PHYSICS="UNKNOWN_PHYSICS"

class ExperimentLifecycle(str,Enum):
    DRAFT="DRAFT"
    VALIDATED="VALIDATED"
    READY="READY"
    RUNNING="RUNNING"
    PAUSED="PAUSED"
    COMPLETED="COMPLETED"
    ABORTED="ABORTED"

class StepKind(str,Enum):
    CONFIGURE="CONFIGURE"
    CHECK="CHECK"
    WAIT="WAIT"
    SAMPLE="SAMPLE"
    COMPUTE="COMPUTE"
    MARK="MARK"

@dataclass(frozen=True)
class ParameterSnapshot:
    revision_id:str
    values:dict[str,Any]
    provenance:str
    digest_sha256:str
    origin:DataOrigin=DataOrigin.SOFTWARE

def parameter_snapshot(values:dict[str,Any],*,revision_id:str,provenance:str)->ParameterSnapshot:
    if not revision_id.strip() or not provenance.strip():raise ValueError("revision/provenance required")
    payload=json.dumps(values,sort_keys=True,separators=(",",":"),default=str)
    return ParameterSnapshot(revision_id,dict(values),provenance,hashlib.sha256(payload.encode()).hexdigest())

@dataclass(frozen=True)
class Prerequisite:
    prerequisite_id:str
    description:str
    satisfied:bool
    evidence:str
    def __post_init__(self):
        if not self.prerequisite_id.strip() or not self.description.strip():raise ValueError("prerequisite identity/description required")
        if self.satisfied and not self.evidence.strip():raise ValueError("satisfied prerequisite requires evidence")

@dataclass(frozen=True)
class ExperimentStep:
    step_id:str
    name:str
    kind:StepKind
    duration_s:float
    prerequisites:tuple[Prerequisite,...]=()
    parameters:dict[str,Any]=field(default_factory=dict)
    provenance:str="JOE experiment definition"
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if self.origin!=DataOrigin.SIMULATION:raise ValueError("EXP-001A executable steps are SIMULATION only")
        if not self.step_id.strip() or not self.name.strip() or not self.provenance.strip():raise ValueError("step identity/name/provenance required")
        if not math.isfinite(self.duration_s) or self.duration_s<0:raise ValueError("nonnegative finite duration required")

@dataclass(frozen=True)
class ExperimentPhase:
    phase_id:str
    name:str
    steps:tuple[ExperimentStep,...]
    provenance:str
    def __post_init__(self):
        if not self.phase_id.strip() or not self.name.strip() or not self.provenance.strip():raise ValueError("phase identity/name/provenance required")
        ids=[x.step_id for x in self.steps]
        if len(ids)!=len(set(ids)):raise ValueError("duplicate step identity in phase")

@dataclass(frozen=True)
class ExperimentPlan:
    experiment_id:str
    name:str
    revision:int
    parameter_snapshot:ParameterSnapshot
    phases:tuple[ExperimentPhase,...]
    provenance:str
    lifecycle:ExperimentLifecycle=ExperimentLifecycle.DRAFT
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if self.origin!=DataOrigin.SIMULATION:raise ValueError("EXP-001A plans are SIMULATION only")
        if not self.experiment_id.strip() or not self.name.strip() or not self.provenance.strip():raise ValueError("experiment identity/name/provenance required")
        if self.revision<1:raise ValueError("revision must be >= 1")
        ids=[x.phase_id for x in self.phases]
        if len(ids)!=len(set(ids)):raise ValueError("duplicate phase identity")

def create_experiment_plan(name:str,snapshot:ParameterSnapshot,phases=(),*,provenance:str="JOE Experiment Designer")->ExperimentPlan:
    return ExperimentPlan(str(uuid4()),name,1,snapshot,tuple(phases),provenance)

def revise_experiment_plan(plan:ExperimentPlan,*,phases=None,snapshot=None)->ExperimentPlan:
    if plan.lifecycle in (ExperimentLifecycle.RUNNING,ExperimentLifecycle.COMPLETED,ExperimentLifecycle.ABORTED):
        raise ValueError("running/finalized plan cannot be revised in place")
    return replace(plan,revision=plan.revision+1,phases=tuple(phases) if phases is not None else plan.phases,
                   parameter_snapshot=snapshot or plan.parameter_snapshot,lifecycle=ExperimentLifecycle.DRAFT)

@dataclass(frozen=True)
class PlanValidation:
    status:ExperimentStatus
    valid:bool
    failures:tuple[str,...]
    warnings:tuple[str,...]
    total_duration_s:float
    step_count:int

def validate_experiment_plan(plan:ExperimentPlan)->PlanValidation:
    failures=[];warnings=[];seen=set();duration=0.;count=0
    if not plan.phases:failures.append("experiment contains no phases")
    for phase in plan.phases:
        if not phase.steps:warnings.append(f"phase {phase.phase_id} contains no steps")
        for step in phase.steps:
            count+=1;duration+=step.duration_s
            if step.step_id in seen:failures.append(f"duplicate global step identity: {step.step_id}")
            seen.add(step.step_id)
            for req in step.prerequisites:
                if not req.satisfied:failures.append(f"unsatisfied prerequisite {req.prerequisite_id} for step {step.step_id}")
    return PlanValidation(ExperimentStatus.PASS if not failures else ExperimentStatus.INPUT_INCONSISTENT,
                          not failures,tuple(failures),tuple(warnings),duration,count)

def validate_plan(plan:ExperimentPlan)->ExperimentPlan:
    q=validate_experiment_plan(plan)
    if not q.valid:raise ValueError("; ".join(q.failures))
    return replace(plan,lifecycle=ExperimentLifecycle.VALIDATED)

def ready_plan(plan:ExperimentPlan)->ExperimentPlan:
    if plan.lifecycle!=ExperimentLifecycle.VALIDATED:raise ValueError("plan must be VALIDATED before READY")
    return replace(plan,lifecycle=ExperimentLifecycle.READY)

@dataclass(frozen=True)
class SequencerCursor:
    phase_index:int=0
    step_index:int=0
    elapsed_in_step_s:float=0.0

@dataclass(frozen=True)
class SequencerEvent:
    sequence:int
    event_type:str
    experiment_id:str
    phase_id:str|None
    step_id:str|None
    simulation_time_s:float
    message:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

@dataclass(frozen=True)
class SequencerState:
    plan:ExperimentPlan
    cursor:SequencerCursor
    simulation_time_s:float
    sequence:int
    events:tuple[SequencerEvent,...]

class SimulationSequencer:
    """Deterministic research sequencer; no hardware actuator binding."""
    def __init__(self,plan:ExperimentPlan,*,provenance:str="JOE simulation sequencer"):
        if plan.lifecycle!=ExperimentLifecycle.READY:raise ValueError("sequencer requires READY plan")
        self.provenance=provenance;self.state=SequencerState(plan,SequencerCursor(),0.,0,())
    def _emit(self,event_type,message,phase=None,step=None):
        s=self.state;ev=SequencerEvent(s.sequence+1,event_type,s.plan.experiment_id,
            phase.phase_id if phase else None,step.step_id if step else None,s.simulation_time_s,message,self.provenance)
        self.state=replace(s,sequence=s.sequence+1,events=s.events+(ev,))
    def start(self):
        if self.state.plan.lifecycle!=ExperimentLifecycle.READY:raise ValueError("sequencer is not READY")
        self.state=replace(self.state,plan=replace(self.state.plan,lifecycle=ExperimentLifecycle.RUNNING))
        self._emit("START","SIMULATION experiment started")
    def pause(self):
        if self.state.plan.lifecycle!=ExperimentLifecycle.RUNNING:raise ValueError("sequencer is not RUNNING")
        self.state=replace(self.state,plan=replace(self.state.plan,lifecycle=ExperimentLifecycle.PAUSED));self._emit("PAUSE","SIMULATION experiment paused")
    def resume(self):
        if self.state.plan.lifecycle!=ExperimentLifecycle.PAUSED:raise ValueError("sequencer is not PAUSED")
        self.state=replace(self.state,plan=replace(self.state.plan,lifecycle=ExperimentLifecycle.RUNNING));self._emit("RESUME","SIMULATION experiment resumed")
    def abort(self,reason:str):
        if self.state.plan.lifecycle not in (ExperimentLifecycle.RUNNING,ExperimentLifecycle.PAUSED):raise ValueError("only active experiment can abort")
        self.state=replace(self.state,plan=replace(self.state.plan,lifecycle=ExperimentLifecycle.ABORTED));self._emit("ABORT",f"SIMULATION abort: {reason}")
    def current(self):
        c=self.state.cursor;p=self.state.plan
        if c.phase_index>=len(p.phases):return None,None
        phase=p.phases[c.phase_index]
        if c.step_index>=len(phase.steps):return phase,None
        return phase,phase.steps[c.step_index]
    def advance(self,dt_s:float):
        dt=float(dt_s)
        if self.state.plan.lifecycle!=ExperimentLifecycle.RUNNING:raise ValueError("sequencer must be RUNNING")
        if not math.isfinite(dt) or dt<=0:raise ValueError("positive finite advance required")
        remaining=dt
        while remaining>0 and self.state.plan.lifecycle==ExperimentLifecycle.RUNNING:
            phase,step=self.current()
            if step is None:
                c=self.state.cursor
                if phase is not None and c.phase_index+1<len(self.state.plan.phases):
                    self.state=replace(self.state,cursor=SequencerCursor(c.phase_index+1,0,0));continue
                self.state=replace(self.state,plan=replace(self.state.plan,lifecycle=ExperimentLifecycle.COMPLETED))
                self._emit("COMPLETE","SIMULATION experiment completed");break
            c=self.state.cursor;need=step.duration_s-c.elapsed_in_step_s
            take=min(remaining,need) if need>0 else 0
            self.state=replace(self.state,simulation_time_s=self.state.simulation_time_s+take,
                               cursor=replace(c,elapsed_in_step_s=c.elapsed_in_step_s+take))
            remaining-=take
            if need<=take:
                self._emit("STEP_COMPLETE",f"Completed SIMULATION step {step.name}",phase,step)
                self.state=replace(self.state,cursor=SequencerCursor(c.phase_index,c.step_index+1,0))
            if take==0 and need>0:break
        return self.state

@dataclass(frozen=True)
class ExperimentGuardianContract:
    schema:str
    status:str
    facts:dict[str,Any]
    provenance:str
    authority:str

def experiment_guardian_contract(state:SequencerState)->ExperimentGuardianContract:
    phase,step=(None,None)
    c=state.cursor
    if c.phase_index<len(state.plan.phases):
        phase=state.plan.phases[c.phase_index]
        if c.step_index<len(phase.steps):step=phase.steps[c.step_index]
    facts={"experiment_id":state.plan.experiment_id,"name":state.plan.name,"revision":state.plan.revision,
           "lifecycle":state.plan.lifecycle.value,"origin":state.plan.origin.value,
           "parameter_revision":state.plan.parameter_snapshot.revision_id,
           "parameter_digest_sha256":state.plan.parameter_snapshot.digest_sha256,
           "simulation_time_s":state.simulation_time_s,"sequence":state.sequence,
           "current_phase_id":phase.phase_id if phase else None,"current_step_id":step.step_id if step else None,
           "current_step_kind":step.kind.value if step else None,
           "event_count":len(state.events)}
    return ExperimentGuardianContract("JOE-GUARDIAN-EXPERIMENT/1",ExperimentStatus.PASS.value,facts,state.plan.provenance,
        "READ_ONLY_ADVISORY; Guardian may inspect intent/prerequisites/progress and recommend HOLD/ABORT, but cannot bypass BUS-SAFE or deterministic control/interlocks")

@dataclass(frozen=True)
class ExperimentReleaseReadiness:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    notes:tuple[str,...]

def experiment_core_readiness()->ExperimentReleaseReadiness:
    checks=[];fail=[]
    try:
        snap=parameter_snapshot({"test":1},revision_id="r1",provenance="EXP readiness")
        req=Prerequisite("r","declared test prerequisite",True,"unit-test evidence")
        step=ExperimentStep("s","wait",StepKind.WAIT,.1,(req,),provenance="EXP readiness")
        plan=create_experiment_plan("readiness",snap,(ExperimentPhase("p","phase",(step,),"EXP readiness"),),provenance="EXP readiness")
        q=validate_experiment_plan(plan)
        if q.valid and q.step_count==1:checks.append("plan/prerequisite validation passed")
        plan=ready_plan(validate_plan(plan));seq=SimulationSequencer(plan);seq.start();seq.advance(.1);seq.advance(.001)
        if seq.state.plan.lifecycle==ExperimentLifecycle.COMPLETED:checks.append("deterministic SIMULATION sequencing passed")
        if experiment_guardian_contract(seq.state).schema=="JOE-GUARDIAN-EXPERIMENT/1":checks.append("Guardian intent/progress contract passed")
        if snap.digest_sha256:checks.append("parameter snapshot digest passed")
    except Exception as exc:fail.append(f"{type(exc).__name__}: {exc}")
    return ExperimentReleaseReadiness(not fail,tuple(checks),tuple(fail),(
        "EXP-001A qualifies experiment-definition and SIMULATION sequencing software only.",
        "No hardware actuator, BUS-SAFE, or deterministic real-time control binding is provided by this module."))


class ConstraintOperator(str,Enum):
    LT="LT"; LE="LE"; EQ="EQ"; GE="GE"; GT="GT"

class FailurePolicy(str,Enum):
    HOLD="HOLD"
    ABORT="ABORT"
    CONTINUE_WITH_WARNING="CONTINUE_WITH_WARNING"

@dataclass(frozen=True)
class ExperimentConstraint:
    constraint_id:str
    variable:str
    operator:ConstraintOperator
    threshold:float
    unit:str
    failure_policy:FailurePolicy
    description:str
    provenance:str
    def __post_init__(self):
        if not all(str(x).strip() for x in (self.constraint_id,self.variable,self.unit,self.description,self.provenance)):
            raise ValueError("constraint identity/variable/unit/description/provenance required")
        if not math.isfinite(self.threshold):raise ValueError("finite threshold required")

@dataclass(frozen=True)
class ConstraintEvidence:
    constraint_id:str
    variable:str
    value:float
    unit:str
    passed:bool
    failure_policy:FailurePolicy
    message:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def evaluate_constraint(constraint:ExperimentConstraint,value:float,unit:str,*,provenance:str)->ConstraintEvidence:
    v=float(value)
    if not math.isfinite(v):raise ValueError("constraint value must be finite")
    if unit!=constraint.unit:raise ValueError("constraint evaluation requires compatible declared unit")
    op=constraint.operator
    ok={ConstraintOperator.LT:v<constraint.threshold,ConstraintOperator.LE:v<=constraint.threshold,
        ConstraintOperator.EQ:v==constraint.threshold,ConstraintOperator.GE:v>=constraint.threshold,
        ConstraintOperator.GT:v>constraint.threshold}[op]
    return ConstraintEvidence(constraint.constraint_id,constraint.variable,v,unit,ok,constraint.failure_policy,
        f"SIMULATION constraint {'passed' if ok else 'failed'}: {constraint.variable} {op.value} {constraint.threshold} {unit}",
        provenance)

@dataclass(frozen=True)
class StepDependency:
    step_id:str
    depends_on_step_ids:tuple[str,...]
    def __post_init__(self):
        if not self.step_id.strip():raise ValueError("dependency step identity required")
        if self.step_id in self.depends_on_step_ids:raise ValueError("step cannot depend on itself")

@dataclass(frozen=True)
class DecisionGate:
    gate_id:str
    name:str
    constraints:tuple[ExperimentConstraint,...]
    pass_step_id:str|None
    fail_step_id:str|None
    provenance:str
    def __post_init__(self):
        if not self.gate_id.strip() or not self.name.strip() or not self.provenance.strip():raise ValueError("gate identity/name/provenance required")
        if not self.constraints:raise ValueError("decision gate requires constraints")

@dataclass(frozen=True)
class DecisionGateResult:
    gate_id:str
    passed:bool
    next_step_id:str|None
    evidence:tuple[ConstraintEvidence,...]
    recommended_action:str
    provenance:str

def evaluate_decision_gate(gate:DecisionGate,values:dict[str,tuple[float,str]],*,provenance:str)->DecisionGateResult:
    evidence=[]
    for c in gate.constraints:
        if c.variable not in values:raise ValueError(f"missing gate variable: {c.variable}")
        value,unit=values[c.variable];evidence.append(evaluate_constraint(c,value,unit,provenance=provenance))
    failed=[x for x in evidence if not x.passed]
    passed=not failed
    if any(x.failure_policy==FailurePolicy.ABORT for x in failed):action="ABORT"
    elif any(x.failure_policy==FailurePolicy.HOLD for x in failed):action="HOLD"
    elif failed:action="CONTINUE_WITH_WARNING"
    else:action="CONTINUE"
    return DecisionGateResult(gate.gate_id,passed,gate.pass_step_id if passed else gate.fail_step_id,tuple(evidence),action,provenance)

@dataclass(frozen=True)
class TimeoutPolicy:
    timeout_s:float
    failure_policy:FailurePolicy
    def __post_init__(self):
        if not math.isfinite(self.timeout_s) or self.timeout_s<=0:raise ValueError("timeout must be positive and finite")

@dataclass(frozen=True)
class ExecutionBinding:
    experiment_id:str
    plan_revision:int
    parameter_revision_id:str
    parameter_digest_sha256:str
    digital_twin_revision:int|None
    digital_twin_simulation_time_s:float|None
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def bind_execution_context(plan:ExperimentPlan,*,digital_twin_state=None,provenance:str)->ExecutionBinding:
    if plan.lifecycle not in (ExperimentLifecycle.VALIDATED,ExperimentLifecycle.READY):
        raise ValueError("execution binding requires VALIDATED or READY plan")
    dt_rev=dt_time=None
    if digital_twin_state is not None:
        if getattr(digital_twin_state,"origin",DataOrigin.SIMULATION)!=DataOrigin.SIMULATION:
            raise ValueError("EXP-001B Digital Twin binding is SIMULATION only")
        dt_rev=int(digital_twin_state.revision);dt_time=float(digital_twin_state.clock.simulation_time_s)
    return ExecutionBinding(plan.experiment_id,plan.revision,plan.parameter_snapshot.revision_id,
        plan.parameter_snapshot.digest_sha256,dt_rev,dt_time,provenance)

@dataclass(frozen=True)
class DependencyAssessment:
    valid:bool
    failures:tuple[str,...]

def validate_step_dependencies(plan:ExperimentPlan,dependencies:tuple[StepDependency,...])->DependencyAssessment:
    order=[] 
    for phase in plan.phases:
        order.extend(x.step_id for x in phase.steps)
    index={x:i for i,x in enumerate(order)};fail=[]
    for dep in dependencies:
        if dep.step_id not in index:fail.append(f"unknown dependent step: {dep.step_id}");continue
        for parent in dep.depends_on_step_ids:
            if parent not in index:fail.append(f"unknown prerequisite step: {parent}")
            elif index[parent]>=index[dep.step_id]:fail.append(f"dependency {parent}->{dep.step_id} is not strictly prior in deterministic sequence")
    return DependencyAssessment(not fail,tuple(fail))

@dataclass(frozen=True)
class SupervisoryRecommendation:
    action:str
    reasons:tuple[str,...]
    authority:str

def supervisory_recommendation(evidence:tuple[ConstraintEvidence,...],*,timed_out:bool=False,
                               timeout_policy:TimeoutPolicy|None=None)->SupervisoryRecommendation:
    failed=[x for x in evidence if not x.passed];reasons=[x.message for x in failed]
    policies=[x.failure_policy for x in failed]
    if timed_out:
        if timeout_policy is None:raise ValueError("timeout policy required when timed_out")
        policies.append(timeout_policy.failure_policy);reasons.append(f"SIMULATION timeout exceeded {timeout_policy.timeout_s} s")
    if FailurePolicy.ABORT in policies:action="RECOMMEND_ABORT"
    elif FailurePolicy.HOLD in policies:action="RECOMMEND_HOLD"
    elif policies:action="CAUTION"
    else:action="CONTINUE"
    return SupervisoryRecommendation(action,tuple(reasons),
        "ADVISORY ONLY; recommendation cannot execute BUS-SAFE, interlock, or hardware-control action")

def expanded_experiment_guardian_contract(state:SequencerState,*,binding:ExecutionBinding|None=None,
                                          gate:DecisionGateResult|None=None,
                                          recommendation:SupervisoryRecommendation|None=None)->ExperimentGuardianContract:
    base=experiment_guardian_contract(state);facts=dict(base.facts)
    if binding:facts["execution_binding"]={"plan_revision":binding.plan_revision,"parameter_revision_id":binding.parameter_revision_id,
        "parameter_digest_sha256":binding.parameter_digest_sha256,"digital_twin_revision":binding.digital_twin_revision,
        "digital_twin_simulation_time_s":binding.digital_twin_simulation_time_s,"origin":binding.origin.value}
    if gate:facts["decision_gate"]={"gate_id":gate.gate_id,"passed":gate.passed,"next_step_id":gate.next_step_id,
        "recommended_action":gate.recommended_action,"evidence":[{"constraint_id":x.constraint_id,"variable":x.variable,
        "value":x.value,"unit":x.unit,"passed":x.passed,"failure_policy":x.failure_policy.value,"message":x.message} for x in gate.evidence]}
    if recommendation:facts["supervisory_recommendation"]={"action":recommendation.action,"reasons":recommendation.reasons,
        "authority":recommendation.authority}
    return ExperimentGuardianContract(base.schema,base.status,facts,base.provenance,base.authority)


@dataclass(frozen=True)
class RunManifest:
    run_id:str
    experiment_id:str
    plan_revision:int
    parameter_revision_id:str
    parameter_digest_sha256:str
    digital_twin_revision:int|None
    started_simulation_time_s:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def create_run_manifest(binding:ExecutionBinding,*,simulation_time_s:float=0.0,provenance:str)->RunManifest:
    if not math.isfinite(simulation_time_s) or simulation_time_s<0:raise ValueError("valid simulation start time required")
    return RunManifest(str(uuid4()),binding.experiment_id,binding.plan_revision,binding.parameter_revision_id,
        binding.parameter_digest_sha256,binding.digital_twin_revision,float(simulation_time_s),provenance)

@dataclass(frozen=True)
class ExecutionEvidence:
    sequence:int
    run_id:str
    simulation_time_s:float
    phase_id:str|None
    step_id:str|None
    evidence_type:str
    payload:dict[str,Any]
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

@dataclass(frozen=True)
class SequencerCheckpoint:
    run_id:str
    plan_revision:int
    parameter_digest_sha256:str
    lifecycle:ExperimentLifecycle
    cursor:SequencerCursor
    simulation_time_s:float
    sequence:int
    completed_step_ids:tuple[str,...]
    provenance:str

class BranchingSimulationSequencer(SimulationSequencer):
    """Adds deterministic decision branching, timeout policy and replayable checkpoints."""
    def __init__(self,plan:ExperimentPlan,binding:ExecutionBinding,*,dependencies=(),provenance="JOE branching simulation sequencer"):
        dep=validate_step_dependencies(plan,tuple(dependencies))
        if not dep.valid:raise ValueError("; ".join(dep.failures))
        super().__init__(plan,provenance=provenance)
        self.binding=binding;self.manifest=create_run_manifest(binding,provenance=provenance)
        self.dependencies=tuple(dependencies);self.completed=[];self.evidence=[]
    def _flat_steps(self):
        out=[]
        for pi,phase in enumerate(self.state.plan.phases):
            for si,step in enumerate(phase.steps):out.append((pi,si,phase,step))
        return out
    def _jump_to_step(self,step_id:str):
        for pi,si,phase,step in self._flat_steps():
            if step.step_id==step_id:
                self.state=replace(self.state,cursor=SequencerCursor(pi,si,0))
                self._emit("BRANCH",f"SIMULATION branch to step {step_id}",phase,step);return
        raise ValueError(f"unknown branch target: {step_id}")
    def dependencies_satisfied(self,step_id:str)->bool:
        req=set()
        for d in self.dependencies:
            if d.step_id==step_id:req.update(d.depends_on_step_ids)
        return req.issubset(set(self.completed))
    def evaluate_gate(self,gate:DecisionGate,values:dict[str,tuple[float,str]]):
        phase,step=self.current()
        if step and not self.dependencies_satisfied(step.step_id):raise ValueError("current step dependencies are not satisfied")
        q=evaluate_decision_gate(gate,values,provenance=self.provenance)
        self.evidence.append(ExecutionEvidence(len(self.evidence)+1,self.manifest.run_id,self.state.simulation_time_s,
            phase.phase_id if phase else None,step.step_id if step else None,"DECISION_GATE",
            {"gate_id":q.gate_id,"passed":q.passed,"next_step_id":q.next_step_id,"recommended_action":q.recommended_action,
             "constraints":[{"id":x.constraint_id,"value":x.value,"unit":x.unit,"passed":x.passed} for x in q.evidence]},self.provenance))
        if q.recommended_action=="ABORT":
            if self.state.plan.lifecycle==ExperimentLifecycle.RUNNING:self.abort(f"decision gate {q.gate_id}")
            return q
        if q.recommended_action=="HOLD":
            if self.state.plan.lifecycle==ExperimentLifecycle.RUNNING:self.pause()
            return q
        if q.next_step_id:self._jump_to_step(q.next_step_id)
        return q
    def timeout(self,policy:TimeoutPolicy):
        rec=supervisory_recommendation((),timed_out=True,timeout_policy=policy)
        phase,step=self.current()
        self.evidence.append(ExecutionEvidence(len(self.evidence)+1,self.manifest.run_id,self.state.simulation_time_s,
            phase.phase_id if phase else None,step.step_id if step else None,"TIMEOUT",
            {"timeout_s":policy.timeout_s,"failure_policy":policy.failure_policy.value,"recommendation":rec.action},self.provenance))
        if rec.action=="RECOMMEND_ABORT" and self.state.plan.lifecycle==ExperimentLifecycle.RUNNING:self.abort("timeout policy")
        elif rec.action=="RECOMMEND_HOLD" and self.state.plan.lifecycle==ExperimentLifecycle.RUNNING:self.pause()
        return rec
    def advance(self,dt_s:float):
        before={(e.event_type,e.step_id,e.sequence) for e in self.state.events}
        q=super().advance(dt_s)
        for ev in q.events:
            key=(ev.event_type,ev.step_id,ev.sequence)
            if key not in before and ev.event_type=="STEP_COMPLETE" and ev.step_id and ev.step_id not in self.completed:
                self.completed.append(ev.step_id)
        return q
    def checkpoint(self)->SequencerCheckpoint:
        return SequencerCheckpoint(self.manifest.run_id,self.state.plan.revision,self.state.plan.parameter_snapshot.digest_sha256,
            self.state.plan.lifecycle,self.state.cursor,self.state.simulation_time_s,self.state.sequence,tuple(self.completed),self.provenance)
    def restore_checkpoint(self,checkpoint:SequencerCheckpoint):
        if checkpoint.run_id!=self.manifest.run_id:raise ValueError("checkpoint run identity mismatch")
        if checkpoint.plan_revision!=self.state.plan.revision:raise ValueError("checkpoint plan revision mismatch")
        if checkpoint.parameter_digest_sha256!=self.state.plan.parameter_snapshot.digest_sha256:raise ValueError("checkpoint parameter digest mismatch")
        self.state=replace(self.state,plan=replace(self.state.plan,lifecycle=checkpoint.lifecycle),cursor=checkpoint.cursor,
                           simulation_time_s=checkpoint.simulation_time_s,sequence=checkpoint.sequence)
        self.completed=list(checkpoint.completed_step_ids)
        return self.state

@dataclass(frozen=True)
class TwinExecutionSynchronization:
    status:ExperimentStatus
    experiment_time_s:float
    twin_time_s:float
    time_delta_s:float
    experiment_plan_revision:int
    twin_revision:int
    synchronized:bool
    tolerance_s:float
    message:str
    provenance:str

def synchronize_experiment_with_twin(state:SequencerState,twin_state,*,tolerance_s:float=1e-9,provenance:str)->TwinExecutionSynchronization:
    if tolerance_s<0 or not math.isfinite(tolerance_s):raise ValueError("nonnegative finite tolerance required")
    et=float(state.simulation_time_s);tt=float(twin_state.clock.simulation_time_s);delta=tt-et
    ok=abs(delta)<=tolerance_s
    return TwinExecutionSynchronization(ExperimentStatus.PASS if ok else ExperimentStatus.INPUT_INCONSISTENT,
        et,tt,delta,state.plan.revision,int(twin_state.revision),ok,tolerance_s,
        "Experiment and Digital Twin simulation clocks are synchronized." if ok else
        "Experiment and Digital Twin simulation clocks differ beyond declared tolerance; execution must not silently resynchronize.",
        provenance)

def execution_guardian_contract(sequencer:BranchingSimulationSequencer,*,twin_sync:TwinExecutionSynchronization|None=None)->ExperimentGuardianContract:
    base=expanded_experiment_guardian_contract(sequencer.state,binding=sequencer.binding);facts=dict(base.facts)
    facts["run_manifest"]={"run_id":sequencer.manifest.run_id,"plan_revision":sequencer.manifest.plan_revision,
        "parameter_digest_sha256":sequencer.manifest.parameter_digest_sha256,"origin":sequencer.manifest.origin.value}
    facts["checkpoint_capable"]=True;facts["completed_step_ids"]=tuple(sequencer.completed);facts["evidence_count"]=len(sequencer.evidence)
    if twin_sync:facts["digital_twin_synchronization"]={"status":twin_sync.status.value,"experiment_time_s":twin_sync.experiment_time_s,
        "twin_time_s":twin_sync.twin_time_s,"time_delta_s":twin_sync.time_delta_s,"twin_revision":twin_sync.twin_revision,
        "synchronized":twin_sync.synchronized,"tolerance_s":twin_sync.tolerance_s,"message":twin_sync.message}
    status=ExperimentStatus.INPUT_INCONSISTENT.value if twin_sync and not twin_sync.synchronized else base.status
    return ExperimentGuardianContract(base.schema,status,facts,base.provenance,base.authority)


def experiment_v1_release_readiness()->ExperimentReleaseReadiness:
    checks=[];fail=[]
    try:
        snap=parameter_snapshot({"r0_m":100.0,"mode":"simulation"},revision_id="mpr-readiness",provenance="EXP v1 readiness")
        req=Prerequisite("mpr","MPR snapshot present",True,"snapshot digest verified")
        steps=(ExperimentStep("configure","Configure model",StepKind.CONFIGURE,0.1,(req,),provenance="EXP v1 readiness"),
               ExperimentStep("sample","Sample twin",StepKind.SAMPLE,0.2,provenance="EXP v1 readiness"))
        plan=create_experiment_plan("EXP v1 readiness",snap,(ExperimentPhase("phase-1","Qualification",steps,"EXP v1 readiness"),),provenance="EXP v1 readiness")
        v=validate_experiment_plan(plan)
        if v.valid and v.step_count==2:checks.append("versioned plan/phase/step validation passed")
        ready=ready_plan(validate_plan(plan));binding=bind_execution_context(ready,provenance="EXP v1 readiness")
        seq=BranchingSimulationSequencer(ready,binding,provenance="EXP v1 readiness")
        seq.start();seq.advance(.1);cp=seq.checkpoint()
        if cp.parameter_digest_sha256==snap.digest_sha256:checks.append("run/checkpoint parameter binding passed")
        seq.advance(.2);seq.advance(.001)
        if seq.state.plan.lifecycle==ExperimentLifecycle.COMPLETED:checks.append("deterministic simulation execution passed")
        if seq.manifest.run_id and seq.completed==["configure","sample"]:checks.append("run manifest/completed-step evidence passed")
        g=execution_guardian_contract(seq)
        if g.schema=="JOE-GUARDIAN-EXPERIMENT/1" and "run_manifest" in g.facts:checks.append("Guardian execution contract passed")
        c=ExperimentConstraint("limit","x",ConstraintOperator.LE,1.0,"m",FailurePolicy.HOLD,"qualification constraint","EXP v1 readiness")
        gate=evaluate_decision_gate(DecisionGate("gate","Qualification gate",(c,),None,None,"EXP v1 readiness"),{"x":(.5,"m")},provenance="EXP v1 readiness")
        if gate.passed:checks.append("constraint/decision-gate evidence passed")
    except Exception as exc:fail.append(f"{type(exc).__name__}: {exc}")
    return ExperimentReleaseReadiness(not fail,tuple(checks),tuple(fail),(
        "Experiment Designer v1.0 qualifies research/SIMULATION orchestration software only.",
        "It does not bind physical actuators or supersede BUS-SAFE/deterministic real-time control.",
        "Guardian remains READ_ONLY_ADVISORY and cannot cancel trips or rewrite safety thresholds."))
