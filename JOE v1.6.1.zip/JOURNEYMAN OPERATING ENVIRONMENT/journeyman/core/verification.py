"""Independent verification and uncertainty foundation for JOE."""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .state_events import DataOrigin

class VerificationStatus(str,Enum):
    PASS="PASS"
    FAIL="FAIL"
    DOMAIN_INVALID="DOMAIN_INVALID"
    INPUT_INCONSISTENT="INPUT_INCONSISTENT"
    PRECISION_INSUFFICIENT="PRECISION_INSUFFICIENT"
    MODEL_UNAVAILABLE="MODEL_UNAVAILABLE"

class DiscrepancyClass(str,Enum):
    AGREEMENT="AGREEMENT"
    WITHIN_UNCERTAINTY="WITHIN_UNCERTAINTY"
    NUMERICAL="NUMERICAL"
    MODEL="MODEL"
    UNIT_OR_DIMENSION="UNIT_OR_DIMENSION"
    PROVENANCE="PROVENANCE"
    UNRESOLVED="UNRESOLVED"

@dataclass(frozen=True)
class VerificationValue:
    value:float
    unit:str
    standard_uncertainty:float
    source_id:str
    algorithm_id:str
    revision:str
    provenance:str
    origin:DataOrigin=DataOrigin.SOFTWARE
    def __post_init__(self):
        if not math.isfinite(self.value) or not math.isfinite(self.standard_uncertainty) or self.standard_uncertainty<0:
            raise ValueError("finite value and nonnegative finite uncertainty required")
        if not all(str(x).strip() for x in (self.unit,self.source_id,self.algorithm_id,self.revision,self.provenance)):
            raise ValueError("unit/source/algorithm/revision/provenance required")

@dataclass(frozen=True)
class VerificationTolerance:
    absolute:float=0.0
    relative:float=0.0
    sigma:float=3.0
    def __post_init__(self):
        if any(not math.isfinite(x) or x<0 for x in (self.absolute,self.relative,self.sigma)) or self.sigma==0:
            raise ValueError("nonnegative finite tolerances and positive sigma required")

@dataclass(frozen=True)
class VerificationRecord:
    status:VerificationStatus
    discrepancy_class:DiscrepancyClass
    primary:VerificationValue
    independent:VerificationValue
    difference:float|None
    combined_standard_uncertainty:float|None
    normalized_difference_sigma:float|None
    allowed_difference:float|None
    independent_algorithms:bool
    message:str

def compare_independent_results(primary:VerificationValue,independent:VerificationValue,
                                tolerance:VerificationTolerance=VerificationTolerance())->VerificationRecord:
    if primary.unit!=independent.unit:
        return VerificationRecord(VerificationStatus.INPUT_INCONSISTENT,DiscrepancyClass.UNIT_OR_DIMENSION,
            primary,independent,None,None,None,None,primary.algorithm_id!=independent.algorithm_id,
            "Units differ; dimensional/unit conversion must be explicit before numerical comparison.")
    alg_ind=primary.algorithm_id!=independent.algorithm_id
    diff=independent.value-primary.value
    u=math.hypot(primary.standard_uncertainty,independent.standard_uncertainty)
    scale=max(abs(primary.value),abs(independent.value))
    allowed=max(tolerance.absolute,tolerance.relative*scale,tolerance.sigma*u)
    sigma=abs(diff)/u if u>0 else (0.0 if diff==0 else math.inf)
    passed=abs(diff)<=allowed
    if passed:
        cls=DiscrepancyClass.AGREEMENT if diff==0 else DiscrepancyClass.WITHIN_UNCERTAINTY
        status=VerificationStatus.PASS
        msg="Independent results agree within the declared tolerance/uncertainty envelope."
    else:
        cls=DiscrepancyClass.NUMERICAL if alg_ind else DiscrepancyClass.UNRESOLVED
        status=VerificationStatus.FAIL
        msg="Result discrepancy exceeds the declared tolerance/uncertainty envelope and requires investigation."
    if not alg_ind:
        msg+=" Algorithms are not independent; this is a consistency check, not independent verification."
    return VerificationRecord(status,cls,primary,independent,diff,u,sigma,allowed,alg_ind,msg)

@dataclass(frozen=True)
class DimensionSignature:
    length:int=0
    mass:int=0
    time:int=0
    current:int=0
    temperature:int=0
    amount:int=0
    luminous_intensity:int=0

@dataclass(frozen=True)
class DimensionalCheck:
    status:VerificationStatus
    left:DimensionSignature
    right:DimensionSignature
    message:str

def check_dimensions(left:DimensionSignature,right:DimensionSignature)->DimensionalCheck:
    ok=left==right
    return DimensionalCheck(VerificationStatus.PASS if ok else VerificationStatus.INPUT_INCONSISTENT,left,right,
        "Dimensions agree." if ok else "Dimension mismatch: equation/result comparison is invalid until resolved.")

@dataclass(frozen=True)
class ProvenanceCheck:
    status:VerificationStatus
    independent_sources:bool
    independent_algorithms:bool
    message:str

def check_verification_independence(primary:VerificationValue,independent:VerificationValue)->ProvenanceCheck:
    src=primary.source_id!=independent.source_id
    alg=primary.algorithm_id!=independent.algorithm_id
    ok=src and alg
    return ProvenanceCheck(VerificationStatus.PASS if ok else VerificationStatus.INPUT_INCONSISTENT,src,alg,
        "Source and algorithm are independently identified." if ok else
        "Verification independence is incomplete; use a distinct source and algorithm for a true independent check.")

@dataclass(frozen=True)
class VerificationGuardianContract:
    schema:str
    status:str
    facts:dict
    provenance:str
    authority:str

def verification_guardian_contract(record:VerificationRecord|None=None,independence:ProvenanceCheck|None=None,
                                   *,provenance:str="JOE verification")->VerificationGuardianContract:
    facts={}
    status=VerificationStatus.PASS.value
    if record is not None:
        facts["comparison"]={"status":record.status.value,"discrepancy_class":record.discrepancy_class.value,
            "difference":record.difference,"combined_standard_uncertainty":record.combined_standard_uncertainty,
            "normalized_difference_sigma":record.normalized_difference_sigma,"allowed_difference":record.allowed_difference,
            "independent_algorithms":record.independent_algorithms}
        status=record.status.value
    if independence is not None:
        facts["independence"]={"status":independence.status.value,"independent_sources":independence.independent_sources,
            "independent_algorithms":independence.independent_algorithms}
        if independence.status!=VerificationStatus.PASS:status=independence.status.value
    return VerificationGuardianContract("JOE-GUARDIAN-VERIFICATION/1",status,facts,provenance,
        "READ_ONLY_ADVISORY; may flag failed verification or insufficient independence but cannot alter scientific results, safety thresholds, or BUS-SAFE/control authority")


@dataclass(frozen=True)
class UncertainInput:
    name:str
    value:float
    standard_uncertainty:float
    unit:str
    provenance:str
    def __post_init__(self):
        if not self.name.strip() or not self.unit.strip() or not self.provenance.strip():raise ValueError("name/unit/provenance required")
        if not math.isfinite(self.value) or not math.isfinite(self.standard_uncertainty) or self.standard_uncertainty<0:
            raise ValueError("finite value and nonnegative finite uncertainty required")

@dataclass(frozen=True)
class UncertaintyContribution:
    name:str
    sensitivity:float
    standard_uncertainty:float
    variance_contribution:float
    fractional_variance:float

@dataclass(frozen=True)
class UncertaintyBudget:
    combined_standard_uncertainty:float
    contributions:tuple[UncertaintyContribution,...]
    covariance_contribution:float
    message:str

def propagate_linear_uncertainty(inputs:tuple[UncertainInput,...],sensitivities:tuple[float,...],
                                 covariance:tuple[tuple[float,...],...]|None=None)->UncertaintyBudget:
    n=len(inputs)
    if n==0 or len(sensitivities)!=n:raise ValueError("inputs and sensitivities must have equal nonzero length")
    if any(not math.isfinite(float(x)) for x in sensitivities):raise ValueError("sensitivities must be finite")
    if covariance is None:
        covariance=tuple(tuple((inputs[i].standard_uncertainty**2 if i==j else 0.0) for j in range(n)) for i in range(n))
    if len(covariance)!=n or any(len(row)!=n for row in covariance):raise ValueError("covariance must be square and match inputs")
    for i,row in enumerate(covariance):
        for j,x in enumerate(row):
            if not math.isfinite(float(x)):raise ValueError("covariance entries must be finite")
            if abs(x-covariance[j][i])>1e-12*max(1,abs(x),abs(covariance[j][i])):raise ValueError("covariance must be symmetric")
        if row[i]<0:raise ValueError("covariance diagonal must be nonnegative")
    diag=sum((sensitivities[i]**2)*covariance[i][i] for i in range(n))
    cross=sum(2*sensitivities[i]*sensitivities[j]*covariance[i][j] for i in range(n) for j in range(i+1,n))
    var=diag+cross
    if var < -1e-15*max(1,diag):raise ValueError("covariance/sensitivity combination produced negative variance")
    var=max(0.0,var)
    contrib=[]
    for i,x in enumerate(inputs):
        v=(sensitivities[i]**2)*covariance[i][i]
        contrib.append(UncertaintyContribution(x.name,sensitivities[i],math.sqrt(covariance[i][i]),v,(v/var if var>0 else 0.0)))
    return UncertaintyBudget(math.sqrt(var),tuple(contrib),cross,
        "First-order covariance propagation u_y² = J C Jᵀ; fractional entries show diagonal variance contributions and need not sum to one when covariance is present.")

@dataclass(frozen=True)
class NumericalJacobian:
    derivatives:tuple[float,...]
    steps:tuple[float,...]
    message:str

def numerical_jacobian(function,values:tuple[float,...],*,relative_step:float=1e-6)->NumericalJacobian:
    if not values or relative_step<=0 or not math.isfinite(relative_step):raise ValueError("values required and relative_step must be positive")
    vals=tuple(float(v) for v in values)
    if any(not math.isfinite(v) for v in vals):raise ValueError("values must be finite")
    deriv=[];steps=[]
    for i,v in enumerate(vals):
        h=relative_step*max(1.0,abs(v));steps.append(h)
        lo=list(vals);hi=list(vals);lo[i]-=h;hi[i]+=h
        f0=float(function(tuple(lo)));f1=float(function(tuple(hi)))
        if not math.isfinite(f0) or not math.isfinite(f1):raise ValueError("function returned nonfinite value")
        deriv.append((f1-f0)/(2*h))
    return NumericalJacobian(tuple(deriv),tuple(steps),"Centered finite-difference numerical Jacobian.")

@dataclass(frozen=True)
class MonteCarloUncertainty:
    sample_count:int
    mean:float
    standard_deviation:float
    standard_error_of_mean:float
    seed:int
    message:str

def monte_carlo_uncertainty(function,inputs:tuple[UncertainInput,...],*,sample_count:int=10000,seed:int=1729)->MonteCarloUncertainty:
    """Deterministic-seeded Gaussian Monte Carlo for software verification/reproducibility."""
    import random
    if sample_count<2:raise ValueError("sample_count must be >=2")
    rng=random.Random(int(seed));ys=[]
    for _ in range(sample_count):
        x=tuple(rng.gauss(q.value,q.standard_uncertainty) if q.standard_uncertainty else q.value for q in inputs)
        y=float(function(x))
        if not math.isfinite(y):raise ValueError("function returned nonfinite Monte Carlo result")
        ys.append(y)
    mean=sum(ys)/sample_count
    var=sum((y-mean)**2 for y in ys)/(sample_count-1)
    sd=math.sqrt(var)
    return MonteCarloUncertainty(sample_count,mean,sd,sd/math.sqrt(sample_count),int(seed),
        "Gaussian input Monte Carlo with deterministic seed; distributional assumptions must be declared appropriate by the caller.")

@dataclass(frozen=True)
class LinearMonteCarloCrossCheck:
    status:VerificationStatus
    linear_standard_uncertainty:float
    monte_carlo_standard_uncertainty:float
    relative_difference:float
    tolerance:float
    message:str

def cross_check_uncertainty_methods(linear:UncertaintyBudget,mc:MonteCarloUncertainty,*,relative_tolerance:float=.05)->LinearMonteCarloCrossCheck:
    if relative_tolerance<0 or not math.isfinite(relative_tolerance):raise ValueError("relative_tolerance must be nonnegative finite")
    scale=max(linear.combined_standard_uncertainty,mc.standard_deviation)
    rel=abs(linear.combined_standard_uncertainty-mc.standard_deviation)/scale if scale else 0.0
    ok=rel<=relative_tolerance
    return LinearMonteCarloCrossCheck(VerificationStatus.PASS if ok else VerificationStatus.FAIL,
        linear.combined_standard_uncertainty,mc.standard_deviation,rel,relative_tolerance,
        "Linear covariance propagation and Monte Carlo uncertainty agree within tolerance." if ok else
        "Linear and Monte Carlo uncertainty disagree beyond tolerance; investigate nonlinearity, sampling, covariance, or distribution assumptions.")

def expanded_verification_guardian_contract(*,budget:UncertaintyBudget|None=None,
                                             cross_check:LinearMonteCarloCrossCheck|None=None,
                                             provenance:str="JOE uncertainty analysis")->VerificationGuardianContract:
    facts={}
    status=VerificationStatus.PASS.value
    if budget:
        facts["uncertainty_budget"]={"combined_standard_uncertainty":budget.combined_standard_uncertainty,
            "covariance_contribution":budget.covariance_contribution,
            "contributions":[{"name":x.name,"sensitivity":x.sensitivity,"standard_uncertainty":x.standard_uncertainty,
                              "variance_contribution":x.variance_contribution,"fractional_variance":x.fractional_variance} for x in budget.contributions]}
    if cross_check:
        facts["method_cross_check"]={"status":cross_check.status.value,"linear_standard_uncertainty":cross_check.linear_standard_uncertainty,
            "monte_carlo_standard_uncertainty":cross_check.monte_carlo_standard_uncertainty,"relative_difference":cross_check.relative_difference}
        status=cross_check.status.value
    return VerificationGuardianContract("JOE-GUARDIAN-VERIFICATION/1",status,facts,provenance,
        "READ_ONLY_ADVISORY; uncertainty estimates inform scientific significance but cannot rewrite source measurements, safety thresholds, or BUS-SAFE/control authority")


@dataclass(frozen=True)
class ConvergencePoint:
    resolution:int
    value:float
    delta_from_previous:float|None

@dataclass(frozen=True)
class ConvergenceAssessment:
    status:VerificationStatus
    points:tuple[ConvergencePoint,...]
    final_absolute_delta:float|None
    final_relative_delta:float|None
    tolerance_absolute:float
    tolerance_relative:float
    message:str

def assess_convergence(samples:tuple[tuple[int,float],...],*,absolute_tolerance:float=0.0,
                       relative_tolerance:float=1e-8)->ConvergenceAssessment:
    if len(samples)<2:raise ValueError("at least two resolution/value samples required")
    if absolute_tolerance<0 or relative_tolerance<0 or not math.isfinite(absolute_tolerance) or not math.isfinite(relative_tolerance):
        raise ValueError("tolerances must be nonnegative finite")
    prev_r=0;pts=[]
    for r,v in samples:
        if int(r)<=prev_r:raise ValueError("resolutions must be strictly increasing")
        if not math.isfinite(float(v)):raise ValueError("sample values must be finite")
        d=None if not pts else float(v)-pts[-1].value
        pts.append(ConvergencePoint(int(r),float(v),d));prev_r=int(r)
    delta=abs(pts[-1].value-pts[-2].value)
    scale=max(abs(pts[-1].value),abs(pts[-2].value))
    rel=delta/scale if scale else 0.0
    ok=delta<=max(absolute_tolerance,relative_tolerance*scale)
    return ConvergenceAssessment(VerificationStatus.PASS if ok else VerificationStatus.PRECISION_INSUFFICIENT,
        tuple(pts),delta,rel,absolute_tolerance,relative_tolerance,
        "Resolution sequence converged within declared tolerance." if ok else
        "Final resolution change exceeds declared tolerance; precision is insufficient.")

@dataclass(frozen=True)
class RegressionBaseline:
    baseline_id:str
    revision:str
    expected_value:float
    unit:str
    absolute_tolerance:float
    relative_tolerance:float
    provenance:str
    def __post_init__(self):
        if not self.baseline_id.strip() or not self.revision.strip() or not self.unit.strip() or not self.provenance.strip():
            raise ValueError("baseline identity/revision/unit/provenance required")
        if not math.isfinite(self.expected_value) or any(not math.isfinite(x) or x<0 for x in (self.absolute_tolerance,self.relative_tolerance)):
            raise ValueError("finite baseline and nonnegative finite tolerances required")

@dataclass(frozen=True)
class RegressionAssessment:
    status:VerificationStatus
    baseline_id:str
    baseline_revision:str
    observed_value:float
    difference:float
    allowed_difference:float
    message:str

def assess_regression(observed_value:float,unit:str,baseline:RegressionBaseline)->RegressionAssessment:
    v=float(observed_value)
    if not math.isfinite(v):raise ValueError("observed value must be finite")
    if unit!=baseline.unit:
        return RegressionAssessment(VerificationStatus.INPUT_INCONSISTENT,baseline.baseline_id,baseline.revision,v,
            v-baseline.expected_value,0.0,"Regression unit mismatch; explicit conversion is required.")
    d=v-baseline.expected_value
    allowed=max(baseline.absolute_tolerance,baseline.relative_tolerance*max(abs(v),abs(baseline.expected_value)))
    ok=abs(d)<=allowed
    return RegressionAssessment(VerificationStatus.PASS if ok else VerificationStatus.FAIL,baseline.baseline_id,
        baseline.revision,v,d,allowed,"Regression remains within controlled baseline tolerance." if ok else
        "Regression exceeds controlled baseline tolerance.")

@dataclass(frozen=True)
class VerificationMatrixEntry:
    requirement_id:str
    method_id:str
    independent_method_id:str|None
    status:VerificationStatus
    evidence_id:str
    message:str

@dataclass(frozen=True)
class VerificationMatrix:
    status:VerificationStatus
    entries:tuple[VerificationMatrixEntry,...]
    passed:int
    failed:int
    incomplete:int

def build_verification_matrix(entries:tuple[VerificationMatrixEntry,...])->VerificationMatrix:
    if not entries:raise ValueError("verification matrix requires entries")
    failed=sum(e.status in (VerificationStatus.FAIL,VerificationStatus.INPUT_INCONSISTENT) for e in entries)
    incomplete=sum(e.status in (VerificationStatus.MODEL_UNAVAILABLE,VerificationStatus.PRECISION_INSUFFICIENT) for e in entries)
    passed=sum(e.status==VerificationStatus.PASS for e in entries)
    status=VerificationStatus.FAIL if failed else (VerificationStatus.PRECISION_INSUFFICIENT if incomplete else VerificationStatus.PASS)
    return VerificationMatrix(status,entries,passed,failed,incomplete)

@dataclass(frozen=True)
class CrossValidationResult:
    status:VerificationStatus
    verification:VerificationRecord
    independence:ProvenanceCheck
    message:str

def cross_validate_models(primary:VerificationValue,independent:VerificationValue,
                          tolerance:VerificationTolerance=VerificationTolerance())->CrossValidationResult:
    record=compare_independent_results(primary,independent,tolerance)
    independence=check_verification_independence(primary,independent)
    status=record.status if record.status!=VerificationStatus.PASS else independence.status
    return CrossValidationResult(status,record,independence,
        "Independent model/solver cross-validation passed." if status==VerificationStatus.PASS else
        "Cross-validation is not qualified; inspect discrepancy and independence evidence.")

@dataclass(frozen=True)
class VNVReleaseReadiness:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    notes:tuple[str,...]

def vnv_core_readiness()->VNVReleaseReadiness:
    checks=[];fail=[]
    try:
        a=VerificationValue(1.0,"m",.01,"source-a","algorithm-a","r1","VNV readiness")
        b=VerificationValue(1.001,"m",.01,"source-b","algorithm-b","r1","VNV readiness")
        if cross_validate_models(a,b).status==VerificationStatus.PASS:checks.append("independent comparison and provenance gate passed")
        else:fail.append("independent comparison/provenance gate failed")
        c=assess_convergence(((16,1.0),(32,1.000001),(64,1.000001001)),relative_tolerance=1e-8)
        if c.status==VerificationStatus.PASS:checks.append("convergence qualification passed")
        else:fail.append("convergence qualification failed")
        rb=RegressionBaseline("baseline","r1",10,"s",1e-6,1e-6,"VNV readiness")
        if assess_regression(10.000001,"s",rb).status==VerificationStatus.PASS:checks.append("controlled regression baseline passed")
        else:fail.append("regression baseline failed")
        inp=(UncertainInput("x",2,.1,"1","VNV readiness"),)
        budget=propagate_linear_uncertainty(inp,(2,))
        mc=monte_carlo_uncertainty(lambda v:2*v[0],inp,sample_count=6000,seed=7)
        if cross_check_uncertainty_methods(budget,mc,relative_tolerance=.05).status==VerificationStatus.PASS:
            checks.append("linear/Monte Carlo uncertainty cross-check passed")
        else:fail.append("uncertainty method cross-check failed")
    except Exception as exc:fail.append(f"readiness exception: {type(exc).__name__}: {exc}")
    notes=("Readiness qualifies implemented verification software only; it does not validate unresolved physical models.",
           "D-1 target solver now reports NONCONVERGED when its iteration limit is reached without meeting tolerance.")
    return VNVReleaseReadiness(not fail,tuple(checks),tuple(fail),notes)


def vnv_release_readiness()->VNVReleaseReadiness:
    """V&V v1 release gate. Qualifies implemented software mechanisms, not unresolved physics."""
    base=vnv_core_readiness()
    checks=list(base.checks);fail=list(base.failures);notes=list(base.notes)
    try:
        dims=check_dimensions(DimensionSignature(length=1,time=-1),DimensionSignature(length=1,time=-1))
        if dims.status==VerificationStatus.PASS:checks.append("dimensional-consistency gate passed")
        else:fail.append("dimensional-consistency gate failed")
        entries=(VerificationMatrixEntry("VNV-INDEPENDENCE","independent-result-comparison","distinct-source+algorithm",
                                          VerificationStatus.PASS,"VNV-v1-readiness","qualified"),
                 VerificationMatrixEntry("VNV-UNCERTAINTY","linear-covariance","seeded-monte-carlo",
                                          VerificationStatus.PASS,"VNV-v1-readiness","qualified"),
                 VerificationMatrixEntry("VNV-CONVERGENCE","resolution-refinement",None,
                                          VerificationStatus.PASS,"VNV-v1-readiness","qualified"))
        matrix=build_verification_matrix(entries)
        if matrix.status==VerificationStatus.PASS:checks.append("verification-matrix aggregation passed")
        else:fail.append("verification-matrix aggregation failed")
    except Exception as exc:fail.append(f"v1 release exception: {type(exc).__name__}: {exc}")
    notes.append("V&V v1 provides verification infrastructure; each scientific module remains responsible for the validity/domain of its own physical model.")
    return VNVReleaseReadiness(not fail,tuple(checks),tuple(fail),tuple(notes))
