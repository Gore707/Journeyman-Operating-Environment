"""Method-B / Ring-Laser module."""
from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.ring_laser import (sagnac_reference,optical_consistency,ring_laser_guardian_contract,
 ring_optical_energy,null_radiation_stress_energy,gravitational_scale_estimate,ring_energy_scaling,
 compare_declared_required_energy,ring_energy_uncertainty,method_b_epistemic_assessment,
 expanded_ring_laser_guardian_contract,circulating_light_angular_momentum,weak_field_frame_dragging,
 method_b_gravity_scaling,assess_method_b_chronology_hypothesis,weak_field_power_sensitivity,
 rla_numerical_verification,method_b_hypothesis_guardian_contract,rla_release_readiness,closed_loop_resonator,resonator_dispersion,method_b_em_gravity_bridge,method_b_advanced_guardian_contract,method_b_advanced_release_readiness)
RLA_MODULE=ModuleDescriptor(module_id="journeyman.ring-laser",name="Method-B / Ring-Laser Workbench",version="1.0.0",
 description="Rotating-ring optical reference physics and Method-B analysis foundation.",
 requires=("joe.core","journeyman.registry","journeyman.navigation","journeyman.chronology"),
 provides=("joe.ring-laser",),consumes=("joe.registry","joe.navigation","joe.chronology","joe.state-events"))
class RingLaserService:
    sagnac=staticmethod(sagnac_reference)
    optical_consistency=staticmethod(optical_consistency)
    guardian_contract=staticmethod(ring_laser_guardian_contract)
    optical_energy=staticmethod(ring_optical_energy)
    radiation_stress_energy=staticmethod(null_radiation_stress_energy)
    gravitational_scale=staticmethod(gravitational_scale_estimate)
    energy_scaling=staticmethod(ring_energy_scaling)
    compare_required_energy=staticmethod(compare_declared_required_energy)
    energy_uncertainty=staticmethod(ring_energy_uncertainty)
    epistemic_assessment=staticmethod(method_b_epistemic_assessment)
    expanded_guardian_contract=staticmethod(expanded_ring_laser_guardian_contract)
    angular_momentum=staticmethod(circulating_light_angular_momentum)
    weak_field_dragging=staticmethod(weak_field_frame_dragging)
    gravity_scaling=staticmethod(method_b_gravity_scaling)
    assess_chronology_hypothesis=staticmethod(assess_method_b_chronology_hypothesis)
    power_sensitivity=staticmethod(weak_field_power_sensitivity)
    numerical_verification=staticmethod(rla_numerical_verification)
    hypothesis_guardian_contract=staticmethod(method_b_hypothesis_guardian_contract)
    release_readiness=staticmethod(rla_release_readiness)
    closed_loop_resonator=staticmethod(closed_loop_resonator)
    dispersion=staticmethod(resonator_dispersion)
    em_gravity_bridge=staticmethod(method_b_em_gravity_bridge)
    advanced_guardian_contract=staticmethod(method_b_advanced_guardian_contract)
    advanced_release_readiness=staticmethod(method_b_advanced_release_readiness)
class RingLaserInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_ring_laser_module(runtime:ModuleRuntime):
    svc=RingLaserService();runtime.register(RLA_MODULE,RingLaserInstance(svc));runtime.activate("journeyman.ring-laser")
    runtime.publish_service("journeyman.ring-laser","joe.ring-laser",svc);return svc
