import math
import pytest
from journeyman.core.black_hole_research import *

def test_schwarzschild_metric_and_horizon():
    m=schwarzschild_metric(mass=1.0).evaluate((0,4,math.pi/2,0))
    assert m.signature==(-1,1,1,1)
    h=horizons(model="Schwarzschild",mass=1)
    assert h.outer==pytest.approx(2) and h.inner==pytest.approx(0)

def test_kerr_horizons_and_ergosphere():
    h=horizons(model="Kerr",mass=2,spin=1)
    assert h.outer==pytest.approx(2+math.sqrt(3))
    e=kerr_ergosphere(mass=2,spin=1,theta=math.pi/2)
    assert e.outer_static_limit==pytest.approx(4)
    assert e.outer_static_limit>=e.event_horizon

def test_kerr_metric_exterior():
    m=kerr_metric(mass=2,spin=.5).evaluate((0,5,math.pi/2,.1))
    assert m.signature==(-1,1,1,1)

def test_rn_and_kn_metrics():
    assert reissner_nordstrom_metric(mass=2,charge_length=.5).evaluate((0,5,math.pi/2,.2)).determinant<0
    assert kerr_newman_metric(mass=2,spin=.5,charge_length=.5).evaluate((0,5,math.pi/2,.2)).determinant<0

def test_schwarzschild_invariants():
    assert schwarzschild_kretschmann(mass=1,radius=2)==pytest.approx(.75)
    assert 0<schwarzschild_redshift_factor(mass=1,radius=4)<1

def test_cross_model_disagreement():
    r=cross_model_compare(quantity="q",model_a="A",value_a=1,sigma_a=.01,model_b="B",value_b=2,sigma_b=.01)
    assert r.status=="INVESTIGATE" and r.z_score>5
    assert guardian_contract(r)["authority"]=="READ_ONLY_ADVISORY"

def test_naked_and_domains():
    assert horizons(model="KN",mass=1,spin=1,charge_length=1).naked_singularity
    with pytest.raises(ValueError): kerr_metric(mass=1,spin=2)
