"""JOE 004A high-throughput numerical kernels and deterministic pre-HIL qualification.

Synthetic fault injection is SIMULATION only.  This module does not claim physical HIL,
hardware timing, actuator authority, or physical chronology/backreaction detection.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math, time
import numpy as np
try:
    from numba import njit
    NUMBA_AVAILABLE=True
except Exception:  # verified reference fallback remains authoritative
    NUMBA_AVAILABLE=False
    def njit(*args,**kwargs):
        def deco(fn): return fn
        return deco

@njit(cache=True)
def _residual_kernel(a,b):
    n=a.shape[0]; out=np.empty(n,dtype=np.float64)
    for i in range(n):
        s=0.0
        for j in range(a.shape[1]):
            d=a[i,j]-b[i,j]; s+=d*d
        out[i]=math.sqrt(s)
    return out

def reference_residuals(mapped:np.ndarray,state:np.ndarray)->np.ndarray:
    a=np.asarray(mapped,dtype=np.float64); b=np.asarray(state,dtype=np.float64)
    if a.shape!=b.shape or a.ndim!=2: raise ValueError("mapped/state must be equal-shape 2D arrays")
    if not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)): raise ValueError("finite values required")
    return np.linalg.norm(a-b,axis=1)

def accelerated_residuals(mapped:np.ndarray,state:np.ndarray)->np.ndarray:
    a=np.asarray(mapped,dtype=np.float64); b=np.asarray(state,dtype=np.float64)
    if a.shape!=b.shape or a.ndim!=2: raise ValueError("mapped/state must be equal-shape 2D arrays")
    if not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)): raise ValueError("finite values required")
    return _residual_kernel(a,b) if NUMBA_AVAILABLE else reference_residuals(a,b)

@dataclass(frozen=True)
class KernelBenchmark:
    backend:str; samples:int; dimensions:int; reference_s:float; accelerated_s:float
    max_abs_error:float; equivalent:bool; speedup:float
    provenance:str="HOST benchmark; timing applies only to this run and host"

def benchmark_residual_kernel(samples:int=20000,dimensions:int=4)->KernelBenchmark:
    if samples<1 or dimensions<1: raise ValueError("positive benchmark shape required")
    x=np.linspace(-1,1,samples*dimensions,dtype=np.float64).reshape(samples,dimensions); y=.5*x+.1
    if NUMBA_AVAILABLE: accelerated_residuals(x[:2],y[:2]) # exclude JIT compile from steady-state timing
    t=time.perf_counter(); ref=reference_residuals(x,y); tr=time.perf_counter()-t
    t=time.perf_counter(); acc=accelerated_residuals(x,y); ta=time.perf_counter()-t
    err=float(np.max(np.abs(ref-acc)))
    return KernelBenchmark("NUMBA" if NUMBA_AVAILABLE else "NUMPY_REFERENCE",samples,dimensions,tr,ta,err,err<=1e-12,tr/max(ta,1e-15))

class HILFault(str,Enum):
    NONE="NONE"; SENSOR_NOISE="SENSOR_NOISE"; SENSOR_BIAS="SENSOR_BIAS"; CLOCK_DRIFT="CLOCK_DRIFT"
    TIMESTAMP_JITTER="TIMESTAMP_JITTER"; PACKET_DROP="PACKET_DROP"; PACKET_REORDER="PACKET_REORDER"
    STALE_TELEMETRY="STALE_TELEMETRY"; INVALID_SAMPLE="INVALID_SAMPLE"; ACK_DELAY="ACK_DELAY"; WATCHDOG_LOSS="WATCHDOG_LOSS"

@dataclass(frozen=True)
class TelemetryFrame:
    sequence:int; timestamp_s:float; value:float; uncertainty:float; origin:str="SIMULATION"; valid:bool=True

@dataclass(frozen=True)
class FaultInjectionResult:
    fault:HILFault; frames:tuple[TelemetryFrame,...]; acknowledgement_delay_s:float=0.0; watchdog_alive:bool=True
    truth_boundary:str="PRE-HIL EMULATION / SIMULATION; not physical hardware telemetry."

def inject_fault(frames, fault:HILFault, *, magnitude:float=.01, seed:int=1)->FaultInjectionResult:
    src=tuple(frames); rng=np.random.default_rng(seed); out=[]; ack=0.0; watchdog=True
    for i,f in enumerate(src):
        ts=float(f.timestamp_s); val=float(f.value); unc=float(f.uncertainty); valid=bool(f.valid)
        if fault==HILFault.SENSOR_NOISE: val+=float(rng.normal(0,magnitude)); unc=math.hypot(unc,magnitude)
        elif fault==HILFault.SENSOR_BIAS: val+=magnitude; unc=math.hypot(unc,abs(magnitude))
        elif fault==HILFault.CLOCK_DRIFT: ts+=magnitude*max(0.0,ts-src[0].timestamp_s)
        elif fault==HILFault.TIMESTAMP_JITTER: ts+=float(rng.normal(0,magnitude))
        elif fault==HILFault.STALE_TELEMETRY: ts-=abs(magnitude)
        elif fault==HILFault.INVALID_SAMPLE and i==len(src)//2: val=float('nan'); valid=False
        out.append(TelemetryFrame(f.sequence,ts,val,unc,"SIMULATION",valid))
    if fault==HILFault.PACKET_DROP and out: out.pop(len(out)//2)
    if fault==HILFault.PACKET_REORDER and len(out)>2: out[1],out[2]=out[2],out[1]
    if fault==HILFault.ACK_DELAY: ack=abs(magnitude)
    if fault==HILFault.WATCHDOG_LOSS: watchdog=False
    return FaultInjectionResult(fault,tuple(out),ack,watchdog)

def telemetry_integrity(result:FaultInjectionResult, *, now_s:float|None=None,max_age_s:float=1.0):
    reasons=[]; fs=result.frames
    if any(not f.valid or not math.isfinite(f.value) for f in fs): reasons.append("invalid/non-finite sample")
    if any(fs[i].sequence<=fs[i-1].sequence for i in range(1,len(fs))): reasons.append("sequence non-monotonic")
    if any(fs[i].timestamp_s<fs[i-1].timestamp_s for i in range(1,len(fs))): reasons.append("timestamp non-monotonic")
    if not result.watchdog_alive: reasons.append("watchdog loss")
    if now_s is not None and fs and now_s-max(f.timestamp_s for f in fs)>max_age_s: reasons.append("stale telemetry")
    return {"passed":not reasons,"fail_closed":bool(reasons),"reasons":tuple(reasons),"origin":"SIMULATION"}

def pre_hil_fault_campaign():
    base=tuple(TelemetryFrame(i,i*.01,.1*i,.001) for i in range(8)); checks=[]; failures=[]
    for fault in (HILFault.PACKET_REORDER,HILFault.INVALID_SAMPLE,HILFault.WATCHDOG_LOSS):
        q=telemetry_integrity(inject_fault(base,fault,magnitude=.1),now_s=.07)
        (checks if q["fail_closed"] else failures).append(f"{fault.value} fail-closed detection")
    q=telemetry_integrity(inject_fault(base,HILFault.NONE),now_s=.07)
    (checks if q["passed"] else failures).append("nominal synthetic telemetry accepted")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),"truth_boundary":"PRE-HIL EMULATION only; no physical HIL claimed."}

def performance_hil_release_readiness():
    failures=[]; checks=[]
    try:
        b=benchmark_residual_kernel(2000,4)
        if b.equivalent: checks.append(f"accelerated/reference numerical equivalence passed; backend={b.backend}; measured speedup={b.speedup:.3g}x")
        else: failures.append("accelerated/reference numerical equivalence failed")
    except Exception as e: failures.append(type(e).__name__+": "+str(e))
    q=pre_hil_fault_campaign(); checks.extend(q["checks"]); failures.extend(q["failures"])
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),"numba_available":NUMBA_AVAILABLE,"truth_boundary":"Performance timing is host/run-specific; pre-HIL data are SIMULATION."}

def guardian_performance_hil_contract():
    return {"contract":"JOE-GUARDIAN-PERFORMANCE-HIL/1","authority":"READ_ONLY_ADVISORY","may_command":False,
            "observes":("kernel benchmark","numerical equivalence","synthetic fault campaign","telemetry integrity"),
            "truth_boundary":"Guardian cannot promote PRE-HIL emulation to physical HIL or hardware qualification."}
