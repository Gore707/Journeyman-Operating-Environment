"""Journeyman Master Parameter Register (MPR).

Authoritative scientific parameter records with explicit units, dimensions,
uncertainty, epistemic classification, provenance, revision history and
integrity-protected persistence. MPR never invents missing scientific values.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, replace
from enum import Enum
from pathlib import Path
from typing import Any
import csv, hashlib, io, json, math, os, re, tempfile, time

_ID=re.compile(r"^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$")
_SYMBOL=re.compile(r"^.{1,80}$")

class EpistemicClass(str,Enum):
    ESTABLISHED_PHYSICS="ESTABLISHED_PHYSICS"
    DEMONSTRATED_TECHNOLOGY="DEMONSTRATED_TECHNOLOGY"
    EXTRAPOLATED_ENGINEERING="EXTRAPOLATED_ENGINEERING"
    SPECULATIVE_UNRESOLVED="SPECULATIVE_UNRESOLVED"

from .units import Dimension, DIMENSIONLESS, DEFAULT_UNITS

def unit_dimension(unit:str)->Dimension:
    return DEFAULT_UNITS.parse(unit).dimension

def compatible_units(a:str,b:str)->bool:
    return DEFAULT_UNITS.compatible(a,b)

def _finite(value:Any,label:str)->float:
    if isinstance(value,bool) or not isinstance(value,(int,float)):
        raise TypeError(f"{label} must be numeric")
    value=float(value)
    if not math.isfinite(value):raise ValueError(f"{label} must be finite")
    return value

@dataclass(frozen=True)
class ParameterRecord:
    parameter_id:str
    symbol:str
    name:str
    value:float
    unit:str
    dimension:Dimension
    uncertainty:float|None
    uncertainty_unit:str|None
    epistemic_class:EpistemicClass
    provenance:str
    description:str
    revision:int
    registry_revision:int
    created_at:float
    updated_at:float

@dataclass(frozen=True)
class ParameterRevision:
    parameter_id:str
    revision:int
    registry_revision:int
    changed_at:float
    record:ParameterRecord

@dataclass(frozen=True)
class DerivedParameter:
    parameter_id:str
    dependencies:tuple[str,...]
    expression:str
    provenance:str
    revision:int
    created_at:float
    updated_at:float

@dataclass(frozen=True)
class DependencyGraph:
    nodes:tuple[str,...]
    edges:tuple[tuple[str,str],...]
    topological_order:tuple[str,...]

@dataclass(frozen=True)
class ParameterSnapshot:
    snapshot_id:str
    name:str
    registry_revision:int
    created_at:float
    parameter_revisions:tuple[tuple[str,int],...]
    checksum:str


@dataclass(frozen=True)
class GuardianParameterView:
    parameter_id:str
    symbol:str
    value:float
    unit:str
    uncertainty:float|None
    uncertainty_unit:str|None
    epistemic_class:str
    provenance:str
    parameter_revision:int
    registry_revision:int
    dependencies:tuple[str,...]
    dependents:tuple[str,...]

@dataclass(frozen=True)
class GuardianMPRContract:
    schema:str
    generated_at:float
    registry_revision:int
    integrity_ok:bool
    parameters:tuple[GuardianParameterView,...]
    snapshots:tuple[str,...]

@dataclass(frozen=True)
class MPRReleaseReadiness:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    notes:tuple[str,...]


@dataclass(frozen=True)
class MPRStatus:
    registry_revision:int
    parameter_count:int
    history_count:int
    checksum:str|None
    integrity_ok:bool

@dataclass(frozen=True)
class MPRQualification:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]

def _validate_id(value:str)->str:
    value=str(value).strip()
    if not _ID.fullmatch(value):raise ValueError(f"Invalid parameter ID: {value}")
    return value

def _canonical_payload(revision:int,parameters:dict[str,dict],history:list[dict])->bytes:
    return json.dumps({"schema_version":1,"registry_revision":revision,"parameters":parameters,"history":history},
                      sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")

def _checksum(revision:int,parameters:dict[str,dict],history:list[dict])->str:
    return hashlib.sha256(_canonical_payload(revision,parameters,history)).hexdigest()

def _record_to_json(record:ParameterRecord)->dict:
    d=asdict(record)
    d["dimension"]=asdict(record.dimension)
    d["epistemic_class"]=record.epistemic_class.value
    return d

def _record_from_json(raw:dict)->ParameterRecord:
    return ParameterRecord(
        parameter_id=_validate_id(raw["parameter_id"]),symbol=str(raw["symbol"]),name=str(raw["name"]),
        value=_finite(raw["value"],"value"),unit=str(raw["unit"]),
        dimension=Dimension(**raw["dimension"]),
        uncertainty=None if raw.get("uncertainty") is None else _finite(raw["uncertainty"],"uncertainty"),
        uncertainty_unit=raw.get("uncertainty_unit"),
        epistemic_class=EpistemicClass(raw["epistemic_class"]),provenance=str(raw["provenance"]),
        description=str(raw.get("description","")),revision=int(raw["revision"]),
        registry_revision=int(raw["registry_revision"]),created_at=float(raw["created_at"]),updated_at=float(raw["updated_at"])
    )

class MasterParameterRegister:
    """Integrity-protected authoritative register with optimistic revisions."""
    def __init__(self,root:Path,backbone=None)->None:
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        self.path=self.root/"registry.json"
        self.derived_path=self.root/"derived.json"
        self.snapshots_path=self.root/"snapshots.json"
        self._derived={}
        self._snapshots={}
        self._backbone=backbone
        self._client=None
        if backbone is not None:
            # Contracts are registered exactly once for this runtime.
            if backbone.events.topic_definition("joe.mpr.changed") is None:
                backbone.events.register_topic("joe.mpr.changed",("journeyman.mpr",))
            try:backbone.state.register("joe.mpr.registry-revision","journeyman.mpr",value_type=int)
            except ValueError:pass
            try:backbone.state.register("joe.mpr.parameter-count","journeyman.mpr",value_type=int)
            except ValueError:pass
            self._client=backbone.client("journeyman.mpr")
        self._revision=0;self._parameters={};self._history=[];self._stored_checksum=None
        self._load()
        self._load_auxiliary()
        self._publish_state()

    def _load(self):
        if not self.path.exists():return
        try:raw=json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError,json.JSONDecodeError) as exc:raise RuntimeError(f"Cannot read MPR: {exc}") from exc
        if raw.get("schema_version")!=1:raise RuntimeError("Unsupported MPR schema version")
        revision=raw.get("registry_revision");params=raw.get("parameters");history=raw.get("history");checksum=raw.get("checksum")
        if not isinstance(revision,int) or revision<0 or not isinstance(params,dict) or not isinstance(history,list) or not isinstance(checksum,str):
            raise RuntimeError("MPR registry is structurally invalid")
        if checksum!=_checksum(revision,params,history):raise RuntimeError("MPR integrity verification failed")
        parsed={pid:_record_from_json(item) for pid,item in params.items()}
        for pid,record in parsed.items():
            if pid!=record.parameter_id:raise RuntimeError("MPR parameter identity mismatch")
            if unit_dimension(record.unit)!=record.dimension:raise RuntimeError(f"MPR dimension mismatch: {pid}")
            if record.uncertainty is not None:
                if record.uncertainty < 0:raise RuntimeError(f"MPR negative uncertainty: {pid}")
                if record.uncertainty_unit is None or not compatible_units(record.unit,record.uncertainty_unit):
                    raise RuntimeError(f"MPR uncertainty unit mismatch: {pid}")
        self._revision=revision;self._parameters=parsed;self._history=list(history);self._stored_checksum=checksum

    def _atomic_save(self):
        params={pid:_record_to_json(r) for pid,r in sorted(self._parameters.items())}
        checksum=_checksum(self._revision,params,self._history)
        doc={"schema_version":1,"registry_revision":self._revision,"parameters":params,"history":self._history,"checksum":checksum}
        payload=json.dumps(doc,indent=2,sort_keys=True,ensure_ascii=False)+"\n"
        fd,tmp=tempfile.mkstemp(prefix="registry.",suffix=".tmp",dir=str(self.root));tmp=Path(tmp)
        try:
            with os.fdopen(fd,"w",encoding="utf-8",newline="\n") as h:
                h.write(payload);h.flush();os.fsync(h.fileno())
            os.replace(tmp,self.path)
        except Exception:
            tmp.unlink(missing_ok=True);raise
        self._stored_checksum=checksum

    def _atomic_json(self,path:Path,payload:dict):
        body=json.dumps(payload,indent=2,sort_keys=True,ensure_ascii=False)+"\n"
        fd,tmp=tempfile.mkstemp(prefix=path.stem+".",suffix=".tmp",dir=str(self.root));tmp=Path(tmp)
        try:
            with os.fdopen(fd,"w",encoding="utf-8",newline="\n") as h:
                h.write(body);h.flush();os.fsync(h.fileno())
            os.replace(tmp,path)
        except Exception:
            tmp.unlink(missing_ok=True);raise

    def _load_auxiliary(self):
        if self.derived_path.exists():
            raw=json.loads(self.derived_path.read_text(encoding="utf-8"))
            if raw.get("schema_version")!=1 or not isinstance(raw.get("definitions"),dict):
                raise RuntimeError("MPR derived registry is structurally invalid")
            definitions=raw["definitions"];checksum=raw.get("checksum")
            payload=json.dumps({"schema_version":1,"definitions":definitions},sort_keys=True,separators=(",",":")).encode()
            if hashlib.sha256(payload).hexdigest()!=checksum:raise RuntimeError("MPR derived registry integrity verification failed")
            for pid,item in definitions.items():
                self._derived[pid]=DerivedParameter(pid,tuple(item["dependencies"]),item["expression"],item["provenance"],
                                                    int(item["revision"]),float(item["created_at"]),float(item["updated_at"]))
        if self.snapshots_path.exists():
            raw=json.loads(self.snapshots_path.read_text(encoding="utf-8"))
            if raw.get("schema_version")!=1 or not isinstance(raw.get("snapshots"),dict):
                raise RuntimeError("MPR snapshot registry is structurally invalid")
            snaps=raw["snapshots"];checksum=raw.get("checksum")
            payload=json.dumps({"schema_version":1,"snapshots":snaps},sort_keys=True,separators=(",",":")).encode()
            if hashlib.sha256(payload).hexdigest()!=checksum:raise RuntimeError("MPR snapshot registry integrity verification failed")
            for sid,item in snaps.items():
                self._snapshots[sid]=ParameterSnapshot(sid,item["name"],int(item["registry_revision"]),float(item["created_at"]),
                                                       tuple((x[0],int(x[1])) for x in item["parameter_revisions"]),item["parameter_checksum"])

    def _save_derived(self):
        definitions={pid:{"dependencies":list(d.dependencies),"expression":d.expression,"provenance":d.provenance,
                          "revision":d.revision,"created_at":d.created_at,"updated_at":d.updated_at}
                     for pid,d in sorted(self._derived.items())}
        core={"schema_version":1,"definitions":definitions}
        checksum=hashlib.sha256(json.dumps(core,sort_keys=True,separators=(",",":")).encode()).hexdigest()
        self._atomic_json(self.derived_path,{**core,"checksum":checksum})

    def _save_snapshots(self):
        snaps={sid:{"name":x.name,"registry_revision":x.registry_revision,"created_at":x.created_at,
                    "parameter_revisions":[list(v) for v in x.parameter_revisions],"parameter_checksum":x.checksum}
               for sid,x in sorted(self._snapshots.items())}
        core={"schema_version":1,"snapshots":snaps}
        checksum=hashlib.sha256(json.dumps(core,sort_keys=True,separators=(",",":")).encode()).hexdigest()
        self._atomic_json(self.snapshots_path,{**core,"checksum":checksum})

    def define_derived(self,parameter_id:str,*,dependencies:list[str]|tuple[str,...],expression:str,
                       provenance:str)->DerivedParameter:
        pid=_validate_id(parameter_id)
        if pid not in self._parameters:raise KeyError(f"Derived target is not an MPR parameter: {pid}")
        deps=tuple(_validate_id(x) for x in dependencies)
        if not deps:raise ValueError("derived parameter requires at least one dependency")
        if len(set(deps))!=len(deps):raise ValueError("derived dependencies must be unique")
        for dep in deps:
            if dep not in self._parameters:raise KeyError(f"Unknown dependency: {dep}")
        if pid in deps:raise ValueError("derived parameter cannot depend on itself")
        expression=str(expression).strip();provenance=str(provenance).strip()
        if not expression or not provenance:raise ValueError("expression and provenance are required")
        current=self._derived.get(pid);now=time.time()
        candidate=DerivedParameter(pid,deps,expression,provenance,1 if current is None else current.revision+1,
                                   now if current is None else current.created_at,now)
        old=self._derived.get(pid);self._derived[pid]=candidate
        try:
            self.dependency_graph()  # rejects cycles before persistence
            self._save_derived()
        except Exception:
            if old is None:self._derived.pop(pid,None)
            else:self._derived[pid]=old
            raise
        return candidate

    def derived(self,parameter_id:str)->DerivedParameter:
        return self._derived[_validate_id(parameter_id)]

    def derived_definitions(self)->tuple[DerivedParameter,...]:
        return tuple(self._derived[k] for k in sorted(self._derived))

    def dependency_graph(self)->DependencyGraph:
        nodes=tuple(sorted(self._parameters))
        edges=tuple(sorted((dep,pid) for pid,d in self._derived.items() for dep in d.dependencies))
        incoming={n:0 for n in nodes};out={n:[] for n in nodes}
        for a,b in edges:
            incoming[b]+=1;out[a].append(b)
        ready=sorted(n for n,v in incoming.items() if v==0);order=[]
        while ready:
            n=ready.pop(0);order.append(n)
            for nxt in sorted(out[n]):
                incoming[nxt]-=1
                if incoming[nxt]==0:
                    ready.append(nxt);ready.sort()
        if len(order)!=len(nodes):raise RuntimeError("MPR derived dependency cycle detected")
        return DependencyGraph(nodes,edges,tuple(order))

    def dependents(self,parameter_id:str,*,transitive:bool=True)->tuple[str,...]:
        pid=_validate_id(parameter_id)
        if pid not in self._parameters:raise KeyError(pid)
        direct={a:[] for a in self._parameters}
        for a,b in self.dependency_graph().edges:direct[a].append(b)
        if not transitive:return tuple(sorted(direct[pid]))
        seen=set();stack=list(direct[pid])
        while stack:
            item=stack.pop()
            if item in seen:continue
            seen.add(item);stack.extend(direct[item])
        return tuple(sorted(seen))

    def create_snapshot(self,snapshot_id:str,*,name:str)->ParameterSnapshot:
        sid=_validate_id(snapshot_id);name=str(name).strip()
        if not name:raise ValueError("snapshot name is required")
        if sid in self._snapshots:raise ValueError(f"Snapshot already exists: {sid}")
        revisions=tuple((p.parameter_id,p.revision) for p in self.list())
        body=json.dumps({"registry_revision":self._revision,"parameter_revisions":revisions},
                        sort_keys=True,separators=(",",":")).encode()
        snap=ParameterSnapshot(sid,name,self._revision,time.time(),revisions,hashlib.sha256(body).hexdigest())
        self._snapshots[sid]=snap
        try:self._save_snapshots()
        except Exception:self._snapshots.pop(sid,None);raise
        return snap

    def snapshot(self,snapshot_id:str)->ParameterSnapshot:
        return self._snapshots[_validate_id(snapshot_id)]

    def snapshots(self)->tuple[ParameterSnapshot,...]:
        return tuple(self._snapshots[k] for k in sorted(self._snapshots))

    def resolve_snapshot(self,snapshot_id:str)->tuple[ParameterRecord,...]:
        snap=self.snapshot(snapshot_id);result=[]
        history={(h.parameter_id,h.revision):h.record for h in self.history()}
        for pid,rev in snap.parameter_revisions:
            try:result.append(history[(pid,rev)])
            except KeyError:raise RuntimeError(f"Snapshot {snapshot_id} references unavailable revision {pid}@{rev}")
        body=json.dumps({"registry_revision":snap.registry_revision,"parameter_revisions":snap.parameter_revisions},
                        sort_keys=True,separators=(",",":")).encode()
        if hashlib.sha256(body).hexdigest()!=snap.checksum:raise RuntimeError("MPR snapshot checksum mismatch")
        return tuple(result)

    def _publish_state(self):
        if self._client is not None:
            self._client.set_state("joe.mpr.registry-revision",self._revision)
            self._client.set_state("joe.mpr.parameter-count",len(self._parameters))

    def _event(self,action:str,record:ParameterRecord):
        self._publish_state()
        if self._client is not None:
            self._client.publish("joe.mpr.changed",{
                "action":action,"parameter_id":record.parameter_id,"parameter_revision":record.revision,
                "registry_revision":record.registry_revision,"epistemic_class":record.epistemic_class.value,
                "unit":record.unit,"provenance":record.provenance
            })

    @property
    def registry_revision(self)->int:return self._revision

    def get(self,parameter_id:str)->ParameterRecord:
        return self._parameters[_validate_id(parameter_id)]

    def list(self)->tuple[ParameterRecord,...]:
        return tuple(self._parameters[k] for k in sorted(self._parameters))

    def history(self,parameter_id:str|None=None)->tuple[ParameterRevision,...]:
        pid=None if parameter_id is None else _validate_id(parameter_id)
        result=[]
        for item in self._history:
            if pid is None or item["parameter_id"]==pid:
                record=_record_from_json(item["record"])
                result.append(ParameterRevision(item["parameter_id"],item["revision"],item["registry_revision"],item["changed_at"],record))
        return tuple(result)

    def define(self,parameter_id:str,*,symbol:str,name:str,value:float,unit:str,
               uncertainty:float|None=None,uncertainty_unit:str|None=None,
               epistemic_class:EpistemicClass|str,provenance:str,description:str="")->ParameterRecord:
        pid=_validate_id(parameter_id)
        if pid in self._parameters:raise ValueError(f"Parameter already exists: {pid}")
        return self._write(pid,symbol=symbol,name=name,value=value,unit=unit,uncertainty=uncertainty,
                           uncertainty_unit=uncertainty_unit,epistemic_class=epistemic_class,
                           provenance=provenance,description=description,expected_revision=0,action="defined")

    def update(self,parameter_id:str,*,expected_revision:int,**changes)->ParameterRecord:
        pid=_validate_id(parameter_id);current=self.get(pid)
        allowed={"symbol","name","value","unit","uncertainty","uncertainty_unit","epistemic_class","provenance","description"}
        unknown=set(changes)-allowed
        if unknown:raise TypeError("Unsupported parameter fields: "+", ".join(sorted(unknown)))
        values={k:getattr(current,k) for k in allowed}
        values.update(changes)
        return self._write(pid,expected_revision=expected_revision,action="updated",**values)

    def _write(self,pid:str,*,symbol,name,value,unit,uncertainty,uncertainty_unit,
               epistemic_class,provenance,description,expected_revision,action):
        current=self._parameters.get(pid);current_revision=0 if current is None else current.revision
        if expected_revision!=current_revision:
            raise RuntimeError(f"Stale MPR write for {pid}: expected revision {expected_revision}, current revision {current_revision}")
        symbol=str(symbol).strip();name=str(name).strip();unit=str(unit).strip();provenance=str(provenance).strip();description=str(description).strip()
        if not symbol or not _SYMBOL.fullmatch(symbol):raise ValueError("symbol is required and must be <= 80 characters")
        if not name:raise ValueError("name is required")
        if not provenance:raise ValueError("provenance is required")
        value=_finite(value,"value");dimension=unit_dimension(unit)
        if uncertainty is not None:
            uncertainty=_finite(uncertainty,"uncertainty")
            if uncertainty<0:raise ValueError("uncertainty cannot be negative")
            uncertainty_unit=unit if uncertainty_unit is None else str(uncertainty_unit).strip()
            if not compatible_units(unit,uncertainty_unit):raise ValueError("uncertainty unit is dimensionally incompatible with parameter unit")
        elif uncertainty_unit is not None:
            raise ValueError("uncertainty_unit requires uncertainty")
        epistemic_class=EpistemicClass(epistemic_class)
        now=time.time();self._revision+=1
        record=ParameterRecord(pid,symbol,name,value,unit,dimension,uncertainty,uncertainty_unit,
                               epistemic_class,provenance,description,current_revision+1,self._revision,
                               now if current is None else current.created_at,now)
        self._parameters[pid]=record
        self._history.append({"parameter_id":pid,"revision":record.revision,"registry_revision":self._revision,
                              "changed_at":now,"record":_record_to_json(record)})
        try:self._atomic_save()
        except Exception:
            self._history.pop();self._revision-=1
            if current is None:self._parameters.pop(pid,None)
            else:self._parameters[pid]=current
            raise
        self._event(action,record);return record

    def search(self,text:str="",*,epistemic_class:EpistemicClass|str|None=None)->tuple[ParameterRecord,...]:
        query=str(text).strip().casefold();epistemic=None if epistemic_class is None else EpistemicClass(epistemic_class)
        return tuple(r for r in self.list() if (not query or query in " ".join((r.parameter_id,r.symbol,r.name,r.description,r.provenance,r.unit)).casefold())
                     and (epistemic is None or r.epistemic_class is epistemic))

    def export_json(self)->str:
        return json.dumps({"format":"JOE-MPR-INTERCHANGE","version":1,"registry_revision":self._revision,
                           "parameters":[_record_to_json(r) for r in self.list()]},
                          indent=2,sort_keys=True,ensure_ascii=False)+"\n"

    def export_csv(self)->str:
        out=io.StringIO(newline="");fields=["parameter_id","symbol","name","value","unit","uncertainty","uncertainty_unit","epistemic_class","provenance","description","revision","registry_revision"]
        writer=csv.DictWriter(out,fieldnames=fields);writer.writeheader()
        for r in self.list():writer.writerow({k:(r.epistemic_class.value if k=="epistemic_class" else getattr(r,k)) for k in fields})
        return out.getvalue()

    def import_json(self,text:str,*,require_empty:bool=True)->tuple[ParameterRecord,...]:
        raw=json.loads(text)
        if raw.get("format")!="JOE-MPR-INTERCHANGE" or raw.get("version")!=1 or not isinstance(raw.get("parameters"),list):
            raise ValueError("Not a supported JOE MPR interchange document")
        if require_empty and self._parameters:raise RuntimeError("MPR import requires an empty register")
        prepared=[];seen=set()
        for item in raw["parameters"]:
            pid=_validate_id(item["parameter_id"])
            if pid in seen or pid in self._parameters:raise ValueError(f"Duplicate parameter in import: {pid}")
            seen.add(pid);prepared.append(dict(parameter_id=pid,symbol=item["symbol"],name=item["name"],value=item["value"],unit=item["unit"],
                uncertainty=item.get("uncertainty"),uncertainty_unit=item.get("uncertainty_unit"),epistemic_class=item["epistemic_class"],
                provenance=item["provenance"],description=item.get("description","")))
        with tempfile.TemporaryDirectory() as td:
            probe=MasterParameterRegister(Path(td))
            for item in prepared:probe.define(**item)
        return tuple(self.define(**item) for item in prepared)

    def guardian_contract(self)->GuardianMPRContract:
        """Read-only machine contract for Guardian/scientific supervisory consumers.

        This contract exposes evidence and dependency context but no mutation capability.
        """
        status=self.status();views=[]
        for r in self.list():
            try:deps=self.derived(r.parameter_id).dependencies
            except KeyError:deps=()
            views.append(GuardianParameterView(
                r.parameter_id,r.symbol,r.value,r.unit,r.uncertainty,r.uncertainty_unit,
                r.epistemic_class.value,r.provenance,r.revision,r.registry_revision,
                tuple(deps),self.dependents(r.parameter_id)
            ))
        return GuardianMPRContract(
            "JOE-GUARDIAN-MPR/1",time.time(),self._revision,status.integrity_ok,
            tuple(views),tuple(x.snapshot_id for x in self.snapshots())
        )

    def status(self)->MPRStatus:
        if not self.path.exists():
            return MPRStatus(self._revision,len(self._parameters),len(self._history),None,True)
        raw=json.loads(self.path.read_text(encoding="utf-8"))
        actual=_checksum(raw["registry_revision"],raw["parameters"],raw["history"])
        return MPRStatus(self._revision,len(self._parameters),len(self._history),raw.get("checksum"),actual==raw.get("checksum"))

def qualify_mpr(register:MasterParameterRegister)->MPRQualification:
    checks=[];failures=[]
    try:
        status=register.status()
        if status.integrity_ok:checks.append("registry integrity verified")
        else:failures.append("registry integrity verification failed")
        for record in register.list():
            if unit_dimension(record.unit)!=record.dimension:failures.append(f"{record.parameter_id}: dimension mismatch")
            if record.uncertainty is not None and not compatible_units(record.unit,record.uncertainty_unit or ""):
                failures.append(f"{record.parameter_id}: uncertainty dimension mismatch")
        checks.append(f"{len(register.list())} parameter record(s) structurally and dimensionally checked")
        graph=register.dependency_graph()
        checks.append(f"dependency graph acyclic: {len(graph.edges)} edge(s)")
        for snap in register.snapshots():
            register.resolve_snapshot(snap.snapshot_id)
        checks.append(f"{len(register.snapshots())} configuration snapshot(s) integrity checked")
        revisions=[r.registry_revision for r in register.history()]
        if revisions==sorted(revisions) and len(revisions)==len(set(revisions)):
            checks.append("revision history is strictly ordered and unique")
        else:failures.append("revision history ordering/uniqueness failed")
    except Exception as exc:failures.append(f"qualification exception: {type(exc).__name__}: {exc}")
    return MPRQualification(not failures,tuple(checks),tuple(failures))


def mpr_release_readiness(register:MasterParameterRegister)->MPRReleaseReadiness:
    checks=[];failures=[];notes=[]
    q=qualify_mpr(register)
    if q.passed:checks.append("MPR structural/integrity qualification passed")
    else:failures.extend(q.failures)
    try:
        contract=register.guardian_contract()
        if contract.schema=="JOE-GUARDIAN-MPR/1" and contract.integrity_ok:
            checks.append("Guardian read-only contract valid and integrity-backed")
        else:failures.append("Guardian MPR contract invalid")
        if all(v.provenance and v.epistemic_class for v in contract.parameters):
            checks.append("all Guardian-visible parameters carry provenance and epistemic class")
        else:failures.append("Guardian-visible parameter missing provenance/evidence classification")
        graph=register.dependency_graph()
        if len(graph.topological_order)==len(graph.nodes):
            checks.append("dependency graph fully topologically ordered")
        else:failures.append("dependency graph incomplete")
        # Every snapshot must resolve against immutable history.
        for snap in register.snapshots():register.resolve_snapshot(snap.snapshot_id)
        checks.append("all configuration snapshots resolve against immutable history")
    except Exception as exc:failures.append(f"release-readiness exception: {type(exc).__name__}: {exc}")
    notes.append("Guardian contract is advisory/read-only and grants no authority to mutate MPR.")
    notes.append("MPR does not evaluate arbitrary expression text; numerical evaluation belongs to controlled scientific compute modules.")
    return MPRReleaseReadiness(not failures,tuple(checks),tuple(failures),tuple(notes))
