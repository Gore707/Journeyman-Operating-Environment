from __future__ import annotations
from dataclasses import dataclass
from html.parser import HTMLParser
import re

@dataclass(frozen=True)
class DocumentationTopic:
    title:str
    text:str
    anchor:str

class _Text(HTMLParser):
    def __init__(self):super().__init__();self.parts=[]
    def handle_data(self,data):self.parts.append(data)
def _plain(html):
    p=_Text();p.feed(html);return " ".join(" ".join(p.parts).split())

class DocumentationService:
    """Version-matched searchable projection of JOE's integrated manual."""
    def __init__(self,html,version,build):
        self.html=html;self.version=version;self.build=build
        self._topics=self._parse(html)

    def _parse(self,html):
        matches=list(re.finditer(r"<h2>(.*?)</h2>",html,re.I|re.S));out=[]
        for i,m in enumerate(matches):
            end=matches[i+1].start() if i+1<len(matches) else len(html)
            title=_plain(m.group(1));body=_plain(html[m.end():end])
            anchor=re.sub(r"[^a-z0-9]+","-",title.lower()).strip("-")
            out.append(DocumentationTopic(title,body,anchor))
        return tuple(out)

    def topics(self):return self._topics

    def search(self,query):
        q=" ".join(str(query).lower().split())
        if not q:return ()
        terms=q.split();ranked=[]
        for topic in self._topics:
            title=topic.title.lower();text=topic.text.lower()
            if all(term in title or term in text for term in terms):
                score=sum(5*title.count(term)+text.count(term) for term in terms)
                ranked.append((score,topic.title,topic))
        ranked.sort(key=lambda x:(-x[0],x[1]))
        return tuple(x[2] for x in ranked)

    def status(self):
        return {"version":self.version,"build":self.build,"topic_count":len(self._topics),
                "searchable":bool(self._topics)}


@dataclass(frozen=True)
class DocumentationQualification:
    passed:bool
    failures:tuple[str,...]

@dataclass(frozen=True)
class DocumentationReleaseReadiness:
    passed:bool
    index_passed:bool
    search_passed:bool
    version_passed:bool
    failures:tuple[str,...]

def qualify_documentation(service):
    failures=[]
    try:
        status=service.status()
        if not status["searchable"] or status["topic_count"]<1:failures.append("manual has no searchable topics")
        titles=[x.title for x in service.topics()]
        if len(titles)!=len(set(titles)):failures.append("duplicate documentation topic titles")
        if not service.version or not service.build:failures.append("documentation is not version/build matched")
    except Exception as exc:failures.append(f"documentation qualification failed: {exc}")
    return DocumentationQualification(not failures,tuple(failures))

def joe016_release_readiness(service):
    failures=[];q=qualify_documentation(service)
    index_ok=q.passed
    if not q.passed:failures.extend(q.failures)
    search_ok=False;version_ok=False
    try:
        topics=service.topics()
        if topics:
            token=next((w for w in topics[0].title.split() if len(w)>3),topics[0].title)
            search_ok=bool(service.search(token))
        version_ok=(service.status()["version"]==service.version and service.status()["build"]==service.build)
        if not search_ok:failures.append("search exercise returned no matching topic")
        if not version_ok:failures.append("version/build match failed")
    except Exception as exc:failures.append(f"documentation readiness exercise failed: {exc}")
    return DocumentationReleaseReadiness(not failures,index_ok,search_ok,version_ok,tuple(failures))
