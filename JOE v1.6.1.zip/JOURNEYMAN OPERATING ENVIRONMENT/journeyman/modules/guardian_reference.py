from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.guardian_reference import GuardianScientificReferenceEvaluator
MODULE=ModuleDescriptor(module_id="journeyman.guardian-reference",name="Guardian Scientific Reference Evaluator",version="1.0.0",
 requires=("journeyman.scientific-reference",),provides=("joe.guardian-reference",),consumes=("joe.scientific-reference",))
class Instance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_guardian_reference_module(runtime:ModuleRuntime):
    svc=GuardianScientificReferenceEvaluator(runtime.service("joe.scientific-reference"))
    runtime.register(MODULE,Instance(svc));runtime.activate("journeyman.guardian-reference")
    runtime.publish_service("journeyman.guardian-reference","joe.guardian-reference",svc);return svc
