from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.physics_safety import DeterministicPhysicsEnvelopeMonitor,physics_safety_release_readiness
from journeyman.core.predictive_horizon import PredictivePhysicsHorizonSupervisor,HorizonPolicy,predictive_horizon_release_readiness
from journeyman.core.safe_state_recovery import AdaptiveSafeStateSupervisor,RecoveryPolicy,safe_state_release_readiness
from journeyman.core.chronology_protection_governor import ChronologyProtectionGovernor,ProtectionPolicy,chronology_protection_release_readiness
from journeyman.core.performance_hil import performance_hil_release_readiness
from journeyman.core.final_stress_qualification import final_stress_release_readiness
from journeyman.core.rt_control import (DeterministicControlKernel,RTSupervisor,LatchedTripController,
 rt_guardian_contract,rt_core_readiness,rt_supervision_readiness,rt_hardware_boundary_readiness,
 RTAuditChain,CommandAcknowledgementRegistry,SILQualificationAdapter,rt_v1_release_readiness)
RT_MODULE=ModuleDescriptor(module_id="journeyman.rt-control",name="RT / Control / BUS-SAFE Interfaces",version="1.0.0",
 requires=("joe.core",),provides=("joe.rt-control",),consumes=("joe.alerts","joe.authority"))
class RTControlService:
    def __init__(self):self.kernel=DeterministicControlKernel();self.supervisor=RTSupervisor(self.kernel);self.trip_controller=LatchedTripController(self.kernel);self.audit=RTAuditChain();self.acknowledgements=CommandAcknowledgementRegistry();self.sil=SILQualificationAdapter();self.physics_envelope=DeterministicPhysicsEnvelopeMonitor();self.predictive_horizon=PredictivePhysicsHorizonSupervisor(HorizonPolicy(1.0,.05,.1,.02,.03,.25));self.safe_state=AdaptiveSafeStateSupervisor(RecoveryPolicy(-1.0,1.0));self.chronology_protection=ChronologyProtectionGovernor(ProtectionPolicy())
    def guardian_contract(self):return rt_guardian_contract(self.kernel)
    release_readiness=staticmethod(rt_v1_release_readiness)
    supervision_readiness=staticmethod(rt_supervision_readiness)
    hardware_boundary_readiness=staticmethod(rt_hardware_boundary_readiness)
    physics_safety_readiness=staticmethod(physics_safety_release_readiness)
    predictive_horizon_readiness=staticmethod(predictive_horizon_release_readiness)
    safe_state_readiness=staticmethod(safe_state_release_readiness)
    chronology_protection_readiness=staticmethod(chronology_protection_release_readiness)
    performance_hil_readiness=staticmethod(performance_hil_release_readiness)
    final_stress_readiness=staticmethod(final_stress_release_readiness)
class RTControlInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_rt_control_module(runtime:ModuleRuntime):
    svc=RTControlService();runtime.register(RT_MODULE,RTControlInstance(svc));runtime.activate("journeyman.rt-control")
    runtime.publish_service("journeyman.rt-control","joe.rt-control",svc);return svc
