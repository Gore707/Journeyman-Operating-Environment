"""Deterministic scientific-envelope protection for JOE.

This layer protects experiment progression when an implemented model becomes
invalid or numerically untrustworthy.  It is not a physical chronology-
protection detector and it never assigns probabilities to unresolved physics.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import IntEnum
import math
from typing import Iterable, Mapping

class PhysicsSafetyDisposition(IntEnum):
    NOMINAL=0
    CAUTION=10
    HOLD=20
    ABORT=30
    TRIP=40

@dataclass(frozen=True)
class SafetyCeiling:
    quantity_id:str
    caution:float|None=None
    hold:float|None=None
    abort:float|None=None
    trip:float|None=None
    absolute:bool=True
    unit:str="1"
    provenance:str="SOFTWARE: configured scientific envelope"
    def __post_init__(self):
        vals=[x for x in (self.caution,self.hold,self.abort,self.trip) if x is not None]
        if any(not math.isfinite(x) or x < 0 for x in vals): raise ValueError("ceilings must be finite and nonnegative")
        if vals != sorted(vals): raise ValueError("ceilings must be monotonic")

@dataclass(frozen=True)
class PhysicsSafetySample:
    quantity_id:str
    value:float
    unit:str
    solver_status:str="PASS"
    uncertainty:float|None=None
    provenance:str="SOFTWARE"

@dataclass(frozen=True)
class PhysicsSafetyFinding:
    quantity_id:str
    disposition:PhysicsSafetyDisposition
    reason:str
    value:float|None
    unit:str
    provenance:str

@dataclass(frozen=True)
class EnvelopeAssessment:
    disposition:PhysicsSafetyDisposition
    findings:tuple[PhysicsSafetyFinding,...]
    may_progress:bool
    epistemic_status:str

_STATUS_LOCKOUT={
    "DOMAIN_INVALID":PhysicsSafetyDisposition.HOLD,
    "MODEL_UNAVAILABLE":PhysicsSafetyDisposition.HOLD,
    "UNKNOWN_PHYSICS":PhysicsSafetyDisposition.HOLD,
    "PRECISION_INSUFFICIENT":PhysicsSafetyDisposition.HOLD,
    "INPUT_INCONSISTENT":PhysicsSafetyDisposition.HOLD,
    "NONCONVERGED":PhysicsSafetyDisposition.HOLD,
    "NUMERICAL_INSTABILITY":PhysicsSafetyDisposition.ABORT,
}

class DeterministicPhysicsEnvelopeMonitor:
    """Fail-closed scientific model envelope monitor; no AI authority required."""
    def __init__(self,ceilings:Iterable[SafetyCeiling]=()):
        self.ceilings={x.quantity_id:x for x in ceilings}
    def assess(self,samples:Iterable[PhysicsSafetySample])->EnvelopeAssessment:
        findings=[]
        for s in samples:
            if not math.isfinite(s.value):
                findings.append(PhysicsSafetyFinding(s.quantity_id,PhysicsSafetyDisposition.ABORT,"non-finite scientific value",s.value,s.unit,s.provenance));continue
            status=_STATUS_LOCKOUT.get(str(s.solver_status).upper())
            if status is not None:
                findings.append(PhysicsSafetyFinding(s.quantity_id,status,f"solver/model status {s.solver_status} requires fail-closed scientific lockout",s.value,s.unit,s.provenance));continue
            c=self.ceilings.get(s.quantity_id)
            if c is None: continue
            if c.unit!=s.unit:
                findings.append(PhysicsSafetyFinding(s.quantity_id,PhysicsSafetyDisposition.HOLD,f"unit mismatch: envelope {c.unit}, sample {s.unit}",s.value,s.unit,s.provenance));continue
            v=abs(s.value) if c.absolute else s.value
            # uncertainty is part of the envelope: test worst represented magnitude.
            if s.uncertainty is not None:
                if not math.isfinite(s.uncertainty) or s.uncertainty < 0:
                    findings.append(PhysicsSafetyFinding(s.quantity_id,PhysicsSafetyDisposition.HOLD,"invalid uncertainty",s.value,s.unit,s.provenance));continue
                v += s.uncertainty
            level=PhysicsSafetyDisposition.NOMINAL;reason="inside configured scientific envelope"
            for threshold,disp in ((c.caution,PhysicsSafetyDisposition.CAUTION),(c.hold,PhysicsSafetyDisposition.HOLD),(c.abort,PhysicsSafetyDisposition.ABORT),(c.trip,PhysicsSafetyDisposition.TRIP)):
                if threshold is not None and v>=threshold: level=disp;reason=f"envelope magnitude {v:.12g} reached {disp.name} ceiling {threshold:.12g}"
            if level!=PhysicsSafetyDisposition.NOMINAL:
                findings.append(PhysicsSafetyFinding(s.quantity_id,level,reason,s.value,s.unit,s.provenance))
        disposition=max((f.disposition for f in findings),default=PhysicsSafetyDisposition.NOMINAL)
        return EnvelopeAssessment(disposition,tuple(findings),disposition<PhysicsSafetyDisposition.HOLD,"MODEL_CONDITIONAL_SAFETY_ENVELOPE")

@dataclass(frozen=True)
class ResidualTrend:
    residual:float
    first_difference:float|None
    second_difference:float|None
    disposition:PhysicsSafetyDisposition
    reason:str

def assess_residual_history(history:Iterable[float],epsilon_max:float,divergence_ratio:float=1.25)->ResidualTrend:
    h=tuple(float(x) for x in history)
    if not h or epsilon_max<=0 or divergence_ratio<=1: raise ValueError("valid history, epsilon_max and divergence_ratio required")
    if any(not math.isfinite(x) or x<0 for x in h): return ResidualTrend(h[-1],None,None,PhysicsSafetyDisposition.ABORT,"invalid/non-finite residual")
    d1=h[-1]-h[-2] if len(h)>=2 else None
    d2=(h[-1]-2*h[-2]+h[-3]) if len(h)>=3 else None
    if h[-1]>epsilon_max:
        disp=PhysicsSafetyDisposition.HOLD
        reason="CTC consistency residual exceeds configured model ceiling"
        if len(h)>=3 and h[-1]>h[-2]*divergence_ratio and h[-2]>h[-3]*divergence_ratio:
            disp=PhysicsSafetyDisposition.ABORT;reason="CTC consistency residual is above ceiling and rapidly diverging"
        return ResidualTrend(h[-1],d1,d2,disp,reason)
    if len(h)>=4 and all(h[i]>=h[i-1] for i in range(len(h)-3,len(h))):
        return ResidualTrend(h[-1],d1,d2,PhysicsSafetyDisposition.CAUTION,"residual is not decreasing")
    return ResidualTrend(h[-1],d1,d2,PhysicsSafetyDisposition.NOMINAL,"residual remains inside configured model ceiling")

def guardian_physics_safety_contract(assessment:EnvelopeAssessment)->dict:
    return {"schema":"JOE-GUARDIAN-PHYSICS-SAFETY/1","authority":"READ_ONLY_ADVISORY","may_command":False,"may_override":False,
            "disposition":assessment.disposition.name,"may_progress":assessment.may_progress,"epistemic_status":assessment.epistemic_status,
            "findings":[{"quantity_id":f.quantity_id,"disposition":f.disposition.name,"reason":f.reason,"value":f.value,"unit":f.unit,"provenance":f.provenance} for f in assessment.findings],
            "truth_boundary":"Model-envelope violations are not detections of Hawking chronology protection or physical backreaction."}

def physics_safety_release_readiness()->dict:
    failures=[];checks=[]
    try:
        m=DeterministicPhysicsEnvelopeMonitor((SafetyCeiling("residual",.1,.2,.5,None,True,"1"),))
        if m.assess((PhysicsSafetySample("residual",.05,"1"),)).may_progress: checks.append("nominal envelope progression passed")
        if m.assess((PhysicsSafetySample("residual",.3,"1"),)).disposition==PhysicsSafetyDisposition.HOLD: checks.append("deterministic HOLD ceiling passed")
        if m.assess((PhysicsSafetySample("x",1,"1","MODEL_UNAVAILABLE"),)).disposition==PhysicsSafetyDisposition.HOLD: checks.append("MODEL_UNAVAILABLE fail-closed lockout passed")
        if assess_residual_history((.1,.2,.3,.5),.2).disposition==PhysicsSafetyDisposition.ABORT: checks.append("rapid residual divergence ABORT passed")
        if guardian_physics_safety_contract(m.assess(()))["authority"]=="READ_ONLY_ADVISORY": checks.append("Guardian authority boundary passed")
    except Exception as exc: failures.append(f"{type(exc).__name__}: {exc}")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),"notes":(
        "Scientific HOLD/ABORT protects model trust and experiment progression; it is not evidence of physical chronology protection.",
        "TRIP ceilings must only be configured where a separately qualified deterministic control requirement justifies them.",
        "No physical BUS-SAFE hardware is implemented by this subsystem.")}
