"""Digital Twin + Source Simulator module."""
from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.digital_twin import (DigitalTwinEngine,digital_twin_guardian_contract,
 synchronized_telemetry_frame,assess_sample_freshness,model_observation_residual,
 monitor_simulated_mouth_pair,digital_twin_monitor_guardian_contract,twin_to_d1_mouth_state,
 mouth_pair_temporal_state,couple_twin_to_chronology,synchronize_twin_object,
 chronology_coupled_guardian_contract,TwinWorldlineHistory,build_spatial_scene,
 relocate_twin_object,scene_bounds,spatial_scene_guardian_contract,digital_twin_release_readiness,
 DigitalTwinSession,digital_twin_v1_release_readiness)
DT_MODULE=ModuleDescriptor(module_id="journeyman.digital-twin",name="Digital Twin + Source Simulator",version="1.0.0",
 description="Deterministic simulation twin state, objects, clock and synthetic sources.",
 requires=("joe.core","journeyman.registry","journeyman.navigation"),provides=("joe.digital-twin",),
 consumes=("joe.registry","joe.navigation","joe.state-events"))
class DigitalTwinService:
    def create_engine(self,**kwargs):return DigitalTwinEngine(**kwargs)
    guardian_contract=staticmethod(digital_twin_guardian_contract)
    synchronized_frame=staticmethod(synchronized_telemetry_frame)
    assess_freshness=staticmethod(assess_sample_freshness)
    residual=staticmethod(model_observation_residual)
    monitor_mouth_pair=staticmethod(monitor_simulated_mouth_pair)
    monitor_guardian_contract=staticmethod(digital_twin_monitor_guardian_contract)
    to_d1_mouth_state=staticmethod(twin_to_d1_mouth_state)
    mouth_temporal_pair=staticmethod(mouth_pair_temporal_state)
    chronology_coupling=staticmethod(couple_twin_to_chronology)
    synchronize_object=staticmethod(synchronize_twin_object)
    chronology_guardian_contract=staticmethod(chronology_coupled_guardian_contract)
    worldline_history=TwinWorldlineHistory
    build_scene=staticmethod(build_spatial_scene)
    relocate_object=staticmethod(relocate_twin_object)
    scene_bounds=staticmethod(scene_bounds)
    spatial_guardian_contract=staticmethod(spatial_scene_guardian_contract)
    release_readiness=staticmethod(digital_twin_v1_release_readiness)
    create_session=staticmethod(DigitalTwinSession)
class DigitalTwinInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_digital_twin_module(runtime:ModuleRuntime):
    svc=DigitalTwinService();runtime.register(DT_MODULE,DigitalTwinInstance(svc));runtime.activate("journeyman.digital-twin")
    runtime.publish_service("journeyman.digital-twin","joe.digital-twin",svc);return svc
