"""Controlled online scientific-intelligence acquisition for JOE.

Network material is untrusted candidate knowledge. This service never mutates
JOE's controlled scientific reference library and never executes downloaded
content.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse, urlencode
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
import hashlib, json, socket, xml.etree.ElementTree as ET
from typing import Iterable

SCHEMA="JOE-SCIENTIFIC-INTELLIGENCE/1"
PIPELINE=("DISCOVERED","INGESTED","CROSS_CHECKED","CANDIDATE","VALIDATED","PROMOTED")
DEFAULT_TOPICS=("black hole","Kerr black hole","wormhole","quantum energy inequality","semiclassical gravity","chronology protection")

@dataclass(frozen=True)
class Source:
    source_id:str; name:str; base_url:str; allowed_hosts:tuple[str,...]; kind:str="ATOM"

@dataclass(frozen=True)
class Finding:
    finding_id:str; source_id:str; title:str; url:str; published:str; summary:str
    stage:str; sha256:str; retrieved_at:str; provenance:str

DEFAULT_SOURCES=(
    Source("arxiv","arXiv","https://export.arxiv.org/api/query",("export.arxiv.org",),"ARXIV_ATOM"),
    Source("crossref","Crossref","https://api.crossref.org/works",("api.crossref.org",),"CROSSREF_JSON"),
)

def utcnow(): return datetime.now(timezone.utc).isoformat()

def _clean(text:str,maxlen:int=4000)->str:
    return " ".join((text or "").split())[:maxlen]

class ScientificIntelligenceService:
    def __init__(self,root:Path,sources:Iterable[Source]=DEFAULT_SOURCES):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        self.db_path=self.root/"candidate_findings.json"
        self.state_path=self.root/"sync_state.json"
        self.sources=tuple(sources);self.paused=False
        if not self.db_path.exists(): self._write_db([])
    def _write_db(self,items):
        tmp=self.db_path.with_suffix(".tmp")
        tmp.write_text(json.dumps({"schema":SCHEMA,"updated_at":utcnow(),"findings":items},indent=2,ensure_ascii=False),encoding="utf-8")
        tmp.replace(self.db_path)
    def findings(self):
        try:return tuple(json.loads(self.db_path.read_text(encoding="utf-8")).get("findings",[]))
        except Exception:return ()
    def network_available(self,timeout:float=1.0):
        # DNS/TCP only; does not send scientific queries.
        for source in self.sources:
            host=source.allowed_hosts[0]
            try:
                with socket.create_connection((host,443),timeout=timeout): return True
            except OSError:continue
        return False
    def _allowed(self,source:Source,url:str):
        p=urlparse(url)
        return p.scheme=="https" and (p.hostname or "").lower() in source.allowed_hosts
    def _fetch(self,source:Source,url:str,timeout:float=8.0,max_bytes:int=2_000_000):
        if not self._allowed(source,url):raise ValueError("URL is outside configured scientific-source allowlist")
        req=Request(url,headers={"User-Agent":"JOE-Scientific-Intelligence/1.0 (controlled literature metadata client)","Accept":"application/atom+xml, application/xml, text/xml"})
        with urlopen(req,timeout=timeout) as r:
            data=r.read(max_bytes+1)
            if len(data)>max_bytes:raise ValueError("source response exceeds configured byte limit")
            return data
    def _arxiv_url(self,source:Source,topics,limit):
        # arXiv API: metadata only; conservative request count/size.
        query=" OR ".join('all:"'+t.replace('"','')+'"' for t in topics)
        return source.base_url+"?"+urlencode({"search_query":query,"start":0,"max_results":min(max(int(limit),1),50),"sortBy":"submittedDate","sortOrder":"descending"})
    def _parse_arxiv(self,source:Source,data:bytes):
        root=ET.fromstring(data);ns={"a":"http://www.w3.org/2005/Atom"};out=[]
        for e in root.findall("a:entry",ns):
            title=_clean(e.findtext("a:title",default="",namespaces=ns),500)
            link=_clean(e.findtext("a:id",default="",namespaces=ns),1000)
            published=_clean(e.findtext("a:published",default="",namespaces=ns),100)
            summary=_clean(e.findtext("a:summary",default="",namespaces=ns),4000)
            payload={"source_id":source.source_id,"title":title,"url":link,"published":published,"summary":summary}
            sha=hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
            out.append(Finding("lit-"+sha[:20],source.source_id,title,link,published,summary,"INGESTED",sha,utcnow(),"INTERNET: untrusted literature metadata; not authoritative JOE physics"))
        return out
    def _crossref_url(self,source:Source,topics,limit):
        return source.base_url+"?"+urlencode({"query.bibliographic":" ".join(topics),"rows":min(max(int(limit),1),50),"select":"DOI,title,URL,published,abstract,publisher"})
    def _parse_crossref(self,source:Source,data:bytes):
        raw=json.loads(data.decode("utf-8"));out=[]
        for e in raw.get("message",{}).get("items",[]):
            title=_clean(" ".join(e.get("title",[]) or []),500);link=_clean(e.get("URL","") or "",1000)
            date=e.get("published",{}).get("date-parts",[[""]])[0];published="-".join(str(x) for x in date if x!="")
            summary=_clean(e.get("abstract","") or e.get("publisher","") or "",4000)
            payload={"source_id":source.source_id,"title":title,"url":link,"published":published,"summary":summary}
            sha=hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
            out.append(Finding("lit-"+sha[:20],source.source_id,title,link,published,summary,"INGESTED",sha,utcnow(),"INTERNET: untrusted literature metadata; not authoritative JOE physics"))
        return out
    def sync_now(self,topics=DEFAULT_TOPICS,limit:int=20):
        if self.paused:return {"status":"PAUSED","new":0,"total":len(self.findings()),"errors":()}
        existing={x.get("finding_id"):x for x in self.findings()};errors=[];new=0;checked=0
        for source in self.sources:
            try:
                if source.kind=="ARXIV_ATOM":
                    data=self._fetch(source,self._arxiv_url(source,topics,limit));items=self._parse_arxiv(source,data)
                elif source.kind=="CROSSREF_JSON":
                    data=self._fetch(source,self._crossref_url(source,topics,limit));items=self._parse_crossref(source,data)
                else:items=[]
                checked+=1
                for item in items:
                    if item.finding_id not in existing:new+=1
                    existing[item.finding_id]=asdict(item)
            except (OSError,ValueError,ET.ParseError,HTTPError,URLError) as exc:
                errors.append(f"{source.source_id}: {type(exc).__name__}: {exc}")
        values=sorted(existing.values(),key=lambda x:(x.get("published",""),x.get("finding_id","")),reverse=True)
        self._write_db(values)
        state={"schema":SCHEMA,"last_sync":utcnow(),"sources_checked":checked,"new_items":new,"total":len(values),"errors":errors,"authoritative_db_changes":0}
        self.state_path.write_text(json.dumps(state,indent=2),encoding="utf-8")
        return {"status":"ONLINE" if checked else "OFFLINE_OR_ERROR","new":new,"total":len(values),"errors":tuple(errors),"sources_checked":checked,"authoritative_db_changes":0}
    def set_paused(self,value:bool):self.paused=bool(value);return self.paused
    def promote(self,*_args,**_kwargs):
        raise PermissionError("Internet findings cannot directly promote themselves into JOE authoritative scientific references")
    def cross_check_candidate(self,finding_id:str,reference_library):
        rows={x.get("finding_id"):x for x in self.findings()};row=rows.get(finding_id)
        if not row:raise KeyError(finding_id)
        terms=[w for w in row.get("title","").split() if len(w)>=5][:8];matches=[]
        for term in terms:
            matches.extend(d.document_id for d in reference_library.search(term))
        return {"finding_id":finding_id,"stage":"CROSS_CHECKED","reference_matches":tuple(sorted(set(matches))),"note":"Lexical cross-check only; scientific validation and promotion remain separate controlled actions."}
    def status(self):
        try:state=json.loads(self.state_path.read_text(encoding="utf-8"))
        except Exception:state={}
        rows=self.findings()
        return {"network":"ONLINE" if self.network_available(.25) else "OFFLINE","background":"PAUSED" if self.paused else "ACTIVE",
                "last_sync":state.get("last_sync","NEVER"),"sources_checked":state.get("sources_checked",0),"new_items":state.get("new_items",0),
                "candidate_findings":len(rows),"validated":sum(x.get("stage")=="VALIDATED" for x in rows),"authoritative_db_changes":0,
                "sources":tuple(asdict(x) for x in self.sources)}
    def guardian_contract(self):
        return {"schema":"JOE-GUARDIAN-SCIENTIFIC-INTELLIGENCE/1","authority":"READ_ONLY_ADVISORY","network_content_trust":"UNTRUSTED_CANDIDATE",
                "pipeline":PIPELINE,"rules":("network content never directly changes controlled physics","downloaded content is never executed","paywalls/authentication barriers are not bypassed","PROMOTED requires a separate controlled validation workflow"),"status":self.status()}
    def readiness(self):
        failures=[]
        try:
            assert self.root.exists(); assert self.db_path.exists()
            for s in self.sources:
                if not self._allowed(s,s.base_url):failures.append("allowlist failure: "+s.source_id)
            try:self.promote("x")
            except PermissionError:pass
            else:failures.append("direct promotion was not blocked")
        except Exception as exc:failures.append(type(exc).__name__+": "+str(exc))
        return {"passed":not failures,"failures":tuple(failures),"notes":("Network availability is not required for local JOE operation.","Candidate literature is isolated from authoritative references.")}
