from .workspaces import LiveTimeSeriesWorkspace, MPRWorkspace, GeometryWorkspace, StressEnergyWorkspace, ScientificRegistryWorkspace, NavigationWorkspace, TraversabilityWorkspace, QFTWorkspace, ChronologyWorkspace, MouthDynamicsWorkspace, RingLaserWorkspace, VerificationWorkspace, DigitalTwinWorkspace, ExperimentDesignerWorkspace, MetrologyWorkspace, GuardianWorkspace, AdvancedVisualizationWorkspace, ScientificDataWorkspace, ReportGeneratorWorkspace, ComputeBackendWorkspace, QuantumRuntimeWorkspace, RTControlWorkspace, IntegratedQualificationWorkspace, ScientificReferenceWorkspace, ScientificIntelligenceWorkspace
import logging
import os
import tempfile
from pathlib import Path
from PySide6.QtCore import QTimer, Qt, QUrl, QByteArray, QProcess
from PySide6.QtGui import QAction, QDesktopServices, QKeySequence, QGuiApplication
from PySide6.QtWidgets import QLabel, QMainWindow, QMessageBox, QStatusBar, QMenu, QInputDialog, QToolBar, QToolButton
from journeyman import __build__, __version__
from journeyman.core.logging_service import LOG_FILE
from journeyman.core.paths import DATA_DIR, LOG_DIR
from journeyman.core.settings import Settings
from journeyman.core.system_info import snapshot
from journeyman.core.runtime import format_uptime
from journeyman.core.workspace_layout import (WorkspaceLayoutEntry, clear_layout, load_layout, save_layout, save_named_layout, load_named_layout, list_named_layouts, delete_named_layout, backup_layout, restore_layout_backup, entries_from_snapshot)
from journeyman.core.workspace_policy import cycle_index, validate_workspace_title, normalize_display_index, can_modify_workspace
from journeyman.core.builtin_modules import register_builtin_modules
from journeyman.core.module_runtime import ModuleRuntime, qualify_module_runtime, joe003_release_readiness
from journeyman.core.state_events import qualify_state_event_backbone, joe004_release_readiness
from journeyman.core.storage import qualify_storage, storage_health, joe005_release_readiness
from journeyman.core.job_engine import qualify_job_engine, joe006_release_readiness
from journeyman.core.telemetry import qualify_host_telemetry, joe007_release_readiness
from journeyman.core.data_streams import qualify_scientific_data_streams, joe008_release_readiness
from journeyman.core.workspace_qualification import qualify_layout, compare_layouts, LifecycleState, qualify_lifecycle, qualify_workspace_system, joe002_release_readiness
from .dialogs import LogViewerDialog, ManualDialog, SettingsDialog, SystemInfoDialog, StartupDiagnosticsDialog, WorkspaceManagerDialog
from .workspaces import ExternalWorkspaceWindow, LogWorkspace, OverviewWorkspace, WorkspaceArea, geometry_to_b64, restore_geometry_b64

log = logging.getLogger("journeyman.ui")

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = Settings.load()
        self.module_runtime = ModuleRuntime()
        register_builtin_modules(self.module_runtime)
        from journeyman.modules.mpr import register_mpr_module
        register_mpr_module(self.module_runtime)
        from journeyman.modules.scientific_registry import register_scientific_registry_module
        register_scientific_registry_module(self.module_runtime)
        from journeyman.modules.navigation import register_navigation_module
        register_navigation_module(self.module_runtime)
        from journeyman.modules.geometry import register_geometry_module
        register_geometry_module(self.module_runtime)
        from journeyman.modules.traversability import register_traversability_module
        register_traversability_module(self.module_runtime)
        from journeyman.modules.stress_energy import register_stress_energy_module
        register_stress_energy_module(self.module_runtime)
        from journeyman.modules.qft import register_qft_module
        register_qft_module(self.module_runtime)
        from journeyman.modules.chronology import register_chronology_module
        register_chronology_module(self.module_runtime)
        from journeyman.modules.mouth_dynamics import register_mouth_dynamics_module
        register_mouth_dynamics_module(self.module_runtime)
        from journeyman.modules.ring_laser import register_ring_laser_module
        register_ring_laser_module(self.module_runtime)
        from journeyman.modules.verification import register_verification_module
        register_verification_module(self.module_runtime)
        from journeyman.modules.digital_twin import register_digital_twin_module
        register_digital_twin_module(self.module_runtime)
        from journeyman.modules.experiment_designer import register_experiment_designer_module
        register_experiment_designer_module(self.module_runtime)
        from journeyman.modules.metrology import register_metrology_module
        register_metrology_module(self.module_runtime)
        from journeyman.modules.guardian import register_guardian_module
        register_guardian_module(self.module_runtime)
        from journeyman.modules.advanced_visualization import register_advanced_visualization_module
        register_advanced_visualization_module(self.module_runtime)
        from journeyman.modules.scientific_data import register_scientific_data_module
        register_scientific_data_module(self.module_runtime)
        from journeyman.modules.reports import register_report_module
        register_report_module(self.module_runtime)
        from journeyman.modules.compute_backends import register_compute_module
        register_compute_module(self.module_runtime)
        from journeyman.modules.quantum_runtime import register_quantum_runtime_module
        register_quantum_runtime_module(self.module_runtime)
        from journeyman.modules.rt_control import register_rt_control_module
        register_rt_control_module(self.module_runtime)
        from journeyman.modules.scientific_reference import register_scientific_reference_module
        from journeyman.core.paths import DATA_DIR
        register_scientific_reference_module(self.module_runtime,DATA_DIR / "reference")
        from journeyman.modules.scientific_intelligence import register_scientific_intelligence_module
        register_scientific_intelligence_module(self.module_runtime,DATA_DIR / "scientific_intelligence")
        from journeyman.modules.guardian_reference import register_guardian_reference_module
        register_guardian_reference_module(self.module_runtime)
        from journeyman.modules.integrated_qualification import register_integrated_qualification_module
        from journeyman import __build__
        register_integrated_qualification_module(self.module_runtime,__build__)
        self._allow_close = False
        self.external_workspaces = []
        self._last_external_workspace = None
        self.setWindowTitle(f"Journeyman Operating Environment — JOE v{__version__} — {__build__}")
        self.resize(1280, 800)
        self.setMinimumSize(900, 600)
        geometry = self.settings.geometry_bytes()
        if geometry:
            self.restoreGeometry(QByteArray(geometry))
        self._build_workspace_area()
        self._build_menu()
        self._build_toolbar()
        self._build_status_bar()
        if not self.restore_workspace_layout():
            self.open_overview_workspace()
        self._restore_last_active_workspace()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.refresh_system_status)
        self._timer.start(self.settings.telemetry_interval_ms)
        self.refresh_system_status()
        log.info("Main application shell initialized (%s / %s)", __build__, __version__)
        self._telemetry_status_timer = QTimer(self)
        self._telemetry_status_timer.setInterval(1000)
        self._telemetry_status_timer.timeout.connect(self._refresh_telemetry_status)
        self._telemetry_status_timer.start()
        self._refresh_telemetry_status()
        self._scientific_intel_timer = QTimer(self)
        self._scientific_intel_timer.setInterval(6 * 60 * 60 * 1000)
        self._scientific_intel_timer.timeout.connect(self._background_scientific_intelligence_sync)
        self._scientific_intel_timer.start()
        QTimer.singleShot(45000, self._background_scientific_intelligence_sync)

    def _background_scientific_intelligence_sync(self):
        """Run literature synchronization out-of-process so network/parser faults cannot stall Qt."""
        if getattr(self, "_sciintel_sync_running", False):
            return
        try:
            svc = self.module_runtime.service("joe.scientific-intelligence")
            if svc.paused:
                return
        except Exception as exc:
            log.info("Background scientific-intelligence sync skipped: %s", exc)
            return
        self._sciintel_sync_running = True
        proc = QProcess(self)
        self._sciintel_process = proc
        proc.setProgram(os.fspath(Path(os.sys.executable)))
        proc.setArguments(["-X", "faulthandler", "-m", "journeyman.core.scientific_intelligence_worker", "--limit", "12"])
        proc.setWorkingDirectory(os.fspath(Path(__file__).resolve().parents[2]))
        def finished(exit_code, exit_status):
            self._sciintel_sync_running = False
            if exit_code != 0:
                log.warning("Scientific-intelligence worker exited with code %s", exit_code)
            self._sciintel_process = None
        proc.finished.connect(finished)
        proc.errorOccurred.connect(lambda _err: log.warning("Scientific-intelligence worker process error: %s", proc.errorString()))
        proc.start()

    def _build_workspace_area(self):
        self.workspace_area = WorkspaceArea(self)
        self.workspace_area.workspace_changed.connect(self._refresh_workspace_menu)
        self.setCentralWidget(self.workspace_area)

    def _add_menu_action(self, menu, text, callback, shortcut=None):
        action = QAction(text, self)
        if shortcut:
            action.setShortcut(shortcut)
        action.triggered.connect(callback)
        menu.addAction(action)
        return action

    def _build_menu(self):
        """Human-oriented navigation. Every existing workspace remains reachable."""
        bar = self.menuBar()
        bar.clear()

        # SYSTEM — settings, files, runtime diagnostics and maintenance only.
        system = bar.addMenu("&System")
        self._add_menu_action(system, "Settings…", self.open_settings)
        system.addSeparator()
        self._add_menu_action(system, "System Information…", self.open_system_info)
        self._add_menu_action(system, "Startup Diagnostics…", self.open_startup_diagnostics)
        self._add_menu_action(system, "Module Runtime Status…", self.show_module_runtime_status)
        self._add_menu_action(system, "State / Event Backbone Status…", self.show_state_event_backbone_status)
        self._add_menu_action(system, "Storage / Configuration Status…", self.show_storage_status)
        self._add_menu_action(system, "Storage Health…", self.show_storage_health)
        self._add_menu_action(system, "Job / Compute Engine Status…", self.show_job_engine_status)
        self._add_menu_action(system, "System Health…", self.open_system_health)
        system.addSeparator()
        self._add_menu_action(system, "Open Data Folder", lambda: self._open_folder(DATA_DIR))
        self._add_menu_action(system, "Open Logs Folder", lambda: self._open_folder(LOG_DIR))
        self._add_menu_action(system, "View JOE Log…", self.open_log_viewer)
        system.addSeparator()
        self._add_menu_action(system, "Save & Quit", self.save_and_quit, "Ctrl+Shift+Q")
        self._add_menu_action(system, "Exit", self.close)

        # WORKSPACES — desktop/window management plus core registries.
        workspaces = bar.addMenu("&Workspaces")
        self._add_menu_action(workspaces, "Overview", self.open_overview_workspace, "Ctrl+Shift+O")
        self._add_menu_action(workspaces, "Master Parameter Register", self.open_mpr)
        self._add_menu_action(workspaces, "Scientific Object / Units Registry", self.open_scientific_registry)
        self._add_menu_action(workspaces, "Coordinate, Time & 3D Navigation", self.open_navigation)
        workspaces.addSeparator()
        self._add_menu_action(workspaces, "Workspace Manager…", self.open_workspace_manager, "Ctrl+Shift+W")
        self._add_menu_action(workspaces, "Detach Active Workspace", self.detach_active_workspace, "Ctrl+Shift+D")
        self._add_menu_action(workspaces, "Reattach All External Workspaces", self.reattach_all_workspaces)
        self._add_menu_action(workspaces, "Tile Workspaces", self.workspace_area.tileSubWindows)
        self._add_menu_action(workspaces, "Cascade Workspaces", self.workspace_area.cascadeSubWindows)
        self._add_menu_action(workspaces, "Minimize All Workspaces", self.minimize_all_workspaces)
        self._add_menu_action(workspaces, "Restore All Workspaces", self.restore_all_workspaces)
        self._add_menu_action(workspaces, "Close Active Workspace", self.close_active_workspace, "Ctrl+W")
        workspaces.addSeparator()
        layouts = workspaces.addMenu("Layouts")
        self._add_menu_action(layouts, "Save Workspace Layout", self.save_workspace_layout)
        self._add_menu_action(layouts, "Save Layout As…", self.save_named_workspace_layout)
        self.named_layouts_menu = QMenu("Named Layouts", self)
        self.named_layouts_menu.aboutToShow.connect(self._refresh_named_layouts_menu)
        layouts.addMenu(self.named_layouts_menu)
        self._add_menu_action(layouts, "Restore Saved Layout", lambda: self.restore_workspace_layout(force=True))
        self._add_menu_action(layouts, "Recover Previous Saved Layout", self.recover_previous_workspace_layout)
        self._add_menu_action(layouts, "Clear Saved Layout", self.clear_saved_workspace_layout)
        navigation = workspaces.addMenu("Workspace Navigation")
        self._add_menu_action(navigation, "Next Workspace", lambda: self.cycle_workspace(1), "Ctrl+Tab")
        self._add_menu_action(navigation, "Previous Workspace", lambda: self.cycle_workspace(-1), "Ctrl+Shift+Tab")
        self.display_menu = QMenu("Move Active Workspace to Display", self)
        self.display_menu.aboutToShow.connect(self._refresh_display_menu)
        navigation.addMenu(self.display_menu)
        self._add_menu_action(navigation, "Center Active Workspace", self.center_active_workspace)
        self._add_menu_action(navigation, "Lock / Unlock Active Workspace", self.toggle_active_workspace_lock, "Ctrl+Shift+K")
        self.workspace_list_menu = QMenu("Open Workspaces", self)
        workspaces.addMenu(self.workspace_list_menu)
        self._refresh_workspace_menu()

        # PHYSICS
        physics = bar.addMenu("&Physics")
        self._add_menu_action(physics, "Geometry / Metric Workbench", self.open_geometry)
        self._add_menu_action(physics, "Stress-Energy / Einstein Tensor", self.open_stress_energy)
        physics.addSeparator()
        self._add_menu_action(physics, "Human Traversability [T-1]", self.open_traversability)
        self._add_menu_action(physics, "QFT / Semiclassical / Quantum Inequality [Q-1]", self.open_qft)
        self._add_menu_action(physics, "Chronology Analyzer [C-1]", self.open_chronology)
        self._add_menu_action(physics, "Mouth Dynamics [D-1]", self.open_mouth_dynamics)
        self._add_menu_action(physics, "Method-B / Ring-Laser", self.open_ring_laser)
        physics.addSeparator()
        self._add_menu_action(physics, "Scientific Reference / Algorithm Library", self.open_scientific_reference)

        # EXPERIMENT
        experiment = bar.addMenu("&Experiment")
        self._add_menu_action(experiment, "Digital Twin + Source Simulator", self.open_digital_twin)
        self._add_menu_action(experiment, "Experiment Designer / Sequencer", self.open_experiment_designer)
        self._add_menu_action(experiment, "Metrology & Temporal Navigation", self.open_metrology)
        experiment.addSeparator()
        self._add_menu_action(experiment, "Projects & Sessions…", self.open_projects_sessions)
        self._add_menu_action(experiment, "Run Records…", self.show_run_records)
        self._add_menu_action(experiment, "Run / Data Review Workbench", self.open_run_review_workbench)

        # ANALYZE
        analyze = bar.addMenu("&Analyze")
        self._add_menu_action(analyze, "Verification & Uncertainty", self.open_verification)
        self._add_menu_action(analyze, "Advanced Analysis & Visualization", self.open_advanced_visualization)
        analyze.addSeparator()
        self._add_menu_action(analyze, "Live Time-Series", self.open_live_time_series)
        self._add_menu_action(analyze, "Scatter / Histogram Analysis", self.open_analysis_plot)
        self._add_menu_action(analyze, "Numeric Instrument", self.open_numeric_instrument)
        self._add_menu_action(analyze, "Scientific Data Table", self.open_scientific_table)
        self._add_menu_action(analyze, "Matrix / Heatmap", self.open_matrix_heatmap)
        self._add_menu_action(analyze, "Scientific Field Visualization", self.open_scientific_field)
        analyze.addSeparator()
        self._add_menu_action(analyze, "Scientific Data & Provenance", self.open_scientific_data)
        self._add_menu_action(analyze, "Report / Dossier Generator", self.open_report_generator)

        # COMPUTE
        compute = bar.addMenu("&Compute")
        self._add_menu_action(compute, "Compute Backend Manager", self.open_compute_backends)
        self._add_menu_action(compute, "QPU Adapter / Quantum Runtime", self.open_quantum_runtime)
        compute.addSeparator()
        self._add_menu_action(compute, "Job / Compute Engine Status…", self.show_job_engine_status)

        # SAFETY
        safety = bar.addMenu("Sa&fety")
        self._add_menu_action(safety, "Guardian AI Governor", self.open_guardian)
        self._add_menu_action(safety, "RT / Control / BUS-SAFE Interfaces", self.open_rt_control)
        self._add_menu_action(safety, "Authority & Safety Boundaries…", self.open_authority_boundaries)
        self._add_menu_action(safety, "Alerts…", self.open_alerts)
        self._add_menu_action(safety, "Synchronize Health Alerts", self.synchronize_health_alerts)
        safety.addSeparator()
        self._add_menu_action(safety, "Integrated Qualification Center", self.open_integrated_qualification)

        # INTELLIGENCE
        intelligence = bar.addMenu("&Intelligence")
        self._add_menu_action(intelligence, "Guardian AI Governor", self.open_guardian)
        self._add_menu_action(intelligence, "Scientific Intelligence / Literature Watch", self.open_scientific_intelligence)
        self._add_menu_action(intelligence, "Scientific Reference / Algorithm Library", self.open_scientific_reference)

        # QUALIFICATION — keeps every legacy qualification/readiness capability reachable,
        # without flooding the System menu.
        qualification = bar.addMenu("&Qualification")
        self._add_menu_action(qualification, "Integrated Qualification Center", self.open_integrated_qualification)
        qualification.addSeparator()
        module_q = qualification.addMenu("Core / Runtime")
        for label, callback in [
            ("Qualify Module Runtime…", self.qualify_module_runtime),
            ("JOE-003 Release Readiness…", self.joe003_release_readiness),
            ("Qualify State/Event Backbone…", self.qualify_state_event_backbone),
            ("JOE-004 Release Readiness…", self.joe004_release_readiness),
            ("Qualify Storage / Configuration…", self.qualify_storage_configuration),
            ("JOE-005 Release Readiness…", self.joe005_release_readiness),
            ("Qualify Job / Compute Engine…", self.qualify_job_compute_engine),
            ("JOE-006 Release Readiness…", self.joe006_release_readiness),
            ("Qualify Host Telemetry…", self.qualify_host_telemetry),
            ("JOE-007 Release Readiness…", self.joe007_release_readiness),
            ("Qualify Scientific Data Streams…", self.qualify_scientific_data_streams),
            ("JOE-008 Release Readiness…", self.joe008_release_readiness),
            ("Qualify Visualization Engine…", self.qualify_visualization_engine),
        ]: self._add_menu_action(module_q, label, callback)

        science_q = qualification.addMenu("Scientific Modules")
        for label, callback in [
            ("MPR Release Readiness…", self.mpr_release_readiness),
            ("Registry Release Readiness…", self.registry_release_readiness),
            ("Navigation Release Readiness…", self.navigation_release_readiness),
            ("Geometry Release Readiness…", self.geometry_release_readiness),
            ("Stress-Energy Release Readiness…", self.stress_energy_release_readiness),
            ("T-1 Release Readiness…", self.traversability_release_readiness),
            ("Q-1 Release Readiness…", self.qft_release_readiness),
            ("C-1 Release Readiness…", self.chronology_release_readiness),
            ("D-1 Release Readiness…", self.mouth_dynamics_release_readiness),
            ("Method-B Release Readiness…", self.ring_laser_release_readiness),
            ("V&V Release Readiness…", self.verification_release_readiness),
            ("Digital Twin Release Readiness…", self.digital_twin_release_readiness),
            ("Experiment Designer Release Readiness…", self.experiment_designer_release_readiness),
            ("Metrology Release Readiness…", self.metrology_release_readiness),
            ("Guardian Release Readiness…", self.guardian_release_readiness),
            ("Visualization Release Readiness…", self.visualization_release_readiness),
            ("Scientific Data Release Readiness…", self.scientific_data_release_readiness),
            ("Report Generator Release Readiness…", self.report_release_readiness),
            ("Compute Backend Release Readiness…", self.compute_release_readiness),
            ("Quantum Runtime Release Readiness…", self.quantum_release_readiness),
            ("RT / Control Release Readiness…", self.rt_release_readiness),
        ]: self._add_menu_action(science_q, label, callback)

        ops_q = qualification.addMenu("Operations / Desktop")
        for label, callback in [
            ("Qualify Current Workspace Desktop…", self.qualify_current_workspace_desktop),
            ("Qualify Workspace Persistence…", self.qualify_workspace_persistence),
            ("Qualify Workspace Lifecycle…", self.qualify_workspace_lifecycle),
            ("Run JOE-002 Qualification Suite…", self.run_joe002_qualification_suite),
            ("JOE-002 Release Readiness…", self.run_joe002_release_readiness),
            ("Qualify Authority & Safety…", self.qualify_authority_safety),
            ("JOE-015 Release Readiness…", self.joe015_release_readiness),
            ("Qualify Alerts & Anomalies…", self.qualify_alerts),
            ("JOE-014 Release Readiness…", self.joe014_release_readiness),
            ("Qualify Diagnostics & Health…", self.qualify_diagnostics_health),
            ("JOE-013 Release Readiness…", self.joe013_release_readiness),
            ("Qualify Projects & Sessions…", self.qualify_projects_sessions),
            ("JOE-012 Release Readiness…", self.joe012_release_readiness),
            ("Qualify Run/Data Review…", self.qualify_run_review),
            ("JOE-011 Release Readiness…", self.joe011_release_readiness),
            ("Qualify Help System…", self.qualify_help_system),
            ("JOE-016 Release Readiness…", self.joe016_release_readiness),
            ("JOE Final Release Gate…", self.joe_final_release_gate),
        ]: self._add_menu_action(ops_q, label, callback)

        # HELP
        help_menu = bar.addMenu("&Help")
        self._add_menu_action(help_menu, "JOE User Manual", self.open_manual, QKeySequence.HelpContents)
        self._add_menu_action(help_menu, "Search Help…", self.search_help)
        help_menu.addSeparator()
        self._add_menu_action(help_menu, "About JOE", self.show_about)

    def _build_toolbar(self):
        """Fast-access toolbar; menus remain the authoritative complete navigation."""
        toolbar = QToolBar("JOE Quick Access", self)
        toolbar.setObjectName("joe_quick_access_toolbar")
        toolbar.setMovable(False)
        toolbar.setToolButtonStyle(Qt.ToolButtonTextOnly)
        self.addToolBar(Qt.TopToolBarArea, toolbar)

        for label, callback in [
            ("Overview", self.open_overview_workspace),
            ("MPR", self.open_mpr),
            ("Navigation", self.open_navigation),
            ("Digital Twin", self.open_digital_twin),
            ("Experiment", self.open_experiment_designer),
            ("Analyze", self.open_advanced_visualization),
            ("Guardian", self.open_guardian),
        ]:
            action = QAction(label, self)
            action.triggered.connect(callback)
            toolbar.addAction(action)

        toolbar.addSeparator()

        launcher = QToolButton(self)
        launcher.setText("Workspace ▾")
        launcher.setPopupMode(QToolButton.InstantPopup)
        launcher_menu = QMenu(launcher)
        groups = [
            ("Core", [
                ("Overview", self.open_overview_workspace), ("Master Parameter Register", self.open_mpr),
                ("Scientific Registry", self.open_scientific_registry), ("Navigation", self.open_navigation)]),
            ("Physics", [
                ("Geometry / Metric", self.open_geometry), ("Stress-Energy", self.open_stress_energy),
                ("Traversability [T-1]", self.open_traversability), ("QFT / QI [Q-1]", self.open_qft),
                ("Chronology [C-1]", self.open_chronology), ("Mouth Dynamics [D-1]", self.open_mouth_dynamics),
                ("Method-B / Ring-Laser", self.open_ring_laser)]),
            ("Experiment", [
                ("Digital Twin", self.open_digital_twin), ("Experiment Designer", self.open_experiment_designer),
                ("Metrology", self.open_metrology)]),
            ("Analysis", [
                ("Verification & Uncertainty", self.open_verification),
                ("Advanced Visualization", self.open_advanced_visualization),
                ("Scientific Data", self.open_scientific_data), ("Reports", self.open_report_generator)]),
            ("Intelligence", [
                ("Guardian", self.open_guardian), ("Scientific Reference", self.open_scientific_reference),
                ("Scientific Intelligence", self.open_scientific_intelligence)]),
            ("Systems", [
                ("Compute Backends", self.open_compute_backends), ("Quantum Runtime", self.open_quantum_runtime),
                ("RT / BUS-SAFE", self.open_rt_control), ("Integrated Qualification", self.open_integrated_qualification)]),
        ]
        for group_name, entries in groups:
            submenu = launcher_menu.addMenu(group_name)
            for label, callback in entries:
                self._add_menu_action(submenu, label, callback)
        launcher.setMenu(launcher_menu)
        toolbar.addWidget(launcher)

        compute_button = QToolButton(self)
        compute_button.setText("Compute ▾")
        compute_button.setPopupMode(QToolButton.InstantPopup)
        compute_menu = QMenu(compute_button)
        self._add_menu_action(compute_menu, "Compute Backend Manager", self.open_compute_backends)
        self._add_menu_action(compute_menu, "Quantum Runtime", self.open_quantum_runtime)
        self._add_menu_action(compute_menu, "Job / Compute Status", self.show_job_engine_status)
        compute_button.setMenu(compute_menu)
        toolbar.addWidget(compute_button)

        qual_button = QToolButton(self)
        qual_button.setText("Qualification ▾")
        qual_button.setPopupMode(QToolButton.InstantPopup)
        qual_menu = QMenu(qual_button)
        self._add_menu_action(qual_menu, "Integrated Qualification Center", self.open_integrated_qualification)
        self._add_menu_action(qual_menu, "Final Release Gate", self.joe_final_release_gate)
        qual_button.setMenu(qual_menu)
        toolbar.addWidget(qual_button)

        toolbar.addSeparator()
        save_quit = QAction("Save & Quit", self)
        save_quit.setToolTip("Save the current JOE workspace/layout and shut down cleanly")
        save_quit.triggered.connect(self.save_and_quit)
        toolbar.addAction(save_quit)

    def _next_workspace_title(self, kind: str, base: str) -> str:
        titles = [sub.windowTitle() for sub in self.workspace_area.subWindowList()]
        titles.extend(window.base_title() for window in self.external_workspaces)
        if base not in titles:
            return base
        number = 2
        while f"{base} {number}" in titles:
            number += 1
        return f"{base} {number}"

    def open_overview_workspace(self):
        widget = OverviewWorkspace(self.settings.telemetry_interval_ms)
        title = self._next_workspace_title("overview", "JOE Overview")
        self.workspace_area.add_workspace(widget, title, kind="overview", width=820, height=520)

    def open_log_workspace(self):
        widget = LogWorkspace(LOG_FILE)
        title = self._next_workspace_title("log", "JOE Application Log")
        self.workspace_area.add_workspace(widget, title, kind="log", width=900, height=560)

    def _create_workspace_widget(self, kind):
        if kind == "overview":
            return OverviewWorkspace(self.settings.telemetry_interval_ms)
        if kind == "log":
            return LogWorkspace(LOG_FILE)
        if kind == "mpr":
            return MPRWorkspace(self.module_runtime.service("joe.mpr"))
        if kind == "scientific-registry":
            return ScientificRegistryWorkspace(self.module_runtime.service("joe.scientific-registry"),self.module_runtime.service("joe.units"))
        if kind == "navigation":
            return NavigationWorkspace(self.module_runtime.service("joe.navigation"))
        if kind == "traversability":
            return TraversabilityWorkspace(self.module_runtime.service("joe.traversability"),self.module_runtime.service("joe.geometry"))
        if kind == "qft":
            return QFTWorkspace(self.module_runtime.service("joe.qft"))
        if kind == "chronology":
            return ChronologyWorkspace(self.module_runtime.service("joe.chronology"))
        if kind == "mouth-dynamics":
            return MouthDynamicsWorkspace(self.module_runtime.service("joe.mouth-dynamics"))
        if kind == "ring-laser":
            return RingLaserWorkspace(self.module_runtime.service("joe.ring-laser"))
        if kind == "verification":
            return VerificationWorkspace(self.module_runtime.service("joe.verification"))
        if kind == "digital-twin":
            return DigitalTwinWorkspace(self.module_runtime.service("joe.digital-twin"))
        if kind == "experiment-designer":
            return ExperimentDesignerWorkspace(self.module_runtime.service("joe.experiment-designer"))
        if kind == "metrology":
            return MetrologyWorkspace(self.module_runtime.service("joe.metrology"))
        if kind == "guardian":
            return GuardianWorkspace(self.module_runtime.service("joe.guardian"), self.module_runtime)
        if kind == "advanced-visualization":
            return AdvancedVisualizationWorkspace(self.module_runtime.service("joe.advanced-visualization"))
        if kind == "scientific-data":
            return ScientificDataWorkspace(self.module_runtime.service("joe.scientific-data"))
        if kind == "report-generator":
            return ReportGeneratorWorkspace(self.module_runtime.service("joe.reports"))
        if kind == "compute-backends":
            return ComputeBackendWorkspace(self.module_runtime.service("joe.compute"))
        if kind == "quantum-runtime":
            return QuantumRuntimeWorkspace(self.module_runtime.service("joe.quantum-runtime"))
        if kind == "rt-control":
            return RTControlWorkspace(self.module_runtime.service("joe.rt-control"))
        if kind == "integrated-qualification":
            return IntegratedQualificationWorkspace(self.module_runtime.service("joe.integrated-qualification"))
        if kind == "scientific-reference":
            return ScientificReferenceWorkspace(self.module_runtime.service("joe.scientific-reference"),self.module_runtime.service("joe.guardian-reference"))
        if kind == "scientific-intelligence":
            return ScientificIntelligenceWorkspace(self.module_runtime.service("joe.scientific-intelligence"),self.module_runtime.service("joe.scientific-reference"))
        if kind == "geometry":
            return GeometryWorkspace(self.module_runtime.service("joe.geometry"))
        if kind == "stress-energy":
            return StressEnergyWorkspace(self.module_runtime.service("joe.stress-energy"))
        visualization = self.module_runtime.service("joe.visualization")
        factories = {
            "live_time_series": LiveTimeSeriesWorkspace,
            "analysis_plot": AnalysisPlotWorkspace,
            "numeric_instrument": NumericInstrumentWorkspace,
            "matrix_heatmap": MatrixHeatmapWorkspace,
            "scientific_table": ScientificTableWorkspace,
            "scientific_field": ScientificFieldWorkspace,
        }
        if kind in factories:
            return factories[kind](visualization)
        raise ValueError(f"Unsupported workspace kind: {kind}")

    @staticmethod
    def _workspace_state(widget):
        exporter=getattr(widget,"export_workspace_state",None)
        if callable(exporter):
            state=exporter()
            return state if isinstance(state,dict) else None
        return None

    @staticmethod
    def _apply_workspace_state(widget,state):
        restorer=getattr(widget,"restore_workspace_state",None)
        if callable(restorer) and isinstance(state,dict):
            restorer(state)

    def detach_active_workspace(self):
        active = self.workspace_area.activeSubWindow()
        if active is not None and not self._require_workspace_modifiable(active, "detach it"):
            return
        detached = self.workspace_area.detach_active()
        if detached is None:
            return
        widget, title, kind, was_maximized, workspace_id = detached
        external = ExternalWorkspaceWindow(widget, title, kind, workspace_id=workspace_id)
        external.reattach_requested.connect(self.reattach_workspace)
        external.closed.connect(self._external_closed)
        external.activated.connect(self._external_activated)
        self.external_workspaces.append(external)
        external.show()
        if was_maximized:
            external.showMaximized()
        self._refresh_workspace_menu()

    def reattach_workspace(self, external):
        if external not in self.external_workspaces:
            return
        if not self._require_workspace_modifiable(external, "reattach it"):
            return
        geometry = external.geometry()
        widget = external.take_workspace()
        title = external.base_title()
        kind = external.workspace_kind
        workspace_id = external.workspace_id
        self.external_workspaces.remove(external)
        external.blockSignals(True)
        external.close()
        sub = self.workspace_area.add_workspace(widget, title, kind=kind, width=max(500, geometry.width()), height=max(350, geometry.height()), workspace_id=workspace_id)
        sub.show()
        log.info("Workspace reattached: %s [%s]", title, kind)
        self._refresh_workspace_menu()

    def reattach_all_workspaces(self):
        for external in list(self.external_workspaces):
            self.reattach_workspace(external)

    def detach_all_workspaces(self):
        # Snapshot the current internal windows because detaching mutates the MDI list.
        for sub in list(self.workspace_area.subWindowList()):
            self.workspace_area.setActiveSubWindow(sub)
            self.detach_active_workspace()
        self._refresh_workspace_menu()

    def _external_activated(self, external):
        # Keep one unambiguous notion of the most recently active JOE workspace.
        self._last_external_workspace = external if external in self.external_workspaces else None

    def _external_closed(self, external):
        if external in self.external_workspaces:
            self.external_workspaces.remove(external)
            if self._last_external_workspace is external:
                self._last_external_workspace = None
            log.info("External workspace closed: %s", external.base_title())
            self._refresh_workspace_menu()

    def _layout_entries(self):
        entries = []
        for sub in self.workspace_area.subWindowList():
            kind = str(sub.property("joe_workspace_kind") or "")
            if kind:
                entries.append(WorkspaceLayoutEntry(
                    kind, sub.windowTitle(), False, geometry_to_b64(sub), sub.isMaximized(),
                    str(sub.property("joe_workspace_id") or ""), self._workspace_locked(sub),
                    sub.isMinimized(), self._workspace_state(sub.widget())
                ))
        for external in self.external_workspaces:
            entries.append(WorkspaceLayoutEntry(
                external.workspace_kind, external.base_title(), True, geometry_to_b64(external),
                external.isMaximized(), external.workspace_id, self._workspace_locked(external),
                external.isMinimized(), self._workspace_state(external.centralWidget())
            ))
        return entries

    def save_workspace_layout(self):
        backup_layout()
        save_layout(self._layout_entries())
        self.statusBar().showMessage("Workspace layout saved", 3000)
        log.info("Workspace layout saved")


    def save_named_workspace_layout(self):
        name, ok = QInputDialog.getText(self, "Save Workspace Layout", "Layout name:")
        if not ok:
            return
        try:
            path = save_named_layout(name, self._layout_entries())
        except ValueError as exc:
            QMessageBox.warning(self, "Invalid Layout Name", str(exc))
            return
        self.statusBar().showMessage(f"Named layout saved: {path.stem}", 3000)
        log.info("Named workspace layout saved: %s", path.stem)

    def restore_named_workspace_layout(self, name: str):
        entries = load_named_layout(name)
        if not entries:
            QMessageBox.warning(self, "Workspace Layout", f"Named layout '{name}' could not be loaded.")
            return
        self._restore_layout_entries(entries)
        self.statusBar().showMessage(f"Named layout restored: {name}", 3000)
        log.info("Named workspace layout restored: %s", name)

    def delete_named_workspace_layout(self, name: str):
        answer = QMessageBox.question(self, "Delete Workspace Layout", f"Delete named layout '{name}'?")
        if answer != QMessageBox.Yes:
            return
        if delete_named_layout(name):
            self.statusBar().showMessage(f"Named layout deleted: {name}", 3000)
            log.info("Named workspace layout deleted: %s", name)

    def _refresh_named_layouts_menu(self):
        self.named_layouts_menu.clear()
        names = list_named_layouts()
        if not names:
            empty = QAction("No named layouts", self); empty.setEnabled(False); self.named_layouts_menu.addAction(empty)
            return
        for name in names:
            restore = QAction(f"Restore {name}", self)
            restore.triggered.connect(lambda checked=False, n=name: self.restore_named_workspace_layout(n))
            self.named_layouts_menu.addAction(restore)
        self.named_layouts_menu.addSeparator()
        delete_menu = self.named_layouts_menu.addMenu("Delete")
        for name in names:
            action = QAction(name, self)
            action.triggered.connect(lambda checked=False, n=name: self.delete_named_workspace_layout(n))
            delete_menu.addAction(action)

    def _ensure_window_visible(self, window):
        frame = window.frameGeometry()
        screens = QGuiApplication.screens()
        if screens and not any(screen.availableGeometry().intersects(frame) for screen in screens):
            screen = QGuiApplication.primaryScreen()
            if screen:
                target = screen.availableGeometry()
                frame.moveCenter(target.center())
                window.move(frame.topLeft())
                log.warning("Recovered off-screen workspace window onto primary display")

    def _restore_layout_entries(self, entries):
        self.workspace_area.close_all_workspaces()
        for external in list(self.external_workspaces):
            external.close()
        restored = 0
        for entry in entries:
            try:
                widget = self._create_workspace_widget(entry.kind)
                self._apply_workspace_state(widget, entry.state)
                if entry.external:
                    external = ExternalWorkspaceWindow(widget, entry.title, entry.kind, workspace_id=entry.workspace_id)
                    external.reattach_requested.connect(self.reattach_workspace)
                    external.closed.connect(self._external_closed)
                    external.activated.connect(self._external_activated)
                    self.external_workspaces.append(external)
                    external.setProperty("joe_workspace_locked", entry.locked)
                    restore_geometry_b64(external, entry.geometry_b64)
                    self._ensure_window_visible(external)
                    external.show()
                    if entry.maximized:
                        external.showMaximized()
                    elif entry.minimized:
                        external.showMinimized()
                else:
                    sub = self.workspace_area.add_workspace(widget, entry.title, kind=entry.kind, workspace_id=entry.workspace_id)
                    sub.setProperty("joe_workspace_locked", entry.locked)
                    restore_geometry_b64(sub, entry.geometry_b64)
                    sub.show()
                    if entry.maximized:
                        sub.showMaximized()
                    elif entry.minimized:
                        sub.showMinimized()
                restored += 1
            except Exception:
                log.exception("Failed to restore workspace: %s", entry.title)
        return restored

    def restore_workspace_layout(self, force=False):
        entries = load_layout()
        if not entries:
            if force:
                self.statusBar().showMessage("No saved workspace layout", 3000)
            return False
        # Startup begins with no workspaces; manual restore replaces the current desktop.
        if force or self.workspace_area.subWindowList() or self.external_workspaces:
            restored = self._restore_layout_entries(entries)
        else:
            restored = 0
            for entry in entries:
                try:
                    widget = self._create_workspace_widget(entry.kind)
                    if entry.external:
                        external = ExternalWorkspaceWindow(widget, entry.title, entry.kind, workspace_id=entry.workspace_id)
                        external.reattach_requested.connect(self.reattach_workspace)
                        external.closed.connect(self._external_closed)
                        external.activated.connect(self._external_activated)
                        self.external_workspaces.append(external)
                        restore_geometry_b64(external, entry.geometry_b64); self._ensure_window_visible(external); external.show()
                        if entry.maximized: external.showMaximized()
                        elif entry.minimized: external.showMinimized()
                    else:
                        sub = self.workspace_area.add_workspace(widget, entry.title, kind=entry.kind, workspace_id=entry.workspace_id)
                        restore_geometry_b64(sub, entry.geometry_b64); sub.show()
                        if entry.maximized: sub.showMaximized()
                        elif entry.minimized: sub.showMinimized()
                    restored += 1
                except Exception:
                    log.exception("Failed to restore workspace: %s", entry.title)
        if restored:
            self.statusBar().showMessage(f"Restored {restored} workspace(s)", 3000)
            log.info("Restored %d workspace(s) from saved layout", restored)
        return restored > 0

    def recover_previous_workspace_layout(self):
        if not restore_layout_backup():
            self.statusBar().showMessage("No previous workspace layout recovery copy is available", 3000)
            return
        if self.restore_workspace_layout(force=True):
            self.statusBar().showMessage("Previous workspace layout recovered", 3000)
            log.warning("Previous workspace layout recovery copy restored")
        else:
            QMessageBox.warning(self, "Workspace Layout Recovery", "The recovery copy could not be restored.")

    def clear_saved_workspace_layout(self):
        clear_layout()
        self.statusBar().showMessage("Saved workspace layout cleared", 3000)
        log.info("Saved workspace layout cleared")

    def close_active_workspace(self):
        # Prefer a genuinely active detached window; otherwise close the active MDI window.
        for external in list(self.external_workspaces):
            if external.isActiveWindow():
                if self._require_workspace_modifiable(external, "close it"):
                    external.close()
                return
        active = self.workspace_area.activeSubWindow()
        if active is not None:
            if self._require_workspace_modifiable(active, "close it"):
                active.close()
            return
        external = self._last_external_workspace
        if external in self.external_workspaces:
            external.close()

    def minimize_all_workspaces(self):
        for sub in self.workspace_area.subWindowList():
            sub.showMinimized()
        for external in self.external_workspaces:
            external.showMinimized()
        self.statusBar().showMessage("All workspaces minimized", 2000)

    def restore_all_workspaces(self):
        for sub in self.workspace_area.subWindowList():
            if sub.isMinimized():
                sub.showNormal()
        for external in self.external_workspaces:
            if external.isMinimized():
                external.showNormal()
        self.statusBar().showMessage("All workspaces restored", 2000)

    def close_all_workspaces(self):
        self.workspace_area.close_all_workspaces()
        for external in list(self.external_workspaces):
            external.close()
        self._refresh_workspace_menu()

    def workspace_records(self):
        records = []
        for sub in self.workspace_area.subWindowList():
            state = "Maximized" if sub.isMaximized() else "Minimized" if sub.isMinimized() else "Normal"
            records.append({"location": "JOE Desktop", "title": sub.windowTitle(), "kind": str(sub.property("joe_workspace_kind") or ""), "workspace_id": str(sub.property("joe_workspace_id") or ""), "state": state, "object": sub})
        for window in self.external_workspaces:
            state = "Maximized" if window.isMaximized() else "Minimized" if window.isMinimized() else "Normal"
            records.append({"location": "External", "title": window.base_title(), "kind": window.workspace_kind, "workspace_id": window.workspace_id, "state": state, "object": window})
        return records

    def focus_workspace_record(self, record):
        window = record.get("object")
        if record.get("location") == "External":
            self._focus_external_workspace(window)
        else:
            self._focus_internal_workspace(window)

    def rename_workspace_record(self, record, title: str):
        title = validate_workspace_title(title)
        window = record.get("object")
        if window is None:
            return
        if not self._require_workspace_modifiable(window, "rename it"):
            return
        if record.get("location") == "External":
            window.setWindowTitle(f"{title} — JOE")
        else:
            window.setWindowTitle(title)
        log.info("Workspace renamed: %s -> %s [%s]", record.get("title"), title, record.get("workspace_id"))
        self._refresh_workspace_menu()

    def toggle_workspace_record_location(self, record):
        window = record.get("object")
        if window is None:
            return
        if record.get("location") == "External":
            self.reattach_workspace(window)
        else:
            self.workspace_area.setActiveSubWindow(window)
            self.detach_active_workspace()

    def close_workspace_record(self, record):
        window = record.get("object")
        if window is not None and self._require_workspace_modifiable(window, "close it"):
            window.close()
        self._refresh_workspace_menu()

    def qualify_current_workspace_desktop(self):
        entries = self._layout_entries()
        result = qualify_layout(entries)
        if result.passed:
            text = (
                f"JOE workspace desktop qualification PASSED.\n\n"
                f"Workspaces inspected: {len(entries)}\n"
                f"Structural checks completed: {result.checks}\n\n"
                "This qualification validates JOE's current persisted workspace records. "
                "It does not claim to validate future scientific modules or hardware."
            )
            QMessageBox.information(self, "Workspace Qualification", text)
            self.statusBar().showMessage("Workspace desktop qualification passed", 3000)
            log.info("Workspace desktop qualification passed: %d workspaces, %d checks", len(entries), result.checks)
        else:
            text = "JOE workspace desktop qualification FAILED.\n\n" + "\n".join(f"• {failure}" for failure in result.failures)
            QMessageBox.warning(self, "Workspace Qualification", text)
            self.statusBar().showMessage("Workspace desktop qualification failed", 3000)
            log.warning("Workspace desktop qualification failed: %s", "; ".join(result.failures))

    def qualify_workspace_persistence(self):
        entries = self._layout_entries()
        structural = qualify_layout(entries)
        if not structural.passed:
            QMessageBox.warning(
                self, "Workspace Persistence Qualification",
                "Persistence qualification stopped because the live desktop failed structural qualification.\n\n"
                + "\n".join(f"• {failure}" for failure in structural.failures)
            )
            return
        try:
            with tempfile.TemporaryDirectory(prefix="joe-layout-qualification-") as td:
                test_path = Path(td) / "workspace_layout.json"
                save_layout(entries, test_path)
                restored = load_layout(test_path)
                round_trip = compare_layouts(entries, restored)
        except Exception as exc:
            log.exception("Workspace persistence qualification encountered an exception")
            QMessageBox.warning(
                self, "Workspace Persistence Qualification",
                f"Qualification could not complete:\n{exc}"
            )
            return

        total_checks = structural.checks + round_trip.checks
        if round_trip.passed:
            QMessageBox.information(
                self, "Workspace Persistence Qualification",
                f"JOE workspace persistence qualification PASSED.\n\n"
                f"Workspaces inspected: {len(entries)}\n"
                f"Checks completed: {total_checks}\n\n"
                "The test used an isolated temporary layout file; the user's saved desktop was not modified."
            )
            self.statusBar().showMessage("Workspace persistence qualification passed", 3000)
            log.info("Workspace persistence qualification passed: %d checks", total_checks)
        else:
            QMessageBox.warning(
                self, "Workspace Persistence Qualification",
                "JOE workspace persistence qualification FAILED.\n\n"
                + "\n".join(f"• {failure}" for failure in round_trip.failures)
            )
            self.statusBar().showMessage("Workspace persistence qualification failed", 3000)
            log.warning("Workspace persistence qualification failed: %s", "; ".join(round_trip.failures))

    def qualify_workspace_lifecycle(self):
        records = self.workspace_records()
        active_record = self._active_workspace_record()
        active_object = active_record.get("object") if active_record else None
        states = []
        for record in records:
            obj = record["object"]
            states.append(LifecycleState(
                workspace_id=record["workspace_id"],
                minimized=bool(obj.isMinimized()),
                active=(obj is active_object),
            ))
        result = qualify_lifecycle(states)
        if result.passed:
            QMessageBox.information(
                self, "Workspace Lifecycle Qualification",
                f"JOE workspace lifecycle qualification PASSED.\n\n"
                f"Workspaces inspected: {len(states)}\n"
                f"Lifecycle checks completed: {result.checks}\n\n"
                "The live desktop identity and active-window model are internally consistent. "
                "No workspace was moved or closed by this qualification."
            )
            self.statusBar().showMessage("Workspace lifecycle qualification passed", 3000)
            log.info("Workspace lifecycle qualification passed: %d checks", result.checks)
        else:
            QMessageBox.warning(
                self, "Workspace Lifecycle Qualification",
                "JOE workspace lifecycle qualification FAILED.\n\n"
                + "\n".join(f"• {failure}" for failure in result.failures)
            )
            self.statusBar().showMessage("Workspace lifecycle qualification failed", 3000)
            log.warning("Workspace lifecycle qualification failed: %s", "; ".join(result.failures))

    def run_joe002_qualification_suite(self):
        entries = self._layout_entries()
        records = self.workspace_records()
        active_record = self._active_workspace_record()
        active_object = active_record.get("object") if active_record else None
        lifecycle = [
            LifecycleState(
                workspace_id=record["workspace_id"],
                minimized=bool(record["object"].isMinimized()),
                active=(record["object"] is active_object),
            )
            for record in records
        ]
        try:
            with tempfile.TemporaryDirectory(prefix="joe-002-qualification-") as td:
                test_path = Path(td) / "workspace_layout.json"
                save_layout(entries, test_path)
                restored = load_layout(test_path)
                result = qualify_workspace_system(entries, restored, lifecycle)
        except Exception as exc:
            log.exception("JOE-002 qualification suite encountered an exception")
            QMessageBox.warning(
                self, "JOE-002 Qualification Suite",
                f"Qualification could not complete:\n{exc}"
            )
            return

        lines = []
        for name, passed, failures in result.sections:
            lines.append(f"{'PASS' if passed else 'FAIL'} — {name}")
            for failure in failures:
                lines.append(f"    • {failure}")
        body = "\n".join(lines)
        if result.passed:
            QMessageBox.information(
                self, "JOE-002 Qualification Suite",
                f"JOE-002 WINDOW & WORKSPACE QUALIFICATION PASSED.\n\n"
                f"Workspaces inspected: {len(entries)}\n"
                f"Checks completed: {result.checks}\n\n{body}\n\n"
                "This suite qualifies the implemented JOE-002 desktop model and persistence chain. "
                "Physical multi-monitor behavior still depends on the user's Windows/Qt environment."
            )
            self.statusBar().showMessage("JOE-002 qualification suite passed", 4000)
            log.info("JOE-002 qualification suite PASSED: %d checks", result.checks)
        else:
            QMessageBox.warning(
                self, "JOE-002 Qualification Suite",
                f"JOE-002 WINDOW & WORKSPACE QUALIFICATION FAILED.\n\n{body}"
            )
            self.statusBar().showMessage("JOE-002 qualification suite failed", 4000)
            log.warning("JOE-002 qualification suite FAILED")

    def run_joe002_release_readiness(self):
        entries = self._layout_entries()
        records = self.workspace_records()
        active_record = self._active_workspace_record()
        active_object = active_record.get("object") if active_record else None
        lifecycle = [
            LifecycleState(
                workspace_id=record["workspace_id"],
                minimized=bool(record["object"].isMinimized()),
                active=(record["object"] is active_object),
            )
            for record in records
        ]
        try:
            with tempfile.TemporaryDirectory(prefix="joe-002-release-") as td:
                test_path = Path(td) / "workspace_layout.json"
                save_layout(entries, test_path)
                restored = load_layout(test_path)
                readiness = joe002_release_readiness(entries, restored, lifecycle)
        except Exception as exc:
            log.exception("JOE-002 release readiness failed to execute")
            QMessageBox.warning(self, "JOE-002 Release Readiness", f"Release gate could not complete:\n{exc}")
            return

        body = "\n".join(readiness.summary)
        if readiness.passed:
            QMessageBox.information(
                self, "JOE-002 Release Readiness",
                f"JOE-002 CODE-LEVEL RELEASE GATE PASSED.\n\n"
                f"Checks completed: {readiness.checks}\n\n{body}\n\n"
                "The implemented Window & Workspace subsystem is code-level qualified. "
                "Physical Windows multi-monitor behavior must still be exercised on the target workstation."
            )
            self.statusBar().showMessage("JOE-002 code-level release gate passed", 4000)
            log.info("JOE-002 code-level release gate PASSED: %d checks", readiness.checks)
        else:
            QMessageBox.warning(
                self, "JOE-002 Release Readiness",
                f"JOE-002 CODE-LEVEL RELEASE GATE FAILED.\n\n{body}"
            )
            self.statusBar().showMessage("JOE-002 code-level release gate failed", 4000)
            log.warning("JOE-002 code-level release gate FAILED")

    def open_workspace_manager(self):
        WorkspaceManagerDialog(self, self).exec()


    def _workspace_locked(self, window) -> bool:
        return bool(window.property("joe_workspace_locked")) if window is not None else False

    def _require_workspace_modifiable(self, window, action: str) -> bool:
        if self._workspace_locked(window):
            self.statusBar().showMessage(f"Workspace is locked; cannot {action}", 3000)
            return False
        return True

    def toggle_active_workspace_lock(self):
        record = self._active_workspace_record()
        if record is None:
            self.statusBar().showMessage("No active workspace", 2000)
            return
        window = record["object"]
        locked = not self._workspace_locked(window)
        window.setProperty("joe_workspace_locked", locked)
        self.statusBar().showMessage(f"Workspace {'locked' if locked else 'unlocked'}", 2500)
        log.info("Workspace %s: %s", "locked" if locked else "unlocked", getattr(window, "windowTitle", lambda: "")())
        self._refresh_workspace_menu()

    def _active_workspace_record(self):
        for external in self.external_workspaces:
            if external.isActiveWindow():
                return {"location": "External", "object": external}
        active = self.workspace_area.activeSubWindow()
        if active is not None:
            return {"location": "JOE Desktop", "object": active}
        if self._last_external_workspace in self.external_workspaces:
            return {"location": "External", "object": self._last_external_workspace}
        return None

    def _refresh_display_menu(self):
        self.display_menu.clear()
        screens = QGuiApplication.screens()
        if not screens:
            action = QAction("No displays reported by Qt", self)
            action.setEnabled(False)
            self.display_menu.addAction(action)
            return
        for index, screen in enumerate(screens):
            geometry = screen.availableGeometry()
            label = f"Display {index + 1}: {screen.name()} ({geometry.width()}×{geometry.height()})"
            action = QAction(label, self)
            action.triggered.connect(lambda _checked=False, i=index: self.move_active_workspace_to_display(i))
            self.display_menu.addAction(action)

    def _move_window_to_screen(self, window, screen):
        available = screen.availableGeometry()
        frame = window.frameGeometry()
        width = min(max(420, frame.width()), available.width())
        height = min(max(300, frame.height()), available.height())
        x = available.x() + max(0, (available.width() - width) // 2)
        y = available.y() + max(0, (available.height() - height) // 2)
        if window.isMaximized():
            window.showNormal()
        window.resize(width, height)
        window.move(x, y)
        window.show()
        window.raise_()
        window.activateWindow()

    def move_active_workspace_to_display(self, display_index: int):
        screens = QGuiApplication.screens()
        try:
            index = normalize_display_index(len(screens), int(display_index))
        except ValueError as exc:
            QMessageBox.warning(self, "Display Selection", str(exc))
            return
        record = self._active_workspace_record()
        if record is None:
            self.statusBar().showMessage("No active workspace to move", 2500)
            return
        window = record["object"]
        if not self._require_workspace_modifiable(window, "move it"):
            return
        # An internal MDI child cannot cross monitor boundaries independently.
        # Detach it first, preserving its identity, then position the resulting top-level window.
        if record["location"] != "External":
            self.workspace_area.setActiveSubWindow(window)
            before = set(id(w) for w in self.external_workspaces)
            self.detach_active_workspace()
            created = [w for w in self.external_workspaces if id(w) not in before]
            if not created:
                return
            window = created[-1]
        self._move_window_to_screen(window, screens[index])
        self._last_external_workspace = window
        self.statusBar().showMessage(f"Workspace moved to display {index + 1}", 2500)
        log.info("Workspace moved to display %d: %s", index + 1, window.base_title())

    def center_active_workspace(self):
        record = self._active_workspace_record()
        if record is None:
            self.statusBar().showMessage("No active workspace to center", 2500)
            return
        window = record["object"]
        if record["location"] == "External":
            screen = window.screen() or QGuiApplication.primaryScreen()
            if screen:
                self._move_window_to_screen(window, screen)
        else:
            area = self.workspace_area.viewport().rect()
            if window.isMaximized():
                window.showNormal()
            width = min(max(420, window.width()), max(420, area.width()))
            height = min(max(300, window.height()), max(300, area.height()))
            window.resize(width, height)
            window.move(max(0, (area.width() - width) // 2), max(0, (area.height() - height) // 2))
            self._focus_internal_workspace(window)
        self.statusBar().showMessage("Active workspace centered", 2000)

    def _refresh_workspace_menu(self):
        menu = getattr(self, "workspace_list_menu", None)
        if menu is None:
            return
        menu.clear()
        internal = list(self.workspace_area.subWindowList())
        external = list(self.external_workspaces)
        if not internal and not external:
            empty = QAction("No open workspaces", self)
            empty.setEnabled(False)
            menu.addAction(empty)
            return
        for sub in internal:
            action = QAction(f"JOE Desktop — {sub.windowTitle()}{' [LOCKED]' if self._workspace_locked(sub) else ''}", self)
            action.triggered.connect(lambda _checked=False, w=sub: self._focus_internal_workspace(w))
            menu.addAction(action)
        if internal and external:
            menu.addSeparator()
        for window in external:
            action = QAction(f"External — {window.base_title()}{' [LOCKED]' if self._workspace_locked(window) else ''}", self)
            action.triggered.connect(lambda _checked=False, w=window: self._focus_external_workspace(w))
            menu.addAction(action)

    def _focus_internal_workspace(self, sub):
        if sub is None:
            return
        if sub.isMinimized():
            sub.showNormal()
        self.workspace_area.setActiveSubWindow(sub)
        sub.raise_()
        sub.setFocus()

    def _focus_external_workspace(self, window):
        if window is None:
            return
        if window.isMinimized():
            window.showNormal()
        window.show()
        window.raise_()
        window.activateWindow()

    def _workspace_sequence(self):
        return [("internal", sub) for sub in self.workspace_area.subWindowList()] + [("external", window) for window in self.external_workspaces]

    def cycle_workspace(self, direction: int = 1):
        sequence = self._workspace_sequence()
        if not sequence:
            self.statusBar().showMessage("No open workspaces", 2000)
            return
        current_index = -1
        active = self.workspace_area.activeSubWindow()
        if active is not None:
            for i, (location, window) in enumerate(sequence):
                if location == "internal" and window is active:
                    current_index = i
                    break
        if current_index < 0:
            for i, (location, window) in enumerate(sequence):
                if location == "external" and window.isActiveWindow():
                    current_index = i
                    break
        target_index = cycle_index(len(sequence), current_index, direction)
        if target_index is None:
            return
        location, target = sequence[target_index]
        if location == "internal":
            self._focus_internal_workspace(target)
        else:
            self._focus_external_workspace(target)

    def _build_status_bar(self):
        bar = QStatusBar(self)
        bar.setSizeGripEnabled(True)
        self.setStatusBar(bar)
        self.cpu = QLabel("CPU --%")
        self.ram = QLabel("RAM --")
        self.proc = QLabel("JOE -- MB")
        self.thermal = QLabel("THERMAL N/A")
        self.uptime = QLabel("UP 00:00")
        self.health = QLabel("JOE OK")
        self.version_label = QLabel(f"JOE v{__version__} | {__build__}")
        self.version_label.setToolTip("Current Journeyman Operating Environment version and build. This remains visible while JOE is running.")
        for widget in (self.cpu, self.ram, self.proc, self.thermal, self.uptime, self.health, self.version_label):
            widget.setMargin(5)
            bar.addPermanentWidget(widget)
        self.thermal.setToolTip("Thermal sensor integration is not part of JOE-001. No temperature is fabricated.")

    def refresh_system_status(self):
        try:
            s = snapshot()
            self.cpu.setText(f"CPU {s.cpu_percent:.0f}%")
            self.cpu.setToolTip(f"Host CPU utilization. JOE process CPU: {s.process_cpu_percent:.1f}%")
            self.ram.setText(f"RAM {s.ram_used_gb:.1f}/{s.ram_total_gb:.1f} GB ({s.ram_percent:.0f}%)")
            self.proc.setText(f"JOE {s.process_ram_mb:.0f} MB")
            self.proc.setToolTip(f"JOE resident memory; process threads: {s.threads}")
            self.uptime.setText(f"UP {format_uptime()}")
            self.uptime.setToolTip("Elapsed time since this JOE process started.")
            self.health.setText("JOE OK")
            self.health.setToolTip("JOE application shell is responsive.")
        except Exception:
            log.exception("System status refresh failed")
            self.health.setText("JOE WARN")
            self.health.setToolTip("System status refresh failed. See JOE log.")

    def _open_folder(self, path):
        path.mkdir(parents=True, exist_ok=True)
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(os.fspath(path))):
            QMessageBox.warning(self, "JOE", f"Windows could not open:\n{path}")

    def qualify_help_system(self):
        from journeyman.core.documentation import qualify_documentation
        r=qualify_documentation(self.module_runtime.service("joe.documentation"))
        QMessageBox.information(self,"Help System Qualification",
                                ("PASS" if r.passed else "FAIL")+("\n\n"+"\n".join(r.failures) if r.failures else ""))

    def joe016_release_readiness(self):
        from journeyman.core.documentation import joe016_release_readiness
        r=joe016_release_readiness(self.module_runtime.service("joe.documentation"))
        lines=["READY" if r.passed else "NOT READY",
               f"Manual index: {'PASS' if r.index_passed else 'FAIL'}",
               f"Search: {'PASS' if r.search_passed else 'FAIL'}",
               f"Version match: {'PASS' if r.version_passed else 'FAIL'}"]
        lines.extend(r.failures)
        QMessageBox.information(self,"JOE-016 Release Readiness","\n".join(lines))

    def search_help(self):
        from PySide6.QtWidgets import QInputDialog,QDialog,QVBoxLayout,QListWidget,QTextBrowser
        query,ok=QInputDialog.getText(self,"Search JOE Help","Search the integrated manual:")
        if not ok or not query.strip():return
        docs=self.module_runtime.service("joe.documentation");results=docs.search(query)
        dialog=QDialog(self);dialog.setWindowTitle(f"JOE Help Search — {query}");dialog.resize(900,600)
        layout=QVBoxLayout(dialog);items=QListWidget();body=QTextBrowser();layout.addWidget(items,1);layout.addWidget(body,2)
        for topic in results:items.addItem(topic.title)
        def selected(row):
            if 0<=row<len(results):
                topic=results[row];body.setPlainText(topic.title+"\n\n"+topic.text)
        items.currentRowChanged.connect(selected)
        if results:items.setCurrentRow(0)
        else:body.setPlainText("No matching version-matched help topics.")
        dialog.exec()

    def open_manual(self):
        ManualDialog(self).exec()

    def open_log_viewer(self):
        LogViewerDialog(LOG_FILE, self).exec()

    def open_system_info(self):
        SystemInfoDialog(self).exec()

    def open_startup_diagnostics(self):
        StartupDiagnosticsDialog(self).exec()

    def _refresh_telemetry_status(self):
        try:
            monitor = self.module_runtime.service("joe.host-telemetry-monitor")
            monitor_status = monitor.status()
            sample = monitor.latest()
        except Exception:
            return
        if sample is None:
            self.statusBar().showMessage("HOST TELEMETRY: WAITING FOR FIRST REAL SAMPLE")
            return
        if not monitor_status.fresh:
            age = "unknown" if monitor_status.sample_age_seconds is None else f"{monitor_status.sample_age_seconds:.1f}s"
            self.statusBar().showMessage(f"HOST TELEMETRY: STALE ({age})   |   NO VALUES SYNTHESIZED")
            return
        cpu = f"CPU {sample.cpu_percent:.0f}%"
        ram = f"RAM {sample.memory_percent:.0f}%"
        if sample.gpu_available:
            values=[g.utilization_percent for g in sample.gpus if g.utilization_percent is not None]
            gpu = f"GPU {max(values):.0f}%" if values else "GPU N/A"
        else:
            gpu = "GPU N/A"
        temps=[]
        temps.extend(r.celsius for r in sample.temperatures)
        temps.extend(g.temperature_celsius for g in sample.gpus if g.temperature_celsius is not None)
        thermal = f"TEMP {max(temps):.0f}°C" if temps else "TEMP N/A"
        jobs = self.module_runtime.service("joe.jobs")
        counts = jobs.counts()
        active = counts.get("QUEUED",0) + counts.get("RUNNING",0)
        self.statusBar().showMessage(
            f"{cpu}   |   {ram}   |   {gpu}   |   {thermal}   |   JOBS {active}   |   HOST"
        )

    def recover_interrupted_runs(self):
        recorder=self.module_runtime.service("joe.runs")
        reports=recorder.recover_all_interrupted()
        if not reports:
            text="No stale ACTIVE run records were found."
        else:
            text=f"Recovered {len(reports)} interrupted run(s) as FAILED.\n\n" + "\n".join(
                report.run_id for report in reports[:30]
            )
        QMessageBox.information(self,"Interrupted Run Recovery",text)

    def qualify_run_recorder(self):
        from journeyman.core.run_recorder import qualify_run_recorder
        result=qualify_run_recorder(self.module_runtime.service("joe.runs"))
        lines=["PASS" if result.passed else "FAIL",f"Checks: {len(result.checks)}"]
        if result.failures: lines.extend([""]+list(result.failures[:30]))
        QMessageBox.information(self,"Run Recorder Qualification","\n".join(lines))

    def run_recorder_release_readiness(self):
        from journeyman.core.run_recorder import joe010_release_readiness
        result=joe010_release_readiness(self.module_runtime.service("joe.runs"))
        lines=["PASS" if result.passed else "FAIL",
               f"Exercise events: {result.exercise_events}",
               f"Exercise samples: {result.exercise_samples}",
               f"Exercise snapshots: {result.exercise_snapshots}",
               f"Exercise links: {result.exercise_associations}",
               f"Integrity-indexed files: {result.integrity_files}"]
        if result.notes: lines.extend([""]+list(result.notes[:30]))
        QMessageBox.information(self,"JOE-010 Release Readiness","\n".join(lines))

    def verify_run_integrity(self):
        recorder=self.module_runtime.service("joe.runs")
        runs=recorder.list_runs()
        if not runs:
            QMessageBox.information(self,"Run Integrity","No persisted JOE runs exist.")
            return
        reports=[recorder.verify_integrity(run.run_id) for run in runs]
        failures=[report for report in reports if not report.passed]
        if not failures:
            text=f"PASS — {len(reports)} run record(s) verified."
        else:
            lines=[f"FAIL — {len(failures)} of {len(reports)} run record(s) failed integrity checks.",""]
            for report in failures[:20]:
                lines.append(report.run_id)
                lines.extend(f"  • {failure}" for failure in report.failures)
            text="\n".join(lines)
        QMessageBox.information(self,"Run Integrity",text)

    def qualify_authority_safety(self):
        from journeyman.core.authority import qualify_authority
        r=qualify_authority(self.module_runtime.service("joe.authority"))
        QMessageBox.information(self,"Authority & Safety Qualification",
                                ("PASS" if r.passed else "FAIL")+("\n\n"+"\n".join(r.failures) if r.failures else ""))

    def joe015_release_readiness(self):
        from journeyman.core.authority import joe015_release_readiness
        r=joe015_release_readiness()
        lines=["READY" if r.passed else "NOT READY",
               f"Hierarchy: {'PASS' if r.hierarchy_passed else 'FAIL'}",
               f"Guardian boundary: {'PASS' if r.guardian_boundary_passed else 'FAIL'}",
               f"HOLD boundary: {'PASS' if r.hold_boundary_passed else 'FAIL'}",
               f"ABORT boundary: {'PASS' if r.abort_boundary_passed else 'FAIL'}"]
        lines.extend(r.failures)
        QMessageBox.information(self,"JOE-015 Release Readiness","\n".join(lines))

    def open_authority_boundaries(self):
        service=self.module_runtime.service("joe.authority")
        lines=["JOE AUTHORITY HIERARCHY","Highest authority first:",""]
        for actor in service.actors():
            lines.append(f"{int(actor.level):2}  {actor.level.name} — {actor.actor_id}")
            lines.append(f"    {actor.description}")
        lines.extend(["","Guardian is supervisory/advisory and cannot satisfy deterministic-control or BUS-SAFE authorization.",
                      "This JOE service defines software authority contracts; it is not a physical BUS-SAFE implementation."])
        QMessageBox.information(self,"Authority & Safety Boundaries","\n".join(lines))

    def synchronize_health_alerts(self):
        alerts=self.module_runtime.service("joe.alerts")
        health=self.module_runtime.service("joe.diagnostics").snapshot()
        created,resolved=alerts.synchronize_health(health)
        QMessageBox.information(self,"Synchronize Health Alerts",
                                f"Created: {len(created)}\nResolved after recovery: {len(resolved)}")

    def qualify_alerts(self):
        from journeyman.core.alerts import qualify_alerts
        result=qualify_alerts(self.module_runtime.service("joe.alerts"))
        QMessageBox.information(self,"Alerts & Anomalies Qualification",
                                ("PASS" if result.passed else "FAIL")+("\n\n"+"\n".join(result.failures) if result.failures else ""))

    def joe014_release_readiness(self):
        from journeyman.core.alerts import joe014_release_readiness
        r=joe014_release_readiness()
        lines=["READY" if r.passed else "NOT READY",
               f"Persistent lifecycle: {'PASS' if r.lifecycle_passed else 'FAIL'}",
               f"Deduplication: {'PASS' if r.dedup_passed else 'FAIL'}",
               f"Recovery resolution: {'PASS' if r.recovery_passed else 'FAIL'}"]
        lines.extend(r.failures)
        QMessageBox.information(self,"JOE-014 Release Readiness","\n".join(lines))

    def open_alerts(self):
        from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QListWidget,QPushButton,QInputDialog,QMessageBox
        service=self.module_runtime.service("joe.alerts")
        dialog=QDialog(self);dialog.setWindowTitle("JOE Alerts");dialog.resize(850,500)
        layout=QVBoxLayout(dialog);items=QListWidget();layout.addWidget(items)
        buttons=QHBoxLayout();ack=QPushButton("Acknowledge");resolve=QPushButton("Resolve");refresh_btn=QPushButton("Refresh")
        for b in (ack,resolve,refresh_btn):buttons.addWidget(b)
        layout.addLayout(buttons);records=[]
        def refresh():
            nonlocal records
            records=list(reversed(service.alerts()));items.clear()
            for a in records:
                prefix="SIMULATION " if a.origin=="SIMULATION" else ""
                items.addItem(f"{a.status.value:12} | {prefix}{a.severity.value:8} | {a.affected_subsystem} | {a.cause} | {a.source}")
        def selected():
            row=items.currentRow()
            return records[row] if 0<=row<len(records) else None
        def do_ack():
            a=selected()
            if not a:return
            note,ok=QInputDialog.getText(dialog,"Acknowledge Alert","Acknowledgement note (optional):")
            if not ok:return
            try:service.acknowledge(a.alert_id,note)
            except Exception as exc:QMessageBox.warning(dialog,"Acknowledge Alert",str(exc))
            refresh()
        def do_resolve():
            a=selected()
            if not a:return
            try:service.resolve(a.alert_id)
            except Exception as exc:QMessageBox.warning(dialog,"Resolve Alert",str(exc))
            refresh()
        ack.clicked.connect(do_ack);resolve.clicked.connect(do_resolve);refresh_btn.clicked.connect(refresh);refresh()
        dialog.exec()

    def qualify_diagnostics_health(self):
        from journeyman.core.diagnostics import qualify_diagnostics
        result=qualify_diagnostics(self.module_runtime.service("joe.diagnostics"))
        QMessageBox.information(self,"Diagnostics & Health Qualification",
                                ("PASS" if result.passed else "FAIL") + ("\n\n" + "\n".join(result.failures) if result.failures else ""))

    def joe013_release_readiness(self):
        from journeyman.core.diagnostics import joe013_release_readiness
        result=joe013_release_readiness(self.module_runtime.service("joe.diagnostics"))
        lines=["READY" if result.passed else "NOT READY",
               f"Normal snapshot: {'PASS' if result.healthy_snapshot_passed else 'FAIL'}",
               f"Fault detection: {'PASS' if result.fault_detection_passed else 'FAIL'}"]
        lines.extend(result.failures)
        QMessageBox.information(self,"JOE-013 Release Readiness","\n".join(lines))

    def open_system_health(self):
        service=self.module_runtime.service("joe.diagnostics")
        snapshot=service.snapshot()
        lines=[f"JOE SYSTEM HEALTH: {snapshot.state.value}",f"Timestamp: {snapshot.timestamp}",""]
        for row in snapshot.components:
            lines.append(f"{row.state.value:11}  {row.component} — {row.summary}")
            for item in row.evidence: lines.append(f"    {item}")
        QMessageBox.information(self,"JOE System Health","\n".join(lines))

    def qualify_projects_sessions(self):
        from journeyman.core.projects_sessions import qualify_projects_sessions
        result=qualify_projects_sessions(self.module_runtime.service("joe.projects"))
        lines=["PASS" if result.passed else "FAIL",""]
        lines.extend(f"✓ {x}" for x in result.checks); lines.extend(f"✗ {x}" for x in result.failures)
        QMessageBox.information(self,"JOE Projects & Sessions Qualification","\n".join(lines))

    def joe012_release_readiness(self):
        from journeyman.core.projects_sessions import joe012_release_readiness
        result=joe012_release_readiness()
        lines=["READY" if result.passed else "NOT READY",""]
        lines.extend(f"✓ {x}" for x in result.checks); lines.extend(f"✗ {x}" for x in result.failures)
        QMessageBox.information(self,"JOE-012 Release Readiness","\n".join(lines))

    def open_projects_sessions(self):
        from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QListWidget,QPushButton,QLabel,
                                      QInputDialog,QMessageBox,QTextEdit)
        service=self.module_runtime.service("joe.projects")
        dialog=QDialog(self); dialog.setWindowTitle("JOE Projects & Sessions"); dialog.resize(950,620)
        root=QVBoxLayout(dialog); status_label=QLabel(); root.addWidget(status_label)
        body=QHBoxLayout(); root.addLayout(body,1)
        projects=QListWidget(); sessions=QListWidget(); detail=QTextEdit(); detail.setReadOnly(True)
        body.addWidget(projects,1); body.addWidget(sessions,1); body.addWidget(detail,2)
        buttons=QHBoxLayout(); root.addLayout(buttons)
        new_project=QPushButton("New Project"); new_session=QPushButton("New Session")
        bind_run=QPushButton("Bind Active Run"); save_workspace=QPushButton("Save Session Workspace")
        restore_workspace=QPushButton("Restore Session Workspace"); capture_config=QPushButton("Capture Config Revision")
        verify_config=QPushButton("Verify Config Revisions")
        close_session=QPushButton("Close Session"); archive_project=QPushButton("Archive Project")
        for b in (new_project,new_session,bind_run,save_workspace,restore_workspace,capture_config,verify_config,close_session,archive_project):buttons.addWidget(b)
        buttons.addStretch(1); done=QPushButton("Close"); buttons.addWidget(done); done.clicked.connect(dialog.accept)
        project_rows=[]; session_rows=[]
        def refresh(select_project_id=None):
            nonlocal project_rows,session_rows
            st=service.status()
            status_label.setText(f"Projects {st.projects} | Active {st.active_projects} | Archived {st.archived_projects} | "
                                 f"Sessions {st.sessions} | Active {st.active_sessions} | Closed {st.closed_sessions}")
            project_rows=list(service.projects()); projects.clear()
            for p in project_rows:projects.addItem(f"{'[ARCHIVED] ' if p.archived else ''}{p.name}")
            target=0
            if select_project_id:
                target=next((i for i,p in enumerate(project_rows) if p.project_id==select_project_id),0)
            if project_rows:projects.setCurrentRow(target)
            else:sessions.clear();detail.setPlainText("No projects exist. Create a project to organize future JOE work.")
        def project_changed(row):
            nonlocal session_rows
            sessions.clear(); detail.clear()
            if row<0 or row>=len(project_rows):return
            p=project_rows[row]; session_rows=list(service.sessions(p.project_id))
            for x in session_rows:
                run_count=len(service.runs_for_session(x.session_id))
                sessions.addItem(f"{'[CLOSED] ' if not x.active else ''}{x.name}  [{run_count} run(s)]")
            detail.setPlainText(f"Project: {p.name}\nID: {p.project_id}\nArchived: {p.archived}\n"
                                f"Created: {p.created_at}\nUpdated: {p.updated_at}\n\n{p.description or '(no description)'}")
        def session_changed(row):
            if row<0 or row>=len(session_rows):return
            x=session_rows[row]; context=service.session_context(x.session_id)
            detail.setPlainText(f"Session: {x.name}\nID: {x.session_id}\nProject: {context.project.name}\nProject ID: {x.project_id}\n"
                                f"Active: {x.active}\nCreated: {x.created_at}\nUpdated: {x.updated_at}\n"
                                f"Closed: {x.closed_at or 'ACTIVE'}\n\n"
                                f"Associated runs: {len(context.run_ids)}\n"
                                f"Workspace snapshot: {'SAVED' if context.workspace_saved else 'NONE'}"
                                + (f" ({context.workspace_saved_at})" if context.workspace_saved_at else "") + "\n"
                                f"Configuration references: {', '.join(context.config_namespaces) if context.config_namespaces else 'NONE'}")
        def create_project():
            name,ok=QInputDialog.getText(dialog,"New Project","Project name:")
            if not ok or not name.strip():return
            desc,ok2=QInputDialog.getMultiLineText(dialog,"Project Description","Description (optional):")
            if not ok2:return
            p=service.create_project(name,desc);refresh(p.project_id)
        def create_session():
            row=projects.currentRow()
            if row<0:return
            p=project_rows[row]
            name,ok=QInputDialog.getText(dialog,"New Session",f"Session name for {p.name}:")
            if not ok or not name.strip():return
            try:service.create_session(p.project_id,name)
            except Exception as exc:QMessageBox.warning(dialog,"New Session",str(exc));return
            refresh(p.project_id)
        def bind_active_run():
            prow=projects.currentRow(); srow=sessions.currentRow()
            if prow<0 or srow<0:return
            sess=session_rows[srow]
            if not sess.active:
                QMessageBox.warning(dialog,"Bind Active Run","Select an active session.");return
            recorder=self.module_runtime.service("joe.runs")
            active=[r for r in recorder.list_runs() if getattr(r.state,"value",str(r.state))=="ACTIVE"]
            if not active:
                QMessageBox.information(dialog,"Bind Active Run","There are no ACTIVE runs to bind.");return
            choices=[f"{i}: {r.name} | {r.run_id}" for i,r in enumerate(active)]
            choice,ok=QInputDialog.getItem(dialog,"Bind Active Run","Run:",choices,0,False)
            if not ok:return
            run=active[int(choice.split(":",1)[0])]
            try:service.bind_run(run.run_id,project_rows[prow].project_id,sess.session_id)
            except Exception as exc:QMessageBox.warning(dialog,"Bind Active Run",str(exc));return
            refresh(project_rows[prow].project_id)
        def save_session_workspace():
            prow=projects.currentRow();srow=sessions.currentRow()
            if prow<0 or srow<0:return
            sess=session_rows[srow]
            try:service.save_workspace_snapshot(sess.session_id,self._layout_entries())
            except Exception as exc:QMessageBox.warning(dialog,"Save Session Workspace",str(exc));return
            QMessageBox.information(dialog,"Save Session Workspace","Current JOE workspace state saved to the selected session.")
            refresh(project_rows[prow].project_id)
        def restore_session_workspace():
            srow=sessions.currentRow()
            if srow<0:return
            snap=service.workspace_snapshot(session_rows[srow].session_id)
            if snap is None:
                QMessageBox.information(dialog,"Restore Session Workspace","This session has no saved workspace state.");return
            try:entries=entries_from_snapshot(snap)
            except Exception as exc:QMessageBox.warning(dialog,"Restore Session Workspace",str(exc));return
            answer=QMessageBox.question(dialog,"Restore Session Workspace",
                                        "Replace the current JOE workspace arrangement with this session's saved workspace?")
            if answer!=QMessageBox.Yes:return
            self._restore_layout_entries(entries)
            self.statusBar().showMessage(f"Session workspace restored: {session_rows[srow].name}",3000)
        def capture_config_revision():
            srow=sessions.currentRow()
            if srow<0:return
            storage=self.module_runtime.service("joe.storage")
            namespaces=storage.config.namespaces()
            if not namespaces:
                QMessageBox.information(dialog,"Capture Config Revision","No JOE configuration namespaces are currently available.");return
            namespace,ok=QInputDialog.getItem(dialog,"Capture Config Revision","Configuration namespace:",list(namespaces),0,False)
            if not ok:return
            try:
                document=storage.config.load(namespace)
                ref=service.capture_config_reference(session_rows[srow].session_id,document)
            except Exception as exc:QMessageBox.warning(dialog,"Capture Config Revision",str(exc));return
            QMessageBox.information(dialog,"Capture Config Revision",
                                    f"Captured {ref['namespace']} revision {ref['revision']} ({ref['checksum'] or 'no checksum'}).")
        def verify_config_revisions():
            srow=sessions.currentRow()
            if srow<0:return
            storage=self.module_runtime.service("joe.storage")
            results=service.verify_config_references(session_rows[srow].session_id,storage.config)
            if not results:
                QMessageBox.information(dialog,"Verify Config Revisions","This session has no captured configuration references.");return
            lines=[]
            for item in results:
                ref=item["reference"]
                lines.append(f"{ref['namespace']} | captured r{ref['revision']} | {item['status']}"
                             + (f" | current r{item.get('current_revision')}" if 'current_revision' in item else ""))
            QMessageBox.information(dialog,"Verify Config Revisions","\n".join(lines))
        def do_close_session():
            prow=projects.currentRow();srow=sessions.currentRow()
            if prow<0 or srow<0:return
            try:service.close_session(session_rows[srow].session_id)
            except Exception as exc:QMessageBox.warning(dialog,"Close Session",str(exc));return
            refresh(project_rows[prow].project_id)
        def do_archive():
            row=projects.currentRow()
            if row<0:return
            pid=project_rows[row].project_id
            try:service.archive_project(pid)
            except Exception as exc:QMessageBox.warning(dialog,"Archive Project",str(exc));return
            refresh(pid)
        projects.currentRowChanged.connect(project_changed);sessions.currentRowChanged.connect(session_changed)
        new_project.clicked.connect(create_project);new_session.clicked.connect(create_session)
        bind_run.clicked.connect(bind_active_run);save_workspace.clicked.connect(save_session_workspace)
        restore_workspace.clicked.connect(restore_session_workspace)
        capture_config.clicked.connect(capture_config_revision);verify_config.clicked.connect(verify_config_revisions)
        close_session.clicked.connect(do_close_session);archive_project.clicked.connect(do_archive)
        refresh();dialog.exec()

    def qualify_run_review(self):
        from journeyman.core.run_review import qualify_run_review
        result=qualify_run_review(self.module_runtime.service("joe.run_review"))
        lines=["PASS" if result.passed else "FAIL",""]
        lines.extend(f"✓ {x}" for x in result.checks)
        lines.extend(f"✗ {x}" for x in result.failures)
        QMessageBox.information(self,"JOE Run/Data Review Qualification","\n".join(lines))

    def joe011_release_readiness(self):
        from journeyman.core.run_review import joe011_release_readiness
        result=joe011_release_readiness(self.module_runtime.service("joe.run_review"))
        lines=["READY" if result.passed else "NOT READY",""]
        lines.extend(f"✓ {x}" for x in result.checks)
        lines.extend(f"✗ {x}" for x in result.failures)
        QMessageBox.information(self,"JOE-011 Release Readiness","\n".join(lines))

    def open_run_review_workbench(self):
        from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QListWidget,QTextEdit,QPushButton,
            QLabel,QTabWidget,QTableWidget,QTableWidgetItem,QComboBox,QFileDialog,QListWidgetItem,QAbstractItemView)
        review=self.module_runtime.service("joe.run_review")
        dialog=QDialog(self); dialog.setWindowTitle("JOE Run/Data Review Workbench"); dialog.resize(1200,760)
        root=QVBoxLayout(dialog)
        status=review.status()
        state_text=", ".join(f"{k}: {v}" for k,v in status.states) or "none"
        root.addWidget(QLabel(
            f"Persisted JOE runs — read-only scientific review | Runs {status.total_runs} | "
            f"Readable {status.readable_runs} | Integrity PASS {status.integrity_passed_runs} | "
            f"Integrity FAIL {status.integrity_failed_runs} | {state_text}"
        ))
        body=QHBoxLayout(); root.addLayout(body,1)
        runs=QListWidget(); body.addWidget(runs,1)
        right=QVBoxLayout(); body.addLayout(right,4)
        tabs=QTabWidget(); right.addWidget(tabs,1)
        summary_text=QTextEdit(); summary_text.setReadOnly(True); tabs.addTab(summary_text,"Summary")
        events=QTableWidget(); tabs.addTab(events,"Events")
        samples=QTableWidget(); tabs.addTab(samples,"Samples")
        snapshots=QTableWidget(); tabs.addTab(snapshots,"Snapshots")
        links=QTableWidget(); tabs.addTab(links,"Provenance Links")
        controls=QHBoxLayout(); right.addLayout(controls)
        controls.addWidget(QLabel("Sample stream:")); stream_filter=QComboBox(); controls.addWidget(stream_filter)
        plot_button=QPushButton("Plot Selected Stream"); controls.addWidget(plot_button)
        multi_plot_button=QPushButton("Multi-Stream Plot"); controls.addWidget(multi_plot_button)
        save_plot_button=QPushButton("Save Plot Config"); controls.addWidget(save_plot_button)
        load_plot_button=QPushButton("Load Plot Config"); controls.addWidget(load_plot_button)
        compare_button=QPushButton("Compare Runs"); controls.addWidget(compare_button)
        export_samples=QPushButton("Export Samples CSV"); controls.addWidget(export_samples)
        export_events=QPushButton("Export Events CSV"); controls.addWidget(export_events)
        controls.addStretch(1)
        records=review.list_runs()
        for run in records:runs.addItem(f"{run.started_at} | {run.state.value} | {run.mode} | {run.name}")
        def fill(table,headers,rows):
            table.clear(); table.setColumnCount(len(headers)); table.setHorizontalHeaderLabels(headers)
            table.setRowCount(len(rows))
            for r,row in enumerate(rows):
                for c,key in enumerate(headers):
                    value=row.get(key.lower().replace(" ","_"),"")
                    table.setItem(r,c,QTableWidgetItem(str(value)))
            table.resizeColumnsToContents()
        def render_samples(run_id):
            stream=stream_filter.currentData()
            rows=review.filter_samples(run_id,stream_id=stream,limit=2000)
            fill(samples,["sequence","timestamp","stream_id","value","origin","source","frame_id"],rows)
        def selected():
            row=runs.currentRow()
            if row<0 or row>=len(records): return
            summary=review.open_run(records[row].run_id); run=summary.run
            text=[f"Run: {run.name}",f"ID: {run.run_id}",f"State: {run.state.value}",
                  f"Mode / provenance: {run.mode}",f"Source: {run.source}",
                  f"Started: {run.started_at}",f"Ended: {run.ended_at or 'ACTIVE'}","",
                  f"Integrity: {'PASS' if summary.integrity.passed else 'FAIL'} ({summary.integrity.checked_files} files)",
                  f"Events: {len(summary.events)}",f"Samples: {len(summary.samples)}",
                  f"Snapshots: {len(summary.snapshots)}",f"Associations: {len(summary.associations)}",
                  f"Streams: {', '.join(summary.stream_ids) if summary.stream_ids else 'none'}"]
            if summary.integrity.failures:text+=["","Integrity failures:"]+list(summary.integrity.failures)
            summary_text.setPlainText("\n".join(text))
            fill(events,["sequence","timestamp","type","source"],list(summary.events))
            fill(snapshots,["sequence","timestamp","type","source","revision"],list(summary.snapshots))
            fill(links,["sequence","timestamp","type","identifier","source"],list(summary.associations))
            stream_filter.blockSignals(True); stream_filter.clear(); stream_filter.addItem("All streams",None)
            for sid in summary.stream_ids:stream_filter.addItem(sid,sid)
            stream_filter.blockSignals(False); render_samples(run.run_id)
        def stream_changed(_):
            row=runs.currentRow()
            if 0<=row<len(records):render_samples(records[row].run_id)
        def show_plot(run_record,stream_ids,title=None):
            try:
                spec=review.create_plot_spec(run_record.run_id,stream_ids,limit=5000,
                                             title=title or f"{run_record.name} — recorded streams")
                view=review.render_plot_spec(spec)
            except Exception as exc:
                QMessageBox.warning(dialog,"Recorded Stream Plot",str(exc)); return
            if not view.traces or not any(trace.values for trace in view.traces):
                QMessageBox.information(dialog,"Recorded Stream Plot","The selection has no plottable numeric samples."); return
            import pyqtgraph as pg
            plot_dialog=QDialog(dialog); plot_dialog.setWindowTitle(view.title); plot_dialog.resize(1050,680)
            layout=QVBoxLayout(plot_dialog)
            origins=", ".join(sorted({trace.origin for trace in view.traces}))
            layout.addWidget(QLabel(f"RECORDED DATA | Run {run_record.run_id} | Origins {origins}"))
            widget=pg.PlotWidget(); widget.showGrid(x=True,y=True,alpha=0.25); widget.addLegend()
            for trace in view.traces:
                for n,(seg_start,seg_end) in enumerate(trace.segments):
                    widget.plot(trace.timestamps[seg_start:seg_end],trace.values[seg_start:seg_end],
                                name=trace.name if n==0 else None)
            widget.setLabel("bottom","Recorded timestamp")
            units=sorted({trace.unit for trace in view.traces if trace.unit})
            widget.setLabel("left","Recorded value",units=units[0] if len(units)==1 else None)
            layout.addWidget(widget,1)
            button=QPushButton("Close"); button.clicked.connect(plot_dialog.accept); layout.addWidget(button)
            plot_dialog.exec()
        def plot_selected():
            row=runs.currentRow(); stream=stream_filter.currentData()
            if row<0 or row>=len(records) or not stream:
                QMessageBox.information(dialog,"Recorded Stream Plot","Select a specific recorded stream first."); return
            show_plot(records[row],[stream],f"{records[row].name} — {stream}")
        def choose_streams(run_record):
            summary=review.open_run(run_record.run_id)
            numeric=set(review.visualization_for_run(run_record.run_id).numeric_stream_ids())
            choices=[sid for sid in summary.stream_ids if sid in numeric]
            if not choices:
                QMessageBox.information(dialog,"Multi-Stream Plot","This run has no recorded numeric streams."); return ()
            picker=QDialog(dialog); picker.setWindowTitle("Select Recorded Streams"); picker.resize(480,420)
            lay=QVBoxLayout(picker); lay.addWidget(QLabel("Select one or more numeric streams from this recorded run:"))
            lst=QListWidget(); lst.setSelectionMode(QAbstractItemView.SelectionMode.MultiSelection)
            for sid in choices: lst.addItem(QListWidgetItem(sid))
            lay.addWidget(lst,1)
            buttons=QHBoxLayout(); ok=QPushButton("Plot"); cancel=QPushButton("Cancel")
            ok.clicked.connect(picker.accept); cancel.clicked.connect(picker.reject)
            buttons.addStretch(1); buttons.addWidget(ok); buttons.addWidget(cancel); lay.addLayout(buttons)
            if picker.exec()!=QDialog.DialogCode.Accepted:return ()
            return tuple(item.text() for item in lst.selectedItems())
        def multi_plot():
            row=runs.currentRow()
            if row<0 or row>=len(records):return
            selected_streams=choose_streams(records[row])
            if selected_streams:show_plot(records[row],selected_streams)
        def save_plot_config():
            row=runs.currentRow()
            if row<0 or row>=len(records):return
            selected_streams=choose_streams(records[row])
            if not selected_streams:return
            spec=review.create_plot_spec(records[row].run_id,selected_streams,limit=5000,
                                         title=f"{records[row].name} — recorded streams")
            path,_=QFileDialog.getSaveFileName(dialog,"Save Reproducible Plot Configuration",
                                               "review_plot.json","JOE Review Plot (*.json)")
            if path:
                __import__("pathlib").Path(path).write_text(review.export_plot_spec_json(spec),encoding="utf-8")
        def load_plot_config():
            path,_=QFileDialog.getOpenFileName(dialog,"Load Reproducible Plot Configuration",
                                               "","JOE Review Plot (*.json)")
            if not path:return
            try:
                spec=review.import_plot_spec_json(__import__("pathlib").Path(path).read_text(encoding="utf-8"))
                target=next((r for r in records if r.run_id==spec.run_id),None)
                if target is None:raise KeyError(f"run {spec.run_id} is not present in this JOE repository")
                view=review.render_plot_spec(spec)
            except Exception as exc:
                QMessageBox.warning(dialog,"Load Plot Configuration",str(exc)); return
            show_plot(target,spec.stream_ids,spec.title)
        def compare_runs():
            left=runs.currentRow()
            if left<0 or len(records)<2:
                QMessageBox.information(dialog,"Run Comparison","At least two persisted runs are required."); return
            choices=[f"{i}: {r.name} | {r.run_id}" for i,r in enumerate(records) if i!=left]
            from PySide6.QtWidgets import QInputDialog
            choice,ok=QInputDialog.getItem(dialog,"Compare Runs","Compare selected run with:",choices,0,False)
            if not ok:return
            right=int(choice.split(":",1)[0])
            c=review.compare_runs(records[left].run_id,records[right].run_id)
            text=(f"LEFT: {records[left].name}\nRIGHT: {records[right].name}\n\n"
                  f"Lifecycle equal: {c.lifecycle_equal}\nMode/provenance equal: {c.mode_equal}\nSource equal: {c.source_equal}\n"
                  f"Common streams: {', '.join(c.common_stream_ids) or 'none'}\n"
                  f"Left-only streams: {', '.join(c.left_only_stream_ids) or 'none'}\n"
                  f"Right-only streams: {', '.join(c.right_only_stream_ids) or 'none'}\n\n"
                  f"Counts (events, samples, snapshots, links)\nLEFT: {c.left_counts}\nRIGHT: {c.right_counts}")
            QMessageBox.information(dialog,"JOE Run Comparison",text)
        def save_samples():
            row=runs.currentRow()
            if row<0:return
            sid=stream_filter.currentData()
            path,_=QFileDialog.getSaveFileName(dialog,"Export Recorded Samples","run_samples.csv","CSV (*.csv)")
            if path:
                __import__("pathlib").Path(path).write_text(review.export_samples_csv(records[row].run_id,stream_id=sid),encoding="utf-8")
        def save_events():
            row=runs.currentRow()
            if row<0:return
            path,_=QFileDialog.getSaveFileName(dialog,"Export Recorded Events","run_events.csv","CSV (*.csv)")
            if path:
                __import__("pathlib").Path(path).write_text(review.export_events_csv(records[row].run_id),encoding="utf-8")
        runs.currentRowChanged.connect(lambda _:selected()); stream_filter.currentIndexChanged.connect(stream_changed)
        plot_button.clicked.connect(plot_selected); multi_plot_button.clicked.connect(multi_plot)
        save_plot_button.clicked.connect(save_plot_config); load_plot_button.clicked.connect(load_plot_config)
        compare_button.clicked.connect(compare_runs)
        export_samples.clicked.connect(save_samples); export_events.clicked.connect(save_events)
        close=QPushButton("Close"); close.clicked.connect(dialog.accept); root.addWidget(close)
        if records:runs.setCurrentRow(0)
        else:summary_text.setPlainText("No persisted run records exist. JOE does not fabricate review data.")
        dialog.exec()

    def show_run_records(self):
        recorder=self.module_runtime.service("joe.runs")
        runs=recorder.list_runs()
        status=recorder.status()
        if not runs:
            text=("No JOE run records exist yet.\n\n"
                  "JOE does not create demonstration records merely to populate this view.")
        else:
            summary=(f"Total: {status.total_runs} | ACTIVE: {status.active_runs} | "
                     f"COMPLETED: {status.completed_runs} | FAILED: {status.failed_runs} | "
                     f"CANCELLED: {status.cancelled_runs}\n\n")
            text=summary+"\n".join(
                f"{run.started_at} | {run.state.value} | {run.mode} | {run.name} | "
                f"events={run.event_count} | samples={run.sample_count} | snapshots={run.snapshot_count} | links={run.association_count} | {run.run_id}"
                for run in runs[:50]
            )
        QMessageBox.information(self,"JOE Run Records",text)

    def qualify_visualization_engine(self):
        from journeyman.core.visualization import qualify_visualization_engine
        engine=self.module_runtime.service("joe.visualization")
        result=qualify_visualization_engine(engine)
        lines=["PASS" if result.passed else "FAIL",""]
        lines.extend(f"✓ {item}" for item in result.checks)
        lines.extend(f"✗ {item}" for item in result.failures)
        QMessageBox.information(self,"Visualization Engine Qualification","\n".join(lines))

    def open_scientific_intelligence(self):
        widget=ScientificIntelligenceWorkspace(self.module_runtime.service("joe.scientific-intelligence"),self.module_runtime.service("joe.scientific-reference"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("scientific-intelligence","Scientific Intelligence / Literature Watch"),kind="scientific-intelligence",width=1450,height=850)
        log.info("Opened Scientific Intelligence / Literature Watch")

    def open_scientific_reference(self):
        widget=ScientificReferenceWorkspace(self.module_runtime.service("joe.scientific-reference"),self.module_runtime.service("joe.guardian-reference"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("scientific-reference","Scientific Reference / Algorithm Library"),
                                          kind="scientific-reference",width=1450,height=850)
        log.info("Opened Scientific Reference / Algorithm Library")

    def joe_final_release_gate(self):
        r=self.module_runtime.service("joe.integrated-qualification").final_release()
        body=("PASS" if r.passed else "FAIL")+"\nRelease: "+r.release_version+"\nBuild: "+r.build+"\nRelease SHA-256: "+r.release_sha256
        body+="\n\nDeclared limitations:\n- "+"\n- ".join(r.manifest.limitations)
        QMessageBox.information(self,"JOE v1.5.0 Final Release Gate",body)

    def open_integrated_qualification(self):
        widget=IntegratedQualificationWorkspace(self.module_runtime.service("joe.integrated-qualification"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("integrated-qualification","JOE v1.5 Integrated Qualification"),
                                          kind="integrated-qualification",width=1450,height=850)
        log.info("Opened JOE v1.5 Integrated Qualification")

    def rt_release_readiness(self):
        result=self.module_runtime.service("joe.rt-control").release_readiness()
        body=("PASS" if result["passed"] else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result["checks"] or ("none",))
        if result["failures"]:body+="\n\nFailures:\n- "+"\n- ".join(result["failures"])
        body+="\n\nNotes:\n- "+"\n- ".join(result["notes"])
        QMessageBox.information(self,"RT / Control / BUS-SAFE v1.0 Release Readiness",body)

    def open_rt_control(self):
        widget=RTControlWorkspace(self.module_runtime.service("joe.rt-control"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("rt-control","RT / Control / BUS-SAFE Interfaces"),
                                          kind="rt-control",width=1450,height=800)
        log.info("Opened RT / Control / BUS-SAFE Interfaces")

    def quantum_release_readiness(self):
        result=self.module_runtime.service("joe.quantum-runtime").release_readiness()
        body=("PASS" if result["passed"] else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result["checks"] or ("none",))
        if result["failures"]:body+="\n\nFailures:\n- "+"\n- ".join(result["failures"])
        body+="\n\nNotes:\n- "+"\n- ".join(result["notes"])
        QMessageBox.information(self,"QPU Adapter / Quantum Runtime v1.0 Release Readiness",body)

    def open_quantum_runtime(self):
        widget=QuantumRuntimeWorkspace(self.module_runtime.service("joe.quantum-runtime"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("quantum-runtime","QPU Adapter / Quantum Runtime"),
                                          kind="quantum-runtime",width=1450,height=800)
        log.info("Opened QPU Adapter / Quantum Runtime")

    def compute_release_readiness(self):
        result=self.module_runtime.service("joe.compute").release_readiness()
        body=("PASS" if result["passed"] else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result["checks"] or ("none",))
        if result["failures"]:body+="\n\nFailures:\n- "+"\n- ".join(result["failures"])
        body+="\n\nNotes:\n- "+"\n- ".join(result["notes"])
        QMessageBox.information(self,"Compute Backend Manager v1.0 Release Readiness",body)

    def open_compute_backends(self):
        widget=ComputeBackendWorkspace(self.module_runtime.service("joe.compute"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("compute-backends","Compute Backend Manager"),
                                          kind="compute-backends",width=1450,height=800)
        log.info("Opened Compute Backend Manager")

    def report_release_readiness(self):
        result=self.module_runtime.service("joe.reports").release_readiness()
        body=("PASS" if result["passed"] else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result["checks"] or ("none",))
        if result["failures"]:body+="\n\nFailures:\n- "+"\n- ".join(result["failures"])
        body+="\n\nNotes:\n- "+"\n- ".join(result["notes"])
        QMessageBox.information(self,"Report / Dossier Generator v1.0 Release Readiness",body)

    def open_report_generator(self):
        widget=ReportGeneratorWorkspace(self.module_runtime.service("joe.reports"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("report-generator","Report / Dossier Generator"),
                                          kind="report-generator",width=1450,height=900)
        log.info("Opened Report / Dossier Generator")

    def scientific_data_release_readiness(self):
        result=self.module_runtime.service("joe.scientific-data").release_readiness()
        body=("PASS" if result["passed"] else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result["checks"] or ("none",))
        if result["failures"]:body+="\n\nFailures:\n- "+"\n- ".join(result["failures"])
        body+="\n\nNotes:\n- "+"\n- ".join(result["notes"])
        QMessageBox.information(self,"Scientific Data & Provenance v1.0 Release Readiness",body)

    def open_scientific_data(self):
        widget=ScientificDataWorkspace(self.module_runtime.service("joe.scientific-data"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("scientific-data","Scientific Data & Provenance"),
                                          kind="scientific-data",width=1500,height=900)
        log.info("Opened Scientific Data & Provenance")

    def visualization_release_readiness(self):
        from journeyman.core.visualization import joe009_release_readiness
        engine=self.module_runtime.service("joe.visualization")
        result=joe009_release_readiness(engine)
        lines=[
            "PASS — JOE-009 release ready" if result.passed else "FAIL — JOE-009 not release ready",
            "",
            f"Isolated coherent frames: {result.exercise_frames}",
            f"Isolated retained samples: {result.exercise_samples}",
            f"Decimated display points: {result.displayed_points}",
            f"Exported samples: {result.exported_samples}",
            f"High-rate retained samples: {result.high_rate_samples}",
            f"High-rate displayed points: {result.high_rate_displayed}",
        ]
        if result.notes:
            lines.extend(["","Issues:"]+[f"• {note}" for note in result.notes])
        QMessageBox.information(self,"JOE-009 Release Readiness","\n".join(lines))

    def open_scientific_field(self):
        visualization = self.module_runtime.service("joe.visualization")
        widget = ScientificFieldWorkspace(visualization)
        self.workspace_area.add_workspace(
            widget, self._next_workspace_title("scientific_field","Scientific Field Visualization"),
            kind="scientific_field", width=900, height=560
        )
        log.info("Opened scientific field visualization workspace")

    def visualization_release_readiness(self):
        result=self.module_runtime.service("joe.advanced-visualization").release_readiness()
        body=("PASS" if result["passed"] else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result["checks"] or ("none",))
        if result["failures"]:body+="\n\nFailures:\n- "+"\n- ".join(result["failures"])
        body+="\n\nNotes:\n- "+"\n- ".join(result["notes"])
        QMessageBox.information(self,"Advanced Analysis & Visualization v1.0 Release Readiness",body)

    def open_advanced_visualization(self):
        widget=AdvancedVisualizationWorkspace(self.module_runtime.service("joe.advanced-visualization"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("advanced-visualization","Advanced Analysis & Visualization"),
                                          kind="advanced-visualization",width=1500,height=900)
        log.info("Opened Advanced Analysis & Visualization")

    def guardian_release_readiness(self):
        result=self.module_runtime.service("joe.guardian").release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        body+="\n\nAuthority: "+result.authority
        QMessageBox.information(self,"Guardian AI Governor v1.0 Release Readiness",body)

    def open_guardian(self):
        widget=GuardianWorkspace(self.module_runtime.service("joe.guardian"),self.module_runtime)
        self.workspace_area.add_workspace(widget,self._next_workspace_title("guardian","Guardian AI Governor"),
                                          kind="guardian",width=1500,height=900)
        log.info("Opened Guardian AI Governor")

    def metrology_release_readiness(self):
        result=self.module_runtime.service("joe.metrology").release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"Metrology & Temporal Navigation v1.0 Release Readiness",body)

    def open_metrology(self):
        widget=MetrologyWorkspace(self.module_runtime.service("joe.metrology"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("metrology","Metrology & Temporal Navigation"),
                                          kind="metrology",width=1500,height=900)
        log.info("Opened Metrology & Temporal Navigation")

    def experiment_designer_release_readiness(self):
        result=self.module_runtime.service("joe.experiment-designer").release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"Experiment Designer v1.0 Release Readiness",body)

    def open_experiment_designer(self):
        widget=ExperimentDesignerWorkspace(self.module_runtime.service("joe.experiment-designer"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("experiment-designer","Experiment Designer / Sequencer"),
                                          kind="experiment-designer",width=1500,height=900)
        log.info("Opened Experiment Designer / Sequencer")

    def digital_twin_release_readiness(self):
        result=self.module_runtime.service("joe.digital-twin").release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"Digital Twin v1.0 Release Readiness",body)

    def open_digital_twin(self):
        widget=DigitalTwinWorkspace(self.module_runtime.service("joe.digital-twin"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("digital-twin","Digital Twin + Source Simulator"),kind="digital-twin",width=1500,height=900)
        log.info("Opened Digital Twin + Source Simulator")

    def open_verification(self):
        widget=VerificationWorkspace(self.module_runtime.service("joe.verification"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("verification","Verification & Uncertainty"),kind="verification",width=1500,height=900)
        log.info("Opened Verification & Uncertainty")

    def verification_release_readiness(self):
        result=self.module_runtime.service("joe.verification").release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"Verification & Uncertainty v1.0 Release Readiness",body)

    def open_ring_laser(self):
        widget=RingLaserWorkspace(self.module_runtime.service("joe.ring-laser"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("ring-laser","Method B / Ring-Laser"),kind="ring-laser",width=1550,height=900)
        log.info("Opened Method B / Ring-Laser")

    def ring_laser_release_readiness(self):
        result=self.module_runtime.service("joe.ring-laser").release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"Method-B v1.0 Release Readiness",body)

    def open_mouth_dynamics(self):
        widget=MouthDynamicsWorkspace(self.module_runtime.service("joe.mouth-dynamics"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("mouth-dynamics","Mouth Dynamics [D-1]"),kind="mouth-dynamics",width=1550,height=900)
        log.info("Opened Mouth Dynamics [D-1]")

    def mouth_dynamics_release_readiness(self):
        result=self.module_runtime.service("joe.mouth-dynamics").release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"D-1 v1.0 Release Readiness",body)

    def open_chronology(self):
        widget=ChronologyWorkspace(self.module_runtime.service("joe.chronology"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("chronology","Chronology Analyzer [C-1]"),kind="chronology",width=1500,height=900)
        log.info("Opened Chronology Analyzer [C-1]")

    def chronology_release_readiness(self):
        result=self.module_runtime.service("joe.chronology").release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"C-1 v1.0 Release Readiness",body)

    def open_qft(self):
        widget=QFTWorkspace(self.module_runtime.service("joe.qft"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("qft","QFT / Semiclassical / Quantum Inequality [Q-1]"),kind="qft",width=1500,height=900)
        log.info("Opened QFT / Semiclassical / Quantum Inequality [Q-1]")

    def qft_release_readiness(self):
        result=self.module_runtime.service("joe.qft").release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"Q-1 v1.0 Release Readiness",body)

    def open_traversability(self):
        widget=TraversabilityWorkspace(self.module_runtime.service("joe.traversability"),self.module_runtime.service("joe.geometry"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("traversability","Human Traversability Analyzer [T-1]"),kind="traversability",width=1500,height=900)
        log.info("Opened Human Traversability Analyzer [T-1]")

    def traversability_release_readiness(self):
        result=self.module_runtime.service("joe.traversability").release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"T-1 v1.0 Release Readiness",body)

    def open_navigation(self):
        widget=NavigationWorkspace(self.module_runtime.service("joe.navigation"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("navigation","Coordinate, Time & 3D Navigation"),kind="navigation",width=1450,height=850)
        log.info("Opened Coordinate, Time & 3D Navigation Workbench")

    def navigation_release_readiness(self):
        from journeyman.core.navigation import navigation_release_readiness
        result=navigation_release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"Navigation v1.0 Release Readiness",body)

    def open_scientific_registry(self):
        widget=ScientificRegistryWorkspace(self.module_runtime.service("joe.scientific-registry"),self.module_runtime.service("joe.units"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("scientific-registry","Scientific Object / Units Registry"),kind="scientific-registry",width=1450,height=850)
        log.info("Opened Scientific Object / Units Registry")

    def registry_release_readiness(self):
        from journeyman.core.scientific_registry import scientific_registry_release_readiness
        result=scientific_registry_release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"Scientific Registry v1.0 Release Readiness",body)

    def mpr_release_readiness(self):
        from journeyman.core.mpr import mpr_release_readiness
        result=mpr_release_readiness(self.module_runtime.service("joe.mpr"))
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"MPR v1.0 Release Readiness",body)

    def open_stress_energy(self):
        widget=StressEnergyWorkspace(self.module_runtime.service("joe.stress-energy"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("stress-energy","Stress-Energy / Einstein Tensor Workbench"),kind="stress-energy",width=1400,height=850)
        log.info("Opened Stress-Energy / Einstein Tensor Workbench")

    def stress_energy_release_readiness(self):
        from journeyman.core.stress_energy import stress_energy_release_readiness
        result=stress_energy_release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"Stress-Energy v1.0 Release Readiness",body)

    def geometry_release_readiness(self):
        from journeyman.core.geometry import geometry_release_readiness
        result=geometry_release_readiness()
        body=("PASS" if result.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(result.checks or ("none",))
        if result.failures:body+="\n\nFailures:\n- "+"\n- ".join(result.failures)
        if result.notes:body+="\n\nNotes:\n- "+"\n- ".join(result.notes)
        QMessageBox.information(self,"Geometry v1.0 Release Readiness",body)

    def open_geometry(self):
        widget=GeometryWorkspace(self.module_runtime.service("joe.geometry"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("geometry","Geometry / Metric Workbench"),kind="geometry",width=1350,height=820)
        log.info("Opened Geometry / Metric Workbench")

    def open_mpr(self):
        widget=MPRWorkspace(self.module_runtime.service("joe.mpr"))
        self.workspace_area.add_workspace(widget,self._next_workspace_title("mpr","Master Parameter Register"),kind="mpr",width=1250,height=760)
        log.info("Opened Master Parameter Register workspace")

    def open_scientific_table(self):
        visualization=self.module_runtime.service("joe.visualization")
        widget=ScientificTableWorkspace(visualization)
        self.workspace_area.add_workspace(widget,self._next_workspace_title("scientific_table","Scientific Data Table"),
                                          kind="scientific_table",width=950,height=560)
        log.info("Opened scientific data table workspace")

    def open_matrix_heatmap(self):
        visualization = self.module_runtime.service("joe.visualization")
        widget = MatrixHeatmapWorkspace(visualization)
        self.workspace_area.add_workspace(
            widget, self._next_workspace_title("matrix_heatmap","Matrix / Heatmap Visualization"),
            kind="matrix_heatmap", width=900, height=560
        )
        log.info("Opened matrix / heatmap visualization workspace")

    def open_numeric_instrument(self):
        visualization = self.module_runtime.service("joe.visualization")
        widget = NumericInstrumentWorkspace(visualization)
        self.workspace_area.add_workspace(
            widget, self._next_workspace_title("numeric_instrument","Numeric Instrument"),
            kind="numeric_instrument", width=700, height=300
        )
        log.info("Opened numeric instrument workspace")

    def open_analysis_plot(self):
        visualization = self.module_runtime.service("joe.visualization")
        widget = AnalysisPlotWorkspace(visualization)
        self.workspace_area.add_workspace(
            widget, self._next_workspace_title("analysis_plot","Scatter / Histogram Analysis"),
            kind="analysis_plot", width=900, height=560
        )
        log.info("Opened scatter / histogram analysis workspace")

    def open_live_time_series(self):
        visualization = self.module_runtime.service("joe.visualization")
        widget = LiveTimeSeriesWorkspace(visualization)
        self.workspace_area.add_workspace(
            widget, self._next_workspace_title("live_time_series","Live Time-Series Visualization"),
            kind="live_time_series", width=900, height=560
        )
        log.info("Opened live time-series visualization workspace")

    def joe008_release_readiness(self):
        streams = self.module_runtime.service("joe.streams")
        result = joe008_release_readiness(streams)
        live = result.live_qualification.status
        lines = [
            "JOE-008 SCIENTIFIC DATA STREAM ENGINE — RELEASE READINESS",
            "",
            f"Live stream qualification: {'PASS' if result.live_qualification.passed else 'FAIL'}",
            f"Live registered streams: {live.registered_streams}",
            f"Live retained samples: {live.retained_samples}",
            f"Live callback failures retained: {live.callback_failures}",
            "",
            "Isolated functional exercise:",
            f"• coherent frames committed: {result.exercise_frames}",
            f"• scientific samples committed: {result.exercise_samples}",
            "• bounded retention exercised at 64 samples/channel",
            "• retention-gap detection exercised",
            "• frame synchronization exercised",
            "• isolated provenance/sequence/timestamp qualification exercised",
            "",
            f"JOE-008 result: {'READY' if result.passed else 'NOT READY'}",
        ]
        if result.failures:
            lines.extend(["", "Failures:"] + [f"• {item}" for item in result.failures])
        else:
            lines.extend([
                "",
                "JOE-008 is code-level qualified as JOE's in-process scientific data transport.",
                "This does not certify deterministic real-time control, sensor calibration,",
                "scientific model validity, or physical experiment safety.",
            ])
        if result.passed:
            QMessageBox.information(self, "JOE-008 Release Readiness", "\n".join(lines))
            log.info("JOE-008 release readiness PASSED")
        else:
            QMessageBox.warning(self, "JOE-008 Release Readiness", "\n".join(lines))
            log.warning("JOE-008 release readiness FAILED: %s", result.failures)

    def qualify_scientific_data_streams(self):
        streams = self.module_runtime.service("joe.streams")
        result = qualify_scientific_data_streams(streams)
        status = result.status
        origin_text = ", ".join(f"{name}={count}" for name,count in status.origins) or "none"
        lines = [
            "JOE-008 SCIENTIFIC DATA STREAM QUALIFICATION",
            "",
            f"Registered streams: {status.registered_streams}",
            f"Streams with retained samples: {status.streams_with_samples}",
            f"Retained samples: {status.retained_samples}",
            f"Subscriber callback failures: {status.callback_failures}",
            f"Registered provenance classes: {origin_text}",
            f"Latest sample timestamp: {status.latest_timestamp if status.latest_timestamp is not None else 'N/A'}",
            "",
            f"Result: {'PASS' if result.passed else 'FAIL'}",
        ]
        if result.failures:
            lines.extend(["", "Failures:"] + [f"• {item}" for item in result.failures])
        else:
            lines.extend(["", "Stream identities, source/provenance contracts, retained sequences, and timestamps are internally consistent."])
        if result.passed:
            QMessageBox.information(self, "Scientific Data Stream Qualification", "\n".join(lines))
            log.info("JOE-008 scientific data stream qualification PASSED")
        else:
            QMessageBox.warning(self, "Scientific Data Stream Qualification", "\n".join(lines))
            log.warning("JOE-008 scientific data stream qualification FAILED: %s", result.failures)

    def show_scientific_data_streams(self):
        streams = self.module_runtime.service("joe.streams")
        definitions = streams.definitions()
        lines = [
            "JOE SCIENTIFIC DATA STREAM ENGINE",
            "",
            f"Registered streams: {len(definitions)}",
            f"Subscriber callback failures: {len(streams.callback_failures())}",
            "",
            "No stream is created until a real software, HOST, IMPORTED, SIMULATION,",
            "or HARDWARE producer explicitly registers one.",
        ]
        if definitions:
            lines.extend(["", "Streams:"])
            for definition in definitions:
                latest=streams.latest(definition.stream_id)
                count=len(streams.history(definition.stream_id))
                latest_text=("NO SAMPLES" if latest is None else
                             f"seq {latest.sequence}; frame={latest.frame_id if latest.frame_id is not None else 'single'}; "
                             f"value={latest.value!r}; source={latest.source}; "
                             f"origin={latest.origin.value}; t={latest.timestamp:.3f}")
                lines.append(
                    f"• {definition.stream_id} — {definition.name} [{definition.unit or 'unitless'}] "
                    f"{definition.origin.value}; {count} retained; {latest_text}"
                )
        QMessageBox.information(self, "Scientific Data Streams", "\n".join(lines))

    def joe007_release_readiness(self):
        telemetry = self.module_runtime.service("joe.host-telemetry")
        monitor = self.module_runtime.service("joe.host-telemetry-monitor")
        result = joe007_release_readiness(telemetry, monitor)
        q = result.qualification
        maximum = "N/A" if result.maximum_interval_seconds is None else f"{result.maximum_interval_seconds:.3f}s"
        lines = [
            "JOE-007 HOST / SYSTEM TELEMETRY RELEASE READINESS",
            "",
            f"Monitor: {'RUNNING' if q.monitor_running else 'STOPPED'}",
            f"Retained real samples: {q.retained_samples}",
            f"Measured sample intervals: {len(result.sample_intervals)}",
            f"Maximum observed interval: {maximum}",
            f"Acquisition failures: {result.acquisition_failures}",
            f"Subscriber callback failures: {result.callback_failures}",
            f"Temperature source: {'AVAILABLE' if q.temperature_available else 'UNAVAILABLE'}",
            f"GPU source: {'AVAILABLE' if q.gpu_available else 'UNAVAILABLE'}",
            "",
            f"Result: {'PASS' if result.passed else 'FAIL'}",
        ]
        if result.failures:
            lines.extend(["", "Failures:"] + [f"• {item}" for item in result.failures])
        else:
            lines.extend([
                "",
                "JOE-007 real host telemetry acquisition is code-level ready.",
                "Optional unsupported sensors remain explicitly unavailable.",
                "Sampling cadence is observational/UI cadence, not deterministic real-time timing.",
            ])
        if result.passed:
            QMessageBox.information(self, "JOE-007 Release Readiness", "\n".join(lines))
            log.info("JOE-007 release readiness PASSED")
        else:
            QMessageBox.warning(self, "JOE-007 Release Readiness", "\n".join(lines))
            log.warning("JOE-007 release readiness FAILED: %s", result.failures)

    def qualify_host_telemetry(self):
        telemetry = self.module_runtime.service("joe.host-telemetry")
        monitor = self.module_runtime.service("joe.host-telemetry-monitor")
        result = qualify_host_telemetry(telemetry, monitor)
        lines = [
            "JOE HOST TELEMETRY QUALIFICATION",
            "",
            f"Continuous monitor: {'RUNNING' if result.monitor_running else 'STOPPED'}",
            f"Retained samples: {result.retained_samples}",
            f"Subscriber callback failures: {result.callback_failures}",
            f"Acquisition failures: {len(monitor.acquisition_failures())}",
            f"Sample freshness: {'FRESH' if monitor.status().fresh else 'STALE/UNAVAILABLE'}",
            f"Temperature source available: {'YES' if result.temperature_available else 'UNAVAILABLE'}",
            f"GPU source available: {'YES' if result.gpu_available else 'UNAVAILABLE'}",
            "",
            f"Result: {'PASS' if result.passed else 'FAIL'}",
        ]
        if result.failures:
            lines.extend(["", "Failures:"] + [f"• {item}" for item in result.failures])
        else:
            lines.extend([
                "",
                "Real host acquisition invariants passed.",
                "Unavailable optional sensors are not qualification failures.",
            ])
        if result.passed:
            QMessageBox.information(self, "JOE Host Telemetry Qualification", "\n".join(lines))
            log.info("JOE host telemetry qualification PASSED")
        else:
            QMessageBox.warning(self, "JOE Host Telemetry Qualification", "\n".join(lines))
            log.warning("JOE host telemetry qualification FAILED: %s", result.failures)

    def show_host_telemetry(self):
        telemetry = self.module_runtime.service("joe.host-telemetry")
        monitor = self.module_runtime.service("joe.host-telemetry-monitor")
        sample = monitor.latest() or telemetry.sample()
        gib = 1024 ** 3
        lines = [
            "JOE REAL HOST TELEMETRY",
            "",
            f"CPU utilization: {sample.cpu_percent:.1f}%",
            f"CPU logical processors: {sample.cpu_logical_count if sample.cpu_logical_count is not None else 'UNAVAILABLE'}",
            f"CPU physical cores: {sample.cpu_physical_count if sample.cpu_physical_count is not None else 'UNAVAILABLE'}",
            f"Memory utilization: {sample.memory_percent:.1f}%",
            f"Memory available: {sample.memory_available_bytes/gib:.2f} GiB / {sample.memory_total_bytes/gib:.2f} GiB",
            f"JOE process RSS: {sample.process_rss_bytes/gib:.3f} GiB",
            f"JOE process CPU: {sample.process_cpu_percent:.1f}%",
            f"Storage utilization: {sample.disk_percent:.1f}%",
            f"Storage free: {sample.disk_free_bytes/gib:.2f} GiB / {sample.disk_total_bytes/gib:.2f} GiB",
            f"Continuous monitor: {'RUNNING' if monitor.running else 'STOPPED'}",
            f"Retained samples: {len(monitor.history())}",
            f"Subscriber callback failures: {len(monitor.callback_failures())}",
            f"Acquisition failures: {len(monitor.acquisition_failures())}",
            f"Latest sample freshness: {'FRESH' if monitor.status().fresh else 'STALE/UNAVAILABLE'}",
            "",
        ]
        if sample.temperature_available:
            lines.append("Temperature sensors:")
            for reading in sample.temperatures:
                name = f"{reading.sensor} / {reading.label}" if reading.label else reading.sensor
                lines.append(f"  {name}: {reading.celsius:.1f} °C")
        else:
            lines.append("Temperature sensors: UNAVAILABLE from current host API")
        lines.append("")
        if sample.gpu_available:
            lines.append("GPU telemetry:")
            for gpu in sample.gpus:
                util = "UNAVAILABLE" if gpu.utilization_percent is None else f"{gpu.utilization_percent:.1f}%"
                temp = "UNAVAILABLE" if gpu.temperature_celsius is None else f"{gpu.temperature_celsius:.1f} °C"
                if gpu.memory_used_bytes is None or gpu.memory_total_bytes is None:
                    memory = "UNAVAILABLE"
                else:
                    memory = f"{gpu.memory_used_bytes/(1024**3):.2f} / {gpu.memory_total_bytes/(1024**3):.2f} GiB"
                lines.append(f"  GPU {gpu.index}: {gpu.name}")
                lines.append(f"    Utilization: {util}; VRAM: {memory}; Temperature: {temp}")
                lines.append(f"    Source: {gpu.source}")
        else:
            lines.append("GPU telemetry: UNAVAILABLE from supported vendor API")
        lines.extend([
            "",
            "Origin: HOST",
            "No unavailable measurement is synthesized.",
        ])
        QMessageBox.information(self, "JOE Host Telemetry Snapshot", "\n".join(lines))

    def joe006_release_readiness(self):
        jobs = self.module_runtime.service("joe.jobs")
        result = joe006_release_readiness(jobs)
        live = result.lifecycle_qualification
        lines = [
            "JOE-006 JOB & COMPUTE ENGINE RELEASE READINESS",
            "",
            f"Live known jobs: {live.known_jobs}",
            f"Live active jobs: {live.active_jobs}",
            f"Registered owners: {live.registered_owners}",
            f"Isolated jobs exercised: {result.exercised_jobs}",
            "",
            f"Result: {'PASS' if result.passed else 'FAIL'}",
        ]
        if result.failures:
            lines.extend(["", "Failures:"] + [f"• {item}" for item in result.failures])
        else:
            lines.extend([
                "",
                "JOE-006 code-level compute readiness passed.",
                "Functional exercises ran in an isolated engine and did not pollute live job history.",
                "This remains research/software compute, not deterministic RT or BUS-SAFE.",
            ])
        if result.passed:
            QMessageBox.information(self, "JOE-006 Release Readiness", "\n".join(lines))
            log.info("JOE-006 release readiness PASSED")
        else:
            QMessageBox.warning(self, "JOE-006 Release Readiness", "\n".join(lines))
            log.warning("JOE-006 release readiness FAILED: %s", result.failures)

    def qualify_job_compute_engine(self):
        jobs = self.module_runtime.service("joe.jobs")
        result = qualify_job_engine(jobs)
        lines = [
            "JOE JOB / COMPUTE ENGINE QUALIFICATION",
            "",
            f"Known jobs: {result.known_jobs}",
            f"Active jobs: {result.active_jobs}",
            f"Registered owners: {result.registered_owners}",
            f"Retained transitions: {result.transition_count}",
            "",
            f"Result: {'PASS' if result.passed else 'FAIL'}",
        ]
        if result.failures:
            lines.extend(["", "Failures:"] + [f"• {item}" for item in result.failures])
        else:
            lines.extend([
                "",
                "Process-local job lifecycle and policy invariants passed.",
                "This is not real-time, hardware, or BUS-SAFE qualification.",
            ])
        if result.passed:
            QMessageBox.information(self, "JOE Job Engine Qualification", "\n".join(lines))
            log.info("JOE job engine qualification PASSED")
        else:
            QMessageBox.warning(self, "JOE Job Engine Qualification", "\n".join(lines))
            log.warning("JOE job engine qualification FAILED: %s", result.failures)

    def show_job_engine_status(self):
        jobs = self.module_runtime.service("joe.jobs")
        counts = jobs.counts()
        lines = [
            "JOE JOB / COMPUTE ENGINE",
            "",
            f"Worker threads: {jobs.max_workers}",
            f"Jobs known: {len(jobs.snapshots())}",
            f"Registered owners: {len(jobs.owner_policies())}",
            f"Completed-job retention: {jobs.completed_limit}",
        ]
        for state,count in counts.items():
            lines.append(f"{state.value}: {count}")
        active = [job for job in jobs.snapshots() if job.state.value in ("QUEUED","RUNNING")]
        if active:
            lines.append("")
            lines.append("Active jobs:")
            for job in active:
                lines.append(
                    f"  {job.name} [{job.priority.name}] {job.state.value} "
                    f"{job.progress*100:.1f}% — {job.owner}"
                )
        if jobs.owner_policies():
            lines.append("")
            lines.append("Owner policies:")
            for policy in jobs.owner_policies():
                lines.append(f"  {policy.owner}: max active {policy.max_active}")
        lines.extend([
            "",
            "Execution domain: process-local CPU worker threads",
            "Authority: research/software only — NOT real-time control or BUS-SAFE",
        ])
        QMessageBox.information(self, "JOE Job / Compute Engine Status", "\n".join(lines))

    def joe005_release_readiness(self):
        storage = self.module_runtime.service("joe.storage")
        result = joe005_release_readiness(storage)
        lines = [
            "JOE-005 STORAGE & CONFIGURATION RELEASE READINESS",
            "",
            f"Configuration namespaces: {len(result.config_namespaces)}",
            f"Filesystem capacity: {result.total_bytes / (1024**3):.2f} GiB",
            f"Filesystem free: {result.free_bytes / (1024**3):.2f} GiB",
            "",
            f"Result: {'PASS' if result.passed else 'FAIL'}",
        ]
        if result.failures:
            lines.extend(["", "Failures:"] + [f"• {item}" for item in result.failures])
        else:
            lines.extend([
                "",
                "JOE-005 code-level storage/configuration readiness passed.",
                "The durability probe ran in an isolated temporary JOE root and did not alter user data.",
                "Scientific run/provenance storage remains owned by JOE-010.",
            ])
        if result.passed:
            QMessageBox.information(self, "JOE-005 Release Readiness", "\n".join(lines))
            log.info("JOE-005 release readiness PASSED")
        else:
            QMessageBox.warning(self, "JOE-005 Release Readiness", "\n".join(lines))
            log.warning("JOE-005 release readiness FAILED: %s", result.failures)

    def show_storage_health(self):
        storage = self.module_runtime.service("joe.storage")
        health = storage_health(storage)
        def gib(value):
            return f"{value / (1024**3):.2f} GiB"
        lines = [
            "JOE STORAGE HEALTH",
            "",
            f"Total capacity: {gib(health.total_bytes)}",
            f"Used: {gib(health.used_bytes)}",
            f"Free: {gib(health.free_bytes)}",
            "",
            f"Config writable: {'YES' if health.config_writable else 'NO'}",
            f"Data writable: {'YES' if health.data_writable else 'NO'}",
            f"Logs writable: {'YES' if health.logs_writable else 'NO'}",
            "",
            f"Health: {'PASS' if health.passed else 'FAIL'}",
        ]
        if health.failures:
            lines.extend(["", "Failures:"] + [f"• {item}" for item in health.failures])
        if health.passed:
            QMessageBox.information(self, "JOE Storage Health", "\n".join(lines))
        else:
            QMessageBox.warning(self, "JOE Storage Health", "\n".join(lines))

    def qualify_storage_configuration(self):
        storage = self.module_runtime.service("joe.storage")
        result = qualify_storage(storage)
        if result.passed:
            QMessageBox.information(
                self, "JOE Storage / Configuration Qualification",
                "STORAGE / CONFIGURATION QUALIFICATION PASSED.\n\n"
                f"Namespaces verified: {len(result.namespaces)}\n\n"
                "This qualifies JOE's current storage/configuration integrity only; "
                "it is not scientific run-record qualification."
            )
            log.info("JOE storage/configuration qualification PASSED")
        else:
            QMessageBox.warning(
                self, "JOE Storage / Configuration Qualification",
                "STORAGE / CONFIGURATION QUALIFICATION FAILED.\n\n"
                + "\n".join(f"• {item}" for item in result.failures)
            )
            log.warning("JOE storage/configuration qualification FAILED: %s", result.failures)

    def show_storage_status(self):
        storage = self.module_runtime.service("joe.storage")
        namespaces = storage.config.namespaces()
        health = storage_health(storage)
        lines = [
            "JOE STORAGE / CONFIGURATION",
            "",
            f"Root: {storage.paths.root}",
            f"Config: {storage.paths.config}",
            f"Data: {storage.paths.data}",
            f"Logs: {storage.paths.logs}",
            f"Free storage: {health.free_bytes / (1024**3):.2f} GiB",
            "",
            f"Configuration namespaces: {len(namespaces)}",
        ]
        data_namespaces = sorted(
            path.name for path in storage.paths.data.iterdir() if path.is_dir()
        )
        lines.extend([
            "",
            f"Data namespaces: {len(data_namespaces)}",
        ])
        for namespace in data_namespaces:
            try:
                artifacts = storage.data.list_artifacts(namespace)
                total = sum(item.size_bytes for item in artifacts)
                lines.append(
                    f"  {namespace}: {len(artifacts)} artifact(s), {total} bytes"
                )
            except Exception as exc:
                lines.append(f"  {namespace}: ERROR — {exc}")
        if namespaces:
            for namespace in namespaces:
                try:
                    document = storage.config.load(namespace)
                    backup = "yes" if storage.config.has_backup(namespace) else "no"
                    integrity = "SHA-256" if document.checksum else "legacy/no checksum"
                    lines.append(
                        f"  {namespace}: revision {document.revision}, "
                        f"schema {document.schema_version}, backup {backup}, "
                        f"integrity {integrity}"
                    )
                except Exception as exc:
                    lines.append(f"  {namespace}: ERROR — {exc}")
        else:
            lines.append("  None")
        QMessageBox.information(self, "JOE Storage / Configuration Status", "\n".join(lines))

    def joe004_release_readiness(self):
        backbone = self.module_runtime.service("joe.state-events")
        result = joe004_release_readiness(backbone)
        q = result.qualification
        summary = (
            f"State definitions: {q.state_definition_count}\n"
            f"Event topics: {q.event_topic_count}\n"
            f"Required states: {', '.join(result.required_states)}\n"
            f"Required topics: {', '.join(result.required_topics)}"
        )
        if result.passed:
            QMessageBox.information(
                self, "JOE-004 Release Readiness",
                "JOE-004 STATE / EVENT BACKBONE RELEASE GATE PASSED.\n\n" +
                summary +
                "\n\nJOE-004 is code-level ready. This does not qualify physical "
                "hardware, scientific models, simulations as measurements, or BUS-SAFE."
            )
            log.info("JOE-004 state/event release gate PASSED")
        else:
            QMessageBox.warning(
                self, "JOE-004 Release Readiness",
                "JOE-004 STATE / EVENT BACKBONE RELEASE GATE FAILED.\n\n" +
                summary + "\n\nFailures:\n" +
                "\n".join(f"• {item}" for item in result.failures)
            )
            log.warning("JOE-004 state/event release gate FAILED: %s", result.failures)

    def qualify_state_event_backbone(self):
        backbone = self.module_runtime.service("joe.state-events")
        result = qualify_state_event_backbone(backbone)
        summary = (
            f"State definitions: {result.state_definition_count}\n"
            f"Event topics: {result.event_topic_count}\n"
            f"State history retained: {result.state_history_count}\n"
            f"Event history retained: {result.event_history_count}"
        )
        if result.passed:
            QMessageBox.information(
                self, "JOE State/Event Backbone Qualification",
                "STATE / EVENT BACKBONE QUALIFICATION PASSED.\n\n" + summary +
                "\n\nThis qualifies JOE's in-process coordination backbone only. "
                "It does not qualify physical experiments, instruments, BUS-SAFE, "
                "or simulated physics as real measurements."
            )
            log.info("JOE state/event backbone qualification PASSED")
        else:
            QMessageBox.warning(
                self, "JOE State/Event Backbone Qualification",
                "STATE / EVENT BACKBONE QUALIFICATION FAILED.\n\n" + summary +
                "\n\nFailures:\n" + "\n".join(f"• {item}" for item in result.failures)
            )
            log.warning("JOE state/event backbone qualification FAILED: %s", result.failures)

    def show_state_event_backbone_status(self):
        backbone = self.module_runtime.service("joe.state-events")
        state_snapshot = backbone.state.snapshot()
        state_failures = backbone.state.callback_failures()
        event_failures = backbone.events.callback_failures()
        lines = [
            "JOE STATE / EVENT BACKBONE",
            "",
            f"State keys: {len(state_snapshot)}",
            f"State changes retained: {len(backbone.state.history())}",
            f"Event records retained: {len(backbone.events.history())}",
            f"State callback failures: {len(state_failures)}",
            f"Event callback failures: {len(event_failures)}",
            "",
            "CURRENT STATE:",
        ]
        if state_snapshot:
            latest_origin = {}
            for change in backbone.state.history():
                latest_origin[change.key] = change.origin.value
            lines.extend(
                f"  {key} [rev {backbone.state.revision(key)} / "
                f"{latest_origin.get(key, 'UNKNOWN')}] = {state_snapshot[key]!r}"
                for key in sorted(state_snapshot)
            )
        else:
            lines.append("  None")
        failures = (*state_failures[-5:], *event_failures[-5:])
        lines.extend(["", "RECENT CALLBACK FAILURES:"])
        if failures:
            lines.extend(
                f"  #{item.sequence} [{item.channel}] {item.name} / "
                f"{item.callback_name}: {item.error}"
                for item in failures
            )
        else:
            lines.append("  None")
        QMessageBox.information(self, "JOE State/Event Backbone Status", "\n".join(lines))

    def joe003_release_readiness(self):
        result = joe003_release_readiness(self.module_runtime)
        order = " → ".join(result.activation_order) if result.activation_order else "None"
        capabilities = ", ".join(result.published_capabilities) if result.published_capabilities else "None"
        summary = (
            f"Modules: {result.module_count}\n"
            f"Active: {result.active_count}\n"
            f"Published capabilities: {capabilities}\n"
            f"Dependency-safe order: {order}"
        )
        if result.passed:
            QMessageBox.information(
                self, "JOE-003 Release Readiness",
                "JOE-003 MODULE RUNTIME RELEASE GATE PASSED.\n\n" + summary +
                "\n\nThis is a code-level JOE module-runtime release gate. "
                "It does not qualify scientific calculations, experiments, or hardware."
            )
            log.info("JOE-003 module runtime release gate PASSED")
        else:
            QMessageBox.warning(
                self, "JOE-003 Release Readiness",
                "JOE-003 MODULE RUNTIME RELEASE GATE FAILED.\n\n" + summary +
                "\n\nFailures:\n" + "\n".join(f"• {item}" for item in result.failures)
            )
            log.warning("JOE-003 module runtime release gate FAILED: %s", result.failures)

    def show_module_runtime_status(self):
        lines = ["REGISTERED MODULES:"]
        for record in self.module_runtime.records():
            d = record.descriptor
            lines.extend([
                "",
                f"{d.name} [{d.module_id}]",
                f"  Version: {d.version}",
                f"  State: {record.state.value}",
                f"  Requires: {', '.join(d.requires) if d.requires else 'None'}",
                f"  Provides: {', '.join(d.provides) if d.provides else 'None'}",
                f"  Consumes: {', '.join(d.consumes) if d.consumes else 'None'}",
                f"  Error: {record.error if record.error else 'None'}",
            ])
        capabilities = self.module_runtime.available_capabilities()
        lines.extend(["", "ACTIVE SERVICES:"])
        lines.extend([f"  {cap}" for cap in capabilities] or ["  None"])
        lines.extend(["", "RECENT MODULE TRANSITIONS:"])
        recent = self.module_runtime.transitions()[-12:]
        if recent:
            for transition in recent:
                previous = transition.previous.value if transition.previous else "none"
                lines.append(
                    f"  #{transition.sequence} {transition.module_id}: "
                    f"{previous} → {transition.current.value} ({transition.reason})"
                )
        else:
            lines.append("  None")
        QMessageBox.information(self, "JOE Module Runtime Status", "\n".join(lines))

    def qualify_module_runtime(self):
        result = qualify_module_runtime(self.module_runtime)
        order = " → ".join(result.activation_order) if result.activation_order else "None"
        if result.passed:
            QMessageBox.information(
                self, "JOE Module Runtime Qualification",
                "MODULE RUNTIME STRUCTURAL QUALIFICATION PASSED.\n\n"
                f"Dependency-safe activation order:\n{order}\n\n"
                "This validates the live module graph and runtime contracts; it is not "
                "scientific or physical-hardware qualification."
            )
            log.info("Module runtime structural qualification PASSED")
        else:
            QMessageBox.warning(
                self, "JOE Module Runtime Qualification",
                "MODULE RUNTIME STRUCTURAL QUALIFICATION FAILED.\n\n" +
                "\n".join(result.failures)
            )
            log.warning("Module runtime structural qualification FAILED: %s", result.failures)

    def reset_window_position(self):
        screen = self.screen().availableGeometry() if self.screen() else None
        self.resize(1280, 800)
        if screen:
            frame = self.frameGeometry()
            frame.moveCenter(screen.center())
            self.move(frame.topLeft())
        self.settings.window_geometry = ""
        self.settings.save()
        log.info("Main window geometry reset")

    def open_settings(self):
        dialog = SettingsDialog(self.settings, self)
        if dialog.exec():
            self.settings.telemetry_interval_ms = dialog.interval.value()
            self.settings.confirm_exit = dialog.confirm_exit.isChecked()
            self.settings.save()
            self._timer.setInterval(self.settings.telemetry_interval_ms)
            log.info("Settings updated")

    def show_about(self):
        QMessageBox.about(self, "About JOE", f"<b>Journeyman Operating Environment</b><br>{__build__}<br>Version {__version__}<br><br>Project Journeyman integrated scientific operating environment.")

    def _active_workspace_id(self) -> str:
        record = self._active_workspace_record()
        if not record:
            return ""
        window = record["object"]
        if record["location"] == "External":
            return str(window.workspace_id or "")
        return str(window.property("joe_workspace_id") or "")

    def _restore_last_active_workspace(self):
        target_id = str(self.settings.active_workspace_id or "")
        if not target_id:
            return
        for record in self.workspace_records():
            if record.get("workspace_id") == target_id:
                self.focus_workspace_record(record)
                log.info("Restored last active workspace: %s", target_id)
                return

    def _persist_window_state(self):
        self.settings.set_geometry(bytes(self.saveGeometry()))
        self.settings.active_workspace_id = self._active_workspace_id()
        self.settings.save()

    def save_and_quit(self):
        """User-facing orderly shutdown: persist state, then close JOE."""
        self._allow_close = True
        self.close()

    def closeEvent(self, event):
        if getattr(self, "_shutdown_in_progress", False):
            event.accept()
            return

        if not self._allow_close and self.settings.confirm_exit:
            result = QMessageBox.question(
                self,
                "Save & Quit JOE",
                "Save the current workspace/layout and shut down JOE?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.Yes,
            )
            if result != QMessageBox.Yes:
                event.ignore()
                return

        self._shutdown_in_progress = True
        self._allow_close = True
        try:
            # Persist before tearing down Qt objects or module services.
            self.save_workspace_layout()
            self._persist_window_state()

            # Close external windows while the main Qt object graph is still alive.
            for external in list(self.external_workspaces):
                try:
                    external.close()
                except RuntimeError:
                    pass
            self.external_workspaces.clear()

            stopped_modules = self.module_runtime.shutdown_all()
            if stopped_modules:
                log.info("Module runtime shutdown order: %s", ", ".join(stopped_modules))
        except Exception:
            log.exception("Failed during orderly JOE shutdown")
        finally:
            log.info("JOE shutdown accepted")
            event.accept()
