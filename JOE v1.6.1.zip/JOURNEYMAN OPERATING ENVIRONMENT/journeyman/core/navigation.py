"""Typed coordinate, epoch/time, and navigation contracts for JOE."""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Any
import math,time,uuid
import numpy as np
from .state_events import DataOrigin
from .units import VectorEstimate

class FrameKind(str,Enum):
    LOCAL_ENGINEERING="LOCAL_ENGINEERING"
    EARTH_FIXED="EARTH_FIXED"
    EARTH_INERTIAL="EARTH_INERTIAL"
    BARYCENTRIC_INERTIAL="BARYCENTRIC_INERTIAL"
    BODY_FIXED="BODY_FIXED"
    INSTRUMENT="INSTRUMENT"
    OBJECT_RELATIVE="OBJECT_RELATIVE"
    GENERIC_CARTESIAN="GENERIC_CARTESIAN"

class TimeScale(str,Enum):
    UTC="UTC";TAI="TAI";TT="TT";TDB="TDB"
    MONOTONIC="MONOTONIC";EXPERIMENT_ELAPSED="EXPERIMENT_ELAPSED"
    SIMULATION="SIMULATION";PROPER_TIME="PROPER_TIME";COORDINATE_TIME="COORDINATE_TIME"

class SyncQuality(str,Enum):
    UNKNOWN="UNKNOWN";UNSYNCHRONIZED="UNSYNCHRONIZED";DEGRADED="DEGRADED";SYNCHRONIZED="SYNCHRONIZED"

@dataclass(frozen=True)
class ReferenceEllipsoid:
    name:str
    semi_major_axis_m:float
    inverse_flattening:float
    def __post_init__(self):
        if not self.name.strip() or not math.isfinite(self.semi_major_axis_m) or self.semi_major_axis_m<=0:
            raise ValueError("ellipsoid requires name and positive finite semi-major axis")
        if not math.isfinite(self.inverse_flattening) or self.inverse_flattening<=1:raise ValueError("inverse flattening must be finite > 1")
    @property
    def flattening(self):return 1.0/self.inverse_flattening
    @property
    def semi_minor_axis_m(self):return self.semi_major_axis_m*(1-self.flattening)
WGS84=ReferenceEllipsoid("WGS 84",6378137.0,298.257223563)

@dataclass(frozen=True)
class CoordinateFrame:
    frame_id:str
    name:str
    kind:FrameKind
    parent_frame_id:str|None
    object_id:str|None
    provenance:str
    origin:DataOrigin
    revision:int=1
    def __post_init__(self):
        try:uuid.UUID(self.frame_id)
        except Exception as exc:raise ValueError("frame_id must be a UUID") from exc
        if not self.name.strip() or not self.provenance.strip():raise ValueError("frame name/provenance required")
        if self.parent_frame_id==self.frame_id:raise ValueError("frame cannot parent itself")

@dataclass(frozen=True)
class Epoch:
    value:float
    scale:TimeScale
    clock_id:str
    synchronization:SyncQuality
    standard_uncertainty_s:float
    provenance:str
    origin:DataOrigin
    def __post_init__(self):
        if not math.isfinite(float(self.value)):raise ValueError("epoch value must be finite")
        if not self.clock_id.strip() or not self.provenance.strip():raise ValueError("clock identity/provenance required")
        if not math.isfinite(float(self.standard_uncertainty_s)) or self.standard_uncertainty_s<0:raise ValueError("time uncertainty must be finite and nonnegative")

@dataclass(frozen=True)
class Position3D:
    values_m:tuple[float,float,float]
    frame_id:str
    epoch:Epoch
    covariance_m2:tuple[tuple[float,float,float],tuple[float,float,float],tuple[float,float,float]]
    provenance:str
    origin:DataOrigin
    def __post_init__(self):
        if len(self.values_m)!=3 or not all(math.isfinite(float(x)) for x in self.values_m):raise ValueError("position must contain three finite values")
        try:uuid.UUID(self.frame_id)
        except Exception as exc:raise ValueError("position frame_id must be a UUID") from exc
        VectorEstimate(tuple(float(x) for x in self.values_m),"m",self.covariance_m2,self.provenance)

@dataclass(frozen=True)
class StateVector:
    position:Position3D
    velocity_m_s:tuple[float,float,float]
    velocity_covariance:tuple[tuple[float,float,float],tuple[float,float,float],tuple[float,float,float]]
    def __post_init__(self):
        if len(self.velocity_m_s)!=3 or not all(math.isfinite(float(x)) for x in self.velocity_m_s):raise ValueError("velocity must contain three finite values")
        VectorEstimate(tuple(float(x) for x in self.velocity_m_s),"m/s",self.velocity_covariance,self.position.provenance)

@dataclass(frozen=True)
class TimeReading:
    epoch:Epoch
    elapsed_s:float|None=None
    proper_time_s:float|None=None
    coordinate_time_s:float|None=None
    def __post_init__(self):
        for x in (self.elapsed_s,self.proper_time_s,self.coordinate_time_s):
            if x is not None and not math.isfinite(float(x)):raise ValueError("time channels must be finite")

class TimeEpochService:
    """Typed clock/epoch construction. It does not silently convert relativistic time scales."""
    def host_utc(self,clock_id="host.system-clock"):
        return Epoch(time.time(),TimeScale.UTC,clock_id,SyncQuality.UNKNOWN,0.0,
                     "Host wall clock; synchronization uncertainty not independently measured",DataOrigin.HOST)
    def experiment_elapsed(self,seconds,clock_id,uncertainty_s=0.0,provenance="experiment clock"):
        return Epoch(float(seconds),TimeScale.EXPERIMENT_ELAPSED,str(clock_id),SyncQuality.UNKNOWN,
                     float(uncertainty_s),str(provenance),DataOrigin.SOFTWARE)
    def simulation(self,seconds,clock_id="simulation.clock",uncertainty_s=0.0,provenance="simulation timeline"):
        return Epoch(float(seconds),TimeScale.SIMULATION,str(clock_id),SyncQuality.SYNCHRONIZED,
                     float(uncertainty_s),str(provenance),DataOrigin.SIMULATION)
    def require_same_scale(self,a:Epoch,b:Epoch):
        if a.scale!=b.scale:raise ValueError(f"Time-scale mismatch: {a.scale.value} vs {b.scale.value}")
        return True

class CoordinateFrameRegistry:
    def __init__(self,scientific_registry):
        self.objects=scientific_registry;self._frames={}
    def create(self,*,name,kind,provenance,origin=DataOrigin.SOFTWARE,parent_frame_id=None):
        rec=self.objects.create(name=name,object_type="COORDINATE_FRAME",provenance=provenance,origin=origin,
                                description=f"Navigation frame kind={FrameKind(kind).value}")
        f=CoordinateFrame(rec.object_id,name,FrameKind(kind),parent_frame_id,rec.object_id,provenance,DataOrigin(origin),rec.config_revision)
        self._frames[f.frame_id]=f;return f
    def get(self,frame_id):
        try:return self._frames[str(frame_id)]
        except KeyError:raise KeyError(f"Unknown coordinate frame: {frame_id}")
    def list(self):return tuple(self._frames.values())
    def require_comparable(self,a:Position3D,b:Position3D):
        if a.frame_id!=b.frame_id:raise ValueError("Coordinate-frame mismatch; transform required before comparison")
        if a.epoch.scale!=b.epoch.scale:raise ValueError("Epoch time-scale mismatch; explicit time transformation required")
        return True

@dataclass(frozen=True)
class NavigationGuardianContract:
    schema:str
    frame_count:int
    time_scales:tuple[str,...]
    requirements:tuple[str,...]
    authority:str

def navigation_guardian_contract(frames:CoordinateFrameRegistry):
    return NavigationGuardianContract("JOE-GUARDIAN-NAVIGATION/1",len(frames.list()),
        tuple(x.value for x in TimeScale),
        ("FRAME_REQUIRED","EPOCH_REQUIRED","TIME_SCALE_REQUIRED","CLOCK_ID_REQUIRED","UNCERTAINTY_REQUIRED","PROVENANCE_REQUIRED","ORIGIN_REQUIRED"),
        "READ_ONLY_ADVISORY; cannot silently transform frames, epochs, or time scales")


class AltitudeReference(str,Enum):
    ELLIPSOID="ELLIPSOID"
    MEAN_SEA_LEVEL="MEAN_SEA_LEVEL"

@dataclass(frozen=True)
class GeodeticPosition:
    latitude_deg:float
    longitude_deg:float
    altitude_m:float
    ellipsoid:ReferenceEllipsoid
    altitude_reference:AltitudeReference
    epoch:Epoch
    covariance:tuple[tuple[float,float,float],tuple[float,float,float],tuple[float,float,float]]
    provenance:str
    origin:DataOrigin
    def __post_init__(self):
        if not all(math.isfinite(float(x)) for x in (self.latitude_deg,self.longitude_deg,self.altitude_m)):
            raise ValueError("geodetic coordinates must be finite")
        if self.latitude_deg < -90 or self.latitude_deg > 90:raise ValueError("latitude must be in [-90,90] degrees")
        if self.longitude_deg < -180 or self.longitude_deg > 180:raise ValueError("longitude must be in [-180,180] degrees")
        a=np.asarray(self.covariance,dtype=float)
        if a.shape!=(3,3) or not np.all(np.isfinite(a)) or not np.allclose(a,a.T,atol=1e-12,rtol=0):
            raise ValueError("geodetic covariance must be finite symmetric 3x3")
        if np.min(np.linalg.eigvalsh(a)) < -1e-12:raise ValueError("geodetic covariance must be positive semidefinite")

def geodetic_to_ecef(latitude_deg:float,longitude_deg:float,altitude_m:float,ellipsoid:ReferenceEllipsoid=WGS84):
    lat=math.radians(float(latitude_deg));lon=math.radians(float(longitude_deg));h=float(altitude_m)
    if not (-math.pi/2<=lat<=math.pi/2) or not all(math.isfinite(x) for x in (lat,lon,h)):raise ValueError("invalid geodetic coordinate")
    a=ellipsoid.semi_major_axis_m;f=ellipsoid.flattening;e2=f*(2-f)
    n=a/math.sqrt(1-e2*math.sin(lat)**2)
    x=(n+h)*math.cos(lat)*math.cos(lon);y=(n+h)*math.cos(lat)*math.sin(lon)
    z=(n*(1-e2)+h)*math.sin(lat)
    return (x,y,z)

def ecef_to_geodetic(x_m:float,y_m:float,z_m:float,ellipsoid:ReferenceEllipsoid=WGS84):
    x,y,z=map(float,(x_m,y_m,z_m))
    if not all(math.isfinite(v) for v in (x,y,z)):raise ValueError("ECEF coordinates must be finite")
    a=ellipsoid.semi_major_axis_m;f=ellipsoid.flattening;e2=f*(2-f);b=ellipsoid.semi_minor_axis_m
    p=math.hypot(x,y)
    if p<1e-12:
        if abs(z)<1e-12:raise ValueError("ECEF origin has undefined geodetic coordinates")
        return (90.0 if z>0 else -90.0,0.0,abs(z)-b)
    lon=math.atan2(y,x);lat=math.atan2(z,p*(1-e2))
    for _ in range(12):
        n=a/math.sqrt(1-e2*math.sin(lat)**2)
        h=p/math.cos(lat)-n
        new=math.atan2(z,p*(1-e2*n/(n+h)))
        if abs(new-lat)<1e-14:lat=new;break
        lat=new
    n=a/math.sqrt(1-e2*math.sin(lat)**2);h=p/math.cos(lat)-n
    return (math.degrees(lat),math.degrees(lon),h)

def ecef_to_enu_matrix(latitude_deg:float,longitude_deg:float):
    lat=math.radians(float(latitude_deg));lon=math.radians(float(longitude_deg))
    sl,cl=math.sin(lat),math.cos(lat);so,co=math.sin(lon),math.cos(lon)
    return ((-so,co,0.0),(-sl*co,-sl*so,cl),(cl*co,cl*so,sl))

def ecef_delta_to_enu(delta_ecef,latitude_deg,longitude_deg):
    d=np.asarray(delta_ecef,dtype=float)
    if d.shape!=(3,) or not np.all(np.isfinite(d)):raise ValueError("ECEF delta must be finite 3-vector")
    return tuple(float(x) for x in np.asarray(ecef_to_enu_matrix(latitude_deg,longitude_deg))@d)

def enu_to_ecef_delta(enu,latitude_deg,longitude_deg):
    v=np.asarray(enu,dtype=float)
    if v.shape!=(3,) or not np.all(np.isfinite(v)):raise ValueError("ENU must be finite 3-vector")
    r=np.asarray(ecef_to_enu_matrix(latitude_deg,longitude_deg))
    return tuple(float(x) for x in r.T@v)

def enu_to_ned(enu):
    e,n,u=map(float,enu);return (n,e,-u)
def ned_to_enu(ned):
    n,e,d=map(float,ned);return (e,n,-d)

@dataclass(frozen=True)
class GeoidCorrection:
    undulation_m:float
    model_name:str
    provenance:str
    def __post_init__(self):
        if not math.isfinite(float(self.undulation_m)) or not self.model_name.strip() or not self.provenance.strip():
            raise ValueError("valid geoid correction and provenance required")

def ellipsoid_height_to_msl(ellipsoid_height_m:float,correction:GeoidCorrection):
    return float(ellipsoid_height_m)-correction.undulation_m
def msl_height_to_ellipsoid(msl_height_m:float,correction:GeoidCorrection):
    return float(msl_height_m)+correction.undulation_m

@dataclass(frozen=True)
class GeodesyValidation:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]

def validate_wgs84_geodesy():
    checks=[];fail=[]
    refs=[(0,0,0),(0,90,0),(90,0,0),(37.5,-122.2,123.4),(-33.9,151.2,25.0)]
    for lat,lon,h in refs:
        xyz=geodetic_to_ecef(lat,lon,h);back=ecef_to_geodetic(*xyz)
        lonerr=abs(((back[1]-lon+180)%360)-180)
        if abs(back[0]-lat)<1e-9 and lonerr<1e-9 and abs(back[2]-h)<1e-5:checks.append(f"round-trip {lat},{lon},{h}")
        else:fail.append(f"round-trip failed {lat},{lon},{h}: {back}")
    r=np.asarray(ecef_to_enu_matrix(23.0,-41.0))
    if np.allclose(r@r.T,np.eye(3),atol=1e-12):checks.append("ENU rotation orthonormal")
    else:fail.append("ENU rotation not orthonormal")
    return GeodesyValidation(not fail,tuple(checks),tuple(fail))


@dataclass(frozen=True)
class SphericalCoordinate:
    radius_m:float
    azimuth_rad:float
    elevation_rad:float
    def __post_init__(self):
        if not all(math.isfinite(float(x)) for x in (self.radius_m,self.azimuth_rad,self.elevation_rad)):raise ValueError("spherical coordinates must be finite")
        if self.radius_m<0:raise ValueError("radius must be nonnegative")
        if not -math.pi/2<=self.elevation_rad<=math.pi/2:raise ValueError("elevation must be in [-pi/2,pi/2]")

def cartesian_to_spherical(xyz):
    x,y,z=map(float,xyz);r=math.sqrt(x*x+y*y+z*z)
    if r==0:return SphericalCoordinate(0.0,0.0,0.0)
    return SphericalCoordinate(r,math.atan2(y,x),math.asin(z/r))
def spherical_to_cartesian(s:SphericalCoordinate):
    ce=math.cos(s.elevation_rad)
    return (s.radius_m*ce*math.cos(s.azimuth_rad),s.radius_m*ce*math.sin(s.azimuth_rad),s.radius_m*math.sin(s.elevation_rad))

@dataclass(frozen=True)
class Quaternion:
    w:float;x:float;y:float;z:float
    def __post_init__(self):
        if not all(math.isfinite(float(v)) for v in (self.w,self.x,self.y,self.z)):raise ValueError("quaternion must be finite")
        if self.norm()==0:raise ValueError("zero quaternion is invalid")
    def norm(self):return math.sqrt(self.w*self.w+self.x*self.x+self.y*self.y+self.z*self.z)
    def normalized(self):
        n=self.norm();return Quaternion(self.w/n,self.x/n,self.y/n,self.z/n)
    def conjugate(self):return Quaternion(self.w,-self.x,-self.y,-self.z)
    def __mul__(self,o):
        a,b,c,d=self.w,self.x,self.y,self.z;e,f,g,h=o.w,o.x,o.y,o.z
        return Quaternion(a*e-b*f-c*g-d*h,a*f+b*e+c*h-d*g,a*g-b*h+c*e+d*f,a*h+b*g-c*f+d*e)
    @staticmethod
    def from_axis_angle(axis,angle_rad):
        a=np.asarray(axis,dtype=float)
        if a.shape!=(3,) or not np.all(np.isfinite(a)) or np.linalg.norm(a)==0 or not math.isfinite(float(angle_rad)):raise ValueError("valid axis and finite angle required")
        a=a/np.linalg.norm(a);h=float(angle_rad)/2;s=math.sin(h)
        return Quaternion(math.cos(h),*(a*s)).normalized()
    def rotation_matrix(self):
        q=self.normalized();w,x,y,z=q.w,q.x,q.y,q.z
        return ((1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)),
                (2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)),
                (2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)))
    def rotate(self,vector):
        v=np.asarray(vector,dtype=float)
        if v.shape!=(3,) or not np.all(np.isfinite(v)):raise ValueError("vector must be finite 3-vector")
        return tuple(float(x) for x in np.asarray(self.rotation_matrix())@v)

@dataclass(frozen=True)
class RigidTransform:
    source_frame_id:str
    target_frame_id:str
    rotation:Quaternion
    translation_m:tuple[float,float,float]
    provenance:str
    def __post_init__(self):
        if self.source_frame_id==self.target_frame_id:raise ValueError("transform source and target must differ")
        for x in (self.source_frame_id,self.target_frame_id):
            try:uuid.UUID(x)
            except Exception as exc:raise ValueError("transform frame IDs must be UUIDs") from exc
        if len(self.translation_m)!=3 or not all(math.isfinite(float(x)) for x in self.translation_m):raise ValueError("translation must be finite 3-vector")
        if not self.provenance.strip():raise ValueError("transform provenance required")
    def apply_point(self,p):
        r=self.rotation.rotate(p);return tuple(r[i]+self.translation_m[i] for i in range(3))
    def apply_vector(self,v):return self.rotation.rotate(v)
    def rotate_covariance(self,cov):
        c=np.asarray(cov,dtype=float);r=np.asarray(self.rotation.rotation_matrix())
        if c.shape!=(3,3) or not np.all(np.isfinite(c)):raise ValueError("covariance must be finite 3x3")
        out=r@c@r.T;return tuple(tuple(float(x) for x in row) for row in out)
    def inverse(self):
        qi=self.rotation.normalized().conjugate();t=qi.rotate(tuple(-x for x in self.translation_m))
        return RigidTransform(self.target_frame_id,self.source_frame_id,qi,t,f"inverse of: {self.provenance}")

def compose_transforms(first:RigidTransform,second:RigidTransform):
    """Return second(first(point))."""
    if first.target_frame_id!=second.source_frame_id:raise ValueError("transform chain frame mismatch")
    q=second.rotation*first.rotation
    rt=second.rotation.rotate(first.translation_m)
    t=tuple(rt[i]+second.translation_m[i] for i in range(3))
    return RigidTransform(first.source_frame_id,second.target_frame_id,q.normalized(),t,
                          f"composed: [{first.provenance}] -> [{second.provenance}]")

class TransformGraph:
    def __init__(self):self._edges={}
    def add(self,t:RigidTransform):
        self._edges[(t.source_frame_id,t.target_frame_id)]=t
        self._edges[(t.target_frame_id,t.source_frame_id)]=t.inverse()
    def resolve(self,source_frame_id,target_frame_id):
        if source_frame_id==target_frame_id:raise ValueError("identity transform does not require graph resolution")
        direct=self._edges.get((source_frame_id,target_frame_id))
        if direct:return direct
        queue=[(source_frame_id,None)];seen={source_frame_id}
        while queue:
            node,chain=queue.pop(0)
            for (a,b),edge in tuple(self._edges.items()):
                if a!=node or b in seen:continue
                new=edge if chain is None else compose_transforms(chain,edge)
                if b==target_frame_id:return new
                seen.add(b);queue.append((b,new))
        raise KeyError("no transform chain connects requested frames")

def transform_position(position:Position3D,transform:RigidTransform):
    if position.frame_id!=transform.source_frame_id:raise ValueError("position/transform source-frame mismatch")
    return Position3D(transform.apply_point(position.values_m),transform.target_frame_id,position.epoch,
                      transform.rotate_covariance(position.covariance_m2),
                      f"{position.provenance}; transformed via {transform.provenance}",position.origin)

def transform_state_vector(state:StateVector,transform:RigidTransform):
    p=transform_position(state.position,transform)
    v=transform.apply_vector(state.velocity_m_s);c=transform.rotate_covariance(state.velocity_covariance)
    return StateVector(p,v,c)

@dataclass(frozen=True)
class TransformValidation:
    passed:bool;checks:tuple[str,...];failures:tuple[str,...]
def validate_transform_engine():
    checks=[];fail=[]
    a,b,c=(str(uuid.uuid4()) for _ in range(3))
    q=Quaternion.from_axis_angle((0,0,1),math.pi/2)
    t1=RigidTransform(a,b,q,(10,0,0),"qualification t1")
    t2=RigidTransform(b,c,Quaternion(1,0,0,0),(0,5,0),"qualification t2")
    p=(2,3,4);back=t1.inverse().apply_point(t1.apply_point(p))
    if np.allclose(back,p,atol=1e-12):checks.append("rigid transform inverse round-trip")
    else:fail.append("rigid transform inverse failed")
    comp=compose_transforms(t1,t2)
    if np.allclose(comp.apply_point(p),t2.apply_point(t1.apply_point(p)),atol=1e-12):checks.append("transform composition")
    else:fail.append("transform composition failed")
    r=np.asarray(q.rotation_matrix())
    if np.allclose(r@r.T,np.eye(3),atol=1e-12) and abs(np.linalg.det(r)-1)<1e-12:checks.append("quaternion rotation orthonormal/right-handed")
    else:fail.append("quaternion rotation invalid")
    cov=((4,1,0),(1,9,0),(0,0,16));out=np.asarray(t1.rotate_covariance(cov))
    if abs(np.trace(out)-np.trace(cov))<1e-10 and np.min(np.linalg.eigvalsh(out))>=-1e-12:checks.append("covariance rotation preserves trace/PSD")
    else:fail.append("covariance rotation failed")
    return TransformValidation(not fail,tuple(checks),tuple(fail))


@dataclass(frozen=True)
class NavigationReleaseReadiness:
    passed:bool;checks:tuple[str,...];failures:tuple[str,...];notes:tuple[str,...]

def navigation_release_readiness():
    import tempfile
    from pathlib import Path
    from .scientific_registry import ScientificObjectRegistry
    checks=[];fail=[];notes=[]
    try:
        g=validate_wgs84_geodesy()
        if g.passed:checks.append("WGS-84 geodetic/ECEF and ENU qualification passed")
        else:fail.extend(g.failures)
        t=validate_transform_engine()
        if t.passed:checks.append("3D quaternion/rigid-transform/covariance qualification passed")
        else:fail.extend(t.failures)
        objects=ScientificObjectRegistry(Path(tempfile.mkdtemp(prefix="joe-nav-ready-")))
        frames=CoordinateFrameRegistry(objects)
        a=frames.create(name="Qualification A",kind="GENERIC_CARTESIAN",provenance="navigation release qualification",origin=DataOrigin.SIMULATION)
        b=frames.create(name="Qualification B",kind="GENERIC_CARTESIAN",provenance="navigation release qualification",origin=DataOrigin.SIMULATION)
        epoch=TimeEpochService().simulation(0.0)
        cov=((1.,0.,0.),(0.,1.,0.),(0.,0.,1.))
        pa=Position3D((0.,0.,0.),a.frame_id,epoch,cov,"qualification",DataOrigin.SIMULATION)
        pb=Position3D((0.,0.,0.),b.frame_id,epoch,cov,"qualification",DataOrigin.SIMULATION)
        try:frames.require_comparable(pa,pb);fail.append("frame mismatch was not rejected")
        except ValueError:checks.append("frame mismatch rejection passed")
        try:TimeEpochService().require_same_scale(epoch,TimeEpochService().experiment_elapsed(0,"qualification.clock"));fail.append("time-scale mismatch was not rejected")
        except ValueError:checks.append("time-scale mismatch rejection passed")
        c=navigation_guardian_contract(frames)
        if c.schema=="JOE-GUARDIAN-NAVIGATION/1" and "silently" in c.authority:checks.append("Guardian navigation authority contract passed")
        else:fail.append("Guardian navigation contract failed")
        if all(x.object_type.value=="COORDINATE_FRAME" for x in objects.list()):checks.append("frame identities originate in Scientific Object Registry")
        else:fail.append("coordinate frame identity registry integration failed")
    except Exception as exc:fail.append(f"release-readiness exception: {type(exc).__name__}: {exc}")
    notes.append("Navigation v1.0 does not invent transforms when a frame chain is unavailable.")
    notes.append("Map/workbench calculations are SOFTWARE or SIMULATION products, not physical telemetry.")
    return NavigationReleaseReadiness(not fail,tuple(checks),tuple(fail),tuple(notes))
