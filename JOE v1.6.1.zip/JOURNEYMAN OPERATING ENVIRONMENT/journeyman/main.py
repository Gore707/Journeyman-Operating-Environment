import logging
import sys
import traceback
from PySide6.QtCore import QLockFile
from PySide6.QtWidgets import QApplication, QMessageBox
from journeyman.core.paths import LOCK_FILE, ensure_directories
from journeyman.core.logging_service import configure_logging
from journeyman.ui.main_window import MainWindow
from journeyman.core.startup_checks import run_startup_checks, all_critical_ok


def main() -> int:
    ensure_directories()
    logger = configure_logging()
    logger.info("JOE startup requested")
    try:
        from journeyman.core.telemetry import HostTelemetry
        from journeyman.core.paths import ROOT
        from journeyman.core.resource_governor import derive_local_envelope
        from journeyman.core.operational_autoconfig import configure_startup
        sample=HostTelemetry(ROOT).sample(); env=derive_local_envelope(sample); cfg=configure_startup(sample,env)
        logger.info("JOE auto-config: %s | profile=%s | workers=%s | hardware_changed=%s",cfg.operating_environment,cfg.local_profile,cfg.maximum_workers,cfg.hardware_changed)
    except Exception as exc:
        logger.warning("JOE operational auto-configuration unavailable; conservative startup continues: %s",exc)
    checks = run_startup_checks()
    for item in checks:
        logger.info("Startup check %s: %s — %s", "PASS" if item.ok else "FAIL", item.name, item.detail)
    if not all_critical_ok(checks):
        logger.error("JOE startup diagnostics reported a critical failure")
    app = QApplication(sys.argv)
    app.setApplicationName("Journeyman Operating Environment")
    app.setOrganizationName("Sierra Kilo Labs")

    lock = QLockFile(str(LOCK_FILE))
    lock.setStaleLockTime(0)
    if not lock.tryLock(100):
        QMessageBox.warning(None, "JOE Already Running", "This Journeyman project already has an active JOE instance.")
        logger.warning("Second JOE instance blocked")
        return 2

    def excepthook(exc_type, exc_value, exc_tb):
        text = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        logging.getLogger("journeyman.crash").critical("Unhandled exception\n%s", text)
        QMessageBox.critical(None, "JOE Error", "An unexpected error occurred and was written to logs/joe.log.\n\n" + str(exc_value))

    sys.excepthook = excepthook
    window = MainWindow()
    window.show()
    rc = app.exec()
    lock.unlock()
    logger.info("JOE stopped with code %s", rc)
    return rc

if __name__ == "__main__":
    raise SystemExit(main())
