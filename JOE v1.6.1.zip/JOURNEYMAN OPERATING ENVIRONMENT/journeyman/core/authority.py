from __future__ import annotations
from dataclasses import dataclass
from enum import IntEnum, Enum
from datetime import datetime, timezone
from uuid import uuid4

class AuthorityLevel(IntEnum):
    RESEARCH_ASSISTANCE=10
    GUARDIAN=20
    DETERMINISTIC_CONTROL=30
    BUS_SAFE=40

class Decision(str,Enum):
    ALLOW="ALLOW"
    DENY="DENY"

@dataclass(frozen=True)
class AuthorityIdentity:
    actor_id:str
    level:AuthorityLevel
    description:str

@dataclass(frozen=True)
class AuthorityDecision:
    decision_id:str
    decision:Decision
    actor_id:str
    actor_level:AuthorityLevel
    required_level:AuthorityLevel
    action:str
    target:str
    reason:str
    timestamp:str

class AuthorityService:
    """Deterministic software authority contract. It does not implement BUS-SAFE hardware."""
    def __init__(self):
        self._actors={}
        self._decisions=[]
        self.register("joe.operator",AuthorityLevel.RESEARCH_ASSISTANCE,"JOE operator/research assistance")
        self.register("joe.guardian",AuthorityLevel.GUARDIAN,"Guardian supervisory advisory authority")
        self.register("joe.deterministic-control",AuthorityLevel.DETERMINISTIC_CONTROL,"Deterministic real-time control/interlock boundary")
        self.register("joe.bus-safe",AuthorityLevel.BUS_SAFE,"BUS-SAFE final authority boundary")

    def register(self,actor_id,level,description):
        actor_id=str(actor_id).strip()
        if not actor_id: raise ValueError("actor_id is required")
        level=AuthorityLevel(level)
        if actor_id in self._actors: raise ValueError("actor already registered")
        identity=AuthorityIdentity(actor_id,level,str(description).strip())
        self._actors[actor_id]=identity
        return identity

    def actors(self): return tuple(sorted(self._actors.values(),key=lambda x:(-int(x.level),x.actor_id)))

    def identity(self,actor_id):
        try:return self._actors[actor_id]
        except KeyError:raise KeyError(f"unregistered authority actor: {actor_id}")

    def authorize(self,actor_id,*,required_level,action,target,reason=""):
        actor=self.identity(actor_id);required=AuthorityLevel(required_level)
        action=str(action).strip();target=str(target).strip()
        if not action or not target: raise ValueError("action and target are required")
        allowed=actor.level>=required
        d=AuthorityDecision(str(uuid4()),Decision.ALLOW if allowed else Decision.DENY,
            actor.actor_id,actor.level,required,action,target,
            str(reason).strip() or ("authority sufficient" if allowed else "authority below required boundary"),
            datetime.now(timezone.utc).isoformat())
        self._decisions.append(d);return d

    def decisions(self):return tuple(self._decisions)

    def guardian_recommendation(self,action,target,reason):
        """Guardian may recommend, but this method grants no control execution."""
        return self.authorize("joe.guardian",required_level=AuthorityLevel.GUARDIAN,
                              action=action,target=target,reason=reason)

    def require_control(self,actor_id,action,target,reason=""):
        return self.authorize(actor_id,required_level=AuthorityLevel.DETERMINISTIC_CONTROL,
                              action=action,target=target,reason=reason)

    def require_bus_safe(self,actor_id,action,target,reason=""):
        return self.authorize(actor_id,required_level=AuthorityLevel.BUS_SAFE,
                              action=action,target=target,reason=reason)

    def recommend_hold(self,actor_id,target,reason):
        """Supervisory HOLD recommendation. Recommendation is not deterministic execution."""
        actor=self.identity(actor_id)
        required=AuthorityLevel.GUARDIAN if actor.level>=AuthorityLevel.GUARDIAN else AuthorityLevel.RESEARCH_ASSISTANCE
        return self.authorize(actor_id,required_level=required,action="RECOMMEND_HOLD",target=target,reason=reason)

    def execute_hold(self,actor_id,target,reason):
        """HOLD execution requires deterministic-control authority or higher."""
        return self.authorize(actor_id,required_level=AuthorityLevel.DETERMINISTIC_CONTROL,
                              action="HOLD",target=target,reason=reason)

    def recommend_abort(self,actor_id,target,reason):
        """Supervisory ABORT recommendation. Recommendation is not BUS-SAFE execution."""
        actor=self.identity(actor_id)
        required=AuthorityLevel.GUARDIAN if actor.level>=AuthorityLevel.GUARDIAN else AuthorityLevel.RESEARCH_ASSISTANCE
        return self.authorize(actor_id,required_level=required,action="RECOMMEND_ABORT",target=target,reason=reason)

    def execute_abort(self,actor_id,target,reason):
        """Final ABORT execution is reserved to the BUS-SAFE authority boundary."""
        return self.authorize(actor_id,required_level=AuthorityLevel.BUS_SAFE,
                              action="ABORT",target=target,reason=reason)

@dataclass(frozen=True)
class AuthorityQualification:
    passed:bool
    failures:tuple[str,...]

def qualify_authority(service):
    failures=[]
    try:
        levels={x.actor_id:x.level for x in service.actors()}
        expected={"joe.operator":AuthorityLevel.RESEARCH_ASSISTANCE,"joe.guardian":AuthorityLevel.GUARDIAN,
                  "joe.deterministic-control":AuthorityLevel.DETERMINISTIC_CONTROL,"joe.bus-safe":AuthorityLevel.BUS_SAFE}
        if levels!=expected: failures.append("canonical authority hierarchy mismatch")
        if service.require_control("joe.guardian","test","qualification").decision is not Decision.DENY:
            failures.append("Guardian improperly crossed deterministic-control boundary")
        if service.require_bus_safe("joe.deterministic-control","test","qualification").decision is not Decision.DENY:
            failures.append("deterministic control improperly crossed BUS-SAFE boundary")
        if service.require_bus_safe("joe.bus-safe","test","qualification").decision is not Decision.ALLOW:
            failures.append("BUS-SAFE could not satisfy its own boundary")
        if service.execute_hold("joe.guardian","qualification","test").decision is not Decision.DENY:
            failures.append("Guardian improperly executed HOLD")
        if service.execute_hold("joe.deterministic-control","qualification","test").decision is not Decision.ALLOW:
            failures.append("deterministic control could not execute HOLD")
        if service.execute_abort("joe.deterministic-control","qualification","test").decision is not Decision.DENY:
            failures.append("deterministic control improperly executed BUS-SAFE ABORT")
        if service.execute_abort("joe.bus-safe","qualification","test").decision is not Decision.ALLOW:
            failures.append("BUS-SAFE could not execute ABORT")
    except Exception as exc:failures.append(f"authority qualification failed: {exc}")
    return AuthorityQualification(not failures,tuple(failures))


@dataclass(frozen=True)
class AuthorityReleaseReadiness:
    passed:bool
    hierarchy_passed:bool
    guardian_boundary_passed:bool
    hold_boundary_passed:bool
    abort_boundary_passed:bool
    failures:tuple[str,...]

def joe015_release_readiness():
    service=AuthorityService();failures=[]
    q=qualify_authority(service)
    hierarchy=q.passed
    if not q.passed:failures.extend(q.failures)
    guardian=(service.guardian_recommendation("ASSESS_RISK","experiment","qualification").decision is Decision.ALLOW
              and service.execute_hold("joe.guardian","experiment","qualification").decision is Decision.DENY
              and service.execute_abort("joe.guardian","experiment","qualification").decision is Decision.DENY)
    hold=(service.execute_hold("joe.deterministic-control","experiment","qualification").decision is Decision.ALLOW)
    abort=(service.execute_abort("joe.deterministic-control","experiment","qualification").decision is Decision.DENY
           and service.execute_abort("joe.bus-safe","experiment","qualification").decision is Decision.ALLOW)
    if not guardian:failures.append("Guardian advisory/execution boundary failed")
    if not hold:failures.append("deterministic HOLD boundary failed")
    if not abort:failures.append("BUS-SAFE ABORT boundary failed")
    return AuthorityReleaseReadiness(not failures,hierarchy,guardian,hold,abort,tuple(failures))
