"""Authoritative Scientific Object Registry for JOE."""
from __future__ import annotations
from dataclasses import dataclass, asdict, replace
from enum import Enum
from pathlib import Path
from typing import Any
import hashlib,json,os,tempfile,time,uuid,re
from .state_events import DataOrigin

_NAME=re.compile(r"^.{1,160}$")
class ObjectType(str,Enum):
    MOUTH="MOUTH";CLOCK="CLOCK";SENSOR="SENSOR";SPACECRAFT="SPACECRAFT"
    TEST_ARTICLE="TEST_ARTICLE";COORDINATE_FRAME="COORDINATE_FRAME";FACILITY="FACILITY"
    SIMULATED_BODY="SIMULATED_BODY";HARDWARE_DEVICE="HARDWARE_DEVICE";GENERIC="GENERIC"

@dataclass(frozen=True)
class ScientificObject:
    object_id:str
    name:str
    object_type:ObjectType
    config_revision:int
    registry_revision:int
    provenance:str
    origin:DataOrigin
    description:str
    tags:tuple[str,...]
    created_at:float
    updated_at:float

@dataclass(frozen=True)
class RegistryRevision:
    registry_revision:int
    operation:str
    object_id:str
    object_revision:int
    timestamp:float
    record:ScientificObject

@dataclass(frozen=True)
class RegistryGuardianContract:
    schema:str
    registry_revision:int
    object_count:int
    objects:tuple[dict[str,Any],...]
    anomalies:tuple[str,...]
    authority:str

def _object_type(value):
    if isinstance(value,ObjectType):return value
    try:return ObjectType(str(value).upper())
    except ValueError as exc:raise ValueError(f"Unsupported scientific object type: {value}") from exc
def _origin(value):
    if isinstance(value,DataOrigin):return value
    try:return DataOrigin(str(value).upper())
    except ValueError as exc:raise ValueError(f"Unsupported data origin: {value}") from exc
def _clean_text(value,label,required=False):
    x=str(value).strip()
    if required and not x:raise ValueError(f"{label} is required")
    return x
def _record_dict(r):
    d=asdict(r);d["object_type"]=r.object_type.value;d["origin"]=r.origin.value;d["tags"]=list(r.tags);return d
def _from_dict(d):
    return ScientificObject(str(d["object_id"]),str(d["name"]),_object_type(d["object_type"]),
        int(d["config_revision"]),int(d["registry_revision"]),str(d["provenance"]),_origin(d["origin"]),
        str(d.get("description","")),tuple(str(x) for x in d.get("tags",[])),float(d["created_at"]),float(d["updated_at"]))

class ScientificObjectRegistry:
    SCHEMA="JOE-SCIENTIFIC-OBJECT-REGISTRY/1"
    def __init__(self,directory:Path,backbone=None):
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=True)
        self.path=self.directory/"objects.json";self._objects={};self._history=[];self._revision=0
        self._backbone=backbone;self._client=None
        if backbone is not None:self._integrate_backbone(backbone)
        self._load()
        self._publish_state()
    def _integrate_backbone(self,b):
        source="journeyman.registry";self._client=b.client(source)
        if b.state.definition("registry.revision") is None:b.state.register("registry.revision",source,value_type=int)
        if b.state.definition("registry.object-count") is None:b.state.register("registry.object-count",source,value_type=int)
        if b.events.topic_definition("registry.changed") is None:b.events.register_topic("registry.changed",(source,))
    @property
    def revision(self):return self._revision
    def list(self):return tuple(sorted(self._objects.values(),key=lambda x:(x.object_type.value,x.name.lower(),x.object_id)))
    def get(self,object_id):
        try:return self._objects[str(object_id)]
        except KeyError:raise KeyError(f"Unknown scientific object: {object_id}")
    def history(self,object_id=None):
        return tuple(x for x in self._history if object_id is None or x.object_id==object_id)
    def create(self,*,name,object_type,provenance,origin=DataOrigin.SOFTWARE,description="",tags=(),object_id=None):
        name=_clean_text(name,"name",True);prov=_clean_text(provenance,"provenance",True)
        oid=str(uuid.uuid4()) if object_id is None else str(object_id)
        try:uuid.UUID(oid)
        except Exception as exc:raise ValueError("object_id must be a UUID") from exc
        if oid in self._objects:raise ValueError(f"Duplicate scientific object identity: {oid}")
        now=time.time();self._revision+=1
        r=ScientificObject(oid,name,_object_type(object_type),1,self._revision,prov,_origin(origin),
                           _clean_text(description,"description"),tuple(sorted(set(str(x).strip() for x in tags if str(x).strip()))),now,now)
        self._objects[oid]=r;self._history.append(RegistryRevision(self._revision,"CREATE",oid,1,now,r))
        self._persist();self._publish_state("CREATE",r);return r
    def update(self,object_id,*,expected_config_revision,name=None,object_type=None,provenance=None,origin=None,description=None,tags=None):
        old=self.get(object_id)
        if int(expected_config_revision)!=old.config_revision:
            raise RuntimeError(f"Stale scientific object write: expected revision {expected_config_revision}, current {old.config_revision}")
        self._revision+=1;now=time.time()
        r=replace(old,name=old.name if name is None else _clean_text(name,"name",True),
            object_type=old.object_type if object_type is None else _object_type(object_type),
            provenance=old.provenance if provenance is None else _clean_text(provenance,"provenance",True),
            origin=old.origin if origin is None else _origin(origin),
            description=old.description if description is None else _clean_text(description,"description"),
            tags=old.tags if tags is None else tuple(sorted(set(str(x).strip() for x in tags if str(x).strip()))),
            config_revision=old.config_revision+1,registry_revision=self._revision,updated_at=now)
        self._objects[r.object_id]=r;self._history.append(RegistryRevision(self._revision,"UPDATE",r.object_id,r.config_revision,now,r))
        self._persist();self._publish_state("UPDATE",r);return r
    def _payload(self):
        return {"schema":self.SCHEMA,"registry_revision":self._revision,"objects":[_record_dict(x) for x in self.list()],
                "history":[{"registry_revision":h.registry_revision,"operation":h.operation,"object_id":h.object_id,
                            "object_revision":h.object_revision,"timestamp":h.timestamp,"record":_record_dict(h.record)} for h in self._history]}
    def _persist(self):
        body=self._payload();canonical=json.dumps(body,sort_keys=True,separators=(",",":")).encode()
        envelope={"sha256":hashlib.sha256(canonical).hexdigest(),"payload":body}
        fd,tmp=tempfile.mkstemp(prefix="registry-",suffix=".tmp",dir=self.directory)
        try:
            with os.fdopen(fd,"w",encoding="utf-8") as f:json.dump(envelope,f,sort_keys=True,indent=2);f.flush();os.fsync(f.fileno())
            os.replace(tmp,self.path)
        finally:
            if os.path.exists(tmp):os.unlink(tmp)
    def _load(self):
        if not self.path.exists():return
        e=json.loads(self.path.read_text(encoding="utf-8"));body=e["payload"]
        canonical=json.dumps(body,sort_keys=True,separators=(",",":")).encode()
        if hashlib.sha256(canonical).hexdigest()!=e.get("sha256"):raise RuntimeError("Scientific Object Registry integrity check failed")
        if body.get("schema")!=self.SCHEMA:raise RuntimeError("Unsupported Scientific Object Registry schema")
        self._revision=int(body["registry_revision"]);self._objects={x["object_id"]:_from_dict(x) for x in body["objects"]}
        self._history=[RegistryRevision(int(h["registry_revision"]),h["operation"],h["object_id"],int(h["object_revision"]),
                         float(h["timestamp"]),_from_dict(h["record"])) for h in body.get("history",[])]
    def _publish_state(self,operation=None,record=None):
        if not self._client:return
        self._client.set_state("registry.revision",self._revision,origin=DataOrigin.SOFTWARE)
        self._client.set_state("registry.object-count",len(self._objects),origin=DataOrigin.SOFTWARE)
        if operation:self._client.publish("registry.changed",{"operation":operation,"object_id":record.object_id,
            "config_revision":record.config_revision,"registry_revision":self._revision},origin=DataOrigin.SOFTWARE)
    def guardian_contract(self):
        anomalies=[]
        if len(self._objects)!=len(set(self._objects)):anomalies.append("duplicate-object-id")
        objs=tuple({"object_id":r.object_id,"name":r.name,"object_type":r.object_type.value,
                    "config_revision":r.config_revision,"origin":r.origin.value,"provenance":r.provenance} for r in self.list())
        return RegistryGuardianContract("JOE-GUARDIAN-REGISTRY/1",self._revision,len(objs),objs,tuple(anomalies),
                                        "READ_ONLY_ADVISORY; registry mutation remains outside Guardian authority")


@dataclass(frozen=True)
class RegistryReleaseReadiness:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    notes:tuple[str,...]

def scientific_registry_release_readiness():
    import tempfile
    checks=[];fail=[];notes=[]
    try:
        d=Path(tempfile.mkdtemp(prefix="joe-reg-ready-"))
        r=ScientificObjectRegistry(d)
        if r.list()==():checks.append("empty registry creates no fabricated scientific objects")
        else:fail.append("new registry was not empty")
        a=r.create(name="Qualification Clock",object_type="CLOCK",provenance="release qualification",origin="SIMULATION")
        b=r.update(a.object_id,expected_config_revision=1,description="revision qualification")
        if a.object_id==b.object_id and b.config_revision==2:checks.append("stable UUID and revision progression passed")
        else:fail.append("stable identity/revision progression failed")
        try:
            r.update(a.object_id,expected_config_revision=1,name="stale")
            fail.append("stale-write protection failed")
        except RuntimeError:checks.append("stale-write protection passed")
        q=ScientificObjectRegistry(d)
        if q.get(a.object_id).config_revision==2 and len(q.history(a.object_id))==2:checks.append("integrity persistence/history reload passed")
        else:fail.append("persistence/history reload failed")
        g=q.guardian_contract()
        if g.schema=="JOE-GUARDIAN-REGISTRY/1" and "READ_ONLY" in g.authority:checks.append("Guardian identity/provenance contract passed")
        else:fail.append("Guardian registry contract failed")
        from .units import DEFAULT_UNITS,UncertainValue,VectorEstimate,propagate_linear_covariance,units_guardian_contract
        if DEFAULT_UNITS.compatible("Pa","J/m^3") and abs(DEFAULT_UNITS.convert(1,"km","m")-1000)<1e-12:
            checks.append("shared units/dimensional conversion passed")
        else:fail.append("shared units/dimensional conversion failed")
        uv=UncertainValue(2,"km",.01).converted("m")
        ve=VectorEstimate((1,2),"m",((4,1),(1,9)))
        cp=propagate_linear_covariance(((2,0),(0,3)),ve.covariance)
        if abs(uv.standard_uncertainty-10)<1e-9 and abs(cp[0][0]-16)<1e-12 and units_guardian_contract().schema=="JOE-GUARDIAN-UNITS/1":
            checks.append("uncertainty/covariance and Guardian units contract passed")
        else:fail.append("uncertainty/covariance qualification failed")
    except Exception as exc:fail.append(f"release-readiness exception: {type(exc).__name__}: {exc}")
    notes.append("Object origin is provenance metadata and does not assert live telemetry availability.")
    notes.append("Registry v1.0 contains no default mouths, clocks, sensors, facilities, or hardware.")
    return RegistryReleaseReadiness(not fail,tuple(checks),tuple(fail),tuple(notes))
