from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable
from uuid import UUID, uuid4

from .paths import CONFIG_DIR

LAYOUT_FILE = CONFIG_DIR / "workspace_layout.json"
LAYOUTS_DIR = CONFIG_DIR / "workspace_layouts"
_ALLOWED_KINDS = {
    "overview", "log", "live_time_series", "analysis_plot",
    "numeric_instrument", "matrix_heatmap", "scientific_field",
}


@dataclass(frozen=True)
class WorkspaceLayoutEntry:
    kind: str
    title: str
    external: bool
    geometry_b64: str
    maximized: bool = False
    workspace_id: str = ""
    locked: bool = False
    minimized: bool = False
    state: dict | None = None

    def normalized_id(self) -> str:
        try:
            return str(UUID(self.workspace_id))
        except (ValueError, TypeError, AttributeError):
            return str(uuid4())


def save_layout(entries: Iterable[WorkspaceLayoutEntry], path: Path = LAYOUT_FILE) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for entry in entries:
        row = asdict(entry)
        row["workspace_id"] = entry.normalized_id()
        rows.append(row)
    payload = {"schema": 6, "workspaces": rows}
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    temp.replace(path)


def load_layout(path: Path = LAYOUT_FILE) -> list[WorkspaceLayoutEntry]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        schema = raw.get("schema")
        if schema not in {1, 2, 3, 4, 5, 6} or not isinstance(raw.get("workspaces"), list):
            return []
        result: list[WorkspaceLayoutEntry] = []
        seen_ids: set[str] = set()
        for item in raw["workspaces"]:
            if not isinstance(item, dict):
                continue
            kind = str(item.get("kind", "")).strip()
            if kind not in _ALLOWED_KINDS:
                continue
            workspace_id = str(item.get("workspace_id", "")) if schema >= 3 else ""
            entry = WorkspaceLayoutEntry(
                kind=kind,
                title=str(item.get("title", "JOE Workspace")),
                external=bool(item.get("external", False)),
                geometry_b64=str(item.get("geometry_b64", "")),
                maximized=bool(item.get("maximized", False)) if schema >= 2 else False,
                workspace_id=workspace_id,
                locked=bool(item.get("locked", False)) if schema >= 4 else False,
                minimized=bool(item.get("minimized", False)) if schema >= 5 else False,
                state=item.get("state") if schema >= 6 and isinstance(item.get("state"), dict) else None,
            )
            normalized_id = entry.normalized_id()
            while normalized_id in seen_ids:
                normalized_id = str(uuid4())
            seen_ids.add(normalized_id)
            result.append(WorkspaceLayoutEntry(
                kind=entry.kind, title=entry.title, external=entry.external,
                geometry_b64=entry.geometry_b64, maximized=entry.maximized,
                workspace_id=normalized_id, locked=entry.locked, minimized=entry.minimized,
                state=entry.state,
            ))
        return result
    except (FileNotFoundError, OSError, ValueError, TypeError, json.JSONDecodeError):
        return []


def clear_layout(path: Path = LAYOUT_FILE) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        pass


def _safe_layout_name(name: str) -> str:
    cleaned = " ".join(str(name).strip().split())
    if not cleaned or len(cleaned) > 80:
        raise ValueError("Layout name must contain 1-80 characters")
    if any(ch in cleaned for ch in '<>:"/\\|?*'):
        raise ValueError("Layout name contains characters Windows cannot use in a file name")
    return cleaned


def named_layout_path(name: str, directory: Path = LAYOUTS_DIR) -> Path:
    clean = _safe_layout_name(name)
    return directory / f"{clean}.json"


def save_named_layout(name: str, entries: Iterable[WorkspaceLayoutEntry], directory: Path = LAYOUTS_DIR) -> Path:
    path = named_layout_path(name, directory)
    save_layout(entries, path)
    return path


def list_named_layouts(directory: Path = LAYOUTS_DIR) -> list[str]:
    try:
        return sorted((p.stem for p in directory.glob("*.json") if p.is_file()), key=str.casefold)
    except OSError:
        return []


def load_named_layout(name: str, directory: Path = LAYOUTS_DIR) -> list[WorkspaceLayoutEntry]:
    return load_layout(named_layout_path(name, directory))


def delete_named_layout(name: str, directory: Path = LAYOUTS_DIR) -> bool:
    path = named_layout_path(name, directory)
    try:
        path.unlink()
        return True
    except FileNotFoundError:
        return False


def backup_layout(path: Path = LAYOUT_FILE) -> Path | None:
    """Create a byte-for-byte recovery copy of a layout before destructive replacement."""
    try:
        if not path.is_file():
            return None
        backup = path.with_suffix(path.suffix + ".bak")
        temp = backup.with_suffix(backup.suffix + ".tmp")
        temp.write_bytes(path.read_bytes())
        temp.replace(backup)
        return backup
    except OSError:
        return None


def restore_layout_backup(path: Path = LAYOUT_FILE) -> bool:
    """Restore the most recent recovery copy atomically."""
    backup = path.with_suffix(path.suffix + ".bak")
    try:
        if not backup.is_file():
            return False
        temp = path.with_suffix(path.suffix + ".restore.tmp")
        temp.write_bytes(backup.read_bytes())
        temp.replace(path)
        return True
    except OSError:
        return False


def entries_to_snapshot(entries: Iterable[WorkspaceLayoutEntry]) -> dict:
    rows=[]
    for entry in entries:
        row=asdict(entry); row["workspace_id"]=entry.normalized_id(); rows.append(row)
    return {"schema":6,"workspaces":rows}

def entries_from_snapshot(payload: dict) -> list[WorkspaceLayoutEntry]:
    """Validate an in-memory schema-6 snapshot using the same accepted workspace kinds."""
    if not isinstance(payload,dict) or payload.get("schema")!=6 or not isinstance(payload.get("workspaces"),list):
        raise ValueError("invalid workspace snapshot")
    result=[];seen=set()
    for item in payload["workspaces"]:
        if not isinstance(item,dict): raise ValueError("invalid workspace entry")
        kind=str(item.get("kind","")).strip()
        if kind not in _ALLOWED_KINDS: raise ValueError(f"unsupported workspace kind: {kind}")
        entry=WorkspaceLayoutEntry(kind,str(item.get("title","JOE Workspace")),bool(item.get("external",False)),
            str(item.get("geometry_b64","")),bool(item.get("maximized",False)),str(item.get("workspace_id","")),
            bool(item.get("locked",False)),bool(item.get("minimized",False)),
            item.get("state") if isinstance(item.get("state"),dict) else None)
        wid=entry.normalized_id()
        if wid in seen: raise ValueError("duplicate workspace identity in snapshot")
        seen.add(wid)
        result.append(WorkspaceLayoutEntry(entry.kind,entry.title,entry.external,entry.geometry_b64,entry.maximized,
                                           wid,entry.locked,entry.minimized,entry.state))
    return result
