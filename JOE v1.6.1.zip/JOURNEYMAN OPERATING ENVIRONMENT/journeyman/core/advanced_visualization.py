"""Advanced Analysis & Visualization — VIS-001A scientific data/specification core."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterable
import math
from uuid import uuid4

class VisualizationMode(str,Enum):
    LIVE="LIVE"
    POST_RUN="POST_RUN"

class PlotKind(str,Enum):
    TIME_SERIES="TIME_SERIES"
    SCATTER="SCATTER"
    BAR="BAR"
    HISTOGRAM="HISTOGRAM"
    HEATMAP="HEATMAP"
    MATRIX="MATRIX"
    CONTOUR="CONTOUR"
    SURFACE="SURFACE"
    FIELD="FIELD"
    NUMERIC="NUMERIC"
    TABLE="TABLE"

class DataQuality(str,Enum):
    GOOD="GOOD"
    DEGRADED="DEGRADED"
    STALE="STALE"
    UNAVAILABLE="UNAVAILABLE"
    INVALID="INVALID"

@dataclass(frozen=True)
class VisualizationPoint:
    x:float
    y:float
    standard_uncertainty:float|None=None
    timestamp_s:float|None=None
    quality:DataQuality=DataQuality.GOOD
    def __post_init__(self):
        for v in (self.x,self.y):
            if not math.isfinite(v):raise ValueError("visualization point requires finite x/y")
        if self.standard_uncertainty is not None and (not math.isfinite(self.standard_uncertainty) or self.standard_uncertainty<0):
            raise ValueError("uncertainty must be finite and nonnegative")
        if self.timestamp_s is not None and not math.isfinite(self.timestamp_s):raise ValueError("finite timestamp required")

@dataclass(frozen=True)
class ScientificSeries:
    series_id:str
    name:str
    variable:str
    x_unit:str
    y_unit:str
    points:tuple[VisualizationPoint,...]
    origin:str
    provenance:str
    source_module:str
    frame_id:str|None=None
    epoch_id:str|None=None
    run_id:str|None=None
    def __post_init__(self):
        if not all((self.series_id.strip(),self.name.strip(),self.variable.strip(),self.x_unit.strip(),self.y_unit.strip(),
                    self.origin.strip(),self.provenance.strip(),self.source_module.strip())):
            raise ValueError("complete scientific-series metadata required")
        if any(self.points[i].x>self.points[i+1].x for i in range(len(self.points)-1)):
            raise ValueError("series x coordinates must be nondecreasing")

@dataclass(frozen=True)
class AxisSpecification:
    label:str
    unit:str
    minimum:float|None=None
    maximum:float|None=None
    logarithmic:bool=False
    def __post_init__(self):
        if not self.label.strip() or not self.unit.strip():raise ValueError("axis label/unit required")
        if self.minimum is not None and not math.isfinite(self.minimum):raise ValueError("finite axis minimum required")
        if self.maximum is not None and not math.isfinite(self.maximum):raise ValueError("finite axis maximum required")
        if self.minimum is not None and self.maximum is not None and self.minimum>=self.maximum:raise ValueError("axis minimum must be below maximum")
        if self.logarithmic and self.minimum is not None and self.minimum<=0:raise ValueError("log axis minimum must be positive")

@dataclass(frozen=True)
class CursorState:
    x:float
    synchronized:bool=True
    def __post_init__(self):
        if not math.isfinite(self.x):raise ValueError("finite cursor position required")

@dataclass(frozen=True)
class RangeSelection:
    start_x:float
    end_x:float
    def __post_init__(self):
        if not math.isfinite(self.start_x) or not math.isfinite(self.end_x) or self.start_x>=self.end_x:
            raise ValueError("valid increasing range required")

@dataclass(frozen=True)
class PlotSpecification:
    plot_id:str
    title:str
    kind:PlotKind
    mode:VisualizationMode
    series_ids:tuple[str,...]
    x_axis:AxisSpecification
    y_axis:AxisSpecification
    cursor:CursorState|None=None
    selection:RangeSelection|None=None
    show_uncertainty:bool=True
    provenance:str="JOE visualization"
    def __post_init__(self):
        if not self.plot_id.strip() or not self.title.strip() or not self.provenance.strip():raise ValueError("plot identity/title/provenance required")
        if len(set(self.series_ids))!=len(self.series_ids):raise ValueError("duplicate series in plot specification")

@dataclass(frozen=True)
class VisualizationLayout:
    layout_id:str
    name:str
    plots:tuple[PlotSpecification,...]
    synchronized_cursor:bool
    synchronized_x_range:bool
    provenance:str
    def __post_init__(self):
        if not self.layout_id.strip() or not self.name.strip() or not self.provenance.strip():raise ValueError("layout identity/name/provenance required")
        ids=[p.plot_id for p in self.plots]
        if len(ids)!=len(set(ids)):raise ValueError("duplicate plot identity")

class ScientificVisualizationStore:
    def __init__(self):
        self._series={}
        self._layouts={}
    def register_series(self,series:ScientificSeries):
        if series.series_id in self._series:raise ValueError("series identity already registered")
        self._series[series.series_id]=series;return series
    def replace_series(self,series:ScientificSeries):
        if series.series_id not in self._series:raise KeyError(series.series_id)
        self._series[series.series_id]=series;return series
    def series(self,series_id):return self._series[series_id]
    def all_series(self):return tuple(self._series.values())
    def save_layout(self,layout:VisualizationLayout):
        self._layouts[layout.layout_id]=layout;return layout
    def layout(self,layout_id):return self._layouts[layout_id]

def append_live_point(series:ScientificSeries,point:VisualizationPoint)->ScientificSeries:
    if series.points and point.x<series.points[-1].x:raise ValueError("live point precedes existing series")
    return ScientificSeries(series.series_id,series.name,series.variable,series.x_unit,series.y_unit,
        series.points+(point,),series.origin,series.provenance,series.source_module,series.frame_id,series.epoch_id,series.run_id)

def compatible_overlay(series:Iterable[ScientificSeries])->tuple[bool,tuple[str,...]]:
    xs=tuple(series);fail=[]
    if not xs:return False,("no series supplied",)
    first=xs[0]
    for s in xs[1:]:
        if s.x_unit!=first.x_unit:fail.append(f"x-unit mismatch: {first.x_unit} vs {s.x_unit}")
        if s.y_unit!=first.y_unit:fail.append(f"y-unit mismatch: {first.y_unit} vs {s.y_unit}")
        if s.frame_id!=first.frame_id:fail.append(f"frame mismatch: {first.frame_id} vs {s.frame_id}")
        if s.epoch_id!=first.epoch_id:fail.append(f"epoch mismatch: {first.epoch_id} vs {s.epoch_id}")
    return not fail,tuple(fail)

def synchronized_cursor_values(series:Iterable[ScientificSeries],cursor_x:float)->dict[str,VisualizationPoint|None]:
    if not math.isfinite(cursor_x):raise ValueError("finite cursor required")
    out={}
    for s in series:
        if not s.points:out[s.series_id]=None;continue
        out[s.series_id]=min(s.points,key=lambda p:abs(p.x-cursor_x))
    return out

def select_range(series:ScientificSeries,selection:RangeSelection)->ScientificSeries:
    pts=tuple(p for p in series.points if selection.start_x<=p.x<=selection.end_x)
    return ScientificSeries(series.series_id,series.name,series.variable,series.x_unit,series.y_unit,pts,
        series.origin,series.provenance,series.source_module,series.frame_id,series.epoch_id,series.run_id)

@dataclass(frozen=True)
class VisualizationGuardianContract:
    schema:str
    status:str
    facts:dict[str,Any]
    provenance:str
    authority:str="READ_ONLY_ADVISORY"

def visualization_guardian_contract(store:ScientificVisualizationStore)->VisualizationGuardianContract:
    series=store.all_series()
    origins=tuple(sorted(set(s.origin for s in series)))
    unavailable=sum(sum(1 for p in s.points if p.quality==DataQuality.UNAVAILABLE) for s in series)
    return VisualizationGuardianContract("JOE-GUARDIAN-VISUALIZATION/1","PASS",
        {"series_count":len(series),"origins":origins,"unavailable_point_count":unavailable,
         "note":"Visualization does not create scientific measurements; it renders supplied data with provenance."},
        "Advanced Visualization VIS-001A")

def visualization_core_readiness():
    p=(VisualizationPoint(0,1,.1,0),VisualizationPoint(1,2,.1,1))
    a=ScientificSeries("a","A","x","s","m",p,"SIMULATION","readiness","test","f","e")
    b=ScientificSeries("b","B","x","s","m",p,"SIMULATION","readiness","test","f","e")
    ok,_=compatible_overlay((a,b))
    spec=PlotSpecification("p","Test",PlotKind.TIME_SERIES,VisualizationMode.POST_RUN,("a","b"),
        AxisSpecification("Time","s"),AxisSpecification("Value","m"),CursorState(.5),RangeSelection(0,1))
    layout=VisualizationLayout("l","Readiness",(spec,),True,True,"readiness")
    store=ScientificVisualizationStore();store.register_series(a);store.register_series(b);store.save_layout(layout)
    return {"passed":ok and len(synchronized_cursor_values((a,b),.5))==2 and visualization_guardian_contract(store).facts["series_count"]==2,
            "checks":("typed scientific series","uncertainty metadata","overlay compatibility","synchronized cursor","range selection","reproducible layout","Guardian contract")}


@dataclass(frozen=True)
class HistogramResult:
    bin_edges:tuple[float,...]
    counts:tuple[int,...]
    provenance:str

def histogram(series:ScientificSeries,*,bins:int=20,provenance:str)->HistogramResult:
    if bins<1:raise ValueError("bins must be positive")
    vals=[p.y for p in series.points if p.quality not in (DataQuality.INVALID,DataQuality.UNAVAILABLE)]
    if not vals:return HistogramResult((),(),provenance)
    lo=min(vals);hi=max(vals)
    if lo==hi:return HistogramResult((lo,hi),(len(vals),),provenance)
    width=(hi-lo)/bins
    edges=tuple(lo+i*width for i in range(bins+1));counts=[0]*bins
    for v in vals:
        idx=min(bins-1,int((v-lo)/width));counts[idx]+=1
    return HistogramResult(edges,tuple(counts),provenance)

@dataclass(frozen=True)
class MatrixDataset:
    dataset_id:str
    name:str
    values:tuple[tuple[float,...],...]
    x_unit:str
    y_unit:str
    value_unit:str
    origin:str
    provenance:str
    source_module:str
    def __post_init__(self):
        if not all((self.dataset_id.strip(),self.name.strip(),self.x_unit.strip(),self.y_unit.strip(),self.value_unit.strip(),
                    self.origin.strip(),self.provenance.strip(),self.source_module.strip())):raise ValueError("complete matrix metadata required")
        if not self.values:raise ValueError("matrix cannot be empty")
        width=len(self.values[0])
        if width<1 or any(len(r)!=width for r in self.values):raise ValueError("matrix must be rectangular")
        if any(not math.isfinite(v) for r in self.values for v in r):raise ValueError("matrix values must be finite")

@dataclass(frozen=True)
class StreamPolicy:
    maximum_points:int=10000
    def __post_init__(self):
        if self.maximum_points<2:raise ValueError("stream maximum must be at least two points")

def append_stream_point(series:ScientificSeries,point:VisualizationPoint,policy:StreamPolicy=StreamPolicy())->ScientificSeries:
    updated=append_live_point(series,point)
    pts=updated.points[-policy.maximum_points:]
    return ScientificSeries(updated.series_id,updated.name,updated.variable,updated.x_unit,updated.y_unit,pts,
        updated.origin,updated.provenance,updated.source_module,updated.frame_id,updated.epoch_id,updated.run_id)

def aligned_overlay_values(series:Iterable[ScientificSeries])->tuple[tuple[float,...],dict[str,tuple[float,...]]]:
    xs=tuple(series);ok,fail=compatible_overlay(xs)
    if not ok:raise ValueError("; ".join(fail))
    if not xs:return (),{}
    common=set(p.x for p in xs[0].points)
    for s in xs[1:]:common.intersection_update(p.x for p in s.points)
    axis=tuple(sorted(common));out={}
    for s in xs:
        lookup={p.x:p.y for p in s.points};out[s.series_id]=tuple(lookup[x] for x in axis)
    return axis,out

def visualization_rendering_readiness():
    pts=tuple(VisualizationPoint(float(i),float(i*i),.1) for i in range(5))
    s=ScientificSeries("s","Series","x","s","m",pts,"SIMULATION","readiness","test")
    h=histogram(s,bins=3,provenance="readiness")
    streamed=append_stream_point(s,VisualizationPoint(5,25,.1),StreamPolicy(3))
    m=MatrixDataset("m","Matrix",((1.,2.),(3.,4.)),"m","m","K","SIMULATION","readiness","test")
    axis,vals=aligned_overlay_values((s,))
    return {"passed":sum(h.counts)==5 and len(streamed.points)==3 and len(m.values)==2 and len(axis)==5 and len(vals["s"])==5,
            "checks":("histogram computation","bounded live stream","matrix validation","aligned overlay values")}


class LinkMode(str,Enum):
    NONE="NONE"
    X_RANGE="X_RANGE"
    CURSOR="CURSOR"
    X_RANGE_AND_CURSOR="X_RANGE_AND_CURSOR"

@dataclass(frozen=True)
class PlotLinkGroup:
    group_id:str
    plot_ids:tuple[str,...]
    mode:LinkMode
    def __post_init__(self):
        if not self.group_id.strip() or len(self.plot_ids)<2:raise ValueError("linked plot group requires identity and at least two plots")
        if len(set(self.plot_ids))!=len(self.plot_ids):raise ValueError("duplicate plot in link group")

@dataclass(frozen=True)
class MultiPlotWorkspaceSpecification:
    workspace_id:str
    name:str
    plots:tuple[PlotSpecification,...]
    link_groups:tuple[PlotLinkGroup,...]
    columns:int
    detachable:bool
    provenance:str
    def __post_init__(self):
        if not self.workspace_id.strip() or not self.name.strip() or not self.provenance.strip():raise ValueError("workspace identity/name/provenance required")
        if self.columns<1:raise ValueError("workspace columns must be positive")
        ids={p.plot_id for p in self.plots}
        if len(ids)!=len(self.plots):raise ValueError("duplicate plot identity")
        if any(pid not in ids for g in self.link_groups for pid in g.plot_ids):raise ValueError("link group references unknown plot")

@dataclass(frozen=True)
class UnitConversion:
    source_unit:str
    target_unit:str
    scale:float
    offset:float=0.0
    provenance:str="declared conversion"
    def __post_init__(self):
        if not self.source_unit.strip() or not self.target_unit.strip() or not self.provenance.strip():raise ValueError("conversion units/provenance required")
        if not math.isfinite(self.scale) or self.scale==0 or not math.isfinite(self.offset):raise ValueError("finite nonzero conversion required")

def convert_series_units(series:ScientificSeries,conversion:UnitConversion)->ScientificSeries:
    if series.y_unit!=conversion.source_unit:raise ValueError("conversion source unit does not match series")
    pts=tuple(VisualizationPoint(p.x,p.y*conversion.scale+conversion.offset,
        None if p.standard_uncertainty is None else abs(conversion.scale)*p.standard_uncertainty,
        p.timestamp_s,p.quality) for p in series.points)
    return ScientificSeries(series.series_id,series.name,series.variable,series.x_unit,conversion.target_unit,pts,
        series.origin,series.provenance+"; "+conversion.provenance,series.source_module,series.frame_id,series.epoch_id,series.run_id)

@dataclass(frozen=True)
class MatrixStatistics:
    rows:int
    columns:int
    minimum:float
    maximum:float
    mean:float

def matrix_statistics(dataset:MatrixDataset)->MatrixStatistics:
    vals=[v for row in dataset.values for v in row]
    return MatrixStatistics(len(dataset.values),len(dataset.values[0]),min(vals),max(vals),sum(vals)/len(vals))

@dataclass(frozen=True)
class VectorFieldDataset:
    dataset_id:str
    name:str
    x:tuple[float,...]
    y:tuple[float,...]
    u:tuple[float,...]
    v:tuple[float,...]
    coordinate_unit:str
    vector_unit:str
    origin:str
    provenance:str
    source_module:str
    def __post_init__(self):
        n=len(self.x)
        if not all((self.dataset_id.strip(),self.name.strip(),self.coordinate_unit.strip(),self.vector_unit.strip(),
                    self.origin.strip(),self.provenance.strip(),self.source_module.strip())):raise ValueError("complete vector-field metadata required")
        if n<1 or any(len(a)!=n for a in (self.y,self.u,self.v)):raise ValueError("vector-field arrays must have equal nonzero length")
        if any(not math.isfinite(z) for a in (self.x,self.y,self.u,self.v) for z in a):raise ValueError("vector field requires finite values")

@dataclass(frozen=True)
class SurfaceDataset:
    dataset_id:str
    name:str
    x:tuple[float,...]
    y:tuple[float,...]
    z:tuple[tuple[float,...],...]
    x_unit:str
    y_unit:str
    z_unit:str
    origin:str
    provenance:str
    source_module:str
    def __post_init__(self):
        if not self.x or not self.y or len(self.z)!=len(self.y) or any(len(r)!=len(self.x) for r in self.z):
            raise ValueError("surface dimensions must match x/y axes")
        if any(not math.isfinite(q) for q in self.x+self.y) or any(not math.isfinite(q) for r in self.z for q in r):
            raise ValueError("surface requires finite values")

def advanced_workspace_readiness():
    axis=AxisSpecification("t","s");value=AxisSpecification("x","m")
    p1=PlotSpecification("p1","One",PlotKind.TIME_SERIES,VisualizationMode.POST_RUN,(),axis,value)
    p2=PlotSpecification("p2","Two",PlotKind.SCATTER,VisualizationMode.POST_RUN,(),axis,value)
    g=PlotLinkGroup("g",("p1","p2"),LinkMode.X_RANGE_AND_CURSOR)
    ws=MultiPlotWorkspaceSpecification("w","W",(p1,p2),(g,),2,True,"readiness")
    m=MatrixDataset("m","M",((1.,2.),(3.,4.)),"m","m","K","SIMULATION","readiness","test")
    f=VectorFieldDataset("f","F",(0.,1.),(0.,1.),(1.,1.),(0.,1.),"m","m/s","SIMULATION","readiness","test")
    return {"passed":ws.detachable and matrix_statistics(m).mean==2.5 and len(f.x)==2,
            "checks":("linked multi-plot specification","declared unit conversion","matrix statistics","vector field validation","surface validation")}


import csv, json
from pathlib import Path as _Path

@dataclass(frozen=True)
class ExportResult:
    path:str
    format:str
    rows:int
    provenance:str

def export_series_csv(series:ScientificSeries,path:str|_Path)->ExportResult:
    target=_Path(path);target.parent.mkdir(parents=True,exist_ok=True)
    with target.open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f)
        w.writerow(["series_id","name","variable","x","x_unit","y","y_unit","standard_uncertainty",
                    "timestamp_s","quality","origin","source_module","frame_id","epoch_id","run_id","provenance"])
        for p in series.points:
            w.writerow([series.series_id,series.name,series.variable,repr(p.x),series.x_unit,repr(p.y),series.y_unit,
                        "" if p.standard_uncertainty is None else repr(p.standard_uncertainty),
                        "" if p.timestamp_s is None else repr(p.timestamp_s),p.quality.value,series.origin,
                        series.source_module,series.frame_id or "",series.epoch_id or "",series.run_id or "",series.provenance])
    return ExportResult(str(target),"CSV",len(series.points),series.provenance)

def _axis_dict(a:AxisSpecification)->dict[str,Any]:
    return {"label":a.label,"unit":a.unit,"minimum":a.minimum,"maximum":a.maximum,"logarithmic":a.logarithmic}

def plot_specification_dict(p:PlotSpecification)->dict[str,Any]:
    return {"plot_id":p.plot_id,"title":p.title,"kind":p.kind.value,"mode":p.mode.value,"series_ids":list(p.series_ids),
            "x_axis":_axis_dict(p.x_axis),"y_axis":_axis_dict(p.y_axis),
            "cursor":None if p.cursor is None else {"x":p.cursor.x,"synchronized":p.cursor.synchronized},
            "selection":None if p.selection is None else {"start_x":p.selection.start_x,"end_x":p.selection.end_x},
            "show_uncertainty":p.show_uncertainty,"provenance":p.provenance}

def export_workspace_specification(spec:MultiPlotWorkspaceSpecification,path:str|_Path)->ExportResult:
    target=_Path(path);target.parent.mkdir(parents=True,exist_ok=True)
    payload={"schema":"JOE-VIS-WORKSPACE/1","workspace_id":spec.workspace_id,"name":spec.name,
             "plots":[plot_specification_dict(p) for p in spec.plots],
             "link_groups":[{"group_id":g.group_id,"plot_ids":list(g.plot_ids),"mode":g.mode.value} for g in spec.link_groups],
             "columns":spec.columns,"detachable":spec.detachable,"provenance":spec.provenance}
    target.write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    return ExportResult(str(target),"JSON",len(spec.plots),spec.provenance)

def load_workspace_specification(path:str|_Path)->MultiPlotWorkspaceSpecification:
    q=json.loads(_Path(path).read_text(encoding="utf-8"))
    if q.get("schema")!="JOE-VIS-WORKSPACE/1":raise ValueError("unsupported visualization workspace schema")
    def axis(x):return AxisSpecification(x["label"],x["unit"],x.get("minimum"),x.get("maximum"),bool(x.get("logarithmic",False)))
    plots=[]
    for p in q["plots"]:
        c=p.get("cursor");r=p.get("selection")
        plots.append(PlotSpecification(p["plot_id"],p["title"],PlotKind(p["kind"]),VisualizationMode(p["mode"]),
            tuple(p["series_ids"]),axis(p["x_axis"]),axis(p["y_axis"]),
            None if c is None else CursorState(float(c["x"]),bool(c["synchronized"])),
            None if r is None else RangeSelection(float(r["start_x"]),float(r["end_x"])),
            bool(p["show_uncertainty"]),p["provenance"]))
    groups=tuple(PlotLinkGroup(g["group_id"],tuple(g["plot_ids"]),LinkMode(g["mode"])) for g in q["link_groups"])
    return MultiPlotWorkspaceSpecification(q["workspace_id"],q["name"],tuple(plots),groups,int(q["columns"]),bool(q["detachable"]),q["provenance"])

@dataclass(frozen=True)
class AnalysisSummary:
    series_id:str
    count:int
    minimum:float|None
    maximum:float|None
    mean:float|None
    sample_standard_deviation:float|None
    provenance:str

def summarize_series(series:ScientificSeries)->AnalysisSummary:
    vals=[p.y for p in series.points if p.quality not in (DataQuality.INVALID,DataQuality.UNAVAILABLE)]
    if not vals:return AnalysisSummary(series.series_id,0,None,None,None,None,series.provenance)
    mean=sum(vals)/len(vals)
    sd=None if len(vals)<2 else math.sqrt(sum((v-mean)**2 for v in vals)/(len(vals)-1))
    return AnalysisSummary(series.series_id,len(vals),min(vals),max(vals),mean,sd,series.provenance)

def visualization_v1_release_readiness():
    failures=[];checks=[]
    for name,fn in (("scientific visualization core",visualization_core_readiness),
                    ("interactive rendering core",visualization_rendering_readiness),
                    ("advanced workspace core",advanced_workspace_readiness)):
        try:
            r=fn()
            if r["passed"]:checks.append(name+" passed")
            else:failures.append(name+" failed")
        except Exception as exc:failures.append(f"{name}: {type(exc).__name__}: {exc}")
    try:
        import tempfile
        pts=(VisualizationPoint(0,1,.1),VisualizationPoint(1,3,.2))
        ser=ScientificSeries("s","S","x","s","m",pts,"SIMULATION","readiness","test")
        with tempfile.TemporaryDirectory() as d:
            if export_series_csv(ser,_Path(d)/"s.csv").rows==2:checks.append("scientific CSV export passed")
            a=AxisSpecification("t","s");b=AxisSpecification("x","m")
            p=PlotSpecification("p","P",PlotKind.TIME_SERIES,VisualizationMode.POST_RUN,("s",),a,b)
            ws=MultiPlotWorkspaceSpecification("w","W",(p,),(),1,True,"readiness")
            target=_Path(d)/"layout.json";export_workspace_specification(ws,target)
            if load_workspace_specification(target)==ws:checks.append("reproducible workspace round-trip passed")
        if summarize_series(ser).mean==2:checks.append("quantitative analysis summary passed")
    except Exception as exc:failures.append(f"export/reproducibility: {type(exc).__name__}: {exc}")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),
            "notes":("Visualization renders supplied HOST/HARDWARE/IMPORTED/SIMULATION/SOFTWARE data with declared provenance.",
                     "No visualization result establishes unresolved Journeyman physics.",
                     "3D surface/field data contracts are qualified; specialized OpenGL rendering remains backend-dependent.")}
