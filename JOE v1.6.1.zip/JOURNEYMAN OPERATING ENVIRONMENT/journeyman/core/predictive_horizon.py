"""Predictive Physics Horizon Supervisor for JOE.

Model-conditional forward projection used to protect experiment progression.
It does not predict Hawking chronology protection and it has no actuator authority.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
from statistics import fmean
from typing import Callable, Iterable
from journeyman.core.physics_safety import PhysicsSafetyDisposition

@dataclass(frozen=True)
class HorizonPolicy:
    horizon_s: float
    step_s: float
    required_stop_s: float
    control_latency_s: float
    uncertainty_margin_s: float
    stale_after_s: float
    caution_fraction: float = .70
    hold_fraction: float = .90
    def __post_init__(self):
        vals=(self.horizon_s,self.step_s,self.required_stop_s,self.control_latency_s,self.uncertainty_margin_s,self.stale_after_s)
        if any(not math.isfinite(x) or x < 0 for x in vals) or self.horizon_s<=0 or self.step_s<=0 or self.step_s>self.horizon_s:
            raise ValueError("invalid horizon policy")
        if not (0 < self.caution_fraction < self.hold_fraction <= 1): raise ValueError("invalid fractions")
    @property
    def required_lead_s(self): return self.required_stop_s+self.control_latency_s+self.uncertainty_margin_s

@dataclass(frozen=True)
class ProjectedPoint:
    t_s: float
    value: float
    sigma: float

@dataclass(frozen=True)
class HorizonAssessment:
    disposition: PhysicsSafetyDisposition
    time_to_violation_s: float|None
    required_lead_s: float
    model_age_s: float
    violation_fraction: float
    first_rate: float|None
    second_rate: float|None
    reason: str
    epistemic_status: str="MODEL_CONDITIONAL_PREDICTION"
    may_progress: bool=True


def finite_difference_rates(points: Iterable[ProjectedPoint])->tuple[float|None,float|None]:
    p=tuple(points)
    if len(p)<2:return None,None
    dt=p[-1].t_s-p[-2].t_s
    if dt<=0:return None,None
    r1=(p[-1].value-p[-2].value)/dt
    if len(p)<3:return r1,None
    dt0=p[-2].t_s-p[-3].t_s
    if dt0<=0:return r1,None
    r0=(p[-2].value-p[-3].value)/dt0
    return r1,(r1-r0)/((dt+dt0)/2)

class PredictivePhysicsHorizonSupervisor:
    """Deterministic evaluator of already-produced model projections."""
    def __init__(self,policy:HorizonPolicy):self.policy=policy
    def assess(self,trajectories:Iterable[Iterable[ProjectedPoint]],ceiling:float,model_age_s:float)->HorizonAssessment:
        if not math.isfinite(ceiling) or ceiling<=0: raise ValueError("positive finite ceiling required")
        if not math.isfinite(model_age_s) or model_age_s<0: raise ValueError("valid model age required")
        if model_age_s>self.policy.stale_after_s:
            return HorizonAssessment(PhysicsSafetyDisposition.HOLD,None,self.policy.required_lead_s,model_age_s,0,None,None,"predictive model is stale; prediction may not authorize progression",may_progress=False)
        trs=tuple(tuple(t) for t in trajectories)
        if not trs:return HorizonAssessment(PhysicsSafetyDisposition.HOLD,None,self.policy.required_lead_s,model_age_s,0,None,None,"no predictive trajectories available",may_progress=False)
        violation_times=[];max_fraction=0.0
        representative=trs[0]
        for tr in trs:
            last=-1.0
            for p in tr:
                if p.t_s<last or p.sigma<0 or not all(math.isfinite(x) for x in (p.t_s,p.value,p.sigma)):
                    return HorizonAssessment(PhysicsSafetyDisposition.HOLD,None,self.policy.required_lead_s,model_age_s,0,None,None,"invalid predictive trajectory",may_progress=False)
                last=p.t_s
                worst=abs(p.value)+p.sigma
                max_fraction=max(max_fraction,worst/ceiling)
                if worst>=ceiling:
                    violation_times.append(p.t_s);break
        r1,r2=finite_difference_rates(representative)
        ttv=min(violation_times) if violation_times else None
        frac=len(violation_times)/len(trs)
        disp=PhysicsSafetyDisposition.NOMINAL;reason="projected uncertainty envelope remains inside configured model boundary"
        if ttv is not None:
            if ttv<=self.policy.required_lead_s:
                disp=PhysicsSafetyDisposition.ABORT;reason="projected envelope violation occurs inside required stopping/latency margin"
            else:
                disp=PhysicsSafetyDisposition.HOLD;reason="projected envelope violation detected within prediction horizon"
        elif max_fraction>=self.policy.hold_fraction:
            disp=PhysicsSafetyDisposition.HOLD;reason="projected uncertainty envelope approaches HOLD fraction of boundary"
        elif max_fraction>=self.policy.caution_fraction:
            disp=PhysicsSafetyDisposition.CAUTION;reason="projected uncertainty envelope approaches CAUTION fraction of boundary"
        return HorizonAssessment(disp,ttv,self.policy.required_lead_s,model_age_s,frac,r1,r2,reason,may_progress=disp<PhysicsSafetyDisposition.HOLD)


def project_scalar_ensemble(initial_values:Iterable[float],derivative:Callable[[float,float],float],policy:HorizonPolicy)->tuple[tuple[ProjectedPoint,...],...]:
    """Bounded Euler reference projector for SIL/model qualification, not hardware control."""
    out=[]
    for x0 in initial_values:
        if not math.isfinite(x0):raise ValueError("finite initial values required")
        t=0.;x=float(x0);pts=[]
        while t<=policy.horizon_s+1e-15:
            pts.append(ProjectedPoint(t,x,0.0))
            dx=float(derivative(t,x))
            if not math.isfinite(dx):raise ValueError("non-finite model derivative")
            x+=policy.step_s*dx;t+=policy.step_s
        out.append(tuple(pts))
    return tuple(out)


def guardian_predictive_horizon_contract(a:HorizonAssessment)->dict:
    return {"schema":"JOE-GUARDIAN-PREDICTIVE-HORIZON/1","authority":"READ_ONLY_ADVISORY","may_command":False,"may_override":False,
            "disposition":a.disposition.name,"may_progress":a.may_progress,"time_to_violation_s":a.time_to_violation_s,
            "required_lead_s":a.required_lead_s,"model_age_s":a.model_age_s,"model_conditional_violation_fraction":a.violation_fraction,
            "first_rate":a.first_rate,"second_rate":a.second_rate,"reason":a.reason,"epistemic_status":a.epistemic_status,
            "truth_boundary":"This is a model-conditional envelope forecast, not a probability or detection of Hawking chronology protection/backreaction."}


def predictive_horizon_release_readiness()->dict:
    failures=[];checks=[]
    try:
        p=HorizonPolicy(1,.1,.1,.02,.03,.25)
        s=PredictivePhysicsHorizonSupervisor(p)
        nominal=s.assess((((ProjectedPoint(0,.1,.01),ProjectedPoint(.1,.2,.01))),),1,0)
        if nominal.disposition==PhysicsSafetyDisposition.NOMINAL:checks.append("nominal forward envelope passed")
        stale=s.assess(((ProjectedPoint(0,.1,0),),),1,.3)
        if stale.disposition==PhysicsSafetyDisposition.HOLD:checks.append("stale-model HOLD passed")
        near=s.assess(((ProjectedPoint(0,.8,.15),),),1,0)
        if near.disposition==PhysicsSafetyDisposition.HOLD:checks.append("uncertainty-aware predictive HOLD passed")
        imminent=s.assess((((ProjectedPoint(0,.2,0),ProjectedPoint(.1,1.1,0))),),1,0)
        if imminent.disposition==PhysicsSafetyDisposition.ABORT:checks.append("insufficient stopping-lead ABORT passed")
        if guardian_predictive_horizon_contract(nominal)["authority"]=="READ_ONLY_ADVISORY":checks.append("Guardian authority boundary passed")
    except Exception as exc:failures.append(f"{type(exc).__name__}: {exc}")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),"notes":(
        "Forecasts are model-conditional and cannot establish physical chronology protection or backreaction.",
        "Stopping/latency values are configuration inputs until measured qualified hardware exists.",
        "The supervisor does not command actuators; deterministic RT/BUS-SAFE authority remains separate.")}
