"""Method-B / Ring-Laser reference physics core.

This module begins with established rotating-ring/Sagnac reference physics. It does not
treat the Sagnac effect as evidence of spacetime chronology violation or time travel.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .state_events import DataOrigin

C=299_792_458.0

class RLAStatus(str,Enum):
    PASS="PASS"
    DOMAIN_INVALID="DOMAIN_INVALID"
    INPUT_INCONSISTENT="INPUT_INCONSISTENT"
    MODEL_UNAVAILABLE="MODEL_UNAVAILABLE"
    UNKNOWN_PHYSICS="UNKNOWN_PHYSICS"

@dataclass(frozen=True)
class RingGeometry:
    ring_id:str
    area_m2:float
    perimeter_m:float
    normal_unit:tuple[float,float,float]
    area_standard_uncertainty_m2:float
    perimeter_standard_uncertainty_m:float
    frame_id:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if not self.ring_id.strip() or not self.frame_id.strip() or not self.provenance.strip():raise ValueError("ring identity/frame/provenance required")
        vals=(self.area_m2,self.perimeter_m,self.area_standard_uncertainty_m2,self.perimeter_standard_uncertainty_m)
        if not all(math.isfinite(float(x)) for x in vals):raise ValueError("geometry values must be finite")
        if self.area_m2<=0 or self.perimeter_m<=0:raise ValueError("area and perimeter must be positive")
        if self.area_standard_uncertainty_m2<0 or self.perimeter_standard_uncertainty_m<0:raise ValueError("uncertainties must be nonnegative")
        if len(self.normal_unit)!=3 or not all(math.isfinite(float(x)) for x in self.normal_unit):raise ValueError("finite 3D normal required")
        n=math.sqrt(sum(float(x)**2 for x in self.normal_unit))
        if abs(n-1)>1e-9:raise ValueError("ring normal must be unit length")

@dataclass(frozen=True)
class OpticalState:
    vacuum_wavelength_m:float
    optical_frequency_hz:float
    circulating_power_w:float
    wavelength_standard_uncertainty_m:float
    frequency_standard_uncertainty_hz:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        vals=(self.vacuum_wavelength_m,self.optical_frequency_hz,self.circulating_power_w,
              self.wavelength_standard_uncertainty_m,self.frequency_standard_uncertainty_hz)
        if not all(math.isfinite(float(x)) for x in vals):raise ValueError("optical values must be finite")
        if self.vacuum_wavelength_m<=0 or self.optical_frequency_hz<=0 or self.circulating_power_w<0:raise ValueError("positive wavelength/frequency and nonnegative power required")
        if self.wavelength_standard_uncertainty_m<0 or self.frequency_standard_uncertainty_hz<0:raise ValueError("uncertainties must be nonnegative")
        if not self.provenance.strip():raise ValueError("optical provenance required")

@dataclass(frozen=True)
class RotationState:
    angular_velocity_rad_s:tuple[float,float,float]
    angular_velocity_standard_uncertainty_rad_s:float
    frame_id:str
    epoch_id:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if len(self.angular_velocity_rad_s)!=3 or not all(math.isfinite(float(x)) for x in self.angular_velocity_rad_s):raise ValueError("finite 3D angular velocity required")
        if not math.isfinite(self.angular_velocity_standard_uncertainty_rad_s) or self.angular_velocity_standard_uncertainty_rad_s<0:raise ValueError("nonnegative finite angular uncertainty required")
        if not self.frame_id.strip() or not self.epoch_id.strip() or not self.provenance.strip():raise ValueError("rotation frame/epoch/provenance required")

@dataclass(frozen=True)
class SagnacResult:
    status:RLAStatus
    projected_angular_velocity_rad_s:float|None
    time_difference_s:float|None
    beat_frequency_hz:float|None
    scale_factor_hz_per_rad_s:float|None
    time_difference_standard_uncertainty_s:float|None
    beat_frequency_standard_uncertainty_hz:float|None
    message:str
    provenance:str

def sagnac_reference(geometry:RingGeometry,optical:OpticalState,rotation:RotationState)->SagnacResult:
    """Leading-order vacuum ring-laser Sagnac reference.

    Δt = 4 A (Ω·n) / c²
    Δf = 4 A (Ω·n) / (λ P)
    """
    if geometry.frame_id!=rotation.frame_id:
        return SagnacResult(RLAStatus.INPUT_INCONSISTENT,None,None,None,None,None,None,
            "Geometry and rotation require an explicit frame transform before comparison.",geometry.provenance)
    omega=sum(rotation.angular_velocity_rad_s[i]*geometry.normal_unit[i] for i in range(3))
    dt=4*geometry.area_m2*omega/(C*C)
    scale=4*geometry.area_m2/(optical.vacuum_wavelength_m*geometry.perimeter_m)
    df=scale*omega
    # Independent first-order uncertainty; normal-orientation uncertainty is not represented in this initial contract.
    u_dt=math.sqrt((4*omega/(C*C)*geometry.area_standard_uncertainty_m2)**2+
                   (4*geometry.area_m2/(C*C)*rotation.angular_velocity_standard_uncertainty_rad_s)**2)
    rel_terms=[]
    if geometry.area_m2:rel_terms.append((geometry.area_standard_uncertainty_m2/geometry.area_m2)**2)
    if optical.vacuum_wavelength_m:rel_terms.append((optical.wavelength_standard_uncertainty_m/optical.vacuum_wavelength_m)**2)
    if geometry.perimeter_m:rel_terms.append((geometry.perimeter_standard_uncertainty_m/geometry.perimeter_m)**2)
    if omega!=0:rel_terms.append((rotation.angular_velocity_standard_uncertainty_rad_s/abs(omega))**2)
    u_df=abs(df)*math.sqrt(sum(rel_terms)) if df!=0 else abs(scale)*rotation.angular_velocity_standard_uncertainty_rad_s
    return SagnacResult(RLAStatus.PASS,omega,dt,df,scale,u_dt,u_df,
        "Established leading-order Sagnac reference for a rotating vacuum ring. This is not a chronology/time-travel effect.",
        geometry.provenance)

@dataclass(frozen=True)
class OpticalConsistency:
    status:RLAStatus
    expected_frequency_hz:float
    declared_frequency_hz:float
    fractional_error:float
    within_declared_uncertainty:bool
    message:str

def optical_consistency(optical:OpticalState,*,sigma:float=3.0)->OpticalConsistency:
    if sigma<=0 or not math.isfinite(sigma):raise ValueError("positive finite sigma required")
    expected=C/optical.vacuum_wavelength_m
    err=(optical.optical_frequency_hz-expected)/expected
    u=math.hypot(optical.frequency_standard_uncertainty_hz,
                 C*optical.wavelength_standard_uncertainty_m/(optical.vacuum_wavelength_m**2))
    ok=abs(optical.optical_frequency_hz-expected)<=sigma*u if u>0 else optical.optical_frequency_hz==expected
    return OpticalConsistency(RLAStatus.PASS if ok else RLAStatus.INPUT_INCONSISTENT,expected,optical.optical_frequency_hz,err,ok,
        "Checks declared vacuum wavelength/frequency consistency using f=c/λ.")

@dataclass(frozen=True)
class RingLaserGuardianContract:
    schema:str
    status:str
    facts:dict
    provenance:str
    authority:str

def ring_laser_guardian_contract(*,sagnac:SagnacResult|None=None,consistency:OpticalConsistency|None=None,
                                 provenance:str="Method-B ring-laser reference")->RingLaserGuardianContract:
    facts={}
    status=RLAStatus.PASS.value
    for name,obj in (("sagnac",sagnac),("optical_consistency",consistency)):
        if obj is not None:
            d={k:(v.value if isinstance(v,Enum) else v) for k,v in obj.__dict__.items()}
            facts[name]=d
            if obj.status!=RLAStatus.PASS:status=obj.status.value
    return RingLaserGuardianContract("JOE-GUARDIAN-RING-LASER/1",status,facts,provenance,
        "READ_ONLY_ADVISORY; Sagnac observables cannot be promoted to chronology/time-travel evidence or override BUS-SAFE/control authority")


MU0=1.25663706212e-6
EPS0=1.0/(MU0*C*C)

@dataclass(frozen=True)
class RingOpticalEnergyRequest:
    circulating_power_w:float
    optical_path_length_m:float
    mode_area_m2:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        vals=(self.circulating_power_w,self.optical_path_length_m,self.mode_area_m2)
        if not all(math.isfinite(float(x)) for x in vals):raise ValueError("optical-energy inputs must be finite")
        if self.circulating_power_w<0 or self.optical_path_length_m<=0 or self.mode_area_m2<=0:
            raise ValueError("nonnegative power and positive path length/mode area required")
        if not self.provenance.strip():raise ValueError("provenance required")

@dataclass(frozen=True)
class RingOpticalEnergy:
    status:RLAStatus
    stored_energy_j:float
    mean_intensity_w_m2:float
    mean_energy_density_j_m3:float
    effective_mode_volume_m3:float
    circulating_momentum_kg_m_s:float
    equivalent_mass_kg:float
    message:str
    provenance:str

def ring_optical_energy(request:RingOpticalEnergyRequest)->RingOpticalEnergy:
    """Vacuum traveling-wave bookkeeping: U=P L/c, I=P/A, u=I/c."""
    volume=request.optical_path_length_m*request.mode_area_m2
    U=request.circulating_power_w*request.optical_path_length_m/C
    I=request.circulating_power_w/request.mode_area_m2
    u=I/C
    return RingOpticalEnergy(RLAStatus.PASS,U,I,u,volume,U/C,U/(C*C),
        "Vacuum traveling-wave energy/momentum bookkeeping. Geometry and mode structure are idealized.",request.provenance)

@dataclass(frozen=True)
class NullRadiationStressEnergy:
    energy_density_j_m3:float
    momentum_density_kg_m2_s:float
    longitudinal_pressure_pa:float
    trace_j_m3:float
    message:str

def null_radiation_stress_energy(energy_density_j_m3:float)->NullRadiationStressEnergy:
    u=float(energy_density_j_m3)
    if not math.isfinite(u) or u<0:raise ValueError("finite nonnegative radiation energy density required")
    return NullRadiationStressEnergy(u,u/C,u,0.0,
        "Local idealized null-radiation reference: energy density u, momentum density u/c, longitudinal pressure u; trace zero.")

@dataclass(frozen=True)
class GravitationalScaleEstimate:
    status:RLAStatus
    equivalent_mass_kg:float
    characteristic_radius_m:float
    compactness:float
    schwarzschild_radius_m:float
    message:str
    provenance:str

def gravitational_scale_estimate(optical_energy_j:float,characteristic_radius_m:float,*,provenance:str)->GravitationalScaleEstimate:
    """Order-of-magnitude GR scale only: compactness 2GE/(c^4 R)."""
    G=6.67430e-11
    E=float(optical_energy_j);R=float(characteristic_radius_m)
    if not math.isfinite(E) or E<0 or not math.isfinite(R) or R<=0:raise ValueError("nonnegative finite energy and positive radius required")
    mass=E/(C*C);rs=2*G*mass/(C*C);comp=rs/R
    return GravitationalScaleEstimate(RLAStatus.PASS,mass,R,comp,rs,
        "Order-of-magnitude compactness scale only; it is not a solution for a circulating-light spacetime metric.",provenance)

@dataclass(frozen=True)
class EnergyScalingPoint:
    circulating_power_w:float
    stored_energy_j:float
    energy_density_j_m3:float
    compactness:float

def ring_energy_scaling(powers_w,*,path_length_m:float,mode_area_m2:float,characteristic_radius_m:float,
                        provenance:str="Method-B scaling")->tuple[EnergyScalingPoint,...]:
    out=[]
    for power in powers_w:
        e=ring_optical_energy(RingOpticalEnergyRequest(float(power),path_length_m,mode_area_m2,provenance))
        g=gravitational_scale_estimate(e.stored_energy_j,characteristic_radius_m,provenance=provenance)
        out.append(EnergyScalingPoint(float(power),e.stored_energy_j,e.mean_energy_density_j_m3,g.compactness))
    return tuple(out)

@dataclass(frozen=True)
class RequiredEnergyComparison:
    status:RLAStatus
    available_energy_j:float
    declared_required_energy_j:float
    energy_ratio:float
    orders_of_magnitude_gap:float
    message:str
    provenance:str

def compare_declared_required_energy(available_energy_j:float,declared_required_energy_j:float,*,provenance:str)->RequiredEnergyComparison:
    """Compare against a user/model-declared target; does not derive a chronology threshold."""
    a=float(available_energy_j);r=float(declared_required_energy_j)
    if not math.isfinite(a) or a<0 or not math.isfinite(r) or r<=0:raise ValueError("available energy nonnegative and required energy positive")
    ratio=a/r
    gap=math.inf if a==0 else math.log10(r/a)
    return RequiredEnergyComparison(RLAStatus.PASS,a,r,ratio,gap,
        "Comparison to a declared energy target only. JOE does not possess a validated chronology-producing energy threshold for Method B.",provenance)

@dataclass(frozen=True)
class RingEnergyUncertainty:
    stored_energy_standard_uncertainty_j:float
    energy_density_standard_uncertainty_j_m3:float
    method:str
    provenance:str

def ring_energy_uncertainty(request:RingOpticalEnergyRequest,*,power_standard_uncertainty_w:float,
                            path_length_standard_uncertainty_m:float,mode_area_standard_uncertainty_m2:float)->RingEnergyUncertainty:
    vals=(power_standard_uncertainty_w,path_length_standard_uncertainty_m,mode_area_standard_uncertainty_m2)
    if any(not math.isfinite(float(x)) or x<0 for x in vals):raise ValueError("uncertainties must be finite and nonnegative")
    P=request.circulating_power_w;L=request.optical_path_length_m;A=request.mode_area_m2
    uU=math.sqrt((L/C*power_standard_uncertainty_w)**2+(P/C*path_length_standard_uncertainty_m)**2)
    uu=math.sqrt((power_standard_uncertainty_w/(A*C))**2+
                 (P*mode_area_standard_uncertainty_m2/(A*A*C))**2)
    return RingEnergyUncertainty(uU,uu,"independent first-order propagation for U=PL/c and u=P/(Ac)",request.provenance)

@dataclass(frozen=True)
class MethodBEpistemicAssessment:
    established_reference_physics:tuple[str,...]
    extrapolated_engineering:tuple[str,...]
    unresolved_physics:tuple[str,...]
    chronology_claim_status:RLAStatus
    message:str

def method_b_epistemic_assessment()->MethodBEpistemicAssessment:
    return MethodBEpistemicAssessment(
        ("Sagnac rotation phase/time asymmetry in rotating interferometers",
         "vacuum electromagnetic energy/momentum bookkeeping",
         "electromagnetic stress-energy gravitates in general relativity"),
        ("high circulating optical power and cavity energy-storage engineering",
         "idealized ring mode area/path-length scaling"),
        ("a validated self-consistent circulating-light metric producing closed timelike curves",
         "a demonstrated chronology threshold for a laboratory ring laser",
         "semiclassical backreaction/stability near any proposed chronology horizon"),
        RLAStatus.UNKNOWN_PHYSICS,
        "Established ring-laser/Sagnac physics must remain separated from speculative Method-B chronology claims.")

def expanded_ring_laser_guardian_contract(*,energy:RingOpticalEnergy|None=None,
                                           gravity:GravitationalScaleEstimate|None=None,
                                           comparison:RequiredEnergyComparison|None=None,
                                           provenance:str="Method-B energy analysis")->RingLaserGuardianContract:
    facts={"epistemic_assessment":{
        "chronology_claim_status":method_b_epistemic_assessment().chronology_claim_status.value,
        "unresolved_physics":method_b_epistemic_assessment().unresolved_physics}}
    for name,obj in (("optical_energy",energy),("gravitational_scale",gravity),("declared_energy_comparison",comparison)):
        if obj is not None:
            facts[name]={k:(v.value if isinstance(v,Enum) else v) for k,v in obj.__dict__.items()}
    return RingLaserGuardianContract("JOE-GUARDIAN-RING-LASER/1",RLAStatus.UNKNOWN_PHYSICS.value,facts,provenance,
        "READ_ONLY_ADVISORY; may report established optical/GR scale calculations but cannot assert chronology generation, authorize hardware, or override BUS-SAFE/control authority")


G=6.67430e-11

@dataclass(frozen=True)
class CirculatingAngularMomentum:
    status:RLAStatus
    stored_energy_j:float
    characteristic_radius_m:float
    angular_momentum_kg_m2_s:float
    message:str
    provenance:str

def circulating_light_angular_momentum(stored_energy_j:float,characteristic_radius_m:float,*,provenance:str)->CirculatingAngularMomentum:
    """Idealized tangential null-energy ring: J ≈ E R / c."""
    E=float(stored_energy_j);R=float(characteristic_radius_m)
    if not math.isfinite(E) or E<0 or not math.isfinite(R) or R<=0:raise ValueError("nonnegative finite energy and positive radius required")
    return CirculatingAngularMomentum(RLAStatus.PASS,E,R,E*R/C,
        "Idealized thin-ring angular-momentum scale J≈ER/c; not a self-consistent circulating-light GR solution.",provenance)

@dataclass(frozen=True)
class WeakFieldFrameDragging:
    status:RLAStatus
    angular_momentum_kg_m2_s:float
    observation_radius_m:float
    angular_rate_rad_s:float
    dimensionless_rotation_scale:float
    message:str
    provenance:str

def weak_field_frame_dragging(angular_momentum_kg_m2_s:float,observation_radius_m:float,*,provenance:str)->WeakFieldFrameDragging:
    """Far-field rotating-source scale Ω_LT = 2 G J / (c² r³).

    Used only as a weak-field comparison scale, not as the metric of a light ring.
    """
    J=float(angular_momentum_kg_m2_s);r=float(observation_radius_m)
    if not math.isfinite(J) or J<0 or not math.isfinite(r) or r<=0:raise ValueError("nonnegative finite angular momentum and positive radius required")
    omega=2*G*J/(C*C*r**3)
    return WeakFieldFrameDragging(RLAStatus.PASS,J,r,omega,omega*r/C,
        "Weak-field far-source frame-dragging comparison scale only; not valid as a chronology criterion.",provenance)

@dataclass(frozen=True)
class MethodBScalingPoint:
    circulating_power_w:float
    stored_energy_j:float
    angular_momentum_kg_m2_s:float
    compactness:float
    weak_field_drag_rate_rad_s:float

def method_b_gravity_scaling(powers_w,*,path_length_m:float,mode_area_m2:float,ring_radius_m:float,
                             observation_radius_m:float,provenance:str="Method-B weak-field scaling")->tuple[MethodBScalingPoint,...]:
    out=[]
    for P in powers_w:
        e=ring_optical_energy(RingOpticalEnergyRequest(float(P),path_length_m,mode_area_m2,provenance))
        j=circulating_light_angular_momentum(e.stored_energy_j,ring_radius_m,provenance=provenance)
        g=gravitational_scale_estimate(e.stored_energy_j,ring_radius_m,provenance=provenance)
        fd=weak_field_frame_dragging(j.angular_momentum_kg_m2_s,observation_radius_m,provenance=provenance)
        out.append(MethodBScalingPoint(float(P),e.stored_energy_j,j.angular_momentum_kg_m2_s,g.compactness,fd.angular_rate_rad_s))
    return tuple(out)

@dataclass(frozen=True)
class ChronologyHypothesisRequest:
    metric_model_id:str
    metric_model_revision:str
    chronology_indicator_name:str
    declared_indicator_value:float|None
    declared_threshold:float|None
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if not self.metric_model_id.strip() or not self.metric_model_revision.strip() or not self.chronology_indicator_name.strip() or not self.provenance.strip():
            raise ValueError("model identity/revision/indicator/provenance required")
        for v in (self.declared_indicator_value,self.declared_threshold):
            if v is not None and not math.isfinite(float(v)):raise ValueError("declared indicator/threshold must be finite when supplied")

@dataclass(frozen=True)
class ChronologyHypothesisAssessment:
    status:RLAStatus
    threshold_crossed:bool|None
    metric_model_id:str
    metric_model_revision:str
    message:str
    provenance:str

def assess_method_b_chronology_hypothesis(request:ChronologyHypothesisRequest)->ChronologyHypothesisAssessment:
    """Epistemic gate for an externally declared speculative chronology indicator.

    JOE records whether a supplied model's own threshold is crossed, but never treats that
    as a validated GR chronology condition.
    """
    if request.declared_indicator_value is None or request.declared_threshold is None:
        return ChronologyHypothesisAssessment(RLAStatus.MODEL_UNAVAILABLE,None,request.metric_model_id,request.metric_model_revision,
            "No complete declared chronology indicator/threshold was supplied. JOE will not invent one.",request.provenance)
    crossed=request.declared_indicator_value>=request.declared_threshold
    return ChronologyHypothesisAssessment(RLAStatus.UNKNOWN_PHYSICS,crossed,request.metric_model_id,request.metric_model_revision,
        "Declared speculative model threshold evaluated. Crossing is not evidence of a physical CTC; no validated self-consistent Method-B chronology solution is implemented.",
        request.provenance)

@dataclass(frozen=True)
class WeakFieldSensitivity:
    base_power_w:float
    fractional_power_step:float
    d_drag_rate_d_power_rad_s_w:float
    d_compactness_d_power_per_w:float
    message:str

def weak_field_power_sensitivity(base_power_w:float,*,fractional_step:float,path_length_m:float,mode_area_m2:float,
                                 ring_radius_m:float,observation_radius_m:float)->WeakFieldSensitivity:
    P=float(base_power_w);h=float(fractional_step)
    if P<=0 or not math.isfinite(P) or h<=0 or h>=1 or not math.isfinite(h):raise ValueError("positive power and 0<fractional_step<1 required")
    lo,hi=P*(1-h),P*(1+h)
    pts=method_b_gravity_scaling((lo,hi),path_length_m=path_length_m,mode_area_m2=mode_area_m2,
                                 ring_radius_m=ring_radius_m,observation_radius_m=observation_radius_m)
    dp=hi-lo
    return WeakFieldSensitivity(P,h,(pts[1].weak_field_drag_rate_rad_s-pts[0].weak_field_drag_rate_rad_s)/dp,
        (pts[1].compactness-pts[0].compactness)/dp,
        "Centered finite-difference sensitivity of weak-field comparison scales to circulating power.")

@dataclass(frozen=True)
class RLAConvergence:
    passed:bool
    analytic_drag_rate_rad_s:float
    finite_difference_extrapolation_rad_s:float
    relative_error:float
    tolerance:float
    message:str

def rla_numerical_verification(*,power_w:float=1e6,path_length_m:float=10,mode_area_m2:float=1e-3,
                               ring_radius_m:float=1,observation_radius_m:float=2,tolerance:float=1e-10)->RLAConvergence:
    # Since the current reference is exactly linear in P, verify numerical sensitivity reconstructs the analytic value.
    point=method_b_gravity_scaling((power_w,),path_length_m=path_length_m,mode_area_m2=mode_area_m2,
                                   ring_radius_m=ring_radius_m,observation_radius_m=observation_radius_m)[0]
    sens=weak_field_power_sensitivity(power_w,fractional_step=1e-4,path_length_m=path_length_m,mode_area_m2=mode_area_m2,
                                      ring_radius_m=ring_radius_m,observation_radius_m=observation_radius_m)
    reconstructed=sens.d_drag_rate_d_power_rad_s_w*power_w
    rel=0.0 if point.weak_field_drag_rate_rad_s==0 else abs(reconstructed-point.weak_field_drag_rate_rad_s)/abs(point.weak_field_drag_rate_rad_s)
    return RLAConvergence(rel<=tolerance,point.weak_field_drag_rate_rad_s,reconstructed,rel,tolerance,
        "Numerical power sensitivity cross-check for the implemented linear weak-field reference scale.")

def method_b_hypothesis_guardian_contract(assessment:ChronologyHypothesisAssessment,*,provenance:str)->RingLaserGuardianContract:
    return RingLaserGuardianContract("JOE-GUARDIAN-RING-LASER/1",assessment.status.value,
        {"chronology_hypothesis":{"metric_model_id":assessment.metric_model_id,"metric_model_revision":assessment.metric_model_revision,
                                 "threshold_crossed":assessment.threshold_crossed,"status":assessment.status.value,
                                 "message":assessment.message}},provenance,
        "READ_ONLY_ADVISORY; a declared speculative threshold crossing remains UNKNOWN_PHYSICS and cannot be treated as CTC/time-travel evidence or hardware authority")


@dataclass(frozen=True)
class RLAReleaseReadiness:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    notes:tuple[str,...]

def rla_release_readiness()->RLAReleaseReadiness:
    checks=[];fail=[];notes=[]
    try:
        lam=632.8e-9
        geo=RingGeometry("qualification-ring",1.0,4.0,(0,0,1),1e-4,1e-4,"qualification.inertial","RLA readiness")
        opt=OpticalState(lam,C/lam,1e6,1e-12,1e6,"RLA readiness")
        rot=RotationState((0,0,1.0),1e-6,"qualification.inertial","J2000","RLA readiness")
        sag=sagnac_reference(geo,opt,rot)
        if sag.status==RLAStatus.PASS and sag.time_difference_s>0 and sag.beat_frequency_hz>0:
            checks.append("Sagnac reference benchmark passed")
        else: fail.append("Sagnac reference benchmark failed")
        oc=optical_consistency(opt)
        if oc.status==RLAStatus.PASS: checks.append("vacuum wavelength/frequency consistency passed")
        else: fail.append("vacuum wavelength/frequency consistency failed")
        e=ring_optical_energy(RingOpticalEnergyRequest(1e6,10,.001,"RLA readiness"))
        if e.status==RLAStatus.PASS and e.stored_energy_j>0: checks.append("circulating optical-energy bookkeeping passed")
        else: fail.append("circulating optical-energy bookkeeping failed")
        j=circulating_light_angular_momentum(e.stored_energy_j,1,provenance="RLA readiness")
        fd=weak_field_frame_dragging(j.angular_momentum_kg_m2_s,2,provenance="RLA readiness")
        if fd.status==RLAStatus.PASS and fd.angular_rate_rad_s>0: checks.append("weak-field comparison scale passed")
        else: fail.append("weak-field comparison scale failed")
        nv=rla_numerical_verification()
        if nv.passed: checks.append("numerical sensitivity cross-check passed")
        else: fail.append("numerical sensitivity cross-check failed")
        hyp=assess_method_b_chronology_hypothesis(ChronologyHypothesisRequest("qualification-speculative-model","r1","declared_indicator",2,1,"RLA readiness"))
        if hyp.status==RLAStatus.UNKNOWN_PHYSICS and hyp.threshold_crossed:
            checks.append("speculative chronology threshold remains epistemically gated")
        else: fail.append("chronology epistemic gate failed")
        guardian=method_b_hypothesis_guardian_contract(hyp,provenance="RLA readiness")
        if "cannot be treated as CTC/time-travel evidence" in guardian.authority:
            checks.append("Guardian Method-B authority gate passed")
        else: fail.append("Guardian Method-B authority gate failed")
    except Exception as exc:
        fail.append(f"release-readiness exception: {type(exc).__name__}: {exc}")
    notes.append("PASS qualifies implemented reference software, dimensional/scaling behavior and epistemic gates only.")
    notes.append("No validated self-consistent circulating-light chronology metric or laboratory CTC threshold is implemented.")
    notes.append("No physical ring-laser telemetry is claimed; operational workspace inputs are SIMULATION/model values.")
    return RLAReleaseReadiness(not fail,tuple(checks),tuple(fail),tuple(notes))

# --- JOE-PHYSICS-EXT-002B: advanced closed-loop optical resonator physics ---
@dataclass(frozen=True)
class ResonatorRequest:
    path_length_m:float
    group_index:float
    phase_index:float
    wavelength_m:float
    circulating_power_w:float
    round_trip_power_loss:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        vals=(self.path_length_m,self.group_index,self.phase_index,self.wavelength_m,self.circulating_power_w,self.round_trip_power_loss)
        if not all(math.isfinite(float(x)) for x in vals): raise ValueError("resonator inputs must be finite")
        if self.path_length_m<=0 or self.group_index<=0 or self.phase_index<=0 or self.wavelength_m<=0 or self.circulating_power_w<0: raise ValueError("positive geometry/index/wavelength and nonnegative power required")
        if not 0 < self.round_trip_power_loss < 1: raise ValueError("round-trip power loss must satisfy 0 < loss < 1")
        if not self.provenance.strip(): raise ValueError("provenance required")

@dataclass(frozen=True)
class ResonatorResult:
    status:RLAStatus
    round_trip_time_s:float
    free_spectral_range_hz:float
    optical_frequency_hz:float
    round_trip_phase_rad:float
    photon_lifetime_s:float
    quality_factor:float
    finesse:float
    stored_energy_j:float
    message:str
    provenance:str

def closed_loop_resonator(request:ResonatorRequest)->ResonatorResult:
    trt=request.group_index*request.path_length_m/C
    fsr=1.0/trt
    f=C/request.wavelength_m
    phase=2*math.pi*request.phase_index*request.path_length_m/request.wavelength_m
    # Exact exponential lifetime for fractional round-trip power survival 1-loss.
    tau=-trt/math.log1p(-request.round_trip_power_loss)
    q=2*math.pi*f*tau
    finesse=fsr and (1.0/(fsr*tau))**-1 * math.pi # pi*tau*FSR, lifetime-based reference
    U=request.circulating_power_w*trt
    return ResonatorResult(RLAStatus.PASS,trt,fsr,f,phase,tau,q,finesse,U,
        "Idealized traveling-wave closed-loop resonator bookkeeping; dispersion is represented by declared group/phase indices and does not imply chronology modification.",request.provenance)

@dataclass(frozen=True)
class DispersionResult:
    group_delay_s:float
    phase_delay_s:float
    group_phase_difference_s:float
    message:str

def resonator_dispersion(path_length_m:float,group_index:float,phase_index:float)->DispersionResult:
    vals=(path_length_m,group_index,phase_index)
    if not all(math.isfinite(float(x)) for x in vals) or path_length_m<=0 or group_index<=0 or phase_index<=0: raise ValueError("positive finite dispersion inputs required")
    tg=group_index*path_length_m/C; tp=phase_index*path_length_m/C
    return DispersionResult(tg,tp,tg-tp,"Declared-index group/phase delay comparison; material model validity is external to this calculation.")

@dataclass(frozen=True)
class MethodBEMGravityBridge:
    status:RLAStatus
    energy_density_j_m3:float
    equivalent_mass_density_kg_m3:float
    einstein_source_scale_m2_inv:float
    message:str
    provenance:str

def method_b_em_gravity_bridge(circulating_power_w:float,mode_area_m2:float,*,provenance:str)->MethodBEMGravityBridge:
    if not all(math.isfinite(float(x)) for x in (circulating_power_w,mode_area_m2)) or circulating_power_w<0 or mode_area_m2<=0: raise ValueError("nonnegative power and positive finite mode area required")
    u=circulating_power_w/(mode_area_m2*C)
    rho=u/(C*C)
    G=6.67430e-11
    kappa=8*math.pi*G/(C**4)
    # kappa*T has curvature units; u is the local idealized null-radiation T00 scale.
    return MethodBEMGravityBridge(RLAStatus.PASS,u,rho,kappa*u,
        "Local idealized EM stress-energy to Einstein-equation source scale. This is not a nonlinear Einstein-Maxwell spacetime solution or CTC threshold.",provenance)

@dataclass(frozen=True)
class MethodBAdvancedGuardianContract:
    schema:str
    status:str
    facts:dict
    provenance:str
    authority:str

def method_b_advanced_guardian_contract(*,resonator:ResonatorResult|None=None,bridge:MethodBEMGravityBridge|None=None,provenance:str="Method-B advanced optics")->MethodBAdvancedGuardianContract:
    facts={}; status=RLAStatus.PASS.value
    for name,obj in (("resonator",resonator),("em_gravity_bridge",bridge)):
        if obj is not None:
            facts[name]={k:(v.value if isinstance(v,Enum) else v) for k,v in obj.__dict__.items()}
            if getattr(obj,"status",RLAStatus.PASS)!=RLAStatus.PASS: status=getattr(obj,"status").value
    return MethodBAdvancedGuardianContract("JOE-GUARDIAN-METHOD-B-ADVANCED/1",status,facts,provenance,
        "READ_ONLY_ADVISORY; optical/EM calculations cannot be promoted to physical chronology modification, CTC evidence, actuator authority, or BUS-SAFE authority")

def method_b_advanced_release_readiness():
    failures=[]; checks=[]
    try:
        r=closed_loop_resonator(ResonatorRequest(10,1,1,1064e-9,1e6,.01,"qualification"))
        if r.status==RLAStatus.PASS and r.round_trip_time_s>0 and r.quality_factor>0: checks.append("closed-loop resonator benchmark passed")
        else: failures.append("closed-loop resonator benchmark failed")
        d=resonator_dispersion(10,1.5,1.4)
        if d.group_delay_s>d.phase_delay_s: checks.append("dispersion delay benchmark passed")
        else: failures.append("dispersion delay benchmark failed")
        b=method_b_em_gravity_bridge(1e6,1e-6,provenance="qualification")
        if b.einstein_source_scale_m2_inv>0: checks.append("EM-to-Einstein source-scale bridge passed")
        else: failures.append("EM gravity bridge failed")
        g=method_b_advanced_guardian_contract(resonator=r,bridge=b,provenance="qualification")
        if g.schema=="JOE-GUARDIAN-METHOD-B-ADVANCED/1" and "cannot be promoted" in g.authority: checks.append("advanced Method-B Guardian authority gate passed")
        else: failures.append("advanced Method-B Guardian authority gate failed")
    except Exception as exc: failures.append(f"advanced Method-B readiness exception: {type(exc).__name__}: {exc}")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),"notes":("No validated circulating-light chronology metric or physical CTC threshold is claimed.",)}
