"""Isolated background scientific-intelligence synchronization worker."""
from __future__ import annotations
import argparse
from journeyman.core.paths import DATA_DIR
from journeyman.core.scientific_intelligence import ScientificIntelligenceService

def main() -> int:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--limit", type=int, default=12)
    args = parser.parse_args()
    service = ScientificIntelligenceService(DATA_DIR / "scientific_intelligence")
    if service.paused:
        return 0
    if not service.network_available(0.5):
        return 0
    result = service.sync_now(limit=max(1, min(args.limit, 50)))
    return 0 if result.get("status") in {"ONLINE", "PAUSED", "OFFLINE_OR_ERROR"} else 1

if __name__ == "__main__":
    raise SystemExit(main())
