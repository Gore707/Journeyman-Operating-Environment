"""JOE Window & Workspace qualification checks.

These checks validate persisted workspace records without requiring a GUI.
They are intentionally conservative: a layout must have unique identities,
supported workspace types, valid titles, and structurally usable geometry.
"""
from __future__ import annotations
from dataclasses import dataclass
from uuid import UUID

from .workspace_layout import WorkspaceLayoutEntry
from .workspace_policy import validate_workspace_title

SUPPORTED_KINDS = {"overview", "log"}

@dataclass(frozen=True)
class QualificationResult:
    passed: bool
    checks: int
    failures: tuple[str, ...]

def qualify_layout(entries: list[WorkspaceLayoutEntry]) -> QualificationResult:
    failures: list[str] = []
    seen: set[str] = set()
    checks = 0
    for index, entry in enumerate(entries, start=1):
        prefix = f"Workspace {index}"
        checks += 1
        if entry.kind not in SUPPORTED_KINDS:
            failures.append(f"{prefix}: unsupported type '{entry.kind}'")
        checks += 1
        try:
            validate_workspace_title(entry.title)
        except ValueError as exc:
            failures.append(f"{prefix}: {exc}")
        checks += 1
        try:
            normalized = str(UUID(entry.workspace_id))
            if normalized in seen:
                failures.append(f"{prefix}: duplicate workspace identity")
            seen.add(normalized)
        except (ValueError, TypeError, AttributeError):
            failures.append(f"{prefix}: invalid workspace identity")
        checks += 1
        if not isinstance(entry.external, bool) or not isinstance(entry.maximized, bool) or not isinstance(entry.locked, bool):
            failures.append(f"{prefix}: invalid persisted state flags")
        checks += 1
        if not isinstance(entry.geometry_b64, str):
            failures.append(f"{prefix}: invalid geometry record")
    return QualificationResult(not failures, checks, tuple(failures))


def compare_layouts(expected: list[WorkspaceLayoutEntry],
                    restored: list[WorkspaceLayoutEntry]) -> QualificationResult:
    """Verify that persistence/restoration preserved the desktop model."""
    failures: list[str] = []
    checks = 1
    if len(expected) != len(restored):
        failures.append(
            f"Workspace count changed during round trip: {len(expected)} -> {len(restored)}"
        )
        return QualificationResult(False, checks, tuple(failures))

    def keyed(rows):
        return {row.workspace_id: row for row in rows}

    left = keyed(expected)
    right = keyed(restored)
    checks += 1
    if set(left) != set(right):
        failures.append("Workspace identities changed during round trip")
        return QualificationResult(False, checks, tuple(failures))

    for wid in sorted(left):
        a, b = left[wid], right[wid]
        for field in ("kind", "title", "external", "geometry_b64",
                      "maximized", "locked", "minimized", "workspace_id"):
            checks += 1
            if getattr(a, field) != getattr(b, field):
                failures.append(
                    f"Workspace {wid}: field '{field}' changed during round trip"
                )
    return QualificationResult(not failures, checks, tuple(failures))


@dataclass(frozen=True)
class LifecycleState:
    workspace_id: str
    minimized: bool = False
    active: bool = False

def minimize_states(states: list[LifecycleState]) -> list[LifecycleState]:
    """Return the expected model after a Minimize All operation."""
    return [LifecycleState(s.workspace_id, True, s.active) for s in states]

def restore_states(states: list[LifecycleState]) -> list[LifecycleState]:
    """Return the expected model after a Restore All operation."""
    return [LifecycleState(s.workspace_id, False, s.active) for s in states]

def activate_state(states: list[LifecycleState], workspace_id: str) -> list[LifecycleState]:
    """Return a model with exactly the requested workspace active."""
    if workspace_id not in {s.workspace_id for s in states}:
        raise ValueError("Workspace identity is not present in the lifecycle model.")
    return [
        LifecycleState(s.workspace_id, s.minimized, s.workspace_id == workspace_id)
        for s in states
    ]

def qualify_lifecycle(states: list[LifecycleState]) -> QualificationResult:
    failures: list[str] = []
    checks = 0
    ids = [s.workspace_id for s in states]
    checks += 1
    if len(ids) != len(set(ids)):
        failures.append("Lifecycle model contains duplicate workspace identities.")
    active_count = sum(1 for s in states if s.active)
    checks += 1
    if active_count > 1:
        failures.append("Lifecycle model contains more than one active workspace.")
    for index, state in enumerate(states, start=1):
        checks += 1
        try:
            UUID(state.workspace_id)
        except (ValueError, TypeError, AttributeError):
            failures.append(f"Lifecycle workspace {index} has an invalid identity.")
    return QualificationResult(not failures, checks, tuple(failures))


@dataclass(frozen=True)
class CompositeQualification:
    passed: bool
    checks: int
    sections: tuple[tuple[str, bool, tuple[str, ...]], ...]

def qualify_workspace_system(entries: list[WorkspaceLayoutEntry],
                             restored: list[WorkspaceLayoutEntry],
                             lifecycle: list[LifecycleState]) -> CompositeQualification:
    """Run the complete non-GUI JOE-002 qualification chain."""
    structural = qualify_layout(entries)
    persistence = compare_layouts(entries, restored)
    lifecycle_result = qualify_lifecycle(lifecycle)
    sections = (
        ("Desktop structure", structural.passed, structural.failures),
        ("Persistence round trip", persistence.passed, persistence.failures),
        ("Lifecycle integrity", lifecycle_result.passed, lifecycle_result.failures),
    )
    return CompositeQualification(
        all(section[1] for section in sections),
        structural.checks + persistence.checks + lifecycle_result.checks,
        sections,
    )


@dataclass(frozen=True)
class ReleaseReadiness:
    passed: bool
    checks: int
    summary: tuple[str, ...]

def joe002_release_readiness(entries: list[WorkspaceLayoutEntry],
                             restored: list[WorkspaceLayoutEntry],
                             lifecycle: list[LifecycleState]) -> ReleaseReadiness:
    """Final code-level release gate for the implemented JOE-002 subsystem."""
    composite = qualify_workspace_system(entries, restored, lifecycle)
    summary = tuple(
        f"{'PASS' if passed else 'FAIL'} — {name}"
        for name, passed, _failures in composite.sections
    )
    return ReleaseReadiness(composite.passed, composite.checks, summary)
