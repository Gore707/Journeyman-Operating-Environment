"""Verification & Uncertainty module."""
from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.verification import (compare_independent_results,check_dimensions,
 check_verification_independence,verification_guardian_contract,propagate_linear_uncertainty,
 numerical_jacobian,monte_carlo_uncertainty,cross_check_uncertainty_methods,
 expanded_verification_guardian_contract,assess_convergence,assess_regression,
 build_verification_matrix,cross_validate_models,vnv_core_readiness,vnv_release_readiness)
VNV_MODULE=ModuleDescriptor(module_id="journeyman.verification",name="Verification & Uncertainty",version="1.0.0",
 description="Independent scientific verification, discrepancy and uncertainty foundation.",
 requires=("joe.core","journeyman.registry"),provides=("joe.verification",),
 consumes=("joe.registry","joe.state-events"))
class VerificationService:
    compare=staticmethod(compare_independent_results)
    check_dimensions=staticmethod(check_dimensions)
    check_independence=staticmethod(check_verification_independence)
    guardian_contract=staticmethod(verification_guardian_contract)
    propagate_uncertainty=staticmethod(propagate_linear_uncertainty)
    numerical_jacobian=staticmethod(numerical_jacobian)
    monte_carlo=staticmethod(monte_carlo_uncertainty)
    cross_check_uncertainty=staticmethod(cross_check_uncertainty_methods)
    expanded_guardian_contract=staticmethod(expanded_verification_guardian_contract)
    assess_convergence=staticmethod(assess_convergence)
    assess_regression=staticmethod(assess_regression)
    build_matrix=staticmethod(build_verification_matrix)
    cross_validate=staticmethod(cross_validate_models)
    core_readiness=staticmethod(vnv_core_readiness)
    release_readiness=staticmethod(vnv_release_readiness)
class VerificationInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_verification_module(runtime:ModuleRuntime):
    svc=VerificationService();runtime.register(VNV_MODULE,VerificationInstance(svc));runtime.activate("journeyman.verification")
    runtime.publish_service("journeyman.verification","joe.verification",svc);return svc
