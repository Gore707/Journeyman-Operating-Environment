"""Compute Backend Manager — CMP-001A capability inventory and governed selection."""
from __future__ import annotations
from dataclasses import dataclass,asdict
from enum import Enum
from typing import Any
import os,platform,shutil,subprocess

class BackendKind(str,Enum):
    CPU="CPU"
    GPU="GPU"
    HPC="HPC"

class BackendStatus(str,Enum):
    AVAILABLE="AVAILABLE"
    UNAVAILABLE="UNAVAILABLE"
    DEGRADED="DEGRADED"

@dataclass(frozen=True)
class ComputeBackend:
    backend_id:str
    kind:BackendKind
    status:BackendStatus
    provider:str
    device_name:str
    logical_units:int|None
    memory_bytes:int|None
    capabilities:tuple[str,...]
    provenance:str
    diagnostic:str=""
    def __post_init__(self):
        if not all((self.backend_id.strip(),self.provider.strip(),self.device_name.strip(),self.provenance.strip())):
            raise ValueError("complete compute backend identity/provider/device/provenance required")
        if self.logical_units is not None and self.logical_units<1:raise ValueError("logical units must be positive")
        if self.memory_bytes is not None and self.memory_bytes<0:raise ValueError("memory bytes cannot be negative")

@dataclass(frozen=True)
class ComputeRequirement:
    require_gpu:bool=False
    minimum_memory_bytes:int|None=None
    required_capabilities:tuple[str,...]=()
    deterministic_required:bool=False
    allow_remote_hpc:bool=True
    def __post_init__(self):
        if self.minimum_memory_bytes is not None and self.minimum_memory_bytes<0:raise ValueError("minimum memory cannot be negative")

@dataclass(frozen=True)
class BackendSelection:
    selected_backend_id:str|None
    status:str
    reasons:tuple[str,...]
    provenance:str

def detect_cpu_backend()->ComputeBackend:
    logical=os.cpu_count()
    memory=None
    try:
        import psutil
        memory=int(psutil.virtual_memory().total)
    except Exception:pass
    return ComputeBackend("local.cpu",BackendKind.CPU,BackendStatus.AVAILABLE,platform.python_implementation(),
        platform.processor() or platform.machine() or "Local CPU",logical,memory,
        ("scalar","multicore","python-runtime"),"HOST: Python/platform/psutil APIs")

def _nvidia_smi_backend()->ComputeBackend|None:
    exe=shutil.which("nvidia-smi")
    if not exe:return None
    try:
        cp=subprocess.run([exe,"--query-gpu=name,memory.total","--format=csv,noheader,nounits"],capture_output=True,text=True,timeout=3)
        if cp.returncode:return ComputeBackend("local.gpu.nvidia",BackendKind.GPU,BackendStatus.DEGRADED,"NVIDIA","NVIDIA GPU",None,None,(),
            "HOST: nvidia-smi",cp.stderr.strip() or "nvidia-smi query failed")
        first=cp.stdout.strip().splitlines()[0];name,mem=first.rsplit(",",1)
        return ComputeBackend("local.gpu.nvidia",BackendKind.GPU,BackendStatus.AVAILABLE,"NVIDIA",name.strip(),None,int(float(mem.strip())*1024*1024),
            ("gpu","parallel","cuda-provider"),"HOST: nvidia-smi")
    except Exception as exc:
        return ComputeBackend("local.gpu.nvidia",BackendKind.GPU,BackendStatus.DEGRADED,"NVIDIA","NVIDIA GPU",None,None,(),
            "HOST: nvidia-smi",f"{type(exc).__name__}: {exc}")


def _amd_smi_backend()->ComputeBackend|None:
    """Discover AMD GPU via AMD SMI/ROCm SMI when an actual provider CLI is installed."""
    exe=shutil.which("amd-smi") or shutil.which("rocm-smi")
    if not exe:return None
    name="AMD Radeon / Instinct GPU";memory=None;diag=""
    try:
        if Path(exe).name.lower().startswith("amd-smi"):
            cp=subprocess.run([exe,"static","--asic","--vram","--json"],capture_output=True,text=True,timeout=4)
        else:
            cp=subprocess.run([exe,"--showproductname","--showmeminfo","vram","--json"],capture_output=True,text=True,timeout=4)
        if cp.returncode:diag=cp.stderr.strip() or "AMD GPU query failed"
        else:
            text=cp.stdout
            import re
            # Provider JSON schemas differ by release; extract only clearly declared host fields.
            m=re.search(r'(?i)(?:market_name|product_name|card series|device name|name)"?\s*[:=]\s*"?([^"\n,}]+)',text)
            if m:name=m.group(1).strip()
            # Prefer byte-sized VRAM fields, otherwise MiB-looking values.
            candidates=re.findall(r'(?i)(?:vram[_ ]?(?:total|size)|total[_ ]?vram|vram total)"?\s*[:=]\s*"?([0-9]+)',text)
            if candidates:
                raw=int(candidates[0]);memory=raw if raw>1024**3 else raw*1024*1024
        return ComputeBackend("local.gpu.amd",BackendKind.GPU,BackendStatus.AVAILABLE if not diag else BackendStatus.DEGRADED,
                              "AMD",name,None,memory,("gpu","parallel","amd-provider"),
                              "HOST: "+Path(exe).name,diag)
    except Exception as exc:
        return ComputeBackend("local.gpu.amd",BackendKind.GPU,BackendStatus.DEGRADED,"AMD",name,None,None,(),
                              "HOST: "+Path(exe).name,f"{type(exc).__name__}: {exc}")


def detect_gpu_backends()->tuple[ComputeBackend,...]:
    found=[]
    n=_nvidia_smi_backend()
    if n:found.append(n)
    a=_amd_smi_backend()
    if a:found.append(a)
    if not found:
        found.append(ComputeBackend("local.gpu",BackendKind.GPU,BackendStatus.UNAVAILABLE,"HOST","GPU",None,None,(),
            "HOST: provider executable/API discovery","No supported GPU compute provider detected."))
    return tuple(found)

def detect_hpc_backend()->ComputeBackend:
    schedulers=tuple(x for x in ("sbatch","qsub","bsub") if shutil.which(x))
    if schedulers:
        return ComputeBackend("hpc.scheduler",BackendKind.HPC,BackendStatus.AVAILABLE,"Scheduler","Local/connected HPC scheduler",None,None,
            ("batch","remote-or-cluster","scheduler:"+schedulers[0]),"HOST: scheduler executable discovery")
    return ComputeBackend("hpc.scheduler",BackendKind.HPC,BackendStatus.UNAVAILABLE,"Scheduler","HPC scheduler",None,None,(),
        "HOST: scheduler executable discovery","No supported HPC scheduler command detected.")

def discover_compute_backends()->tuple[ComputeBackend,...]:
    return (detect_cpu_backend(),)+detect_gpu_backends()+(detect_hpc_backend(),)

def select_backend(backends:tuple[ComputeBackend,...],requirement:ComputeRequirement)->BackendSelection:
    reasons=[]
    candidates=[b for b in backends if b.status==BackendStatus.AVAILABLE]
    if requirement.require_gpu:candidates=[b for b in candidates if b.kind==BackendKind.GPU]
    if not requirement.allow_remote_hpc:candidates=[b for b in candidates if b.kind!=BackendKind.HPC]
    if requirement.minimum_memory_bytes is not None:
        candidates=[b for b in candidates if b.memory_bytes is not None and b.memory_bytes>=requirement.minimum_memory_bytes]
    req=set(requirement.required_capabilities);candidates=[b for b in candidates if req.issubset(set(b.capabilities))]
    if requirement.deterministic_required:
        # Research CPU/GPU/HPC backends are not JOE's deterministic RT authority.
        return BackendSelection(None,"REJECTED",("deterministic execution must use the dedicated RT/control path, not the research compute manager",),
                                "JOE compute authority policy")
    if not candidates:
        return BackendSelection(None,"UNAVAILABLE",("no available backend satisfies the declared requirements",),"JOE compute selection")
    order={BackendKind.GPU:0,BackendKind.CPU:1,BackendKind.HPC:2}
    chosen=sorted(candidates,key=lambda b:(order[b.kind],b.backend_id))[0]
    reasons.append(f"selected {chosen.backend_id} from AVAILABLE backends satisfying explicit requirements")
    return BackendSelection(chosen.backend_id,"SELECTED",tuple(reasons),"JOE compute selection")

@dataclass(frozen=True)
class ComputeGuardianContract:
    schema:str
    status:str
    facts:dict[str,Any]
    provenance:str
    authority:str="READ_ONLY_ADVISORY"

def compute_guardian_contract(backends:tuple[ComputeBackend,...])->ComputeGuardianContract:
    return ComputeGuardianContract("JOE-GUARDIAN-COMPUTE/1","PASS",
        {"backends":tuple({"backend_id":b.backend_id,"kind":b.kind.value,"status":b.status.value,"provider":b.provider,
                           "device_name":b.device_name,"memory_bytes":b.memory_bytes,"capabilities":b.capabilities,
                           "diagnostic":b.diagnostic} for b in backends),
         "safety_authority":False,"deterministic_rt_authority":False},"Compute Backend Manager CMP-001A")

def compute_core_readiness():
    bs=discover_compute_backends();cpu=[b for b in bs if b.kind==BackendKind.CPU]
    normal=select_backend(bs,ComputeRequirement())
    rt=select_backend(bs,ComputeRequirement(deterministic_required=True))
    return {"passed":bool(cpu) and cpu[0].status==BackendStatus.AVAILABLE and normal.status=="SELECTED" and rt.status=="REJECTED",
            "checks":("host CPU inventory","GPU provider discovery","HPC scheduler discovery","requirement-based selection",
                      "deterministic RT separation","Guardian compute contract")}


class WorkloadStatus(str,Enum):
    QUEUED="QUEUED"
    RUNNING="RUNNING"
    SUCCEEDED="SUCCEEDED"
    FAILED="FAILED"
    CANCELLED="CANCELLED"
    REJECTED="REJECTED"

@dataclass(frozen=True)
class ResourceBudget:
    maximum_workers:int=1
    maximum_memory_bytes:int|None=None
    timeout_s:float|None=None
    def __post_init__(self):
        if self.maximum_workers<1:raise ValueError("maximum_workers must be positive")
        if self.maximum_memory_bytes is not None and self.maximum_memory_bytes<1:raise ValueError("maximum memory must be positive")
        if self.timeout_s is not None and self.timeout_s<=0:raise ValueError("timeout must be positive")

@dataclass(frozen=True)
class WorkloadRequest:
    workload_id:str
    operation:str
    inputs:tuple[float,...]
    requirement:ComputeRequirement
    budget:ResourceBudget
    provenance:str
    run_id:str|None=None
    def __post_init__(self):
        if not all((self.workload_id.strip(),self.operation.strip(),self.provenance.strip())):raise ValueError("workload identity/operation/provenance required")
        if any(not isinstance(x,(int,float)) for x in self.inputs):raise ValueError("CMP-001B numeric workload inputs required")

@dataclass(frozen=True)
class WorkloadResult:
    workload_id:str
    backend_id:str|None
    status:WorkloadStatus
    output:Any
    started_at_s:float|None
    finished_at_s:float|None
    diagnostic:str
    provenance:str

def _execute_numeric_operation(operation:str,values:tuple[float,...])->Any:
    import math
    if operation=="sum":return math.fsum(values)
    if operation=="mean":
        if not values:raise ValueError("mean requires inputs")
        return math.fsum(values)/len(values)
    if operation=="sum_squares":return math.fsum(x*x for x in values)
    if operation=="min":
        if not values:raise ValueError("min requires inputs")
        return min(values)
    if operation=="max":
        if not values:raise ValueError("max requires inputs")
        return max(values)
    raise ValueError("unsupported governed workload operation: "+operation)

def execute_workload(request:WorkloadRequest,backends:tuple[ComputeBackend,...]|None=None)->WorkloadResult:
    """Execute only the bounded, declared CMP-001B research operation set."""
    import time
    bs=discover_compute_backends() if backends is None else backends
    sel=select_backend(bs,request.requirement)
    if sel.status!="SELECTED":
        return WorkloadResult(request.workload_id,None,WorkloadStatus.REJECTED,None,None,time.time(),
                              "; ".join(sel.reasons),request.provenance)
    backend=next(b for b in bs if b.backend_id==sel.selected_backend_id)
    # CMP-001B does not pretend CPU Python work is GPU execution. GPU/HPC adapters require a qualified runtime.
    if backend.kind!=BackendKind.CPU:
        return WorkloadResult(request.workload_id,backend.backend_id,WorkloadStatus.REJECTED,None,None,time.time(),
                              f"{backend.kind.value} discovered but no qualified execution adapter is bound in CMP-001B",
                              request.provenance)
    start=time.time()
    try:
        output=_execute_numeric_operation(request.operation,request.inputs)
        end=time.time()
        if request.budget.timeout_s is not None and end-start>request.budget.timeout_s:
            return WorkloadResult(request.workload_id,backend.backend_id,WorkloadStatus.FAILED,None,start,end,
                                  "execution exceeded declared timeout budget",request.provenance)
        return WorkloadResult(request.workload_id,backend.backend_id,WorkloadStatus.SUCCEEDED,output,start,end,"",request.provenance)
    except Exception as exc:
        return WorkloadResult(request.workload_id,backend.backend_id,WorkloadStatus.FAILED,None,start,time.time(),
                              f"{type(exc).__name__}: {exc}",request.provenance)

@dataclass
class WorkloadHandle:
    workload_id:str
    future:Any
    request:WorkloadRequest
    def cancel(self)->bool:return self.future.cancel()
    def done(self)->bool:return self.future.done()
    def result(self,timeout=None)->WorkloadResult:return self.future.result(timeout=timeout)

class GovernedComputeExecutor:
    """Bounded asynchronous research executor. Never a deterministic RT executor."""
    def __init__(self,backends:tuple[ComputeBackend,...]|None=None,maximum_workers:int=2):
        from concurrent.futures import ThreadPoolExecutor
        if maximum_workers<1:raise ValueError("maximum_workers must be positive")
        self.backends=discover_compute_backends() if backends is None else backends
        self.maximum_workers=maximum_workers
        self._pool=ThreadPoolExecutor(max_workers=maximum_workers,thread_name_prefix="joe-compute")
        self._handles={}
    def submit(self,request:WorkloadRequest)->WorkloadHandle:
        if request.budget.maximum_workers>self.maximum_workers:
            raise ValueError("workload worker budget exceeds executor limit")
        if request.requirement.deterministic_required:
            raise ValueError("deterministic RT workloads are forbidden in research compute executor")
        if request.workload_id in self._handles:raise ValueError("duplicate workload identity")
        future=self._pool.submit(execute_workload,request,self.backends)
        h=WorkloadHandle(request.workload_id,future,request);self._handles[request.workload_id]=h;return h
    def get(self,workload_id):return self._handles.get(workload_id)
    def shutdown(self,wait=True):self._pool.shutdown(wait=wait,cancel_futures=True)

def workload_provenance_record(request:WorkloadRequest,result:WorkloadResult)->dict[str,Any]:
    return {"schema":"JOE-COMPUTE-WORKLOAD/1","workload_id":request.workload_id,"operation":request.operation,
            "backend_id":result.backend_id,"status":result.status.value,"run_id":request.run_id,
            "input_count":len(request.inputs),"budget":asdict(request.budget),"provenance":request.provenance,
            "started_at_s":result.started_at_s,"finished_at_s":result.finished_at_s,"diagnostic":result.diagnostic}

def compute_execution_readiness():
    cpu=ComputeBackend("cpu",BackendKind.CPU,BackendStatus.AVAILABLE,"test","cpu",2,1024*1024,("scalar","multicore"),"HOST:test")
    req=WorkloadRequest("w","sum_squares",(1.0,2.0,3.0),ComputeRequirement(),ResourceBudget(1), "SIMULATION: qualification")
    out=execute_workload(req,(cpu,))
    ex=GovernedComputeExecutor((cpu,),maximum_workers=2)
    try:
        h=ex.submit(WorkloadRequest("a","mean",(2.0,4.0),ComputeRequirement(),ResourceBudget(1),"SIMULATION: qualification"))
        async_out=h.result(timeout=2)
    finally:ex.shutdown()
    return {"passed":out.status==WorkloadStatus.SUCCEEDED and out.output==14.0 and async_out.output==3.0 and
                     workload_provenance_record(req,out)["schema"]=="JOE-COMPUTE-WORKLOAD/1",
            "checks":("governed CPU execution","bounded operation registry","asynchronous research executor",
                      "worker-budget enforcement","execution provenance","GPU/HPC no-fake-adapter rejection")}


@dataclass(frozen=True)
class BackendHealth:
    backend_id:str
    status:str
    utilization_percent:float|None
    memory_used_bytes:int|None
    memory_total_bytes:int|None
    temperature_c:float|None
    power_w:float|None
    provenance:str
    diagnostic:str=""
    def __post_init__(self):
        if not self.backend_id.strip() or not self.provenance.strip():raise ValueError("backend health identity/provenance required")
        if self.utilization_percent is not None and not 0<=self.utilization_percent<=100:raise ValueError("utilization outside 0..100")
        if self.temperature_c is not None and self.temperature_c < -273.15:raise ValueError("invalid temperature")
        if self.power_w is not None and self.power_w < 0:raise ValueError("power cannot be negative")

def cpu_health()->BackendHealth:
    util=used=total=None;diag=[]
    try:
        import psutil
        util=float(psutil.cpu_percent(interval=None))
        vm=psutil.virtual_memory();used=int(vm.used);total=int(vm.total)
    except Exception as exc:diag.append(f"psutil unavailable: {type(exc).__name__}")
    return BackendHealth("local.cpu","AVAILABLE",util,used,total,None,None,
                         "HOST: psutil/system APIs","; ".join(diag))

def nvidia_gpu_health()->BackendHealth:
    exe=shutil.which("nvidia-smi")
    if not exe:return BackendHealth("local.gpu.nvidia","UNAVAILABLE",None,None,None,None,None,
                                    "HOST: nvidia-smi discovery","nvidia-smi unavailable")
    try:
        cp=subprocess.run([exe,"--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw",
                           "--format=csv,noheader,nounits"],capture_output=True,text=True,timeout=3)
        if cp.returncode:return BackendHealth("local.gpu.nvidia","DEGRADED",None,None,None,None,None,"HOST: nvidia-smi",cp.stderr.strip())
        vals=[x.strip() for x in cp.stdout.strip().splitlines()[0].split(",")]
        def num(x):
            try:return float(x)
            except:return None
        u,mu,mt,temp,powr=map(num,vals)
        mib=1024*1024
        return BackendHealth("local.gpu.nvidia","AVAILABLE",u,None if mu is None else int(mu*mib),
                             None if mt is None else int(mt*mib),temp,powr,"HOST: nvidia-smi")
    except Exception as exc:
        return BackendHealth("local.gpu.nvidia","DEGRADED",None,None,None,None,None,"HOST: nvidia-smi",f"{type(exc).__name__}: {exc}")

def amd_gpu_health()->BackendHealth:
    exe=shutil.which("amd-smi") or shutil.which("rocm-smi")
    if not exe:return BackendHealth("local.gpu.amd","UNAVAILABLE",None,None,None,None,None,
                                    "HOST: AMD SMI/ROCm SMI discovery","AMD GPU telemetry provider unavailable")
    try:
        if Path(exe).name.lower().startswith("amd-smi"):
            cp=subprocess.run([exe,"metric","--usage","--mem-usage","--temperature","--power","--json"],
                              capture_output=True,text=True,timeout=4)
        else:
            cp=subprocess.run([exe,"--showuse","--showmemuse","--showtemp","--showpower","--json"],
                              capture_output=True,text=True,timeout=4)
        if cp.returncode:return BackendHealth("local.gpu.amd","DEGRADED",None,None,None,None,None,"HOST: "+Path(exe).name,cp.stderr.strip())
        text=cp.stdout
        import re
        def first(pattern):
            m=re.search(pattern,text,re.I)
            return float(m.group(1)) if m else None
        util=first(r'(?:gfx[_ ]?activity|gpu use|gpu[_ ]?use|utilization)"?\s*[:=]\s*"?([0-9.]+)')
        temp=first(r'(?:temperature|temp)"?\s*[:=]\s*"?([0-9.]+)')
        power=first(r'(?:socket[_ ]?power|average graphics package power|power)"?\s*[:=]\s*"?([0-9.]+)')
        return BackendHealth("local.gpu.amd","AVAILABLE",util,None,None,temp,power,"HOST: "+Path(exe).name)
    except Exception as exc:
        return BackendHealth("local.gpu.amd","DEGRADED",None,None,None,None,None,"HOST: "+Path(exe).name,f"{type(exc).__name__}: {exc}")

@dataclass(frozen=True)
class ResourcePolicy:
    maximum_cpu_workers:int
    maximum_memory_fraction:float
    maximum_gpu_temperature_c:float|None=None
    maximum_gpu_power_w:float|None=None
    def __post_init__(self):
        if self.maximum_cpu_workers<1:raise ValueError("CPU worker ceiling must be positive")
        if not 0 < self.maximum_memory_fraction <= 1:raise ValueError("memory fraction must be in (0,1]")
        if self.maximum_gpu_temperature_c is not None and self.maximum_gpu_temperature_c<=0:raise ValueError("temperature ceiling must be positive")
        if self.maximum_gpu_power_w is not None and self.maximum_gpu_power_w<=0:raise ValueError("power ceiling must be positive")

@dataclass(frozen=True)
class PolicyDecision:
    allowed:bool
    reasons:tuple[str,...]
    provenance:str

def evaluate_resource_policy(request:WorkloadRequest,backend:ComputeBackend,health:BackendHealth,policy:ResourcePolicy)->PolicyDecision:
    reasons=[]
    if backend.kind==BackendKind.CPU and request.budget.maximum_workers>policy.maximum_cpu_workers:
        reasons.append("requested CPU workers exceed policy ceiling")
    if request.budget.maximum_memory_bytes is not None and health.memory_total_bytes is not None:
        if request.budget.maximum_memory_bytes > health.memory_total_bytes*policy.maximum_memory_fraction:
            reasons.append("requested memory exceeds policy fraction of detected memory")
    if backend.kind==BackendKind.GPU:
        if policy.maximum_gpu_temperature_c is not None and health.temperature_c is not None and health.temperature_c>policy.maximum_gpu_temperature_c:
            reasons.append("GPU temperature exceeds configured research ceiling")
        if policy.maximum_gpu_power_w is not None and health.power_w is not None and health.power_w>policy.maximum_gpu_power_w:
            reasons.append("GPU power exceeds configured research ceiling")
    return PolicyDecision(not reasons,tuple(reasons),"JOE research compute resource policy")

@dataclass(frozen=True)
class WorkloadHistoryEntry:
    sequence:int
    workload_id:str
    backend_id:str|None
    status:str
    operation:str
    run_id:str|None
    started_at_s:float|None
    finished_at_s:float|None
    provenance:str
    diagnostic:str

class WorkloadHistory:
    def __init__(self):self._entries=[]
    def append(self,request:WorkloadRequest,result:WorkloadResult)->WorkloadHistoryEntry:
        if any(e.workload_id==request.workload_id for e in self._entries):raise ValueError("workload history is append-only by workload identity")
        e=WorkloadHistoryEntry(len(self._entries)+1,request.workload_id,result.backend_id,result.status.value,
                               request.operation,request.run_id,result.started_at_s,result.finished_at_s,request.provenance,result.diagnostic)
        self._entries.append(e);return e
    def entries(self)->tuple[WorkloadHistoryEntry,...]:return tuple(self._entries)
    def by_run(self,run_id:str)->tuple[WorkloadHistoryEntry,...]:return tuple(e for e in self._entries if e.run_id==run_id)

class GovernedComputeManager:
    """Research-compute orchestration with host health, policy and append-only history."""
    def __init__(self,policy:ResourcePolicy|None=None):
        logical=max(1,os.cpu_count() or 1)
        self.policy=policy or ResourcePolicy(maximum_cpu_workers=max(1,logical-1),maximum_memory_fraction=.80)
        self.history=WorkloadHistory()
    def health(self)->tuple[BackendHealth,...]:
        return (cpu_health(),nvidia_gpu_health(),amd_gpu_health())
    def execute(self,request:WorkloadRequest)->WorkloadResult:
        bs=discover_compute_backends();sel=select_backend(bs,request.requirement)
        if sel.status!="SELECTED":
            r=execute_workload(request,bs);self.history.append(request,r);return r
        backend=next(b for b in bs if b.backend_id==sel.selected_backend_id)
        hs={h.backend_id:h for h in self.health()}
        health=hs.get(backend.backend_id,BackendHealth(backend.backend_id,"UNAVAILABLE",None,None,None,None,None,"HOST: no health adapter"))
        decision=evaluate_resource_policy(request,backend,health,self.policy)
        if not decision.allowed:
            import time
            r=WorkloadResult(request.workload_id,backend.backend_id,WorkloadStatus.REJECTED,None,None,time.time(),
                             "; ".join(decision.reasons),request.provenance)
        else:r=execute_workload(request,bs)
        self.history.append(request,r);return r

def compute_v1_release_readiness():
    failures=[];checks=[]
    for name,fn in (("backend inventory",compute_core_readiness),("governed execution",compute_execution_readiness)):
        try:
            q=fn()
            if q["passed"]:checks.append(name+" passed")
            else:failures.append(name+" failed")
        except Exception as exc:failures.append(f"{name}: {type(exc).__name__}: {exc}")
    try:
        cpu=ComputeBackend("cpu",BackendKind.CPU,BackendStatus.AVAILABLE,"test","cpu",4,1000,("scalar",),"HOST:test")
        h=BackendHealth("cpu","AVAILABLE",10,100,1000,None,None,"HOST:test")
        q=WorkloadRequest("w","sum",(1.,2.),ComputeRequirement(),ResourceBudget(3,900),"SIMULATION:qualification")
        d=evaluate_resource_policy(q,cpu,h,ResourcePolicy(2,.5))
        if not d.allowed:checks.append("resource policy rejection passed")
        hist=WorkloadHistory()
        r=WorkloadResult("w","cpu",WorkloadStatus.SUCCEEDED,3,1,2,"","SIMULATION:qualification");hist.append(q,r)
        if hist.entries()[0].sequence==1:checks.append("append-only workload history passed")
        ch=cpu_health()
        if ch.provenance.startswith("HOST:"):checks.append("host health provenance passed")
        ah=amd_gpu_health()
        if ah.provenance.startswith("HOST:"):checks.append("AMD GPU provider/UNAVAILABLE provenance passed")
    except Exception as exc:failures.append(f"governance: {type(exc).__name__}: {exc}")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),
            "notes":("Compute Manager is research-compute authority only; BUS-SAFE and deterministic RT control remain separate.",
                     "Unavailable health sensors remain N/A and are never fabricated.",
                     "GPU/HPC execution requires a real qualified provider adapter before JOE will execute there.")}
