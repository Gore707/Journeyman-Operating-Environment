@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONFAULTHANDLER=1"
rem Prefer Qt software rendering on Windows for launcher stability. This does not disable JOE compute GPU backends.
set "QT_OPENGL=software"
set "QT_QUICK_BACKEND=software"

where py >nul 2>nul
if %errorlevel%==0 (
    set "PY=py -3.12"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo [JOE] Python 3.12 was not found. Install Python 3.12 and try again.
        pause
        exit /b 1
    )
    set "PY=python"
)

if not exist ".venv\Scripts\python.exe" (
    echo [JOE] Creating local Python environment...
    %PY% -m venv .venv
    if errorlevel 1 goto :fail
)

set "VPY=.venv\Scripts\python.exe"
%VPY% -c "import PySide6, psutil, pyqtgraph, numpy" >nul 2>nul
if errorlevel 1 (
    echo [JOE] Installing required Python packages...
    %VPY% -m pip install --disable-pip-version-check -r requirements.txt
    if errorlevel 1 goto :fail
)

echo [JOE] Starting JOE v1.6.1...
%VPY% -X faulthandler -m journeyman.main
set "RC=%errorlevel%"
if not "%RC%"=="0" (
    echo.
    echo [JOE] JOE exited with error code %RC%.
    echo [JOE] Check logs\joe.log and the fatal output above for details.
    pause
)
exit /b %RC%

:fail
echo.
echo [JOE] Startup failed. Check the messages above for details.
pause
exit /b 1
