"""Stress-Energy / Einstein Tensor Workbench core.

Energy-condition analysis of effective stress-energy tensors. Results describe
the source required by a spacetime model; they do not establish material
realizability.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Sequence
import math
import numpy as np
from .geometry import StressEnergyEvaluation, morris_thorne_metric, stress_energy_from_geometry

@dataclass(frozen=True)
class EnergyConditionResult:
    nec_axes:tuple[float,float,float]
    nec_satisfied:tuple[bool,bool,bool]
    wec_satisfied:bool
    sec_satisfied:bool
    dec_satisfied:bool
    trace_j_m3:float
    minimum_nec_j_m3:float
    provenance:str

def energy_conditions(stress:StressEnergyEvaluation,*,tolerance_j_m3:float=0.0)->EnergyConditionResult:
    tol=float(tolerance_j_m3)
    if not math.isfinite(tol) or tol<0:raise ValueError("tolerance must be finite and nonnegative")
    rho=float(stress.energy_density_j_m3);p=tuple(float(x) for x in stress.principal_pressures_pa)
    vals=tuple(rho+x for x in p)
    nec=tuple(x>=-tol for x in vals)
    wec=rho>=-tol and all(nec)
    # For diagonal type-I stress-energy: SEC iff rho+p_i>=0 and rho+sum p_i>=0.
    sec=all(nec) and (rho+sum(p)>=-tol)
    # DEC for type-I: rho>=0 and |p_i|<=rho.
    dec=rho>=-tol and all(abs(x)<=rho+tol for x in p)
    trace=-rho+sum(p)
    return EnergyConditionResult(vals,nec,wec,sec,dec,trace,min(vals),
        "Type-I orthonormal-frame condition test; MODEL-derived effective stress-energy.")

@dataclass(frozen=True)
class ExoticityResult:
    radial_exoticity_j_m3:float
    normalized_radial_exoticity:float|None
    requires_radial_nec_violation:bool
    interpretation:str

def radial_exoticity(stress:StressEnergyEvaluation)->ExoticityResult:
    # Positive here means magnitude of radial NEC violation.
    x=-float(stress.radial_nec_j_m3)
    scale=abs(float(stress.energy_density_j_m3))+abs(float(stress.principal_pressures_pa[0]))
    normalized=(x/scale if scale>0 else None)
    return ExoticityResult(x,normalized,x>0,
        "Positive exoticity means rho_E + p_r < 0 for this effective model source; it is not a material feasibility claim.")

@dataclass(frozen=True)
class ShellIntegral:
    r_inner_m:float
    r_outer_m:float
    samples:int
    integrated_energy_j:float
    integrated_radial_nec_j:float
    provenance:str

def integrate_spherical_shell(radii_m:Sequence[float],energy_density_j_m3:Sequence[float],
                              radial_nec_j_m3:Sequence[float])->ShellIntegral:
    r=np.asarray(tuple(float(x) for x in radii_m),dtype=float)
    rho=np.asarray(tuple(float(x) for x in energy_density_j_m3),dtype=float)
    nec=np.asarray(tuple(float(x) for x in radial_nec_j_m3),dtype=float)
    if len(r)<2 or rho.shape!=r.shape or nec.shape!=r.shape:raise ValueError("shell integration arrays must have equal length >= 2")
    if not np.all(np.isfinite(r)) or not np.all(np.isfinite(rho)) or not np.all(np.isfinite(nec)):raise ValueError("shell integration values must be finite")
    if np.any(r<=0) or np.any(np.diff(r)<=0):raise ValueError("radii must be positive and strictly increasing")
    weight=4*math.pi*r*r
    # trapezoidal integration over proper coordinate-volume approximation 4*pi*r^2 dr.
    # This is intentionally named coordinate-shell, not a general invariant volume integral.
    e=float(np.trapezoid(weight*rho,r));n=float(np.trapezoid(weight*nec,r))
    return ShellIntegral(float(r[0]),float(r[-1]),len(r),e,n,
        "Spherical coordinate-shell integral using 4πr²dr trapezoidal quadrature; not a general invariant proper-volume integral.")

@dataclass(frozen=True)
class MorrisThorneSweepPoint:
    throat_radius_m:float
    radius_ratio:float
    radius_m:float
    energy_density_j_m3:float
    radial_pressure_pa:float
    radial_nec_j_m3:float
    radial_exoticity_j_m3:float

def morris_thorne_sweep(throat_radii_m:Sequence[float],radius_ratios:Sequence[float],*,relative_step:float=5e-5):
    r0s=tuple(float(x) for x in throat_radii_m);ratios=tuple(float(x) for x in radius_ratios)
    if not r0s or not ratios:raise ValueError("sweep axes cannot be empty")
    if any((not math.isfinite(x) or x<=0) for x in r0s):raise ValueError("throat radii must be positive finite values")
    if any((not math.isfinite(x) or x<=1) for x in ratios):raise ValueError("radius ratios must be finite and > 1")
    out=[]
    for r0 in r0s:
        model=morris_thorne_metric(throat_radius=r0)
        for ratio in ratios:
            r=r0*ratio
            t=stress_energy_from_geometry(model,(0,r,math.pi/2,math.pi),relative_step=relative_step)
            out.append(MorrisThorneSweepPoint(r0,ratio,r,t.energy_density_j_m3,t.principal_pressures_pa[0],
                                              t.radial_nec_j_m3,radial_exoticity(t).radial_exoticity_j_m3))
    return tuple(out)


@dataclass(frozen=True)
class ProperVolumeIntegral:
    r_inner_m:float
    r_outer_m:float
    samples:int
    integrated_energy_j:float
    integrated_radial_nec_j:float
    volume_m3:float
    provenance:str

def morris_thorne_proper_volume_integral(*,throat_radius:float,r_outer:float,samples:int=801,
                                         throat_offset_fraction:float=1e-4,relative_step:float=5e-5)->ProperVolumeIntegral:
    """Integrate model source over a t=const Morris-Thorne spatial slice.

    dV = 4 pi r^2 dr / sqrt(1-b(r)/r), for the default b=r0^2/r model.
    The curvature-coordinate throat is integrably singular, so integration begins
    at r0*(1+offset) and reports that cutoff explicitly.
    """
    r0=float(throat_radius);ro=float(r_outer);n=int(samples);eps=float(throat_offset_fraction)
    if not math.isfinite(r0) or r0<=0 or not math.isfinite(ro) or ro<=r0:raise ValueError("require finite r_outer > throat_radius > 0")
    if n<101 or n%2==0:raise ValueError("samples must be an odd integer >= 101")
    if not math.isfinite(eps) or eps<=0 or eps>=0.1:raise ValueError("throat offset fraction must be in (0,0.1)")
    ri=r0*(1+eps);r=np.linspace(ri,ro,n);model=morris_thorne_metric(throat_radius=r0)
    rho=[];nec=[]
    for x in r:
        t=stress_energy_from_geometry(model,(0,float(x),math.pi/2,math.pi),relative_step=relative_step)
        rho.append(t.energy_density_j_m3);nec.append(t.radial_nec_j_m3)
    b=r0*r0/r
    jac=4*math.pi*r*r/np.sqrt(1-b/r)
    energy=float(np.trapezoid(jac*np.asarray(rho),r));nint=float(np.trapezoid(jac*np.asarray(nec),r))
    volume=float(np.trapezoid(jac,r))
    return ProperVolumeIntegral(ri,ro,n,energy,nint,volume,
        f"Proper spatial-volume integral on t=const slice for b=r0^2/r; lower cutoff r/r0={1+eps:.8g}; MODEL output.")

@dataclass(frozen=True)
class SensitivityPoint:
    throat_radius_m:float
    radius_ratio:float
    radial_nec_j_m3:float
    logarithmic_sensitivity_r0:float

def morris_thorne_nec_sensitivity(*,throat_radius:float,radius_ratio:float=2.0,fractional_step:float=1e-3)->SensitivityPoint:
    r0=float(throat_radius);q=float(radius_ratio);h=float(fractional_step)
    if r0<=0 or q<=1 or h<=0 or h>=0.1 or not all(math.isfinite(x) for x in (r0,q,h)):raise ValueError("invalid sensitivity inputs")
    def nec_at(a):
        r=a*q;t=stress_energy_from_geometry(morris_thorne_metric(throat_radius=a),(0,r,math.pi/2,math.pi),relative_step=5e-5)
        return t.radial_nec_j_m3
    f0=nec_at(r0);fp=nec_at(r0*(1+h));fm=nec_at(r0*(1-h))
    # d ln |f| / d ln r0, central finite difference.
    sens=(math.log(abs(fp))-math.log(abs(fm)))/(math.log(r0*(1+h))-math.log(r0*(1-h)))
    return SensitivityPoint(r0,q,f0,sens)

@dataclass(frozen=True)
class UncertainScalar:
    value:float
    standard_uncertainty:float
    unit:str
    method:str

def propagate_throat_radius_uncertainty(*,throat_radius:float,standard_uncertainty_m:float,
                                        radius_ratio:float=2.0)->UncertainScalar:
    """First-order propagation of r0 uncertainty into radial NEC at fixed r/r0."""
    r0=float(throat_radius);u=float(standard_uncertainty_m);q=float(radius_ratio)
    if r0<=0 or u<0 or q<=1 or not all(math.isfinite(x) for x in (r0,u,q)):raise ValueError("invalid uncertainty inputs")
    delta=max(r0*1e-5,u*1e-3,1e-9)
    if delta>=r0:delta=r0*1e-3
    def f(a):
        t=stress_energy_from_geometry(morris_thorne_metric(throat_radius=a),(0,a*q,math.pi/2,math.pi),relative_step=5e-5)
        return t.radial_nec_j_m3
    value=f(r0);deriv=(f(r0+delta)-f(r0-delta))/(2*delta)
    return UncertainScalar(value,abs(deriv)*u,"J/m^3",
        "First-order standard-uncertainty propagation from throat radius at fixed r/r0; excludes model-form and numerical uncertainty.")

@dataclass(frozen=True)
class EnergyConditionMapPoint:
    throat_radius_m:float
    radius_ratio:float
    nec:bool
    wec:bool
    sec:bool
    dec:bool
    minimum_nec_j_m3:float

def morris_thorne_condition_map(throat_radii_m:Sequence[float],radius_ratios:Sequence[float]):
    points=morris_thorne_sweep(throat_radii_m,radius_ratios);out=[]
    for p in points:
        t=stress_energy_from_geometry(morris_thorne_metric(throat_radius=p.throat_radius_m),
            (0,p.radius_m,math.pi/2,math.pi),relative_step=5e-5)
        c=energy_conditions(t)
        out.append(EnergyConditionMapPoint(p.throat_radius_m,p.radius_ratio,all(c.nec_satisfied),
                                           c.wec_satisfied,c.sec_satisfied,c.dec_satisfied,c.minimum_nec_j_m3))
    return tuple(out)


@dataclass(frozen=True)
class StressEnergyGuardianContract:
    schema:str
    model_id:str
    model_revision:str
    data_origin:str
    energy_density_j_m3:float
    principal_pressures_pa:tuple[float,float,float]
    nec_satisfied:tuple[bool,bool,bool]
    wec_satisfied:bool
    sec_satisfied:bool
    dec_satisfied:bool
    minimum_nec_j_m3:float
    radial_exoticity_j_m3:float
    provenance:str
    authority:str

def stress_energy_guardian_contract(stress:StressEnergyEvaluation)->StressEnergyGuardianContract:
    c=energy_conditions(stress);x=radial_exoticity(stress)
    return StressEnergyGuardianContract("JOE-GUARDIAN-STRESS-ENERGY/1",stress.model_id,stress.model_revision,
        "SIMULATION/MODEL",stress.energy_density_j_m3,stress.principal_pressures_pa,c.nec_satisfied,
        c.wec_satisfied,c.sec_satisfied,c.dec_satisfied,c.minimum_nec_j_m3,x.radial_exoticity_j_m3,
        stress.provenance,"READ_ONLY_ADVISORY; no control or safety authority")

@dataclass(frozen=True)
class StressEnergyReleaseReadiness:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    notes:tuple[str,...]

def stress_energy_release_readiness()->StressEnergyReleaseReadiness:
    checks=[];fail=[];notes=[]
    try:
        from .geometry import minkowski_metric
        z=stress_energy_from_geometry(minkowski_metric(),(0,0,0,0))
        c=energy_conditions(z,tolerance_j_m3=1e-3)
        if all(c.nec_satisfied) and c.wec_satisfied and c.sec_satisfied and c.dec_satisfied:
            checks.append("Minkowski zero-source energy-condition reference passed")
        else:fail.append("Minkowski energy-condition reference failed")
        mt=stress_energy_from_geometry(morris_thorne_metric(throat_radius=2),(0,4,math.pi/2,math.pi),relative_step=5e-5)
        ec=energy_conditions(mt);ex=radial_exoticity(mt)
        if not ec.nec_satisfied[0] and ex.radial_exoticity_j_m3>0:
            checks.append("Morris-Thorne radial NEC/exoticity requirement passed")
        else:fail.append("Morris-Thorne NEC/exoticity reference failed")
        sens=morris_thorne_nec_sensitivity(throat_radius=2,radius_ratio=2)
        if abs(sens.logarithmic_sensitivity_r0+2)<2e-3:checks.append("fixed-ratio NEC scaling reference passed")
        else:fail.append("NEC throat-radius scaling reference failed")
        u=propagate_throat_radius_uncertainty(throat_radius=2,standard_uncertainty_m=.001)
        if u.standard_uncertainty>0:checks.append("first-order uncertainty propagation passed")
        else:fail.append("uncertainty propagation failed")
        gc=stress_energy_guardian_contract(mt)
        if gc.schema=="JOE-GUARDIAN-STRESS-ENERGY/1" and gc.data_origin=="SIMULATION/MODEL" and "READ_ONLY" in gc.authority:
            checks.append("Guardian contract provenance/authority passed")
        else:fail.append("Guardian contract invalid")
    except Exception as exc:fail.append(f"release-readiness exception: {type(exc).__name__}: {exc}")
    notes.append("Energy-condition violation quantifies a model requirement, not availability of exotic matter.")
    notes.append("Proper-volume totals depend on model, integration bounds, throat cutoff, and numerical resolution.")
    return StressEnergyReleaseReadiness(not fail,tuple(checks),tuple(fail),tuple(notes))
