from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.scientific_data import (ImmutableRunDataStore,create_manifest,register_artifact,verify_artifact,
 data_guardian_contract,scientific_data_core_readiness,list_run_entries,query_records,audit_run,
 verify_manifest_chain,provenance_summary,scientific_data_archive_readiness,validate_lineage,
 write_lineage,load_lineage,trace_record,export_audit_report,scientific_data_v1_release_readiness)
from journeyman.core.paths import RUNS_DIR
SCIENTIFIC_DATA_MODULE=ModuleDescriptor(module_id="journeyman.scientific-data",name="Scientific Data & Provenance",
 version="1.0.0",requires=("joe.core",),provides=("joe.scientific-data",))
class ScientificDataService:
    def __init__(self):self.store=ImmutableRunDataStore(RUNS_DIR/"scientific-data")
    create_manifest=staticmethod(create_manifest)
    register_artifact=staticmethod(register_artifact)
    verify_artifact=staticmethod(verify_artifact)
    guardian_contract=staticmethod(data_guardian_contract)
    release_readiness=staticmethod(scientific_data_v1_release_readiness)
    archive_readiness=staticmethod(scientific_data_archive_readiness)
    def list_runs(self):return list_run_entries(self.store)
    def query_records(self,**kwargs):return query_records(self.store,**kwargs)
    def audit_run(self,run_id):return audit_run(self.store,run_id)
    def verify_manifest_chain(self):return verify_manifest_chain(self.store)
    def provenance_summary(self):return provenance_summary(self.store)
    validate_lineage=staticmethod(validate_lineage)
    write_lineage=staticmethod(write_lineage)
    load_lineage=staticmethod(load_lineage)
    trace_record=staticmethod(trace_record)
    export_audit_report=staticmethod(export_audit_report)
class ScientificDataInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_scientific_data_module(runtime:ModuleRuntime):
    svc=ScientificDataService();runtime.register(SCIENTIFIC_DATA_MODULE,ScientificDataInstance(svc))
    runtime.activate("journeyman.scientific-data")
    runtime.publish_service("journeyman.scientific-data","joe.scientific-data",svc);return svc
