"""Metrology & Temporal Navigation — MET-001A.

Typed clock identities, time domains, clock observations, synchronization, offset,
drift, uncertainty and Guardian-readable timing integrity. No physical clock source
is implied unless a future authenticated HARDWARE adapter explicitly supplies it.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Any
import math

from .state_events import DataOrigin

class MetrologyStatus(str,Enum):
    PASS="PASS"
    NONCONVERGED="NONCONVERGED"
    DOMAIN_INVALID="DOMAIN_INVALID"
    PRECISION_INSUFFICIENT="PRECISION_INSUFFICIENT"
    INPUT_INCONSISTENT="INPUT_INCONSISTENT"
    NUMERICAL_INSTABILITY="NUMERICAL_INSTABILITY"
    MODEL_UNAVAILABLE="MODEL_UNAVAILABLE"
    UNKNOWN_PHYSICS="UNKNOWN_PHYSICS"

class TimeDomain(str,Enum):
    UTC="UTC"
    MONOTONIC="MONOTONIC"
    EXPERIMENT_ELAPSED="EXPERIMENT_ELAPSED"
    SIMULATION="SIMULATION"
    PROPER_TIME="PROPER_TIME"
    COORDINATE_TIME="COORDINATE_TIME"

class ClockQuality(str,Enum):
    GOOD="GOOD"
    DEGRADED="DEGRADED"
    STALE="STALE"
    UNAVAILABLE="UNAVAILABLE"
    INVALID="INVALID"

@dataclass(frozen=True)
class ClockIdentity:
    clock_id:str
    name:str
    time_domain:TimeDomain
    time_scale:str
    frame_id:str|None
    epoch_id:str|None
    provenance:str
    origin:DataOrigin
    def __post_init__(self):
        if not self.clock_id.strip() or not self.name.strip() or not self.time_scale.strip() or not self.provenance.strip():
            raise ValueError("clock identity/name/time scale/provenance required")
        if self.time_domain in (TimeDomain.PROPER_TIME,TimeDomain.COORDINATE_TIME) and not self.epoch_id:
            raise ValueError("proper/coordinate time clock requires declared epoch")

@dataclass(frozen=True)
class ClockObservation:
    clock:ClockIdentity
    reading_s:float
    standard_uncertainty_s:float
    observed_at_s:float
    sequence:int
    quality:ClockQuality
    provenance:str
    origin:DataOrigin
    def __post_init__(self):
        if self.origin!=self.clock.origin:raise ValueError("observation origin must match clock origin")
        for x in (self.reading_s,self.standard_uncertainty_s,self.observed_at_s):
            if not math.isfinite(x):raise ValueError("finite clock values required")
        if self.standard_uncertainty_s<0:raise ValueError("nonnegative uncertainty required")
        if self.sequence<0:raise ValueError("nonnegative sequence required")
        if not self.provenance.strip():raise ValueError("observation provenance required")

@dataclass(frozen=True)
class ClockOffsetEstimate:
    clock_a_id:str
    clock_b_id:str
    offset_a_minus_b_s:float
    standard_uncertainty_s:float
    significance_sigma:float
    status:MetrologyStatus
    provenance:str

def clock_offset(a:ClockObservation,b:ClockObservation,*,provenance:str)->ClockOffsetEstimate:
    if a.clock.time_domain!=b.clock.time_domain:raise ValueError("clock offset requires same time domain")
    if a.clock.time_scale!=b.clock.time_scale:raise ValueError("clock offset requires same time scale")
    if a.clock.epoch_id!=b.clock.epoch_id:raise ValueError("clock offset requires same epoch")
    if a.clock.frame_id!=b.clock.frame_id:raise ValueError("clock offset requires same frame")
    d=a.reading_s-b.reading_s;u=math.hypot(a.standard_uncertainty_s,b.standard_uncertainty_s)
    sig=abs(d)/u if u>0 else (math.inf if d else 0.0)
    status=MetrologyStatus.PASS if a.quality==ClockQuality.GOOD and b.quality==ClockQuality.GOOD else MetrologyStatus.PRECISION_INSUFFICIENT
    return ClockOffsetEstimate(a.clock.clock_id,b.clock.clock_id,d,u,sig,status,provenance)

@dataclass(frozen=True)
class DriftEstimate:
    clock_id:str
    reference_clock_id:str
    fractional_frequency_offset:float
    drift_s_per_s:float
    interval_s:float
    standard_uncertainty_s_per_s:float
    status:MetrologyStatus
    provenance:str

def estimate_clock_drift(a0:ClockObservation,b0:ClockObservation,a1:ClockObservation,b1:ClockObservation,*,provenance:str)->DriftEstimate:
    if a0.clock.clock_id!=a1.clock.clock_id or b0.clock.clock_id!=b1.clock.clock_id:
        raise ValueError("clock identities must remain stable across drift observations")
    o0=clock_offset(a0,b0,provenance=provenance);o1=clock_offset(a1,b1,provenance=provenance)
    dt=b1.reading_s-b0.reading_s
    if not math.isfinite(dt) or dt<=0:raise ValueError("positive reference-clock interval required")
    rate=(o1.offset_a_minus_b_s-o0.offset_a_minus_b_s)/dt
    u=math.hypot(o0.standard_uncertainty_s,o1.standard_uncertainty_s)/dt
    return DriftEstimate(a0.clock.clock_id,b0.clock.clock_id,rate,rate,dt,u,
        MetrologyStatus.PASS if o0.status==o1.status==MetrologyStatus.PASS else MetrologyStatus.PRECISION_INSUFFICIENT,provenance)

@dataclass(frozen=True)
class SynchronizationPolicy:
    maximum_absolute_offset_s:float
    maximum_standard_uncertainty_s:float
    maximum_age_s:float
    maximum_absolute_drift_s_per_s:float
    def __post_init__(self):
        vals=(self.maximum_absolute_offset_s,self.maximum_standard_uncertainty_s,self.maximum_age_s,self.maximum_absolute_drift_s_per_s)
        if any(not math.isfinite(x) or x<0 for x in vals):raise ValueError("synchronization limits must be finite and nonnegative")

@dataclass(frozen=True)
class SynchronizationAssessment:
    synchronized:bool
    status:MetrologyStatus
    offset:ClockOffsetEstimate
    drift:DriftEstimate|None
    age_a_s:float
    age_b_s:float
    failures:tuple[str,...]
    provenance:str

def assess_synchronization(a:ClockObservation,b:ClockObservation,policy:SynchronizationPolicy,*,now_s:float,
                           drift:DriftEstimate|None=None,provenance:str)->SynchronizationAssessment:
    if not math.isfinite(now_s):raise ValueError("finite assessment time required")
    off=clock_offset(a,b,provenance=provenance);age_a=max(0.,now_s-a.observed_at_s);age_b=max(0.,now_s-b.observed_at_s)
    fail=[]
    if abs(off.offset_a_minus_b_s)>policy.maximum_absolute_offset_s:fail.append("clock offset exceeds declared limit")
    if off.standard_uncertainty_s>policy.maximum_standard_uncertainty_s:fail.append("clock synchronization uncertainty exceeds declared limit")
    if age_a>policy.maximum_age_s:fail.append(f"clock {a.clock.clock_id} observation is stale")
    if age_b>policy.maximum_age_s:fail.append(f"clock {b.clock.clock_id} observation is stale")
    if a.quality!=ClockQuality.GOOD:fail.append(f"clock {a.clock.clock_id} quality is {a.quality.value}")
    if b.quality!=ClockQuality.GOOD:fail.append(f"clock {b.clock.clock_id} quality is {b.quality.value}")
    if drift and abs(drift.drift_s_per_s)>policy.maximum_absolute_drift_s_per_s:fail.append("clock drift exceeds declared limit")
    status=MetrologyStatus.PASS if not fail else MetrologyStatus.PRECISION_INSUFFICIENT
    return SynchronizationAssessment(not fail,status,off,drift,age_a,age_b,tuple(fail),provenance)

@dataclass(frozen=True)
class TemporalCoordinate:
    value_s:float
    time_domain:TimeDomain
    time_scale:str
    clock_id:str
    frame_id:str|None
    epoch_id:str|None
    standard_uncertainty_s:float
    provenance:str
    origin:DataOrigin
    def __post_init__(self):
        if not math.isfinite(self.value_s) or not math.isfinite(self.standard_uncertainty_s) or self.standard_uncertainty_s<0:
            raise ValueError("valid temporal coordinate and uncertainty required")
        if not self.clock_id.strip() or not self.time_scale.strip() or not self.provenance.strip():raise ValueError("typed temporal identity required")

@dataclass(frozen=True)
class MetrologyGuardianContract:
    schema:str
    status:str
    facts:dict[str,Any]
    provenance:str
    authority:str

def metrology_guardian_contract(assessment:SynchronizationAssessment)->MetrologyGuardianContract:
    facts={"synchronized":assessment.synchronized,"status":assessment.status.value,
           "clock_a_id":assessment.offset.clock_a_id,"clock_b_id":assessment.offset.clock_b_id,
           "offset_a_minus_b_s":assessment.offset.offset_a_minus_b_s,
           "standard_uncertainty_s":assessment.offset.standard_uncertainty_s,
           "significance_sigma":assessment.offset.significance_sigma,
           "age_a_s":assessment.age_a_s,"age_b_s":assessment.age_b_s,
           "failures":assessment.failures,
           "drift_s_per_s":assessment.drift.drift_s_per_s if assessment.drift else None}
    return MetrologyGuardianContract("JOE-GUARDIAN-METROLOGY/1",assessment.status.value,facts,assessment.provenance,
        "READ_ONLY_ADVISORY; timing integrity may support HOLD/ABORT recommendations but cannot bypass BUS-SAFE or deterministic interlocks")

@dataclass(frozen=True)
class MetrologyReleaseReadiness:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    notes:tuple[str,...]

def metrology_core_readiness()->MetrologyReleaseReadiness:
    checks=[];fail=[]
    try:
        c1=ClockIdentity("A","Clock A",TimeDomain.SIMULATION,"SIM","f","e","MET readiness",DataOrigin.SIMULATION)
        c2=ClockIdentity("B","Clock B",TimeDomain.SIMULATION,"SIM","f","e","MET readiness",DataOrigin.SIMULATION)
        a0=ClockObservation(c1,0,1e-6,0,0,ClockQuality.GOOD,"MET readiness",DataOrigin.SIMULATION)
        b0=ClockObservation(c2,0,1e-6,0,0,ClockQuality.GOOD,"MET readiness",DataOrigin.SIMULATION)
        a1=ClockObservation(c1,10.000001,1e-6,10,1,ClockQuality.GOOD,"MET readiness",DataOrigin.SIMULATION)
        b1=ClockObservation(c2,10,1e-6,10,1,ClockQuality.GOOD,"MET readiness",DataOrigin.SIMULATION)
        d=estimate_clock_drift(a0,b0,a1,b1,provenance="MET readiness")
        if abs(d.drift_s_per_s-1e-7)<1e-12:checks.append("clock drift estimation passed")
        pol=SynchronizationPolicy(1e-5,1e-5,1,1e-6)
        q=assess_synchronization(a1,b1,pol,now_s=10,drift=d,provenance="MET readiness")
        if q.synchronized:checks.append("offset/uncertainty/freshness synchronization gate passed")
        if metrology_guardian_contract(q).schema=="JOE-GUARDIAN-METROLOGY/1":checks.append("Guardian timing-integrity contract passed")
        tc=TemporalCoordinate(10,TimeDomain.SIMULATION,"SIM","A","f","e",1e-6,"MET readiness",DataOrigin.SIMULATION)
        if tc.clock_id=="A":checks.append("typed temporal coordinate passed")
    except Exception as exc:fail.append(f"{type(exc).__name__}: {exc}")
    return MetrologyReleaseReadiness(not fail,tuple(checks),tuple(fail),(
        "MET-001A qualifies typed timing/metrology software only.",
        "No physical precision clock, GNSS, PTP, NTP, optical-clock or laboratory timing source is asserted.",
        "Proper time and coordinate time remain distinct typed domains."))


@dataclass(frozen=True)
class ClockHistory:
    clock:ClockIdentity
    observations:tuple[ClockObservation,...]
    provenance:str
    def __post_init__(self):
        if not self.provenance.strip():raise ValueError("history provenance required")
        last_seq=-1;last_t=-math.inf
        for x in self.observations:
            if x.clock.clock_id!=self.clock.clock_id:raise ValueError("history clock identity mismatch")
            if x.sequence<=last_seq:raise ValueError("clock history sequences must strictly increase")
            if x.observed_at_s<=last_t:raise ValueError("clock history observation times must strictly increase")
            last_seq=x.sequence;last_t=x.observed_at_s

def append_clock_observation(history:ClockHistory,observation:ClockObservation)->ClockHistory:
    return ClockHistory(history.clock,history.observations+(observation,),history.provenance)

@dataclass(frozen=True)
class AllanDeviationPoint:
    averaging_time_s:float
    allan_deviation:float
    pair_count:int

def allan_deviation(history:ClockHistory,*,averaging_samples:int=1)->AllanDeviationPoint:
    n=int(averaging_samples)
    if n<1:raise ValueError("averaging_samples must be >= 1")
    obs=history.observations
    if len(obs)<2*n+1:raise ValueError("insufficient clock observations for Allan deviation")
    dts=[obs[i+1].observed_at_s-obs[i].observed_at_s for i in range(len(obs)-1)]
    base=sum(dts)/len(dts)
    if base<=0 or any(abs(x-base)>max(1e-12,abs(base)*1e-9) for x in dts):
        raise ValueError("MET-001B Allan reference requires uniformly sampled history")
    y=[]
    for i in range(0,len(obs)-n,n):
        if i+n>=len(obs):break
        elapsed=obs[i+n].reading_s-obs[i].reading_s
        y.append(elapsed/(n*base)-1.0)
    if len(y)<2:raise ValueError("insufficient adjacent fractional-frequency averages")
    diffs=[y[i+1]-y[i] for i in range(len(y)-1)]
    adev=math.sqrt(sum(x*x for x in diffs)/(2*len(diffs)))
    return AllanDeviationPoint(n*base,adev,len(diffs))

@dataclass(frozen=True)
class ClockEnsembleMember:
    observation:ClockObservation
    weight:float
    def __post_init__(self):
        if not math.isfinite(self.weight) or self.weight<=0:raise ValueError("ensemble weight must be positive finite")

@dataclass(frozen=True)
class EnsembleTimeEstimate:
    reading_s:float
    standard_uncertainty_s:float
    member_clock_ids:tuple[str,...]
    normalized_weights:tuple[float,...]
    time_domain:TimeDomain
    time_scale:str
    frame_id:str|None
    epoch_id:str|None
    provenance:str
    origin:DataOrigin

def ensemble_time(members:tuple[ClockEnsembleMember,...],*,provenance:str)->EnsembleTimeEstimate:
    if not members:raise ValueError("clock ensemble requires members")
    first=members[0].observation
    for m in members:
        o=m.observation
        if (o.clock.time_domain,o.clock.time_scale,o.clock.frame_id,o.clock.epoch_id)!=(first.clock.time_domain,first.clock.time_scale,first.clock.frame_id,first.clock.epoch_id):
            raise ValueError("ensemble clocks require common time domain/scale/frame/epoch")
        if o.origin!=first.origin:raise ValueError("ensemble origins must match")
    total=sum(m.weight for m in members);w=tuple(m.weight/total for m in members)
    value=sum(x*member.observation.reading_s for x,member in zip(w,members))
    u=math.sqrt(sum((x*member.observation.standard_uncertainty_s)**2 for x,member in zip(w,members)))
    return EnsembleTimeEstimate(value,u,tuple(m.observation.clock.clock_id for m in members),w,
        first.clock.time_domain,first.clock.time_scale,first.clock.frame_id,first.clock.epoch_id,provenance,first.origin)

@dataclass(frozen=True)
class SynchronizationLink:
    link_id:str
    clock_a_id:str
    clock_b_id:str
    assessment:SynchronizationAssessment
    covariance_s2:float=0.0
    def __post_init__(self):
        if not self.link_id.strip():raise ValueError("link identity required")
        if not math.isfinite(self.covariance_s2):raise ValueError("finite covariance required")

@dataclass(frozen=True)
class SynchronizationNetwork:
    links:tuple[SynchronizationLink,...]
    clock_ids:tuple[str,...]
    synchronized:bool
    failed_link_ids:tuple[str,...]
    maximum_absolute_offset_s:float
    provenance:str

def synchronization_network(links:tuple[SynchronizationLink,...],*,provenance:str)->SynchronizationNetwork:
    if not links:raise ValueError("network requires synchronization links")
    ids=set();failed=[];mx=0.
    for link in links:
        ids.update((link.clock_a_id,link.clock_b_id));mx=max(mx,abs(link.assessment.offset.offset_a_minus_b_s))
        if not link.assessment.synchronized:failed.append(link.link_id)
    # Connectivity is required: all declared clocks must be in one connected component.
    adj={x:set() for x in ids}
    for link in links:
        adj[link.clock_a_id].add(link.clock_b_id);adj[link.clock_b_id].add(link.clock_a_id)
    seen=set();stack=[next(iter(ids))]
    while stack:
        x=stack.pop()
        if x in seen:continue
        seen.add(x);stack.extend(adj[x]-seen)
    if seen!=ids:failed.append("NETWORK_DISCONNECTED")
    return SynchronizationNetwork(tuple(links),tuple(sorted(ids)),not failed,tuple(failed),mx,provenance)

@dataclass(frozen=True)
class MouthTemporalMeasurement:
    mouth_a_clock_id:str
    mouth_b_clock_id:str
    proper_time_offset_a_minus_b_s:float
    standard_uncertainty_s:float
    significance_sigma:float
    synchronized:bool
    status:MetrologyStatus
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def mouth_temporal_measurement(a:ClockObservation,b:ClockObservation,policy:SynchronizationPolicy,*,now_s:float,provenance:str)->MouthTemporalMeasurement:
    if a.clock.time_domain!=TimeDomain.PROPER_TIME or b.clock.time_domain!=TimeDomain.PROPER_TIME:
        raise ValueError("Mouth temporal measurement requires PROPER_TIME clocks")
    q=assess_synchronization(a,b,policy,now_s=now_s,provenance=provenance)
    return MouthTemporalMeasurement(a.clock.clock_id,b.clock.clock_id,q.offset.offset_a_minus_b_s,
        q.offset.standard_uncertainty_s,q.offset.significance_sigma,q.synchronized,q.status,provenance,a.origin)

@dataclass(frozen=True)
class TemporalNavigationState:
    mouth_measurement:MouthTemporalMeasurement
    separation_m:float
    separation_standard_uncertainty_m:float
    coordinate_frame_id:str
    epoch_id:str
    simulation_time_s:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if self.separation_m<0 or self.separation_standard_uncertainty_m<0:raise ValueError("nonnegative separation/uncertainty required")
        if not all(math.isfinite(x) for x in (self.separation_m,self.separation_standard_uncertainty_m,self.simulation_time_s)):
            raise ValueError("finite temporal-navigation state required")
        if not self.coordinate_frame_id.strip() or not self.epoch_id.strip():raise ValueError("frame and epoch required")

def temporal_navigation_from_twin(mouth_measurement:MouthTemporalMeasurement,twin_mouth_monitor,*,simulation_time_s:float,provenance:str)->TemporalNavigationState:
    if mouth_measurement.origin!=DataOrigin.SIMULATION:raise ValueError("MET-001B Twin coupling requires SIMULATION mouth measurement")
    return TemporalNavigationState(mouth_measurement,float(twin_mouth_monitor.separation_m),
        float(twin_mouth_monitor.combined_position_standard_uncertainty_m),twin_mouth_monitor.frame_id,
        twin_mouth_monitor.epoch_id,float(simulation_time_s),provenance)

def expanded_metrology_guardian_contract(assessment:SynchronizationAssessment,*,network:SynchronizationNetwork|None=None,
                                         mouth:MouthTemporalMeasurement|None=None,
                                         temporal_navigation:TemporalNavigationState|None=None)->MetrologyGuardianContract:
    base=metrology_guardian_contract(assessment);facts=dict(base.facts)
    if network:facts["synchronization_network"]={"clock_ids":network.clock_ids,"synchronized":network.synchronized,
        "failed_link_ids":network.failed_link_ids,"maximum_absolute_offset_s":network.maximum_absolute_offset_s}
    if mouth:facts["mouth_temporal_measurement"]={"mouth_a_clock_id":mouth.mouth_a_clock_id,"mouth_b_clock_id":mouth.mouth_b_clock_id,
        "proper_time_offset_a_minus_b_s":mouth.proper_time_offset_a_minus_b_s,"standard_uncertainty_s":mouth.standard_uncertainty_s,
        "significance_sigma":mouth.significance_sigma,"synchronized":mouth.synchronized,"origin":mouth.origin.value}
    if temporal_navigation:facts["temporal_navigation"]={"separation_m":temporal_navigation.separation_m,
        "separation_standard_uncertainty_m":temporal_navigation.separation_standard_uncertainty_m,
        "coordinate_frame_id":temporal_navigation.coordinate_frame_id,"epoch_id":temporal_navigation.epoch_id,
        "simulation_time_s":temporal_navigation.simulation_time_s}
    status=base.status
    if network and not network.synchronized:status=MetrologyStatus.PRECISION_INSUFFICIENT.value
    if mouth and not mouth.synchronized:status=MetrologyStatus.PRECISION_INSUFFICIENT.value
    return MetrologyGuardianContract(base.schema,status,facts,base.provenance,base.authority)


class MetrologyAnomalySeverity(str,Enum):
    INFO="INFO"
    CAUTION="CAUTION"
    WARNING="WARNING"
    CRITICAL="CRITICAL"

@dataclass(frozen=True)
class MetrologyAnomaly:
    anomaly_id:str
    severity:MetrologyAnomalySeverity
    source_clock_ids:tuple[str,...]
    simulation_time_s:float
    cause:str
    evidence:dict[str,Any]
    acknowledged:bool
    provenance:str
    origin:DataOrigin
    def __post_init__(self):
        if not self.anomaly_id.strip() or not self.cause.strip() or not self.provenance.strip():raise ValueError("anomaly identity/cause/provenance required")
        if not math.isfinite(self.simulation_time_s):raise ValueError("finite anomaly time required")

def synchronization_anomalies(assessment:SynchronizationAssessment,*,simulation_time_s:float,
                              provenance:str,origin:DataOrigin=DataOrigin.SIMULATION)->tuple[MetrologyAnomaly,...]:
    out=[]
    for i,cause in enumerate(assessment.failures,1):
        sev=MetrologyAnomalySeverity.CRITICAL if "stale" in cause.lower() else MetrologyAnomalySeverity.WARNING
        out.append(MetrologyAnomaly(f"sync-{i}",sev,(assessment.offset.clock_a_id,assessment.offset.clock_b_id),
            simulation_time_s,cause,{"offset_s":assessment.offset.offset_a_minus_b_s,
            "standard_uncertainty_s":assessment.offset.standard_uncertainty_s},False,provenance,origin))
    return tuple(out)

@dataclass(frozen=True)
class TemporalTrajectoryPoint:
    simulation_time_s:float
    proper_time_offset_s:float
    standard_uncertainty_s:float
    separation_m:float
    separation_standard_uncertainty_m:float
    frame_id:str
    epoch_id:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

@dataclass(frozen=True)
class TemporalTrajectory:
    mouth_a_clock_id:str
    mouth_b_clock_id:str
    points:tuple[TemporalTrajectoryPoint,...]
    provenance:str
    def __post_init__(self):
        last=-math.inf
        for p in self.points:
            if p.simulation_time_s<=last:raise ValueError("temporal trajectory time must strictly increase")
            last=p.simulation_time_s
            if p.frame_id!=self.points[0].frame_id or p.epoch_id!=self.points[0].epoch_id:
                raise ValueError("temporal trajectory frame/epoch must remain declared and common")

def append_temporal_navigation(trajectory:TemporalTrajectory,state:TemporalNavigationState)->TemporalTrajectory:
    m=state.mouth_measurement
    if trajectory.mouth_a_clock_id!=m.mouth_a_clock_id or trajectory.mouth_b_clock_id!=m.mouth_b_clock_id:
        raise ValueError("temporal trajectory mouth-clock identity mismatch")
    point=TemporalTrajectoryPoint(state.simulation_time_s,m.proper_time_offset_a_minus_b_s,m.standard_uncertainty_s,
        state.separation_m,state.separation_standard_uncertainty_m,state.coordinate_frame_id,state.epoch_id,state.provenance,state.origin)
    return TemporalTrajectory(trajectory.mouth_a_clock_id,trajectory.mouth_b_clock_id,trajectory.points+(point,),trajectory.provenance)

@dataclass(frozen=True)
class ProperTimePrediction:
    coordinate_duration_s:float
    speed_m_s:float
    predicted_proper_duration_s:float
    gamma:float
    status:MetrologyStatus
    provenance:str

def special_relativistic_proper_time(coordinate_duration_s:float,speed_m_s:float,*,provenance:str)->ProperTimePrediction:
    from .chronology import C
    dt=float(coordinate_duration_s);v=float(speed_m_s)
    if not math.isfinite(dt) or dt<0 or not math.isfinite(v) or v<0 or v>=C:
        raise ValueError("requires finite dt >= 0 and 0 <= speed < c")
    gamma=1.0/math.sqrt(1.0-(v/C)**2)
    return ProperTimePrediction(dt,v,dt/gamma,gamma,MetrologyStatus.PASS,provenance)

@dataclass(frozen=True)
class ProperTimeCrossCheck:
    measured_proper_duration_s:float
    predicted_proper_duration_s:float
    residual_s:float
    combined_standard_uncertainty_s:float
    normalized_residual_sigma:float
    status:MetrologyStatus
    provenance:str

def cross_check_proper_time(measured_s:float,measured_uncertainty_s:float,prediction:ProperTimePrediction,
                            prediction_uncertainty_s:float=0.0,*,sigma_limit:float=5.0,provenance:str)->ProperTimeCrossCheck:
    vals=(measured_s,measured_uncertainty_s,prediction_uncertainty_s,sigma_limit)
    if any(not math.isfinite(x) for x in vals) or measured_uncertainty_s<0 or prediction_uncertainty_s<0 or sigma_limit<=0:
        raise ValueError("invalid proper-time cross-check inputs")
    residual=measured_s-prediction.predicted_proper_duration_s
    u=math.hypot(measured_uncertainty_s,prediction_uncertainty_s)
    z=abs(residual)/u if u>0 else (math.inf if residual else 0.0)
    return ProperTimeCrossCheck(measured_s,prediction.predicted_proper_duration_s,residual,u,z,
        MetrologyStatus.PASS if z<=sigma_limit else MetrologyStatus.INPUT_INCONSISTENT,provenance)

@dataclass(frozen=True)
class D1C1TimingCoupling:
    mouth_time_offset_s:float
    timing_standard_uncertainty_s:float
    d1_declared_offset_s:float
    d1_residual_s:float
    c1_external_return_time_s:float
    c1_chronology_margin_s:float
    c1_loop_condition_met:bool
    status:MetrologyStatus
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def couple_metrology_d1_c1(mouth:MouthTemporalMeasurement,d1_pair_state,c1_assessment,*,provenance:str)->D1C1TimingCoupling:
    if mouth.origin!=DataOrigin.SIMULATION:raise ValueError("MET-001C D1/C1 coupling is SIMULATION only")
    declared=float(d1_pair_state.proper_time_offset_a_minus_b_s)
    residual=mouth.proper_time_offset_a_minus_b_s-declared
    u=mouth.standard_uncertainty_s
    consistent=abs(residual)<=5*u if u>0 else residual==0
    return D1C1TimingCoupling(mouth.proper_time_offset_a_minus_b_s,u,declared,residual,
        float(c1_assessment.external_return_time_s),float(c1_assessment.chronology_margin_s),
        bool(c1_assessment.loop_condition_met),MetrologyStatus.PASS if consistent else MetrologyStatus.INPUT_INCONSISTENT,
        provenance)

def metrology_001c_guardian_contract(assessment:SynchronizationAssessment,*,anomalies=(),trajectory:TemporalTrajectory|None=None,
                                     proper_time_check:ProperTimeCrossCheck|None=None,
                                     d1_c1:D1C1TimingCoupling|None=None)->MetrologyGuardianContract:
    base=expanded_metrology_guardian_contract(assessment);facts=dict(base.facts)
    facts["anomalies"]=[{"anomaly_id":a.anomaly_id,"severity":a.severity.value,"cause":a.cause,
                         "source_clock_ids":a.source_clock_ids,"simulation_time_s":a.simulation_time_s,
                         "acknowledged":a.acknowledged,"origin":a.origin.value} for a in anomalies]
    if trajectory:facts["temporal_trajectory"]={"point_count":len(trajectory.points),
        "mouth_a_clock_id":trajectory.mouth_a_clock_id,"mouth_b_clock_id":trajectory.mouth_b_clock_id}
    if proper_time_check:facts["proper_time_cross_check"]={"residual_s":proper_time_check.residual_s,
        "combined_standard_uncertainty_s":proper_time_check.combined_standard_uncertainty_s,
        "normalized_residual_sigma":proper_time_check.normalized_residual_sigma,"status":proper_time_check.status.value}
    if d1_c1:facts["d1_c1_timing_coupling"]={"mouth_time_offset_s":d1_c1.mouth_time_offset_s,
        "d1_declared_offset_s":d1_c1.d1_declared_offset_s,"d1_residual_s":d1_c1.d1_residual_s,
        "c1_external_return_time_s":d1_c1.c1_external_return_time_s,"c1_chronology_margin_s":d1_c1.c1_chronology_margin_s,
        "c1_loop_condition_met":d1_c1.c1_loop_condition_met,"status":d1_c1.status.value,
        "epistemic_note":"C-1 loop condition is a modeled kinematic condition, not evidence of a physical CTC."}
    status=base.status
    if anomalies or (proper_time_check and proper_time_check.status!=MetrologyStatus.PASS) or (d1_c1 and d1_c1.status!=MetrologyStatus.PASS):
        status=MetrologyStatus.INPUT_INCONSISTENT.value
    return MetrologyGuardianContract(base.schema,status,facts,base.provenance,base.authority)


def metrology_v1_release_readiness()->MetrologyReleaseReadiness:
    checks=[];fail=[]
    try:
        origin=DataOrigin.SIMULATION
        ca=ClockIdentity("mouth-a-clock","Mouth A Clock",TimeDomain.PROPER_TIME,"PROPER","SIM-FRAME","SIM-EPOCH","MET v1 readiness",origin)
        cb=ClockIdentity("mouth-b-clock","Mouth B Clock",TimeDomain.PROPER_TIME,"PROPER","SIM-FRAME","SIM-EPOCH","MET v1 readiness",origin)
        a0=ClockObservation(ca,0,1e-6,0,0,ClockQuality.GOOD,"MET v1 readiness",origin)
        b0=ClockObservation(cb,0,1e-6,0,0,ClockQuality.GOOD,"MET v1 readiness",origin)
        a1=ClockObservation(ca,10.000001,1e-6,10,1,ClockQuality.GOOD,"MET v1 readiness",origin)
        b1=ClockObservation(cb,10,1e-6,10,1,ClockQuality.GOOD,"MET v1 readiness",origin)
        drift=estimate_clock_drift(a0,b0,a1,b1,provenance="MET v1 readiness")
        if math.isfinite(drift.drift_s_per_s):checks.append("clock offset/drift estimation passed")
        policy=SynchronizationPolicy(1e-5,1e-5,1,1e-6)
        sync=assess_synchronization(a1,b1,policy,now_s=10,drift=drift,provenance="MET v1 readiness")
        if sync.synchronized:checks.append("synchronization integrity gate passed")
        hist=ClockHistory(ca,tuple(ClockObservation(ca,float(i),1e-9,float(i),i,ClockQuality.GOOD,"MET v1 readiness",origin) for i in range(5)),"MET v1 readiness")
        if allan_deviation(hist).allan_deviation==0:checks.append("clock stability reference passed")
        mouth=mouth_temporal_measurement(a1,b1,policy,now_s=10,provenance="MET v1 readiness")
        if mouth.mouth_a_clock_id=="mouth-a-clock":checks.append("Mouth A/B proper-time measurement passed")
        pred=special_relativistic_proper_time(10,0,provenance="MET v1 readiness")
        cross=cross_check_proper_time(10,1e-6,pred,1e-6,provenance="MET v1 readiness")
        if cross.status==MetrologyStatus.PASS:checks.append("proper-time reference cross-check passed")
        if metrology_001c_guardian_contract(sync,proper_time_check=cross).schema=="JOE-GUARDIAN-METROLOGY/1":
            checks.append("Guardian metrology contract passed")
    except Exception as exc:fail.append(f"{type(exc).__name__}: {exc}")
    return MetrologyReleaseReadiness(not fail,tuple(checks),tuple(fail),(
        "Metrology v1.0 qualifies timing, uncertainty and SIMULATION temporal-navigation software only.",
        "No physical clock, GNSS/PTP/NTP, optical-clock, Mouth A/B, or laboratory telemetry is asserted.",
        "C-1/D-1 couplings remain declared model/simulation relationships, not physical time-travel evidence."))
