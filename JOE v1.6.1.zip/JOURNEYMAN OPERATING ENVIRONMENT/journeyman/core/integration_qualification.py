from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory
@dataclass(frozen=True)
class FoundationQualification:
    passed:bool;checks:tuple[str,...];failures:tuple[str,...]
def qualify_foundation():
    checks=[];failures=[]
    def check(name,fn):
        try:
            if fn():checks.append(name)
            else:failures.append(name)
        except Exception as exc:failures.append(f"{name}: {type(exc).__name__}: {exc}")
    from .storage import ConfigStore
    def storage():
        with TemporaryDirectory() as td:
            p=Path(td);(p/"joe_settings.json").write_text('{"theme":"dark"}')
            c=ConfigStore(p);c.save("science",{"x":1})
            return c.namespaces()==("science",)
    check("configuration namespace isolation",storage)
    from .job_engine import JobEngine
    def jobs():
        e=JobEngine(max_workers=1,completed_limit=1);e.register_owner("q",max_active=8)
        ids=[e.submit(str(i),"q",lambda ctx,i=i:i) for i in range(5)]
        snaps=[e.wait(x,2) for x in ids];e.shutdown()
        return all(x.state.value=="SUCCEEDED" for x in snaps)
    check("job delayed-wait retention",jobs)
    from .data_streams import ScientificDataStreamEngine
    from .state_events import DataOrigin
    from .run_recorder import RunRecorder
    def runpath():
        with TemporaryDirectory() as td:
            e=ScientificDataStreamEngine(history_limit_per_stream=4);e.register("q","Q","u",float,DataOrigin.SIMULATION,"qualification")
            for i in range(10):e.publish("q",float(i),source="qualification")
            r=RunRecorder(Path(td));run=r.start("qualification",mode="SIMULATION",source="qualification")
            read=r.capture_stream_since(run.run_id,e,"q",0);r.finalize_integrity(run.run_id)
            return read.gap_detected and r.verify_integrity(run.run_id).passed
    check("stream/run provenance-integrity path",runpath)
    from .authority import joe015_release_readiness
    check("authority hierarchy",lambda:joe015_release_readiness().passed)
    from .visualization import VisualizationEngine
    def contour():
        e=ScientificDataStreamEngine()
        for sid in ("x","y","z"):e.register(sid,sid,"m" if sid!="z" else "V",float,DataOrigin.SIMULATION,"qualification")
        e.publish_frame({"x":0.0,"y":0.0,"z":1.0},source="qualification",timestamp=1.0)
        e.publish_frame({"x":1.0,"y":0.0,"z":2.0},source="qualification",timestamp=2.0)
        e.publish_frame({"x":0.0,"y":1.0,"z":3.0},source="qualification",timestamp=3.0)
        v=VisualizationEngine(e).contour_grid("x","y","z")
        return v.occupied_cells==3 and v.origins==("SIMULATION","SIMULATION","SIMULATION")
    check("quantitative contour grid provenance",contour)
    return FoundationQualification(not failures,tuple(checks),tuple(failures))
