"""Guardian AI Governor — GRD-001A deterministic supervisory core.

This module ingests machine-readable Guardian contracts and produces evidence-backed
supervisory findings and recommendations. It is advisory only. BUS-SAFE and deterministic
real-time interlocks remain superior and outside Guardian authority.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Any, Iterable
import math
from uuid import uuid4

class GuardianStatus(str,Enum):
    PASS="PASS"
    CAUTION="CAUTION"
    HOLD="HOLD"
    ABORT="ABORT"
    INPUT_INCONSISTENT="INPUT_INCONSISTENT"
    MODEL_UNAVAILABLE="MODEL_UNAVAILABLE"

class FindingSeverity(str,Enum):
    INFO="INFO"
    CAUTION="CAUTION"
    WARNING="WARNING"
    CRITICAL="CRITICAL"

class GuardianRecommendation(str,Enum):
    CONTINUE="CONTINUE"
    CAUTION="CAUTION"
    RECOMMEND_HOLD="RECOMMEND_HOLD"
    RECOMMEND_ABORT="RECOMMEND_ABORT"

class AuthorityCeiling(str,Enum):
    OBSERVE_ONLY="OBSERVE_ONLY"
    READ_ONLY_ADVISORY="READ_ONLY_ADVISORY"

@dataclass(frozen=True)
class GuardianEvidence:
    evidence_id:str
    source_module:str
    source_schema:str
    key:str
    value:Any
    provenance:str
    confidence:float
    def __post_init__(self):
        if not self.evidence_id.strip() or not self.source_module.strip() or not self.source_schema.strip() or not self.key.strip():
            raise ValueError("evidence identity/source/schema/key required")
        if not math.isfinite(self.confidence) or not 0<=self.confidence<=1:raise ValueError("confidence must be in [0,1]")
        if not self.provenance.strip():raise ValueError("evidence provenance required")

@dataclass(frozen=True)
class GuardianContractEnvelope:
    module_id:str
    schema:str
    status:str
    facts:dict[str,Any]
    provenance:str
    authority:str
    observed_at_s:float|None=None
    def __post_init__(self):
        if not self.module_id.strip() or not self.schema.startswith("JOE-GUARDIAN-") or not self.provenance.strip():
            raise ValueError("valid Guardian contract envelope required")
        if self.observed_at_s is not None and not math.isfinite(self.observed_at_s):raise ValueError("finite observation time required")

def ingest_contract(module_id:str,contract,*,observed_at_s:float|None=None)->GuardianContractEnvelope:
    schema=str(getattr(contract,"schema",""))
    facts=getattr(contract,"facts",None)
    if not isinstance(facts,dict):raise ValueError("Guardian contract facts must be a dictionary")
    return GuardianContractEnvelope(module_id,schema,str(getattr(contract,"status","UNKNOWN")),
        dict(facts),str(getattr(contract,"provenance","")),str(getattr(contract,"authority","")),
        observed_at_s)

@dataclass(frozen=True)
class GuardianRule:
    rule_id:str
    description:str
    fact_path:tuple[str,...]
    operator:str
    threshold:Any
    severity:FindingSeverity
    recommendation:GuardianRecommendation
    required:bool=True
    def __post_init__(self):
        if not self.rule_id.strip() or not self.description.strip() or not self.fact_path:raise ValueError("rule identity/description/path required")
        if self.operator not in {"EQ","NE","LT","LE","GT","GE","TRUTHY","FALSY"}:raise ValueError("unsupported Guardian rule operator")

@dataclass(frozen=True)
class GuardianFinding:
    finding_id:str
    rule_id:str
    source_module:str
    severity:FindingSeverity
    recommendation:GuardianRecommendation
    message:str
    evidence:tuple[GuardianEvidence,...]
    confidence:float
    provenance:str

def _path(facts,path):
    value=facts
    for key in path:
        if not isinstance(value,dict) or key not in value:raise KeyError(".".join(path))
        value=value[key]
    return value

def _compare(value,op,threshold):
    if op=="TRUTHY":return bool(value)
    if op=="FALSY":return not bool(value)
    if op=="EQ":return value==threshold
    if op=="NE":return value!=threshold
    if op in {"LT","LE","GT","GE"}:
        if isinstance(value,bool) or isinstance(threshold,bool):raise TypeError("numeric comparison does not accept bool")
        a=float(value);b=float(threshold)
        if not math.isfinite(a) or not math.isfinite(b):raise ValueError("finite numeric rule values required")
        return {"LT":a<b,"LE":a<=b,"GT":a>b,"GE":a>=b}[op]
    raise ValueError("unsupported operator")

def evaluate_rule(envelope:GuardianContractEnvelope,rule:GuardianRule,*,provenance:str)->GuardianFinding|None:
    try:value=_path(envelope.facts,rule.fact_path)
    except KeyError:
        if not rule.required:return None
        ev=GuardianEvidence(str(uuid4()),envelope.module_id,envelope.schema,".".join(rule.fact_path),
            "MISSING",envelope.provenance,1.0)
        return GuardianFinding(str(uuid4()),rule.rule_id,envelope.module_id,FindingSeverity.WARNING,
            GuardianRecommendation.RECOMMEND_HOLD,f"Required Guardian fact missing: {'.'.join(rule.fact_path)}",
            (ev,),1.0,provenance)
    triggered=_compare(value,rule.operator,rule.threshold)
    if not triggered:return None
    ev=GuardianEvidence(str(uuid4()),envelope.module_id,envelope.schema,".".join(rule.fact_path),
        value,envelope.provenance,1.0)
    return GuardianFinding(str(uuid4()),rule.rule_id,envelope.module_id,rule.severity,rule.recommendation,
        f"{rule.description}; observed {'.'.join(rule.fact_path)}={value!r}",(ev,),1.0,provenance)

@dataclass(frozen=True)
class ContractHealth:
    module_id:str
    stale:bool
    age_s:float|None
    authority_accepted:bool
    schema_accepted:bool
    failures:tuple[str,...]

def contract_health(envelope:GuardianContractEnvelope,*,now_s:float|None=None,maximum_age_s:float|None=None)->ContractHealth:
    fail=[];age=None
    schema_ok=envelope.schema.startswith("JOE-GUARDIAN-")
    if not schema_ok:fail.append("invalid Guardian schema")
    auth_ok=envelope.authority in {AuthorityCeiling.OBSERVE_ONLY.value,AuthorityCeiling.READ_ONLY_ADVISORY.value} or "READ_ONLY_ADVISORY" in envelope.authority
    if not auth_ok:fail.append("contract requests authority above Guardian ceiling")
    stale=False
    if maximum_age_s is not None:
        if maximum_age_s<0 or not math.isfinite(maximum_age_s):raise ValueError("valid maximum age required")
        if now_s is None or envelope.observed_at_s is None:fail.append("freshness cannot be established")
        else:
            age=max(0.,now_s-envelope.observed_at_s);stale=age>maximum_age_s
            if stale:fail.append("Guardian contract is stale")
    return ContractHealth(envelope.module_id,stale,age,auth_ok,schema_ok,tuple(fail))

@dataclass(frozen=True)
class GuardianAssessment:
    status:GuardianStatus
    recommendation:GuardianRecommendation
    findings:tuple[GuardianFinding,...]
    contract_health:tuple[ContractHealth,...]
    confidence:float
    provenance:str
    authority:str="READ_ONLY_ADVISORY"

def assess_contracts(envelopes:Iterable[GuardianContractEnvelope],rules_by_module:dict[str,tuple[GuardianRule,...]],*,
                     now_s:float|None=None,maximum_age_s:float|None=None,provenance:str)->GuardianAssessment:
    envs=tuple(envelopes);findings=[];health=[]
    for env in envs:
        h=contract_health(env,now_s=now_s,maximum_age_s=maximum_age_s);health.append(h)
        if h.failures:
            ev=GuardianEvidence(str(uuid4()),env.module_id,env.schema,"contract_health",h.failures,env.provenance,1.0)
            findings.append(GuardianFinding(str(uuid4()),"GUARDIAN-CONTRACT-HEALTH",env.module_id,
                FindingSeverity.WARNING,GuardianRecommendation.RECOMMEND_HOLD,
                "; ".join(h.failures),(ev,),1.0,provenance))
        for rule in rules_by_module.get(env.module_id,()):
            f=evaluate_rule(env,rule,provenance=provenance)
            if f:findings.append(f)
    rank={GuardianRecommendation.CONTINUE:0,GuardianRecommendation.CAUTION:1,
          GuardianRecommendation.RECOMMEND_HOLD:2,GuardianRecommendation.RECOMMEND_ABORT:3}
    rec=max((f.recommendation for f in findings),key=lambda x:rank[x],default=GuardianRecommendation.CONTINUE)
    status={GuardianRecommendation.CONTINUE:GuardianStatus.PASS,GuardianRecommendation.CAUTION:GuardianStatus.CAUTION,
            GuardianRecommendation.RECOMMEND_HOLD:GuardianStatus.HOLD,GuardianRecommendation.RECOMMEND_ABORT:GuardianStatus.ABORT}[rec]
    confidence=min((f.confidence for f in findings),default=1.0)
    return GuardianAssessment(status,rec,tuple(findings),tuple(health),confidence,provenance)

@dataclass(frozen=True)
class OODAssessment:
    novelty_score:float
    authority_ceiling:AuthorityCeiling
    recommendation:GuardianRecommendation
    reason:str

def assess_ood(novelty_score:float,*,caution_threshold:float=.35,hold_threshold:float=.70)->OODAssessment:
    x=float(novelty_score)
    if not math.isfinite(x) or not 0<=x<=1:raise ValueError("novelty score must be in [0,1]")
    if not 0<=caution_threshold<hold_threshold<=1:raise ValueError("invalid OOD thresholds")
    if x>=hold_threshold:return OODAssessment(x,AuthorityCeiling.OBSERVE_ONLY,GuardianRecommendation.RECOMMEND_HOLD,"High novelty/OOD: reduce Guardian authority to observe-only.")
    if x>=caution_threshold:return OODAssessment(x,AuthorityCeiling.READ_ONLY_ADVISORY,GuardianRecommendation.CAUTION,"Elevated novelty/OOD: advisory interpretation requires caution.")
    return OODAssessment(x,AuthorityCeiling.READ_ONLY_ADVISORY,GuardianRecommendation.CONTINUE,"Within declared supervisory novelty envelope.")

def guardian_core_readiness():
    class C:
        schema="JOE-GUARDIAN-TEST/1";status="PASS";facts={"synchronized":False};provenance="Guardian readiness";authority="READ_ONLY_ADVISORY"
    env=ingest_contract("test",C(),observed_at_s=1)
    rule=GuardianRule("sync","Synchronization lost",("synchronized",),"FALSY",None,FindingSeverity.CRITICAL,GuardianRecommendation.RECOMMEND_HOLD)
    q=assess_contracts((env,),{"test":(rule,)},now_s=1,maximum_age_s=1,provenance="Guardian readiness")
    return {"passed":q.recommendation==GuardianRecommendation.RECOMMEND_HOLD and len(q.findings)==1,
            "checks":("typed contract ingestion","deterministic rule evaluation","authority ceiling","freshness gate","OOD authority reduction"),
            "authority":"BUS-SAFE > deterministic real-time control/interlocks > Guardian > operator/research assistance"}


@dataclass(frozen=True)
class ScalarSample:
    time_s:float
    value:float
    source_module:str
    variable:str
    provenance:str
    def __post_init__(self):
        if not math.isfinite(self.time_s) or not math.isfinite(self.value):raise ValueError("finite scalar sample required")
        if not self.source_module.strip() or not self.variable.strip() or not self.provenance.strip():raise ValueError("sample source/variable/provenance required")

@dataclass(frozen=True)
class RollingStatistics:
    count:int
    mean:float
    standard_deviation:float
    minimum:float
    maximum:float
    slope_per_s:float

def rolling_statistics(samples:Iterable[ScalarSample])->RollingStatistics:
    xs=tuple(samples)
    if not xs:raise ValueError("statistics require samples")
    if any(xs[i].time_s>=xs[i+1].time_s for i in range(len(xs)-1)):raise ValueError("sample times must strictly increase")
    vals=[x.value for x in xs];n=len(vals);mean=sum(vals)/n
    sd=math.sqrt(sum((x-mean)**2 for x in vals)/(n-1)) if n>1 else 0.0
    if n>1:
        tm=sum(x.time_s for x in xs)/n
        den=sum((x.time_s-tm)**2 for x in xs)
        slope=sum((x.time_s-tm)*(x.value-mean) for x in xs)/den if den else 0.0
    else:slope=0.0
    return RollingStatistics(n,mean,sd,min(vals),max(vals),slope)

@dataclass(frozen=True)
class BaselineModel:
    variable:str
    source_module:str
    mean:float
    standard_deviation:float
    minimum_samples:int
    sample_count:int
    provenance:str

def build_baseline(samples:Iterable[ScalarSample],*,minimum_samples:int=5,provenance:str)->BaselineModel:
    xs=tuple(samples)
    if minimum_samples<2 or len(xs)<minimum_samples:raise ValueError("insufficient samples for declared baseline")
    st=rolling_statistics(xs)
    first=xs[0]
    if any(x.variable!=first.variable or x.source_module!=first.source_module for x in xs):raise ValueError("baseline requires one source/variable")
    return BaselineModel(first.variable,first.source_module,st.mean,st.standard_deviation,minimum_samples,st.count,provenance)

@dataclass(frozen=True)
class StatisticalAnomaly:
    anomaly_id:str
    source_module:str
    variable:str
    time_s:float
    value:float
    z_score:float
    severity:FindingSeverity
    reason:str
    confidence:float
    provenance:str

def score_against_baseline(sample:ScalarSample,baseline:BaselineModel,*,caution_sigma:float=3.0,warning_sigma:float=5.0)->StatisticalAnomaly|None:
    if sample.variable!=baseline.variable or sample.source_module!=baseline.source_module:raise ValueError("sample/baseline identity mismatch")
    if not 0<caution_sigma<warning_sigma:raise ValueError("invalid anomaly thresholds")
    if baseline.standard_deviation==0:
        z=0.0 if sample.value==baseline.mean else math.inf
    else:z=abs(sample.value-baseline.mean)/baseline.standard_deviation
    if z<caution_sigma:return None
    sev=FindingSeverity.WARNING if z>=warning_sigma else FindingSeverity.CAUTION
    confidence=1.0 if math.isinf(z) else min(1.0,max(0.0,(z-caution_sigma)/(warning_sigma-caution_sigma)))
    return StatisticalAnomaly(str(uuid4()),sample.source_module,sample.variable,sample.time_s,sample.value,z,sev,
        f"{sample.variable} deviates from declared baseline by {z:.6g} sigma",confidence,sample.provenance)

@dataclass(frozen=True)
class RateOfChangeAssessment:
    variable:str
    rate_per_s:float
    absolute_limit_per_s:float
    exceeded:bool
    provenance:str

def rate_of_change(previous:ScalarSample,current:ScalarSample,*,absolute_limit_per_s:float,provenance:str)->RateOfChangeAssessment:
    if previous.source_module!=current.source_module or previous.variable!=current.variable:raise ValueError("rate samples require same source/variable")
    dt=current.time_s-previous.time_s
    if dt<=0:raise ValueError("rate requires increasing time")
    if not math.isfinite(absolute_limit_per_s) or absolute_limit_per_s<0:raise ValueError("valid rate limit required")
    rate=(current.value-previous.value)/dt
    return RateOfChangeAssessment(current.variable,rate,absolute_limit_per_s,abs(rate)>absolute_limit_per_s,provenance)

@dataclass(frozen=True)
class DriftAssessment:
    variable:str
    slope_per_s:float
    absolute_limit_per_s:float
    exceeded:bool
    sample_count:int
    provenance:str

def detect_drift(samples:Iterable[ScalarSample],*,absolute_limit_per_s:float,provenance:str)->DriftAssessment:
    st=rolling_statistics(samples)
    if not math.isfinite(absolute_limit_per_s) or absolute_limit_per_s<0:raise ValueError("valid drift limit required")
    xs=tuple(samples)
    return DriftAssessment(xs[0].variable,st.slope_per_s,absolute_limit_per_s,abs(st.slope_per_s)>absolute_limit_per_s,st.count,provenance)

@dataclass(frozen=True)
class CrossModuleValue:
    module_id:str
    variable:str
    value:float
    standard_uncertainty:float
    provenance:str
    def __post_init__(self):
        if not math.isfinite(self.value) or not math.isfinite(self.standard_uncertainty) or self.standard_uncertainty<0:raise ValueError("valid value/uncertainty required")

@dataclass(frozen=True)
class ModelDisagreement:
    variable:str
    module_a:str
    module_b:str
    residual:float
    combined_standard_uncertainty:float
    normalized_residual_sigma:float
    disagrees:bool
    sigma_limit:float
    provenance:str

def compare_module_values(a:CrossModuleValue,b:CrossModuleValue,*,sigma_limit:float=5.0,provenance:str)->ModelDisagreement:
    if a.variable!=b.variable:raise ValueError("cross-module comparison requires common variable")
    if not math.isfinite(sigma_limit) or sigma_limit<=0:raise ValueError("positive sigma limit required")
    residual=a.value-b.value;u=math.hypot(a.standard_uncertainty,b.standard_uncertainty)
    z=abs(residual)/u if u>0 else (math.inf if residual else 0.0)
    return ModelDisagreement(a.variable,a.module_id,b.module_id,residual,u,z,z>sigma_limit,sigma_limit,provenance)

@dataclass(frozen=True)
class CorrelatedFinding:
    correlation_id:str
    source_modules:tuple[str,...]
    finding_ids:tuple[str,...]
    severity:FindingSeverity
    recommendation:GuardianRecommendation
    explanation:str
    confidence:float
    provenance:str

def correlate_findings(findings:Iterable[GuardianFinding],*,minimum_modules:int=2,provenance:str)->tuple[CorrelatedFinding,...]:
    fs=tuple(findings)
    if minimum_modules<2:raise ValueError("cross-module correlation requires at least two modules")
    groups={}
    for f in fs:groups.setdefault(f.rule_id,[]).append(f)
    out=[]
    sev_rank={FindingSeverity.INFO:0,FindingSeverity.CAUTION:1,FindingSeverity.WARNING:2,FindingSeverity.CRITICAL:3}
    rec_rank={GuardianRecommendation.CONTINUE:0,GuardianRecommendation.CAUTION:1,GuardianRecommendation.RECOMMEND_HOLD:2,GuardianRecommendation.RECOMMEND_ABORT:3}
    for rule_id,items in groups.items():
        mods=tuple(sorted(set(x.source_module for x in items)))
        if len(mods)<minimum_modules:continue
        sev=max((x.severity for x in items),key=lambda x:sev_rank[x]);rec=max((x.recommendation for x in items),key=lambda x:rec_rank[x])
        out.append(CorrelatedFinding(str(uuid4()),mods,tuple(x.finding_id for x in items),sev,rec,
            f"Independent Guardian findings for rule {rule_id} occur across {len(mods)} modules: {', '.join(mods)}",
            min(x.confidence for x in items),provenance))
    return tuple(out)

def statistical_finding(anomaly:StatisticalAnomaly,*,recommendation:GuardianRecommendation=GuardianRecommendation.CAUTION,
                        provenance:str)->GuardianFinding:
    ev=GuardianEvidence(str(uuid4()),anomaly.source_module,"JOE-GUARDIAN-STATISTICAL/1",anomaly.variable,
        anomaly.value,anomaly.provenance,anomaly.confidence)
    return GuardianFinding(str(uuid4()),"STATISTICAL-ANOMALY",anomaly.source_module,anomaly.severity,recommendation,
        anomaly.reason,(ev,),anomaly.confidence,provenance)


class ConsistencyKind(str,Enum):
    STATUS="STATUS"
    PARAMETER="PARAMETER"
    UNCERTAINTY="UNCERTAINTY"
    DOMAIN="DOMAIN"
    PROVENANCE="PROVENANCE"
    MODEL="MODEL"

@dataclass(frozen=True)
class ScientificConsistencyCheck:
    check_id:str
    kind:ConsistencyKind
    source_modules:tuple[str,...]
    passed:bool
    severity:FindingSeverity
    recommendation:GuardianRecommendation
    explanation:str
    evidence:tuple[GuardianEvidence,...]
    provenance:str

def _evidence_from_path(env:GuardianContractEnvelope,path:tuple[str,...],value:Any,*,confidence:float=1.0)->GuardianEvidence:
    return GuardianEvidence(str(uuid4()),env.module_id,env.schema,".".join(path),value,env.provenance,confidence)

def compare_contract_facts(a:GuardianContractEnvelope,a_path:tuple[str,...],
                           b:GuardianContractEnvelope,b_path:tuple[str,...],*,
                           check_id:str,kind:ConsistencyKind=ConsistencyKind.PARAMETER,
                           numeric_tolerance:float=0.0,severity:FindingSeverity=FindingSeverity.WARNING,
                           recommendation:GuardianRecommendation=GuardianRecommendation.RECOMMEND_HOLD,
                           provenance:str)->ScientificConsistencyCheck:
    if numeric_tolerance<0 or not math.isfinite(numeric_tolerance):raise ValueError("finite nonnegative tolerance required")
    try:av=_path(a.facts,a_path);bv=_path(b.facts,b_path)
    except KeyError as exc:
        msg=f"Scientific consistency fact missing: {exc}"
        return ScientificConsistencyCheck(check_id,kind,(a.module_id,b.module_id),False,severity,
            GuardianRecommendation.RECOMMEND_HOLD,msg,(),provenance)
    if isinstance(av,(int,float)) and not isinstance(av,bool) and isinstance(bv,(int,float)) and not isinstance(bv,bool):
        if not math.isfinite(float(av)) or not math.isfinite(float(bv)):passed=False
        else:passed=abs(float(av)-float(bv))<=numeric_tolerance
    else:passed=av==bv
    ev=(_evidence_from_path(a,a_path,av),_evidence_from_path(b,b_path,bv))
    explanation=(f"Consistent {kind.value.lower()} across {a.module_id} and {b.module_id}"
                 if passed else f"Inconsistent {kind.value.lower()} across {a.module_id} and {b.module_id}: {av!r} vs {bv!r}")
    return ScientificConsistencyCheck(check_id,kind,(a.module_id,b.module_id),passed,
        FindingSeverity.INFO if passed else severity,GuardianRecommendation.CONTINUE if passed else recommendation,
        explanation,ev,provenance)

def status_consistency(envelope:GuardianContractEnvelope,*,accepted_statuses=("PASS","OK","READY"),
                       provenance:str)->ScientificConsistencyCheck:
    ok=str(envelope.status).upper() in {str(x).upper() for x in accepted_statuses}
    ev=GuardianEvidence(str(uuid4()),envelope.module_id,envelope.schema,"status",envelope.status,envelope.provenance,1.0)
    return ScientificConsistencyCheck(f"{envelope.module_id}-STATUS",ConsistencyKind.STATUS,(envelope.module_id,),ok,
        FindingSeverity.INFO if ok else FindingSeverity.WARNING,
        GuardianRecommendation.CONTINUE if ok else GuardianRecommendation.RECOMMEND_HOLD,
        f"{envelope.module_id} Guardian contract status is {envelope.status}",(ev,),provenance)

@dataclass(frozen=True)
class ScientificConsistencyReport:
    checks:tuple[ScientificConsistencyCheck,...]
    passed:bool
    recommendation:GuardianRecommendation
    failed_check_ids:tuple[str,...]
    source_modules:tuple[str,...]
    provenance:str

def scientific_consistency_report(checks:Iterable[ScientificConsistencyCheck],*,provenance:str)->ScientificConsistencyReport:
    cs=tuple(checks);failed=tuple(x.check_id for x in cs if not x.passed)
    rec_rank={GuardianRecommendation.CONTINUE:0,GuardianRecommendation.CAUTION:1,
              GuardianRecommendation.RECOMMEND_HOLD:2,GuardianRecommendation.RECOMMEND_ABORT:3}
    rec=max((x.recommendation for x in cs if not x.passed),key=lambda x:rec_rank[x],default=GuardianRecommendation.CONTINUE)
    mods=tuple(sorted({m for x in cs for m in x.source_modules}))
    return ScientificConsistencyReport(cs,not failed,rec,failed,mods,provenance)

def consistency_findings(report:ScientificConsistencyReport)->tuple[GuardianFinding,...]:
    out=[]
    for c in report.checks:
        if c.passed:continue
        out.append(GuardianFinding(str(uuid4()),c.check_id,"+".join(c.source_modules),c.severity,c.recommendation,
            c.explanation,c.evidence,min((e.confidence for e in c.evidence),default=1.0),report.provenance))
    return tuple(out)

@dataclass(frozen=True)
class CrossModuleScientificState:
    envelopes:tuple[GuardianContractEnvelope,...]
    consistency:ScientificConsistencyReport
    findings:tuple[GuardianFinding,...]
    recommendation:GuardianRecommendation
    provenance:str
    authority:str="READ_ONLY_ADVISORY"

def build_cross_module_scientific_state(envelopes:Iterable[GuardianContractEnvelope],
                                        checks:Iterable[ScientificConsistencyCheck],*,provenance:str)->CrossModuleScientificState:
    envs=tuple(envelopes);report=scientific_consistency_report(checks,provenance=provenance);fs=consistency_findings(report)
    return CrossModuleScientificState(envs,report,fs,report.recommendation,provenance)

def standard_cross_module_checks(envelopes:Iterable[GuardianContractEnvelope],*,provenance:str)->tuple[ScientificConsistencyCheck,...]:
    """Conservative checks valid across heterogeneous JOE contracts.

    Module-specific physics comparisons are only made when an explicit shared fact exists;
    this function does not guess paths or reinterpret quantities.
    """
    envs=tuple(envelopes);out=[status_consistency(e,provenance=provenance) for e in envs]
    by={e.module_id:e for e in envs}
    # Metrology and Digital Twin may both declare simulation time. Compare only when exact
    # machine-readable paths exist in both contracts.
    met=by.get("metrology");dt=by.get("digital-twin")
    if met and dt:
        mp=("temporal_navigation","simulation_time_s");dp=("simulation_time_s",)
        try:_path(met.facts,mp);_path(dt.facts,dp)
        except KeyError:pass
        else:out.append(compare_contract_facts(met,mp,dt,dp,check_id="MET-DT-SIM-TIME",
            kind=ConsistencyKind.PARAMETER,numeric_tolerance=1e-9,provenance=provenance))
    # Experiment/Twin synchronization is itself authoritative evidence when exposed.
    exp=by.get("experiment-designer")
    if exp:
        p=("twin_synchronization","synchronized")
        try:v=_path(exp.facts,p)
        except KeyError:pass
        else:
            ev=_evidence_from_path(exp,p,v)
            out.append(ScientificConsistencyCheck("EXP-DT-SYNC",ConsistencyKind.MODEL,(exp.module_id,),bool(v),
                FindingSeverity.INFO if bool(v) else FindingSeverity.WARNING,
                GuardianRecommendation.CONTINUE if bool(v) else GuardianRecommendation.RECOMMEND_HOLD,
                "Experiment/Digital Twin synchronization declared synchronized" if bool(v) else "Experiment/Digital Twin synchronization mismatch",
                (ev,),provenance))
    return tuple(out)

def guardian_scientific_consistency_readiness():
    a=GuardianContractEnvelope("a","JOE-GUARDIAN-A/1","PASS",{"revision":"r1"},"test","READ_ONLY_ADVISORY")
    b=GuardianContractEnvelope("b","JOE-GUARDIAN-B/1","PASS",{"revision":"r1"},"test","READ_ONLY_ADVISORY")
    good=compare_contract_facts(a,("revision",),b,("revision",),check_id="REV",provenance="test")
    bad=compare_contract_facts(a,("revision",),GuardianContractEnvelope("c","JOE-GUARDIAN-C/1","PASS",{"revision":"r2"},"test","READ_ONLY_ADVISORY"),
                               ("revision",),check_id="REV2",provenance="test")
    report=scientific_consistency_report((good,bad),provenance="test")
    return {"passed":good.passed and not bad.passed and report.recommendation==GuardianRecommendation.RECOMMEND_HOLD,
            "checks":("typed cross-contract comparison","status consistency","missing-fact fail-safe","consistency findings","cross-module state"),
            "epistemic_boundary":"Cross-model agreement is consistency evidence, never proof of unresolved physics."}


class ReasoningRelation(str,Enum):
    SUPPORTS="SUPPORTS"
    CONTRADICTS="CONTRADICTS"
    CORRELATES_WITH="CORRELATES_WITH"
    DEPENDS_ON="DEPENDS_ON"

@dataclass(frozen=True)
class EvidenceNode:
    node_id:str
    label:str
    source_module:str
    confidence:float
    provenance:str
    payload:dict[str,Any]
    def __post_init__(self):
        if not self.node_id.strip() or not self.label.strip() or not self.source_module.strip() or not self.provenance.strip():
            raise ValueError("evidence node identity/label/source/provenance required")
        if not math.isfinite(self.confidence) or not 0<=self.confidence<=1:raise ValueError("node confidence must be in [0,1]")

@dataclass(frozen=True)
class EvidenceEdge:
    edge_id:str
    source_node_id:str
    target_node_id:str
    relation:ReasoningRelation
    confidence:float
    rationale:str
    provenance:str
    def __post_init__(self):
        if not self.edge_id.strip() or not self.source_node_id.strip() or not self.target_node_id.strip() or not self.rationale.strip():
            raise ValueError("evidence edge identity/endpoints/rationale required")
        if self.source_node_id==self.target_node_id:raise ValueError("self-referential evidence edge not allowed")
        if not math.isfinite(self.confidence) or not 0<=self.confidence<=1:raise ValueError("edge confidence must be in [0,1]")

@dataclass(frozen=True)
class EvidenceGraph:
    nodes:tuple[EvidenceNode,...]
    edges:tuple[EvidenceEdge,...]
    provenance:str
    def __post_init__(self):
        ids=[x.node_id for x in self.nodes]
        if len(ids)!=len(set(ids)):raise ValueError("duplicate evidence node identity")
        known=set(ids)
        if any(e.source_node_id not in known or e.target_node_id not in known for e in self.edges):
            raise ValueError("evidence edge references unknown node")

def evidence_graph_from_findings(findings:Iterable[GuardianFinding],*,provenance:str)->EvidenceGraph:
    nodes=[];edges=[]
    for f in findings:
        fn=f"finding:{f.finding_id}"
        nodes.append(EvidenceNode(fn,f.message,f.source_module,f.confidence,f.provenance,
            {"rule_id":f.rule_id,"severity":f.severity.value,"recommendation":f.recommendation.value}))
        for ev in f.evidence:
            en=f"evidence:{ev.evidence_id}"
            nodes.append(EvidenceNode(en,f"{ev.key}={ev.value!r}",ev.source_module,ev.confidence,ev.provenance,
                {"schema":ev.source_schema,"key":ev.key,"value":ev.value}))
            edges.append(EvidenceEdge(str(uuid4()),en,fn,ReasoningRelation.SUPPORTS,min(ev.confidence,f.confidence),
                "Recorded evidence supports the deterministic/statistical finding.",provenance))
    return EvidenceGraph(tuple(nodes),tuple(edges),provenance)

class HypothesisKind(str,Enum):
    CORRELATION="CORRELATION"
    CONSISTENCY="CONSISTENCY"
    POSSIBLE_CAUSE="POSSIBLE_CAUSE"
    DATA_QUALITY="DATA_QUALITY"

@dataclass(frozen=True)
class GuardianHypothesis:
    hypothesis_id:str
    kind:HypothesisKind
    statement:str
    supporting_node_ids:tuple[str,...]
    contradicting_node_ids:tuple[str,...]
    confidence:float
    limitations:tuple[str,...]
    provenance:str
    def __post_init__(self):
        if not self.statement.strip() or not self.provenance.strip():raise ValueError("hypothesis statement/provenance required")
        if not math.isfinite(self.confidence) or not 0<=self.confidence<=1:raise ValueError("hypothesis confidence must be in [0,1]")

def hypothesis_from_correlation(correlation:CorrelatedFinding,graph:EvidenceGraph,*,provenance:str)->GuardianHypothesis:
    supporting=tuple(n.node_id for n in graph.nodes if n.node_id.startswith("finding:") and n.source_module in correlation.source_modules)
    confidence=min(correlation.confidence, min((n.confidence for n in graph.nodes if n.node_id in supporting),default=correlation.confidence))
    return GuardianHypothesis(str(uuid4()),HypothesisKind.CORRELATION,
        f"Related Guardian findings are present across {', '.join(correlation.source_modules)}.",
        supporting,(),confidence,("Correlation does not establish causation.","Software/model agreement does not establish unresolved physics."),provenance)

@dataclass(frozen=True)
class RankedExplanation:
    rank:int
    hypothesis_id:str
    statement:str
    confidence:float
    evidence_count:int
    limitations:tuple[str,...]

def rank_explanations(hypotheses:Iterable[GuardianHypothesis])->tuple[RankedExplanation,...]:
    hs=sorted(tuple(hypotheses),key=lambda h:(-h.confidence,-len(h.supporting_node_ids),h.hypothesis_id))
    return tuple(RankedExplanation(i+1,h.hypothesis_id,h.statement,h.confidence,len(h.supporting_node_ids),h.limitations) for i,h in enumerate(hs))

@dataclass(frozen=True)
class DisagreementInterpretation:
    variable:str
    statement:str
    severity:FindingSeverity
    recommendation:GuardianRecommendation
    normalized_residual_sigma:float
    confidence:float
    limitations:tuple[str,...]
    provenance:str

def interpret_disagreement(disagreement:ModelDisagreement)->DisagreementInterpretation:
    if disagreement.disagrees:
        return DisagreementInterpretation(disagreement.variable,
            f"{disagreement.module_a} and {disagreement.module_b} disagree on {disagreement.variable} by {disagreement.normalized_residual_sigma:.6g} sigma.",
            FindingSeverity.WARNING,GuardianRecommendation.RECOMMEND_HOLD,disagreement.normalized_residual_sigma,
            min(1.0,disagreement.normalized_residual_sigma/max(disagreement.sigma_limit,1e-30)),
            ("Investigate units, frames, epochs, parameter revisions, numerical convergence, uncertainty models and data freshness before assigning physical cause.",),
            disagreement.provenance)
    return DisagreementInterpretation(disagreement.variable,
        f"{disagreement.module_a} and {disagreement.module_b} are consistent within the declared {disagreement.sigma_limit:g}-sigma criterion.",
        FindingSeverity.INFO,GuardianRecommendation.CONTINUE,disagreement.normalized_residual_sigma,1.0,
        ("Consistency is not independent physical validation when models share assumptions, code, parameters or data.",),disagreement.provenance)

@dataclass(frozen=True)
class OperatorRecommendation:
    recommendation:GuardianRecommendation
    summary:str
    reasons:tuple[str,...]
    required_checks:tuple[str,...]
    confidence:float
    authority:str
    provenance:str

def structured_operator_recommendation(assessment:GuardianAssessment,*,explanations:Iterable[RankedExplanation]=(),
                                       disagreement_interpretations:Iterable[DisagreementInterpretation]=(),
                                       ood:OODAssessment|None=None,provenance:str)->OperatorRecommendation:
    ex=tuple(explanations);di=tuple(disagreement_interpretations)
    rank={GuardianRecommendation.CONTINUE:0,GuardianRecommendation.CAUTION:1,
          GuardianRecommendation.RECOMMEND_HOLD:2,GuardianRecommendation.RECOMMEND_ABORT:3}
    candidates=[assessment.recommendation]+[x.recommendation for x in di]
    if ood:candidates.append(ood.recommendation)
    rec=max(candidates,key=lambda x:rank[x])
    reasons=[f.message for f in assessment.findings]
    reasons.extend(x.statement for x in di if x.recommendation!=GuardianRecommendation.CONTINUE)
    if ood and ood.recommendation!=GuardianRecommendation.CONTINUE:reasons.append(ood.reason)
    checks=[]
    if rec in (GuardianRecommendation.RECOMMEND_HOLD,GuardianRecommendation.RECOMMEND_ABORT):
        checks.extend(("Review source evidence and provenance.","Verify data freshness, units, frames, epochs and parameter revisions.",
                       "Confirm deterministic interlocks/BUS-SAFE state independently of Guardian."))
    if ex:checks.append("Review ranked hypotheses as explanations only; do not treat correlation as causation.")
    conf=min([assessment.confidence]+[x.confidence for x in ex]+[x.confidence for x in di] or [1.0])
    return OperatorRecommendation(rec,f"Guardian supervisory recommendation: {rec.value}",tuple(dict.fromkeys(reasons)),
        tuple(dict.fromkeys(checks)),conf,
        "READ_ONLY_ADVISORY — cannot command actuators, clear trips, mask permissives, or override BUS-SAFE/deterministic interlocks.",
        provenance)

def guardian_reasoning_readiness():
    ev=GuardianEvidence("e","m","JOE-GUARDIAN-X/1","x",1,"test",.9)
    f=GuardianFinding("f","R","m",FindingSeverity.WARNING,GuardianRecommendation.RECOMMEND_HOLD,"test finding",(ev,),.9,"test")
    g=evidence_graph_from_findings((f,),provenance="test")
    c=CorrelatedFinding("c",("m","n"),("f","f2"),FindingSeverity.WARNING,GuardianRecommendation.RECOMMEND_HOLD,"correlated",.8,"test")
    h=hypothesis_from_correlation(c,g,provenance="test")
    r=rank_explanations((h,))
    a=GuardianAssessment(GuardianStatus.HOLD,GuardianRecommendation.RECOMMEND_HOLD,(f,),(),.9,"test")
    op=structured_operator_recommendation(a,explanations=r,provenance="test")
    return {"passed":len(g.nodes)==2 and len(g.edges)==1 and len(r)==1 and op.recommendation==GuardianRecommendation.RECOMMEND_HOLD,
            "checks":("evidence graph","correlation hypothesis","ranked explanation","structured operator recommendation","authority boundary"),
            "limitation":"Reasoning hypotheses explain evidence; they do not autonomously establish causation or physical truth."}


class AIModelReleaseState(str,Enum):
    DRAFT="DRAFT"
    SHADOW="SHADOW"
    QUALIFIED="QUALIFIED"
    RETIRED="RETIRED"
    ROLLED_BACK="ROLLED_BACK"

@dataclass(frozen=True)
class AIModelRecord:
    model_id:str
    version:str
    artifact_hash:str
    training_data_manifest:str
    validation_domain:tuple[str,...]
    limitations:tuple[str,...]
    authority_ceiling:AuthorityCeiling
    release_state:AIModelReleaseState
    provenance:str
    predecessor_version:str|None=None
    def __post_init__(self):
        if not all((self.model_id.strip(),self.version.strip(),self.artifact_hash.strip(),self.training_data_manifest.strip(),self.provenance.strip())):
            raise ValueError("complete AI model identity/hash/manifest/provenance required")
        if not self.validation_domain:raise ValueError("AI model requires declared validation domain")

class AIModelRegistry:
    def __init__(self):self._records={}
    def register(self,record:AIModelRecord):
        key=(record.model_id,record.version)
        if key in self._records:raise ValueError("AI model version already registered")
        self._records[key]=record;return record
    def get(self,model_id,version):return self._records[(model_id,version)]
    def versions(self,model_id):return tuple(r for (m,_),r in self._records.items() if m==model_id)
    def qualified(self,model_id):
        q=[r for r in self.versions(model_id) if r.release_state==AIModelReleaseState.QUALIFIED]
        return q[-1] if q else None
    def rollback(self,model_id,current_version,target_version,*,provenance):
        cur=self.get(model_id,current_version);target=self.get(model_id,target_version)
        self._records[(model_id,current_version)]=AIModelRecord(cur.model_id,cur.version,cur.artifact_hash,cur.training_data_manifest,
            cur.validation_domain,cur.limitations,cur.authority_ceiling,AIModelReleaseState.ROLLED_BACK,provenance,cur.predecessor_version)
        return target

class AIRequestKind(str,Enum):
    EXPLAIN_FINDINGS="EXPLAIN_FINDINGS"
    RANK_HYPOTHESES="RANK_HYPOTHESES"
    INTERPRET_DISAGREEMENT="INTERPRET_DISAGREEMENT"
    SUMMARIZE_STATE="SUMMARIZE_STATE"

@dataclass(frozen=True)
class TypedAIRequest:
    request_id:str
    kind:AIRequestKind
    evidence_node_ids:tuple[str,...]
    question:str
    domain:str
    requested_authority:AuthorityCeiling
    provenance:str
    def __post_init__(self):
        if not self.request_id.strip() or not self.question.strip() or not self.domain.strip() or not self.provenance.strip():
            raise ValueError("typed AI request identity/question/domain/provenance required")

@dataclass(frozen=True)
class TypedAIResponse:
    request_id:str
    model_id:str|None
    model_version:str|None
    answer:str
    confidence:float
    evidence_node_ids:tuple[str,...]
    limitations:tuple[str,...]
    recommendation:GuardianRecommendation
    authority:AuthorityCeiling
    shadow:bool
    deterministic_fallback:bool
    provenance:str
    def __post_init__(self):
        if not math.isfinite(self.confidence) or not 0<=self.confidence<=1:raise ValueError("AI response confidence must be in [0,1]")
        if not self.answer.strip() or not self.provenance.strip():raise ValueError("AI response answer/provenance required")

def validate_ai_request(request:TypedAIRequest,model:AIModelRecord|None,graph:EvidenceGraph)->tuple[bool,tuple[str,...]]:
    failures=[]
    known={n.node_id for n in graph.nodes}
    if any(x not in known for x in request.evidence_node_ids):failures.append("request references unknown evidence")
    if request.requested_authority not in (AuthorityCeiling.OBSERVE_ONLY,AuthorityCeiling.READ_ONLY_ADVISORY):
        failures.append("requested authority exceeds Guardian ceiling")
    if model is None:failures.append("AI model unavailable")
    else:
        if request.domain not in model.validation_domain:failures.append("request outside model validation domain")
        if model.release_state not in (AIModelReleaseState.SHADOW,AIModelReleaseState.QUALIFIED):failures.append("model is not released for supervisory use")
    return not failures,tuple(failures)

def deterministic_ai_fallback(request:TypedAIRequest,graph:EvidenceGraph,failures:Iterable[str],*,provenance:str)->TypedAIResponse:
    fs=tuple(failures)
    evidence=[n for n in graph.nodes if n.node_id in request.evidence_node_ids]
    text="AI reasoning unavailable; deterministic Guardian evidence remains authoritative for supervision."
    if fs:text+=" Reasons: "+"; ".join(fs)+"."
    if evidence:text+=f" Preserved evidence nodes: {len(evidence)}."
    return TypedAIResponse(request.request_id,None,None,text,1.0,tuple(n.node_id for n in evidence),
        ("No generative/model inference was used.","Deterministic rules and BUS-SAFE/interlocks remain independent."),
        GuardianRecommendation.CAUTION,AuthorityCeiling.OBSERVE_ONLY,False,True,provenance)

def governed_ai_response(request:TypedAIRequest,graph:EvidenceGraph,model:AIModelRecord|None,*,answer:str|None=None,
                         confidence:float|None=None,novelty_score:float=0.0,provenance:str)->TypedAIResponse:
    ok,fail=validate_ai_request(request,model,graph)
    if not ok:return deterministic_ai_fallback(request,graph,fail,provenance=provenance)
    ood=assess_ood(novelty_score)
    if ood.authority_ceiling==AuthorityCeiling.OBSERVE_ONLY and novelty_score>=.70:
        return deterministic_ai_fallback(request,graph,("high OOD/novelty",),provenance=provenance)
    if answer is None or confidence is None:
        return deterministic_ai_fallback(request,graph,("no AI backend response supplied",),provenance=provenance)
    c=float(confidence)
    if not math.isfinite(c) or not 0<=c<=1:raise ValueError("backend confidence must be in [0,1]")
    shadow=model.release_state==AIModelReleaseState.SHADOW
    authority=AuthorityCeiling.OBSERVE_ONLY if shadow else model.authority_ceiling
    rec=GuardianRecommendation.CAUTION if ood.recommendation==GuardianRecommendation.CAUTION else GuardianRecommendation.CONTINUE
    return TypedAIResponse(request.request_id,model.model_id,model.version,answer,c,request.evidence_node_ids,
        model.limitations+(("SHADOW MODE: response cannot affect supervisory recommendation.",) if shadow else ()),
        rec,authority,shadow,False,provenance)

@dataclass(frozen=True)
class ModelDisagreementRecord:
    deterministic_recommendation:GuardianRecommendation
    ai_recommendation:GuardianRecommendation
    disagrees:bool
    explanation:str
    provenance:str

def compare_ai_to_deterministic(ai:TypedAIResponse,deterministic:GuardianAssessment,*,provenance:str)->ModelDisagreementRecord:
    disagree=ai.recommendation!=deterministic.recommendation
    return ModelDisagreementRecord(deterministic.recommendation,ai.recommendation,disagree,
        "AI and deterministic Guardian recommendations disagree; preserve both as diagnostic evidence." if disagree
        else "AI and deterministic Guardian recommendations agree; agreement does not increase authority.",provenance)

def guardian_ai_governance_readiness():
    reg=AIModelRegistry()
    model=reg.register(AIModelRecord("guardian-local","1","sha256:test","manifest:test",("JOE",),
        ("qualification reference only",),AuthorityCeiling.READ_ONLY_ADVISORY,AIModelReleaseState.SHADOW,"test"))
    graph=EvidenceGraph((EvidenceNode("n","test","m",1,"test",{}),),(),"test")
    req=TypedAIRequest("r",AIRequestKind.SUMMARIZE_STATE,("n",),"summarize","JOE",AuthorityCeiling.READ_ONLY_ADVISORY,"test")
    shadow=governed_ai_response(req,graph,model,answer="test",confidence=.8,provenance="test")
    fallback=governed_ai_response(req,graph,None,provenance="test")
    return {"passed":shadow.shadow and shadow.authority==AuthorityCeiling.OBSERVE_ONLY and fallback.deterministic_fallback,
            "checks":("model registry","artifact hash/manifest","validation domain","shadow mode","typed AI request/response","deterministic fallback","OOD authority reduction"),
            "authority":"AI model output never bypasses deterministic Guardian, real-time interlocks, or BUS-SAFE."}


@dataclass(frozen=True)
class GuardianReleaseReadiness:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    notes:tuple[str,...]
    authority:str="READ_ONLY_ADVISORY"

def guardian_v1_release_readiness()->GuardianReleaseReadiness:
    checks=[];fail=[]
    try:
        core=guardian_core_readiness()
        if core["passed"]:checks.append("deterministic contract/rule/freshness/OOD core passed")
        else:fail.append("deterministic core readiness failed")
        sci=guardian_scientific_consistency_readiness()
        if sci["passed"]:checks.append("scientific consistency engine passed")
        else:fail.append("scientific consistency readiness failed")
        reason=guardian_reasoning_readiness()
        if reason["passed"]:checks.append("evidence graph and structured reasoning passed")
        else:fail.append("reasoning readiness failed")
        ai=guardian_ai_governance_readiness()
        if ai["passed"]:checks.append("AI model governance/shadow/fallback passed")
        else:fail.append("AI governance readiness failed")
        xs=tuple(ScalarSample(float(i),float(i),"readiness","x","Guardian v1 readiness") for i in range(5))
        if rolling_statistics(xs).count==5 and detect_drift(xs,absolute_limit_per_s=.5,provenance="Guardian v1 readiness").exceeded:
            checks.append("statistical baseline/trend/drift layer passed")
        else:fail.append("statistical layer readiness failed")
        a=CrossModuleValue("a","x",1,0.1,"Guardian v1 readiness")
        b=CrossModuleValue("b","x",1,0.1,"Guardian v1 readiness")
        if not compare_module_values(a,b,provenance="Guardian v1 readiness").disagrees:
            checks.append("cross-module uncertainty comparison passed")
        else:fail.append("cross-module comparison readiness failed")
    except Exception as exc:fail.append(f"{type(exc).__name__}: {exc}")
    return GuardianReleaseReadiness(not fail,tuple(checks),tuple(fail),(
        "Guardian v1.0 is supervisory intelligence software, not final safety authority.",
        "No local generative AI model is bundled or fabricated; unavailable model inference falls back deterministically.",
        "Guardian cannot command actuators, clear trips, mask permissives, rewrite safety thresholds, or override BUS-SAFE/interlocks.",
        "Scientific/model agreement is consistency evidence, not proof of unresolved physics."))

def guardian_workspace_snapshot(envelopes:Iterable[GuardianContractEnvelope],*,provenance:str)->dict[str,Any]:
    envs=tuple(envelopes)
    checks=standard_cross_module_checks(envs,provenance=provenance)
    state=build_cross_module_scientific_state(envs,checks,provenance=provenance)
    return {"module_count":len(envs),"modules":tuple(e.module_id for e in envs),
            "recommendation":state.recommendation.value,"failed_checks":state.consistency.failed_check_ids,
            "finding_count":len(state.findings),"authority":"READ_ONLY_ADVISORY","provenance":provenance}
