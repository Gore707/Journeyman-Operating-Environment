"""D-1 Mouth Dynamics module."""
from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.mouth_dynamics import (mouth_pair_separation,mouth_desynchronization,
 propagate_piecewise_inertial_transport,mouth_dynamics_guardian_contract,propagate_accelerated_transport,
 evolve_pair_with_transport,transport_timing_uncertainty,couple_transport_to_chronology,
 symmetric_transport_profile,analyze_symmetric_mission,solve_cruise_speed_for_target_desynchronization,
 mission_speed_sensitivity,mission_feasibility,expanded_mouth_dynamics_guardian_contract,
 d1_transport_convergence,d1_parameter_sweep,d1_uncertainty_sweep,d1_c1_cross_validate,d1_release_readiness)
D1_MODULE=ModuleDescriptor(module_id="journeyman.mouth-dynamics",name="Mouth Dynamics / D-1 Workbench",version="1.0.0",
 description="Typed Mouth A/B simulation state, transport, separation and desynchronization analysis.",
 requires=("joe.core","journeyman.registry","journeyman.navigation","journeyman.geometry","journeyman.chronology"),
 provides=("joe.mouth-dynamics",),consumes=("joe.registry","joe.navigation","joe.geometry","joe.chronology","joe.state-events"))
class MouthDynamicsService:
    separation=staticmethod(mouth_pair_separation)
    desynchronization=staticmethod(mouth_desynchronization)
    transport=staticmethod(propagate_piecewise_inertial_transport)
    guardian_contract=staticmethod(mouth_dynamics_guardian_contract)
    accelerated_transport=staticmethod(propagate_accelerated_transport)
    evolve_pair=staticmethod(evolve_pair_with_transport)
    timing_uncertainty=staticmethod(transport_timing_uncertainty)
    chronology_coupling=staticmethod(couple_transport_to_chronology)
    symmetric_profile=staticmethod(symmetric_transport_profile)
    analyze_mission=staticmethod(analyze_symmetric_mission)
    solve_target_desynchronization=staticmethod(solve_cruise_speed_for_target_desynchronization)
    speed_sensitivity=staticmethod(mission_speed_sensitivity)
    mission_feasibility=staticmethod(mission_feasibility)
    expanded_guardian_contract=staticmethod(expanded_mouth_dynamics_guardian_contract)
    convergence=staticmethod(d1_transport_convergence)
    parameter_sweep=staticmethod(d1_parameter_sweep)
    uncertainty_sweep=staticmethod(d1_uncertainty_sweep)
    c1_cross_validate=staticmethod(d1_c1_cross_validate)
    release_readiness=staticmethod(d1_release_readiness)
class MouthDynamicsInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_mouth_dynamics_module(runtime:ModuleRuntime):
    svc=MouthDynamicsService();runtime.register(D1_MODULE,MouthDynamicsInstance(svc));runtime.activate("journeyman.mouth-dynamics")
    runtime.publish_service("journeyman.mouth-dynamics","joe.mouth-dynamics",svc);return svc
