"""C-1 chronology core: typed events, timelike worldlines, proper time and causal ordering.

This layer evaluates ordinary relativistic causal structure and declared chronology mappings.
It does not claim that a traversable wormhole or closed timelike curve physically exists.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .state_events import DataOrigin

C=299_792_458.0

class ChronologyStatus(str,Enum):
    PASS="PASS"
    DOMAIN_INVALID="DOMAIN_INVALID"
    INPUT_INCONSISTENT="INPUT_INCONSISTENT"
    MODEL_UNAVAILABLE="MODEL_UNAVAILABLE"
    UNKNOWN_PHYSICS="UNKNOWN_PHYSICS"

class IntervalClass(str,Enum):
    TIMELIKE="TIMELIKE"
    NULL="NULL"
    SPACELIKE="SPACELIKE"
    COINCIDENT="COINCIDENT"

class CausalOrder(str,Enum):
    A_BEFORE_B="A_BEFORE_B"
    B_BEFORE_A="B_BEFORE_A"
    LIGHTLIKE_RELATED="LIGHTLIKE_RELATED"
    SPACELIKE_UNORDERED="SPACELIKE_UNORDERED"
    COINCIDENT="COINCIDENT"

@dataclass(frozen=True)
class ChronologyEvent:
    event_id:str
    coordinate_time_s:float
    position_m:tuple[float,float,float]
    frame_id:str
    epoch_id:str
    time_scale:str
    coordinate_time_uncertainty_s:float=0.0
    position_standard_uncertainty_m:float=0.0
    provenance:str="declared chronology event"
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if not self.event_id.strip() or not self.frame_id.strip() or not self.epoch_id.strip() or not self.time_scale.strip() or not self.provenance.strip():
            raise ValueError("event identity/frame/epoch/time scale/provenance required")
        if len(self.position_m)!=3 or not all(math.isfinite(float(x)) for x in self.position_m):raise ValueError("finite 3D position required")
        if not math.isfinite(self.coordinate_time_s):raise ValueError("finite coordinate time required")
        if self.coordinate_time_uncertainty_s<0 or self.position_standard_uncertainty_m<0:raise ValueError("uncertainties must be nonnegative")

@dataclass(frozen=True)
class IntervalResult:
    status:ChronologyStatus
    interval_class:IntervalClass|None
    delta_t_s:float|None
    spatial_separation_m:float|None
    interval_c2s2_m2:float|None
    causal_order:CausalOrder|None
    message:str

def minkowski_interval(a:ChronologyEvent,b:ChronologyEvent,*,null_tolerance_m2:float=1e-9)->IntervalResult:
    if a.frame_id!=b.frame_id or a.epoch_id!=b.epoch_id or a.time_scale!=b.time_scale:
        return IntervalResult(ChronologyStatus.INPUT_INCONSISTENT,None,None,None,None,None,
            "Events cannot be compared without a declared frame/epoch/time-scale transformation.")
    dt=b.coordinate_time_s-a.coordinate_time_s
    dr=math.sqrt(sum((b.position_m[i]-a.position_m[i])**2 for i in range(3)))
    s2=(C*dt)**2-dr**2
    tol=max(float(null_tolerance_m2),1e-15*max((C*dt)**2,dr**2,1.0))
    if abs(dt)<1e-18 and dr<1e-12:
        cls=IntervalClass.COINCIDENT;order=CausalOrder.COINCIDENT
    elif abs(s2)<=tol:
        cls=IntervalClass.NULL;order=CausalOrder.LIGHTLIKE_RELATED
    elif s2>0:
        cls=IntervalClass.TIMELIKE;order=CausalOrder.A_BEFORE_B if dt>0 else CausalOrder.B_BEFORE_A
    else:
        cls=IntervalClass.SPACELIKE;order=CausalOrder.SPACELIKE_UNORDERED
    return IntervalResult(ChronologyStatus.PASS,cls,dt,dr,s2,order,"Minkowski interval evaluated in one declared coordinate frame.")

@dataclass(frozen=True)
class WorldlineSegment:
    coordinate_duration_s:float
    speed_m_s:float
    label:str
    def __post_init__(self):
        if not math.isfinite(self.coordinate_duration_s) or self.coordinate_duration_s<=0:raise ValueError("positive finite segment duration required")
        if not math.isfinite(self.speed_m_s) or self.speed_m_s<0 or self.speed_m_s>=C:raise ValueError("worldline speed must satisfy 0 <= v < c")
        if not self.label.strip():raise ValueError("segment label required")

@dataclass(frozen=True)
class ProperTimeResult:
    status:ChronologyStatus
    coordinate_time_s:float
    proper_time_s:float
    desynchronization_s:float
    segments:int
    provenance:str

def piecewise_inertial_proper_time(segments,*,provenance:str="declared piecewise-inertial worldline")->ProperTimeResult:
    segs=tuple(segments)
    if not segs:raise ValueError("at least one worldline segment required")
    coord=sum(x.coordinate_duration_s for x in segs)
    proper=sum(x.coordinate_duration_s*math.sqrt(1-(x.speed_m_s/C)**2) for x in segs)
    return ProperTimeResult(ChronologyStatus.PASS,coord,proper,coord-proper,len(segs),provenance)

@dataclass(frozen=True)
class ClockReading:
    clock_id:str
    proper_time_s:float
    standard_uncertainty_s:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if not self.clock_id.strip() or not self.provenance.strip():raise ValueError("clock identity/provenance required")
        if not math.isfinite(self.proper_time_s) or not math.isfinite(self.standard_uncertainty_s) or self.standard_uncertainty_s<0:raise ValueError("finite clock reading and nonnegative uncertainty required")

@dataclass(frozen=True)
class ClockOffset:
    offset_s:float
    combined_standard_uncertainty_s:float
    significance_sigma:float|None
    provenance:str

def clock_offset(a:ClockReading,b:ClockReading)->ClockOffset:
    d=a.proper_time_s-b.proper_time_s
    u=math.hypot(a.standard_uncertainty_s,b.standard_uncertainty_s)
    sig=None if u==0 else abs(d)/u
    return ClockOffset(d,u,sig,f"{a.clock_id} minus {b.clock_id}; {a.provenance}; {b.provenance}")

@dataclass(frozen=True)
class DeclaredMouthMapping:
    mouth_a_event:ChronologyEvent
    mouth_b_event:ChronologyEvent
    proper_time_offset_s:float
    mapping_uncertainty_s:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if not math.isfinite(self.proper_time_offset_s) or not math.isfinite(self.mapping_uncertainty_s) or self.mapping_uncertainty_s<0:
            raise ValueError("finite mouth mapping and nonnegative uncertainty required")
        if not self.provenance.strip():raise ValueError("mapping provenance required")

@dataclass(frozen=True)
class ChronologyMappingAssessment:
    status:ChronologyStatus
    coordinate_separation_s:float|None
    declared_proper_time_offset_s:float
    return_time_shift_s:float|None
    chronology_reversal_in_declared_model:bool|None
    message:str

def assess_declared_mouth_mapping(mapping:DeclaredMouthMapping)->ChronologyMappingAssessment:
    iv=minkowski_interval(mapping.mouth_a_event,mapping.mouth_b_event)
    if iv.status!=ChronologyStatus.PASS:
        return ChronologyMappingAssessment(iv.status,None,mapping.proper_time_offset_s,None,None,iv.message)
    dt=iv.delta_t_s
    shift=dt-mapping.proper_time_offset_s
    return ChronologyMappingAssessment(ChronologyStatus.PASS,dt,mapping.proper_time_offset_s,shift,shift<0,
        "Kinematic assessment of a DECLARED/SIMULATED mouth-time mapping only; no wormhole existence or chronology violation is inferred.")

@dataclass(frozen=True)
class ChronologyGuardianContract:
    schema:str
    status:str
    facts:dict
    provenance:str
    authority:str

def chronology_guardian_contract(*,interval:IntervalResult|None=None,proper_time:ProperTimeResult|None=None,
                                 mapping:ChronologyMappingAssessment|None=None,
                                 provenance:str="C-1 chronology core")->ChronologyGuardianContract:
    status=ChronologyStatus.PASS.value
    facts={}
    for name,obj in (("interval",interval),("proper_time",proper_time),("mouth_mapping",mapping)):
        if obj is not None:
            d=dict(obj.__dict__)
            for k,v in tuple(d.items()):
                if isinstance(v,Enum):d[k]=v.value
            facts[name]=d
            if getattr(obj,"status",ChronologyStatus.PASS)!=ChronologyStatus.PASS:status=getattr(obj,"status").value
    return ChronologyGuardianContract("JOE-GUARDIAN-CHRONOLOGY/1",status,facts,provenance,
        "READ_ONLY_ADVISORY; cannot assert physical CTC/wormhole existence or override BUS-SAFE/control authority")


@dataclass(frozen=True)
class DesynchronizationScenario:
    stationary_elapsed_s:float
    traveling_segments:tuple[WorldlineSegment,...]
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if not math.isfinite(self.stationary_elapsed_s) or self.stationary_elapsed_s<=0:
            raise ValueError("stationary elapsed time must be positive and finite")
        if not self.traveling_segments:raise ValueError("traveling worldline segments required")
        if not self.provenance.strip():raise ValueError("scenario provenance required")

@dataclass(frozen=True)
class DesynchronizationResult:
    status:ChronologyStatus
    stationary_proper_time_s:float
    traveler_proper_time_s:float
    offset_s:float
    coordinate_duration_mismatch_s:float
    message:str
    provenance:str

def relativistic_desynchronization(scenario:DesynchronizationScenario)->DesynchronizationResult:
    traveler=piecewise_inertial_proper_time(scenario.traveling_segments,provenance=scenario.provenance)
    mismatch=traveler.coordinate_time_s-scenario.stationary_elapsed_s
    return DesynchronizationResult(ChronologyStatus.PASS,scenario.stationary_elapsed_s,traveler.proper_time_s,
        scenario.stationary_elapsed_s-traveler.proper_time_s,mismatch,
        "Special-relativistic clock desynchronization for declared piecewise-inertial histories; acceleration transients/gravity are not modeled.",
        scenario.provenance)

@dataclass(frozen=True)
class ChronologyLoopRequest:
    external_separation_m:float
    mouth_time_offset_s:float
    external_return_speed_m_s:float
    offset_standard_uncertainty_s:float=0.0
    separation_standard_uncertainty_m:float=0.0
    speed_standard_uncertainty_m_s:float=0.0
    provenance:str="declared chronology-loop model"
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        vals=(self.external_separation_m,self.mouth_time_offset_s,self.external_return_speed_m_s,
              self.offset_standard_uncertainty_s,self.separation_standard_uncertainty_m,self.speed_standard_uncertainty_m_s)
        if not all(math.isfinite(float(x)) for x in vals):raise ValueError("loop-request values must be finite")
        if self.external_separation_m<0:raise ValueError("external separation must be nonnegative")
        if self.external_return_speed_m_s<=0 or self.external_return_speed_m_s>C:
            raise ValueError("external return speed must satisfy 0 < v <= c")
        if min(self.offset_standard_uncertainty_s,self.separation_standard_uncertainty_m,self.speed_standard_uncertainty_m_s)<0:
            raise ValueError("uncertainties must be nonnegative")
        if not self.provenance.strip():raise ValueError("provenance required")

@dataclass(frozen=True)
class ChronologyLoopAssessment:
    status:ChronologyStatus
    external_return_time_s:float
    mouth_time_offset_s:float
    chronology_margin_s:float
    chronology_margin_standard_uncertainty_s:float
    significance_sigma:float|None
    modeled_closed_causal_loop_condition:bool
    message:str
    provenance:str

def assess_round_trip_loop_condition(request:ChronologyLoopRequest)->ChronologyLoopAssessment:
    """Compare a declared mouth time offset against ordinary external return time.

    margin = offset - L/v. Positive margin means the declared mapping is large enough that
    the modeled itinerary can return before its departure coordinate time. This is a
    kinematic condition on an assumed mapping, not evidence that such a mapping exists.
    """
    L=request.external_separation_m;v=request.external_return_speed_m_s
    t_ext=L/v
    margin=request.mouth_time_offset_s-t_ext
    # First-order independent uncertainty: t=L/v.
    u_t=math.hypot(request.separation_standard_uncertainty_m/v,
                   L*request.speed_standard_uncertainty_m_s/(v*v))
    u=math.hypot(request.offset_standard_uncertainty_s,u_t)
    sig=None if u==0 else margin/u
    return ChronologyLoopAssessment(ChronologyStatus.PASS,t_ext,request.mouth_time_offset_s,margin,u,sig,margin>0,
        "DECLARED/SIMULATED causal-loop condition only. Positive margin does not demonstrate a physical wormhole, time machine, or CTC.",
        request.provenance)

@dataclass(frozen=True)
class ChronologyHorizonEstimate:
    status:ChronologyStatus
    threshold_offset_s:float
    current_offset_s:float
    margin_to_threshold_s:float
    horizon_crossed_in_declared_model:bool
    message:str
    provenance:str

def chronology_horizon_estimate(*,external_separation_m:float,mouth_time_offset_s:float,
                                limiting_signal_speed_m_s:float=C,
                                provenance:str="declared chronology-horizon estimate")->ChronologyHorizonEstimate:
    L=float(external_separation_m);dt=float(mouth_time_offset_s);v=float(limiting_signal_speed_m_s)
    if not all(math.isfinite(x) for x in (L,dt,v)) or L<0 or v<=0 or v>C:
        raise ValueError("finite nonnegative separation and 0 < limiting speed <= c required")
    threshold=L/v
    margin=dt-threshold
    return ChronologyHorizonEstimate(ChronologyStatus.PASS,threshold,dt,margin,margin>=0,
        "Kinematic threshold in a declared two-mouth model; not a semiclassical chronology-horizon solution.",
        provenance)

@dataclass(frozen=True)
class WorldlineSample:
    coordinate_time_s:float
    proper_time_s:float
    distance_m:float
    speed_m_s:float
    segment_label:str

def sample_piecewise_worldline(segments,*,samples_per_segment:int=16)->tuple[WorldlineSample,...]:
    segs=tuple(segments)
    if not segs:raise ValueError("at least one segment required")
    n=int(samples_per_segment)
    if n<1:raise ValueError("samples_per_segment must be >= 1")
    out=[];t=0.0;tau=0.0;x=0.0
    for seg in segs:
        gamma_inv=math.sqrt(1-(seg.speed_m_s/C)**2)
        for i in range(n):
            f=i/n
            out.append(WorldlineSample(t+seg.coordinate_duration_s*f,
                tau+seg.coordinate_duration_s*f*gamma_inv,
                x+seg.coordinate_duration_s*f*seg.speed_m_s,seg.speed_m_s,seg.label))
        t+=seg.coordinate_duration_s;tau+=seg.coordinate_duration_s*gamma_inv;x+=seg.coordinate_duration_s*seg.speed_m_s
    last=segs[-1]
    out.append(WorldlineSample(t,tau,x,last.speed_m_s,last.label))
    return tuple(out)

@dataclass(frozen=True)
class ChronologyMarginSweepPoint:
    mouth_time_offset_s:float
    chronology_margin_s:float
    modeled_closed_causal_loop_condition:bool

def chronology_margin_sweep(request:ChronologyLoopRequest,offsets_s)->tuple[ChronologyMarginSweepPoint,...]:
    out=[]
    for off in offsets_s:
        q=ChronologyLoopRequest(request.external_separation_m,float(off),request.external_return_speed_m_s,
            request.offset_standard_uncertainty_s,request.separation_standard_uncertainty_m,
            request.speed_standard_uncertainty_m_s,request.provenance,request.origin)
        r=assess_round_trip_loop_condition(q)
        out.append(ChronologyMarginSweepPoint(float(off),r.chronology_margin_s,r.modeled_closed_causal_loop_condition))
    return tuple(out)

def expanded_chronology_guardian_contract(*,loop:ChronologyLoopAssessment|None=None,
                                          horizon:ChronologyHorizonEstimate|None=None,
                                          desynchronization:DesynchronizationResult|None=None,
                                          provenance:str="C-1 chronology analysis")->ChronologyGuardianContract:
    facts={}
    for name,obj in (("loop",loop),("horizon",horizon),("desynchronization",desynchronization)):
        if obj is not None:
            d=dict(obj.__dict__)
            for k,v in tuple(d.items()):
                if isinstance(v,Enum):d[k]=v.value
            facts[name]=d
    return ChronologyGuardianContract("JOE-GUARDIAN-CHRONOLOGY/1",ChronologyStatus.PASS.value,facts,provenance,
        "READ_ONLY_ADVISORY; modeled loop/horizon conditions are not physical CTC evidence and cannot override BUS-SAFE/control authority")


@dataclass(frozen=True)
class ChronologyUncertaintyEnvelope:
    nominal_margin_s:float
    standard_uncertainty_s:float
    lower_margin_s:float
    upper_margin_s:float
    confidence_factor:float
    classification:str
    provenance:str

def chronology_uncertainty_envelope(assessment:ChronologyLoopAssessment,*,confidence_factor:float=3.0)->ChronologyUncertaintyEnvelope:
    k=float(confidence_factor)
    if not math.isfinite(k) or k<=0:raise ValueError("confidence factor must be positive and finite")
    m=assessment.chronology_margin_s;u=assessment.chronology_margin_standard_uncertainty_s
    lo=m-k*u;hi=m+k*u
    cls="ROBUST_MODELED_LOOP" if lo>0 else ("ROBUST_NO_LOOP" if hi<0 else "INDETERMINATE_WITHIN_UNCERTAINTY")
    return ChronologyUncertaintyEnvelope(m,u,lo,hi,k,cls,
        "uncertainty envelope around a declared/simulated chronology margin")

@dataclass(frozen=True)
class ChronologyProtectionDiagnostic:
    status:ChronologyStatus
    chronology_threshold_reached:bool
    qft_model_available:bool
    conclusion:str
    warnings:tuple[str,...]
    provenance:str

def chronology_protection_diagnostic(*,horizon:ChronologyHorizonEstimate,
                                     qft_solver_status:str|None=None,
                                     provenance:str="C-1 chronology-protection diagnostic")->ChronologyProtectionDiagnostic:
    """Epistemic gate, not a chronology-protection theorem solver."""
    available=qft_solver_status=="PASS"
    warnings=[
        "JOE does not implement a validated renormalized stress-energy solution at a chronology horizon.",
        "A kinematic chronology threshold is not evidence that chronology protection succeeds or fails."
    ]
    if horizon.horizon_crossed_in_declared_model:
        conclusion="UNKNOWN_PHYSICS: declared model reaches chronology threshold; semiclassical backreaction outcome is unresolved."
        status=ChronologyStatus.UNKNOWN_PHYSICS
    else:
        conclusion="No chronology threshold in the declared kinematic scenario; no chronology-protection conclusion required."
        status=ChronologyStatus.PASS
    if available:
        warnings.append("Available QFT reference models do not establish curved-spacetime chronology-horizon backreaction.")
    return ChronologyProtectionDiagnostic(status,horizon.horizon_crossed_in_declared_model,available,conclusion,tuple(warnings),provenance)

@dataclass(frozen=True)
class ChronologyConvergence:
    passed:bool
    tested_offsets_s:tuple[float,...]
    maximum_absolute_identity_error_s:float
    checks:tuple[str,...]
    failures:tuple[str,...]
    provenance:str

def chronology_numerical_verification(request:ChronologyLoopRequest)->ChronologyConvergence:
    checks=[];fail=[];errs=[]
    t=request.external_separation_m/request.external_return_speed_m_s
    offsets=(0.0,.5*t,t,1.5*t,2*t) if t>0 else (0.0,1.0,2.0)
    sweep=chronology_margin_sweep(request,offsets)
    for pt in sweep:
        e=abs(pt.chronology_margin_s-(pt.mouth_time_offset_s-t));errs.append(e)
    if max(errs,default=0.0)<=1e-12*max(1.0,t):checks.append("chronology-margin algebraic identity benchmark passed")
    else:fail.append("chronology-margin identity benchmark failed")
    threshold=chronology_horizon_estimate(external_separation_m=request.external_separation_m,
        mouth_time_offset_s=t,limiting_signal_speed_m_s=request.external_return_speed_m_s,provenance=request.provenance)
    if abs(threshold.margin_to_threshold_s)<=1e-12*max(1.0,t):checks.append("chronology-threshold equality benchmark passed")
    else:fail.append("chronology-threshold equality benchmark failed")
    if len(sweep)>=3 and all(sweep[i].chronology_margin_s<=sweep[i+1].chronology_margin_s for i in range(len(sweep)-1)):
        checks.append("chronology-margin monotonicity benchmark passed")
    else:fail.append("chronology-margin monotonicity benchmark failed")
    return ChronologyConvergence(not fail,tuple(offsets),max(errs,default=0.0),tuple(checks),tuple(fail),
        "independent C-1 kinematic identity/threshold/monotonicity verification")

@dataclass(frozen=True)
class ChronologyExperimentRecord:
    experiment_id:str
    loop_assessment:ChronologyLoopAssessment
    uncertainty:ChronologyUncertaintyEnvelope
    horizon:ChronologyHorizonEstimate
    protection:ChronologyProtectionDiagnostic
    verification:ChronologyConvergence
    epistemic_classification:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def analyze_chronology_experiment(experiment_id:str,request:ChronologyLoopRequest,*,confidence_factor:float=3.0)->ChronologyExperimentRecord:
    if not experiment_id.strip():raise ValueError("experiment ID required")
    loop=assess_round_trip_loop_condition(request)
    env=chronology_uncertainty_envelope(loop,confidence_factor=confidence_factor)
    horizon=chronology_horizon_estimate(external_separation_m=request.external_separation_m,
        mouth_time_offset_s=request.mouth_time_offset_s,limiting_signal_speed_m_s=request.external_return_speed_m_s,
        provenance=request.provenance)
    protection=chronology_protection_diagnostic(horizon=horizon,provenance=request.provenance)
    verify=chronology_numerical_verification(request)
    epistemic=("SIMULATED_KINEMATIC_LOOP_CONDITION" if loop.modeled_closed_causal_loop_condition
               else "SIMULATED_KINEMATIC_NO_LOOP")
    return ChronologyExperimentRecord(experiment_id,loop,env,horizon,protection,verify,epistemic,request.provenance,request.origin)

@dataclass(frozen=True)
class C1ReleaseReadiness:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    notes:tuple[str,...]

def c1_release_readiness()->C1ReleaseReadiness:
    checks=[];fail=[];notes=[]
    try:
        a=ChronologyEvent("A",0,(0,0,0),"frame","epoch","TCB",provenance="qualification")
        b=ChronologyEvent("B",1,(1,0,0),"frame","epoch","TCB",provenance="qualification")
        iv=minkowski_interval(a,b)
        if iv.interval_class==IntervalClass.TIMELIKE and iv.causal_order==CausalOrder.A_BEFORE_B:checks.append("Minkowski causal-order benchmark passed")
        else:fail.append("Minkowski causal-order benchmark failed")
        pt=piecewise_inertial_proper_time((WorldlineSegment(10,.6*C,"qualification"),))
        if abs(pt.proper_time_s-8)<1e-10:checks.append("special-relativistic proper-time benchmark passed")
        else:fail.append("proper-time benchmark failed")
        req=ChronologyLoopRequest(100,2,100,.1,1,1,"qualification")
        ex=analyze_chronology_experiment("qualification",req)
        if ex.verification.passed:checks.append("chronology numerical verification passed")
        else:fail.extend(ex.verification.failures)
        if ex.protection.status==ChronologyStatus.UNKNOWN_PHYSICS:checks.append("chronology-protection unknown-physics gate passed")
        else:fail.append("chronology-protection epistemic gate failed")
        if ex.epistemic_classification.startswith("SIMULATED_"):checks.append("simulation epistemic labeling passed")
        else:fail.append("simulation epistemic labeling failed")
        g=expanded_chronology_guardian_contract(loop=ex.loop_assessment,horizon=ex.horizon)
        if g.schema=="JOE-GUARDIAN-CHRONOLOGY/1" and "not physical CTC evidence" in g.authority:checks.append("Guardian chronology authority gate passed")
        else:fail.append("Guardian chronology authority gate failed")
    except Exception as exc:fail.append(f"release-readiness exception: {type(exc).__name__}: {exc}")
    notes.append("C-1 qualifies kinematic chronology analysis only; it does not demonstrate a wormhole, CTC, chronology horizon, or chronology-protection mechanism.")
    notes.append("Semiclassical behavior at a chronology threshold remains UNKNOWN_PHYSICS in this implementation.")
    return C1ReleaseReadiness(not fail,tuple(checks),tuple(fail),tuple(notes))

# --- JOE-PHYSICS-EXT-002B: CTC consistency hypothesis and open-system diagnostics ---
class CTCConsistencyStatus(str,Enum):
    SELF_CONSISTENT_FIXED_POINT="SELF_CONSISTENT_FIXED_POINT"
    MULTIPLE_FIXED_POINTS="MULTIPLE_FIXED_POINTS"
    NONCONVERGED="NONCONVERGED"
    DOMAIN_INVALID="DOMAIN_INVALID"
    MODEL_UNAVAILABLE="MODEL_UNAVAILABLE"
    UNKNOWN_PHYSICS="UNKNOWN_PHYSICS"

@dataclass(frozen=True)
class FixedPointResult:
    status:CTCConsistencyStatus
    state:tuple[float,...]|None
    residual:float
    iterations:int
    residual_history:tuple[float,...]
    message:str
    provenance:str

def ctc_fixed_point_relaxation(mapping,initial_state,*,damping:float=.5,tolerance:float=1e-10,max_iterations:int=1000,provenance:str="declared Novikov-consistency hypothesis")->FixedPointResult:
    """Search X*=F(X*) for a user/model supplied map. Numerical convergence is not evidence nature enforces Novikov consistency."""
    x=tuple(float(v) for v in initial_state)
    if not x or not all(math.isfinite(v) for v in x) or not (0<damping<=1) or tolerance<=0 or max_iterations<1:
        return FixedPointResult(CTCConsistencyStatus.DOMAIN_INVALID,None,math.inf,0,(),"Invalid fixed-point solver domain.",provenance)
    hist=[]
    for i in range(1,max_iterations+1):
        try: fx=tuple(float(v) for v in mapping(x))
        except Exception as exc: return FixedPointResult(CTCConsistencyStatus.MODEL_UNAVAILABLE,None,math.inf,i-1,tuple(hist),f"Mapping evaluation failed: {type(exc).__name__}: {exc}",provenance)
        if len(fx)!=len(x) or not all(math.isfinite(v) for v in fx): return FixedPointResult(CTCConsistencyStatus.DOMAIN_INVALID,None,math.inf,i-1,tuple(hist),"Mapping returned invalid state.",provenance)
        residual=math.sqrt(sum((fx[j]-x[j])**2 for j in range(len(x))))
        hist.append(residual)
        if residual<tolerance: return FixedPointResult(CTCConsistencyStatus.SELF_CONSISTENT_FIXED_POINT,x,residual,i,tuple(hist),"Numerical fixed point found under the declared self-consistency hypothesis; this is not physical CTC evidence.",provenance)
        x=tuple((1-damping)*x[j]+damping*fx[j] for j in range(len(x)))
    return FixedPointResult(CTCConsistencyStatus.NONCONVERGED,x,hist[-1],max_iterations,tuple(hist),"No fixed point converged within the declared numerical budget; this does not prove no solution exists.",provenance)

@dataclass(frozen=True)
class FixedPointSurvey:
    status:CTCConsistencyStatus
    solutions:tuple[tuple[float,...],...]
    runs:int
    message:str

def ctc_fixed_point_survey(mapping,seeds,*,merge_tolerance:float=1e-7,**kwargs)->FixedPointSurvey:
    sols=[]; runs=0
    for seed in seeds:
        runs+=1; r=ctc_fixed_point_relaxation(mapping,seed,**kwargs)
        if r.status==CTCConsistencyStatus.SELF_CONSISTENT_FIXED_POINT and r.state is not None:
            if not any(math.sqrt(sum((a-b)**2 for a,b in zip(r.state,s)))<=merge_tolerance for s in sols): sols.append(r.state)
    status=CTCConsistencyStatus.MULTIPLE_FIXED_POINTS if len(sols)>1 else (CTCConsistencyStatus.SELF_CONSISTENT_FIXED_POINT if len(sols)==1 else CTCConsistencyStatus.NONCONVERGED)
    return FixedPointSurvey(status,tuple(sols),runs,"Numerical basin survey of the declared consistency map; solution count is seed/method dependent and not a law of nature.")

@dataclass(frozen=True)
class DecoherenceDiagnostic:
    purity:float
    von_neumann_entropy_nats:float
    coherence_l1:float
    message:str

def density_matrix_diagnostics(rho)->DecoherenceDiagnostic:
    """Small density-matrix diagnostic without NumPy dependency; validates Hermitian trace-one positive-semidefinite 2x2 states."""
    if len(rho)!=2 or any(len(row)!=2 for row in rho): raise ValueError("current diagnostic supports 2x2 density matrices")
    a=complex(rho[0][0]); b=complex(rho[0][1]); c=complex(rho[1][0]); d=complex(rho[1][1])
    if abs(c-b.conjugate())>1e-10 or abs(a.imag)>1e-10 or abs(d.imag)>1e-10: raise ValueError("density matrix must be Hermitian")
    if abs((a+d).real-1)>1e-10 or abs((a+d).imag)>1e-10: raise ValueError("density matrix trace must equal one")
    det=(a*d-b*c).real
    if a.real < -1e-10 or d.real < -1e-10 or det < -1e-10: raise ValueError("density matrix must be positive semidefinite")
    purity=(a*a+b*c+c*b+d*d).real
    disc=max(0.0,1-4*max(0.0,det)); root=math.sqrt(disc); eig=((1+root)/2,(1-root)/2)
    entropy=-sum(v*math.log(v) for v in eig if v>0)
    return DecoherenceDiagnostic(purity,entropy,abs(b)+abs(c),"Open-system density-matrix diagnostic only; no universal macroscopic CTC decoherence law is asserted.")

def dephasing_channel_2x2(rho,coherence_factor:float):
    if not math.isfinite(coherence_factor) or not 0<=coherence_factor<=1: raise ValueError("coherence factor must satisfy 0 <= eta <= 1")
    density_matrix_diagnostics(rho)
    return ((complex(rho[0][0]),coherence_factor*complex(rho[0][1])),(coherence_factor*complex(rho[1][0]),complex(rho[1][1])))

@dataclass(frozen=True)
class CTCGuardianContract:
    schema:str
    status:str
    facts:dict
    provenance:str
    authority:str

def ctc_consistency_guardian_contract(*,fixed_point:FixedPointResult|None=None,decoherence:DecoherenceDiagnostic|None=None,provenance:str="C-1 consistency laboratory")->CTCGuardianContract:
    facts={}; status=CTCConsistencyStatus.UNKNOWN_PHYSICS.value
    if fixed_point is not None:
        facts["fixed_point"]={k:(v.value if isinstance(v,Enum) else v) for k,v in fixed_point.__dict__.items()}; status=fixed_point.status.value
    if decoherence is not None: facts["open_system"] = dict(decoherence.__dict__)
    return CTCGuardianContract("JOE-GUARDIAN-CTC-CONSISTENCY/1",status,facts,provenance,
        "READ_ONLY_ADVISORY; numerical self-consistency/decoherence models cannot establish physical CTC existence, Novikov as a law, or override deterministic control/BUS-SAFE")

def ctc_consistency_release_readiness():
    failures=[]; checks=[]
    try:
        r=ctc_fixed_point_relaxation(lambda x:(0.5*x[0]+1.0,),(0.0,),damping=1,tolerance=1e-9,max_iterations=100,provenance="qualification")
        if r.status==CTCConsistencyStatus.SELF_CONSISTENT_FIXED_POINT and abs(r.state[0]-2)<1e-7: checks.append("fixed-point convergence benchmark passed")
        else: failures.append("fixed-point convergence benchmark failed")
        bad=ctc_fixed_point_relaxation(lambda x:(x[0]+1.0,),(0.0,),max_iterations=8,provenance="qualification")
        if bad.status==CTCConsistencyStatus.NONCONVERGED: checks.append("nonconvergence remains explicit")
        else: failures.append("nonconvergence gate failed")
        pure=density_matrix_diagnostics(((.5,.5),(.5,.5)))
        mixed=density_matrix_diagnostics(dephasing_channel_2x2(((.5,.5),(.5,.5)),0.0))
        if abs(pure.purity-1)<1e-10 and abs(mixed.purity-.5)<1e-10 and mixed.von_neumann_entropy_nats>pure.von_neumann_entropy_nats: checks.append("dephasing/purity/entropy benchmark passed")
        else: failures.append("open-system benchmark failed")
        g=ctc_consistency_guardian_contract(fixed_point=r,decoherence=mixed,provenance="qualification")
        if "cannot establish physical CTC" in g.authority: checks.append("CTC Guardian epistemic gate passed")
        else: failures.append("CTC Guardian epistemic gate failed")
    except Exception as exc: failures.append(f"CTC readiness exception: {type(exc).__name__}: {exc}")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),"notes":("Novikov self-consistency is treated as a selectable hypothesis, not established physics.","Open-system diagnostics are phenomenological and do not establish a universal CTC decoherence law.")}
