from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.compute_backends import (discover_compute_backends,select_backend,compute_guardian_contract,compute_core_readiness,
 GovernedComputeExecutor,execute_workload,workload_provenance_record,compute_execution_readiness,
 GovernedComputeManager,cpu_health,nvidia_gpu_health,amd_gpu_health,compute_v1_release_readiness)
COMPUTE_MODULE=ModuleDescriptor(module_id="journeyman.compute",name="Compute Backend Manager",version="1.1.0",
 requires=("joe.core",),provides=("joe.compute",),consumes=("joe.jobs","joe.host-telemetry"))
class ComputeService:
    def discover(self):return discover_compute_backends()
    select=staticmethod(select_backend)
    guardian_contract=staticmethod(compute_guardian_contract)
    release_readiness=staticmethod(compute_v1_release_readiness)
    execution_readiness=staticmethod(compute_execution_readiness)
    execute=staticmethod(execute_workload)
    provenance_record=staticmethod(workload_provenance_record)
    def create_executor(self,maximum_workers=2):return GovernedComputeExecutor(self.discover(),maximum_workers)
    def create_manager(self,policy=None):return GovernedComputeManager(policy)
    def health(self):return (cpu_health(),nvidia_gpu_health(),amd_gpu_health())
class ComputeInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_compute_module(runtime:ModuleRuntime):
    svc=ComputeService();runtime.register(COMPUTE_MODULE,ComputeInstance(svc));runtime.activate("journeyman.compute")
    runtime.publish_service("journeyman.compute","joe.compute",svc);return svc

# JOE-OPS-005A automatic resource-governor integration.
from journeyman.core.resource_governor import (ComputeProfile,HostResourcePolicy,derive_local_envelope,assess_resources,
                                                guardian_resource_contract,resource_governor_readiness)
def _resource_envelope(self,sample,profile="AUTO",policy=None):
    return derive_local_envelope(sample,ComputeProfile(profile),policy)
def _resource_assessment(self,sample,envelope,policy=None):return assess_resources(sample,envelope,policy)
ComputeService.resource_envelope=_resource_envelope
ComputeService.resource_assessment=_resource_assessment
ComputeService.resource_guardian_contract=staticmethod(guardian_resource_contract)
ComputeService.resource_governor_readiness=staticmethod(resource_governor_readiness)

def _sample_host(self):
    from journeyman.core.telemetry import HostTelemetry
    from journeyman.core.paths import ROOT
    return HostTelemetry(ROOT).sample()
ComputeService.sample_host_resources=_sample_host

# JOE-OPS-005B final operational auto-configuration/admission integration.
from journeyman.core.operational_autoconfig import (configure_startup,external_compute_handshake,workload_admission,
    guardian_operational_contract,operational_autoconfig_readiness)
def _startup_configuration(self,profile="AUTO"):
    s=self.sample_host_resources();e=self.resource_envelope(s,profile);ids=tuple(b.backend_id for b in self.discover() if b.kind.value=="GPU" and b.status.value=="AVAILABLE")
    return configure_startup(s,e,ids)
def _external_handshake(self,kind):
    from journeyman.core.quantum_runtime import discover_quantum_backends
    return external_compute_handshake(kind,self.discover(),discover_quantum_backends())
ComputeService.startup_configuration=_startup_configuration
ComputeService.external_handshake=_external_handshake
ComputeService.workload_admission=staticmethod(workload_admission)
ComputeService.operational_guardian_contract=staticmethod(guardian_operational_contract)
ComputeService.operational_autoconfig_readiness=staticmethod(operational_autoconfig_readiness)
