from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from uuid import uuid4
import json, os, threading

class AlertSeverity(str,Enum):
    WARNING="WARNING"
    CRITICAL="CRITICAL"

class AlertStatus(str,Enum):
    ACTIVE="ACTIVE"
    ACKNOWLEDGED="ACKNOWLEDGED"
    RESOLVED="RESOLVED"

@dataclass(frozen=True)
class AlertRecord:
    alert_id:str
    severity:AlertSeverity
    status:AlertStatus
    source:str
    cause:str
    affected_subsystem:str
    origin:str
    created_at:str
    acknowledged_at:str|None=None
    resolved_at:str|None=None
    acknowledgement_note:str|None=None

@dataclass(frozen=True)
class AlertStoreStatus:
    total:int
    active:int
    acknowledged:int
    resolved:int
    warning:int
    critical:int

def _now(): return datetime.now(timezone.utc).isoformat()
def _text(v,name):
    v=str(v).strip()
    if not v: raise ValueError(f"{name} is required")
    return v

class AlertService:
    """Persistent JOE alert records. This does not command hardware or safety interlocks."""
    SCHEMA=1
    def __init__(self,root:Path):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        self.path=self.root/"alerts.json";self._lock=threading.RLock()
        if not self.path.exists():self._save({"schema":self.SCHEMA,"alerts":[]})

    def _load(self):
        raw=json.loads(self.path.read_text(encoding="utf-8"))
        if raw.get("schema")!=self.SCHEMA or not isinstance(raw.get("alerts"),list):
            raise ValueError("invalid alert repository")
        return raw

    def _save(self,data):
        temp=self.path.with_suffix(".json.tmp")
        with temp.open("w",encoding="utf-8") as f:
            json.dump(data,f,indent=2,sort_keys=True);f.flush();os.fsync(f.fileno())
        os.replace(temp,self.path)

    def _record(self,row):
        return AlertRecord(row["alert_id"],AlertSeverity(row["severity"]),AlertStatus(row["status"]),
            row["source"],row["cause"],row["affected_subsystem"],row["origin"],row["created_at"],
            row.get("acknowledged_at"),row.get("resolved_at"),row.get("acknowledgement_note"))

    def create(self,severity,*,source,cause,affected_subsystem,origin):
        severity=AlertSeverity(severity)
        origin=_text(origin,"origin").upper()
        if origin not in {"SOFTWARE","HOST","IMPORTED","SIMULATION","HARDWARE"}:
            raise ValueError("unsupported alert origin")
        with self._lock:
            data=self._load()
            row={"alert_id":str(uuid4()),"severity":severity.value,"status":AlertStatus.ACTIVE.value,
                 "source":_text(source,"source"),"cause":_text(cause,"cause"),
                 "affected_subsystem":_text(affected_subsystem,"affected subsystem"),
                 "origin":origin,"created_at":_now(),"acknowledged_at":None,"resolved_at":None,
                 "acknowledgement_note":None}
            data["alerts"].append(row);self._save(data);return self._record(row)

    def alerts(self,status=None):
        with self._lock:
            rows=[self._record(x) for x in self._load()["alerts"]]
        if status is not None:
            status=AlertStatus(status);rows=[x for x in rows if x.status is status]
        return tuple(rows)

    def get(self,alert_id):
        for row in self.alerts():
            if row.alert_id==alert_id:return row
        raise KeyError(alert_id)

    def acknowledge(self,alert_id,note=""):
        with self._lock:
            data=self._load()
            row=next((x for x in data["alerts"] if x["alert_id"]==alert_id),None)
            if row is None:raise KeyError(alert_id)
            if row["status"]!=AlertStatus.ACTIVE.value:raise RuntimeError("only ACTIVE alerts can be acknowledged")
            row["status"]=AlertStatus.ACKNOWLEDGED.value;row["acknowledged_at"]=_now()
            row["acknowledgement_note"]=str(note).strip() or None
            self._save(data);return self._record(row)

    def resolve(self,alert_id):
        with self._lock:
            data=self._load()
            row=next((x for x in data["alerts"] if x["alert_id"]==alert_id),None)
            if row is None:raise KeyError(alert_id)
            if row["status"]==AlertStatus.RESOLVED.value:raise RuntimeError("alert already resolved")
            row["status"]=AlertStatus.RESOLVED.value;row["resolved_at"]=_now()
            self._save(data);return self._record(row)

    def find_open(self,*,source,cause,affected_subsystem,origin):
        for row in self.alerts():
            if (row.status is not AlertStatus.RESOLVED and row.source==source and row.cause==cause
                    and row.affected_subsystem==affected_subsystem and row.origin==origin):
                return row
        return None

    def synchronize_health(self,system_health):
        """Create/deduplicate/resolve SOFTWARE health alerts from a diagnostics snapshot."""
        current=set()
        created=[];resolved=[]
        for item in system_health.components:
            state=getattr(item.state,"value",str(item.state))
            if state not in {"DEGRADED","FAILED"}: continue
            severity=AlertSeverity.CRITICAL if state=="FAILED" else AlertSeverity.WARNING
            source="joe.diagnostics"
            cause=f"{state}: {item.summary}"
            subsystem=item.component
            key=(source,cause,subsystem,"SOFTWARE");current.add(key)
            existing=self.find_open(source=source,cause=cause,affected_subsystem=subsystem,origin="SOFTWARE")
            if existing is None:
                created.append(self.create(severity,source=source,cause=cause,
                                           affected_subsystem=subsystem,origin="SOFTWARE"))
        # Only auto-resolve alerts created by this synchronization contract.
        for row in self.alerts():
            if row.status is AlertStatus.RESOLVED or row.source!="joe.diagnostics" or row.origin!="SOFTWARE":
                continue
            key=(row.source,row.cause,row.affected_subsystem,row.origin)
            if key not in current:
                resolved.append(self.resolve(row.alert_id))
        return tuple(created),tuple(resolved)


    def status(self):
        rows=self.alerts()
        return AlertStoreStatus(len(rows),sum(x.status is AlertStatus.ACTIVE for x in rows),
            sum(x.status is AlertStatus.ACKNOWLEDGED for x in rows),sum(x.status is AlertStatus.RESOLVED for x in rows),
            sum(x.severity is AlertSeverity.WARNING for x in rows),sum(x.severity is AlertSeverity.CRITICAL for x in rows))


@dataclass(frozen=True)
class AlertQualification:
    passed:bool
    failures:tuple[str,...]

@dataclass(frozen=True)
class AlertReleaseReadiness:
    passed:bool
    lifecycle_passed:bool
    dedup_passed:bool
    recovery_passed:bool
    failures:tuple[str,...]

def qualify_alerts(service):
    failures=[]
    try:
        rows=service.alerts()
        ids=[x.alert_id for x in rows]
        if len(ids)!=len(set(ids)): failures.append("duplicate alert identity")
        for x in rows:
            if not x.source or not x.cause or not x.affected_subsystem: failures.append(f"incomplete alert: {x.alert_id}")
            if x.status is AlertStatus.ACKNOWLEDGED and not x.acknowledged_at: failures.append(f"acknowledged alert lacks timestamp: {x.alert_id}")
            if x.status is AlertStatus.RESOLVED and not x.resolved_at: failures.append(f"resolved alert lacks timestamp: {x.alert_id}")
    except Exception as exc: failures.append(f"alert repository unreadable: {exc}")
    return AlertQualification(not failures,tuple(failures))

def joe014_release_readiness():
    import tempfile
    from types import SimpleNamespace
    failures=[];lifecycle=False;dedup=False;recovery=False
    try:
        with tempfile.TemporaryDirectory() as td:
            service=AlertService(Path(td))
            a=service.create("WARNING",source="qualification",cause="test warning",affected_subsystem="software",origin="SOFTWARE")
            service.acknowledge(a.alert_id,"reviewed");service.resolve(a.alert_id)
            lifecycle=service.get(a.alert_id).status is AlertStatus.RESOLVED
            bad=SimpleNamespace(components=(SimpleNamespace(state=SimpleNamespace(value="FAILED"),summary="required service missing",component="joe.test"),))
            c1,_=service.synchronize_health(bad);c2,_=service.synchronize_health(bad)
            dedup=len(c1)==1 and len(c2)==0
            good=SimpleNamespace(components=(SimpleNamespace(state=SimpleNamespace(value="HEALTHY"),summary="healthy",component="joe.test"),))
            _,r=service.synchronize_health(good)
            recovery=len(r)==1 and service.get(c1[0].alert_id).status is AlertStatus.RESOLVED
            q=qualify_alerts(service)
            if not lifecycle:failures.append("persistent alert lifecycle exercise failed")
            if not dedup:failures.append("health-alert deduplication exercise failed")
            if not recovery:failures.append("health-alert recovery resolution exercise failed")
            if not q.passed:failures.extend(q.failures)
    except Exception as exc:failures.append(f"JOE-014 readiness exercise failed: {exc}")
    return AlertReleaseReadiness(not failures,lifecycle,dedup,recovery,tuple(failures))
