"""JOE core services."""
