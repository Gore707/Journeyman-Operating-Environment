from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.reports import (validate_report,write_report_specification,load_report_specification,
 report_specification_sha256,report_guardian_contract,report_core_readiness,render_report_text,
 render_report_html,write_rendered_text,report_rendering_readiness,render_report_pdf,
 write_report_artifact_manifest,verify_report_artifact,report_v1_release_readiness)
REPORT_MODULE=ModuleDescriptor(module_id="journeyman.reports",name="Report / Dossier Generator",
 version="1.0.0",requires=("joe.core","journeyman.scientific-data"),provides=("joe.reports",))
class ReportService:
    validate=staticmethod(validate_report)
    save_specification=staticmethod(write_report_specification)
    load_specification=staticmethod(load_report_specification)
    specification_sha256=staticmethod(report_specification_sha256)
    guardian_contract=staticmethod(report_guardian_contract)
    release_readiness=staticmethod(report_v1_release_readiness)
    rendering_readiness=staticmethod(report_rendering_readiness)
    render_text=staticmethod(render_report_text)
    render_html=staticmethod(render_report_html)
    write_rendered_text=staticmethod(write_rendered_text)
    render_pdf=staticmethod(render_report_pdf)
    write_artifact_manifest=staticmethod(write_report_artifact_manifest)
    verify_artifact=staticmethod(verify_report_artifact)
class ReportInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_report_module(runtime:ModuleRuntime):
    svc=ReportService();runtime.register(REPORT_MODULE,ReportInstance(svc))
    runtime.activate("journeyman.reports");runtime.publish_service("journeyman.reports","joe.reports",svc);return svc
