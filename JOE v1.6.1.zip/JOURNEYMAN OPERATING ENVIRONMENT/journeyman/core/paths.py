from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CONFIG_DIR = ROOT / "config"
DATA_DIR = ROOT / "data"
RUNS_DIR = DATA_DIR / "runs"
PROJECTS_DIR = DATA_DIR / "projects"
ALERTS_DIR = DATA_DIR / "alerts"
MPR_DIR = DATA_DIR / "mpr"
LOG_DIR = ROOT / "logs"
SETTINGS_FILE = CONFIG_DIR / "joe_settings.json"
LOCK_FILE = CONFIG_DIR / "joe.lock"


def ensure_directories() -> None:
    for path in (CONFIG_DIR, DATA_DIR, LOG_DIR):
        path.mkdir(parents=True, exist_ok=True)

REGISTRY_DIR = DATA_DIR / "registry"
