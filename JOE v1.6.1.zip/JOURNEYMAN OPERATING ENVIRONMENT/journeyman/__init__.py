"""Journeyman Operating Environment."""
__version__ = "1.6.1"
__build__ = "JOE-SCIINTEL-006B-FINAL"
