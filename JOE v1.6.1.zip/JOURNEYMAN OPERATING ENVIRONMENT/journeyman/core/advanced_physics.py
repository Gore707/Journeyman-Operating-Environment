"""Advanced geometry/QFT/electromagnetic physics extensions for JOE.

This module provides executable algorithms. JSON reference documents remain
metadata/configuration only. All outputs are model/software results and do not
claim physical wormholes, exotic-matter sources, or chronology violation.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
from typing import Sequence
import numpy as np
from .geometry import MetricModel, curvature, minkowski_metric, morris_thorne_metric
from .geometry import stress_energy_from_geometry

C=299_792_458.0
G=6.67430e-11
EPS0=8.8541878128e-12
MU0=1.25663706212e-6
HBAR=1.054571817e-34

@dataclass(frozen=True)
class CurvatureInvariants:
    model_id:str
    coordinates:tuple[float,float,float,float]
    ricci_scalar:float
    ricci_tensor_square:float
    kretschmann_scalar:float
    provenance:str
    data_origin:str="SOFTWARE"

def curvature_invariants(model:MetricModel,coordinates:Sequence[float],*,relative_step:float=2e-5)->CurvatureInvariants:
    """Compute scalar contractions from JOE's numerical curvature tensor.

    Riemann is stored as R^rho_{ sigma mu nu}; this routine lowers its first
    index and performs explicit metric contractions. Values inherit the finite-
    difference uncertainty/limitations of the Geometry engine.
    """
    ev=model.evaluate(coordinates); cur=curvature(model,coordinates,relative_step=relative_step)
    g=ev.matrix(); inv=np.linalg.inv(g); ric=np.asarray(cur.ricci,dtype=float); rm=np.asarray(cur.riemann,dtype=float)
    rlow=np.einsum('ae,ebcd->abcd',g,rm)
    ric2=float(np.einsum('ab,cd,ac,bd',ric,ric,inv,inv))
    k=float(np.einsum('abcd,efgh,ae,bf,cg,dh',rlow,rlow,inv,inv,inv,inv,optimize=True))
    return CurvatureInvariants(model.model_id,tuple(float(x) for x in coordinates),float(cur.ricci_scalar),ric2,k,
        "Numerical tensor contractions of JOE curvature; finite-difference model result.")

@dataclass(frozen=True)
class ElectromagneticStressEnergy:
    electric_field_v_m:tuple[float,float,float]
    magnetic_field_t:tuple[float,float,float]
    energy_density_j_m3:float
    poynting_w_m2:tuple[float,float,float]
    contravariant_tensor_si:tuple[tuple[float,...],...]
    invariant_e2_minus_c2b2:float
    invariant_e_dot_b:float
    provenance:str
    data_origin:str="SOFTWARE"

def electromagnetic_stress_energy(electric_field_v_m:Sequence[float],magnetic_field_t:Sequence[float])->ElectromagneticStressEnergy:
    """Flat-local-orthonormal-frame Maxwell stress-energy in SI units.

    Tensor convention is (-,+,+,+), x^0=ct, T^00=u, T^0i=S_i/c.
    Spatial T^ij is minus the conventional Maxwell stress tensor. This is a
    local field-source calculation, not a solved Einstein-Maxwell spacetime.
    """
    e=np.asarray(tuple(float(x) for x in electric_field_v_m),dtype=float)
    b=np.asarray(tuple(float(x) for x in magnetic_field_t),dtype=float)
    if e.shape!=(3,) or b.shape!=(3,) or not np.all(np.isfinite(e)) or not np.all(np.isfinite(b)):
        raise ValueError("E and B must each contain three finite components")
    e2=float(e@e);b2=float(b@b)
    u=0.5*(EPS0*e2+b2/MU0);s=np.cross(e,b)/MU0
    sigma=EPS0*(np.outer(e,e)-0.5*np.eye(3)*e2)+(1/MU0)*(np.outer(b,b)-0.5*np.eye(3)*b2)
    t=np.zeros((4,4),dtype=float);t[0,0]=u;t[0,1:]=s/C;t[1:,0]=s/C;t[1:,1:]=-sigma
    return ElectromagneticStressEnergy(tuple(e),tuple(b),u,tuple(float(x) for x in s),
        tuple(tuple(float(v) for v in row) for row in t),e2-C*C*b2,float(e@b),
        "Classical Maxwell field in a local orthonormal frame; SI; signature (-,+,+,+).")

@dataclass(frozen=True)
class EinsteinSourceCoupling:
    coupling_per_j_m3:float
    source_tensor_per_m2:tuple[tuple[float,...],...]
    interpretation:str
    solver_status:str

def einstein_source_from_stress_energy(tensor_si:Sequence[Sequence[float]],*,cosmological_constant_per_m2:float=0.0)->EinsteinSourceCoupling:
    """Return (8*pi*G/c^4)T_mu_nu source scale, without inventing a metric solution."""
    t=np.asarray(tensor_si,dtype=float)
    lam=float(cosmological_constant_per_m2)
    if t.shape!=(4,4) or not np.all(np.isfinite(t)) or not math.isfinite(lam):raise ValueError("finite 4x4 stress-energy and Lambda required")
    if not np.allclose(t,t.T,rtol=1e-12,atol=1e-12):raise ValueError("stress-energy tensor must be symmetric")
    kappa=8*math.pi*G/C**4;src=kappa*t
    return EinsteinSourceCoupling(kappa,tuple(tuple(float(v) for v in row) for row in src),
        "Einstein-equation source term only. No nonlinear metric solution is inferred; Lambda requires a metric term and is retained as model context.","PASS")

@dataclass(frozen=True)
class CasimirReference:
    separation_m:float
    energy_per_area_j_m2:float
    energy_density_j_m3:float
    normal_pressure_pa:float
    epistemic_class:str
    assumptions:tuple[str,...]

def ideal_parallel_plate_casimir_reference(separation_m:float)->CasimirReference:
    a=float(separation_m)
    if not math.isfinite(a) or a<=0:raise ValueError("plate separation must be positive and finite")
    ea=-(math.pi**2*HBAR*C)/(720*a**3);rho=ea/a;p=-(math.pi**2*HBAR*C)/(240*a**4)
    return CasimirReference(a,ea,rho,p,"ESTABLISHED_PHYSICS_IDEALIZED_MODEL",
        ("perfectly conducting parallel plates","zero-temperature idealization","edge and material corrections neglected","not a macroscopic exotic-matter source model"))

@dataclass(frozen=True)
class SqueezedStateReference:
    squeeze_parameter:float
    mean_photon_number:float
    quadrature_variance_min:float
    quadrature_variance_max:float
    epistemic_class:str
    interpretation:str

def single_mode_squeezed_state_reference(squeeze_parameter:float)->SqueezedStateReference:
    r=float(squeeze_parameter)
    if not math.isfinite(r) or r<0:raise ValueError("squeeze parameter r must be finite and >= 0")
    n=math.sinh(r)**2
    # vacuum-normalized quadrature variance where vacuum = 1/2
    return SqueezedStateReference(r,n,0.5*math.exp(-2*r),0.5*math.exp(2*r),"ESTABLISHED_QUANTUM_OPTICS_MODEL",
        "Single-mode ideal squeezed vacuum. This does not infer a macroscopic negative-energy engineering capability.")

@dataclass(frozen=True)
class TensorCrossVerification:
    case_id:str
    passed:bool
    max_absolute_error:float
    max_relative_error:float
    compared_components:int
    route_a:str
    route_b:str
    notes:tuple[str,...]

def verify_minkowski_curvature(*,absolute_tolerance:float=1e-8)->TensorCrossVerification:
    cur=curvature(minkowski_metric(),(0,0,0,0));arrays=(cur.christoffel_array(),cur.riemann_array(),cur.ricci_matrix(),cur.einstein_matrix())
    err=max(float(np.max(np.abs(x))) for x in arrays)
    return TensorCrossVerification("GEOM.XV.MINKOWSKI.ZERO",err<=absolute_tolerance,err,0.0,sum(x.size for x in arrays),
        "JOE numerical finite-difference tensor route","Independent analytic Minkowski zero-curvature identity",
        ("Known-answer verification; not experimental evidence.",))

def verify_morris_thorne_phi0(*,throat_radius_m:float=2.0,radius_ratio:float=2.0,relative_step:float=5e-5,relative_tolerance:float=5e-3)->TensorCrossVerification:
    """Cross-check numerical Einstein-derived source against analytic Phi=0,b=r0^2/r orthonormal components."""
    r0=float(throat_radius_m);q=float(radius_ratio)
    if r0<=0 or q<=1 or not math.isfinite(r0) or not math.isfinite(q):raise ValueError("require r0>0 and radius_ratio>1")
    r=r0*q;num=stress_energy_from_geometry(morris_thorne_metric(throat_radius=r0),(0,r,math.pi/2,math.pi),relative_step=relative_step)
    scale=C**4/(8*math.pi*G);common=scale*r0*r0/r**4
    analytic=np.asarray((-common,-common,common,common))
    observed=np.asarray((num.energy_density_j_m3,*num.principal_pressures_pa))
    abs_err=np.abs(observed-analytic);rel=abs_err/np.maximum(np.abs(analytic),1e-300)
    return TensorCrossVerification("GEOM.XV.MT.PHI0.BR0SQOVERR",bool(np.max(rel)<=relative_tolerance),float(np.max(abs_err)),float(np.max(rel)),4,
        "JOE numerical metric→curvature→Einstein→stress-energy route","Independent analytic Morris-Thorne Phi=0, b=r0^2/r orthonormal source",
        ("Comparison is model verification only.","No physical wormhole or source feasibility is inferred."))

@dataclass(frozen=True)
class AdvancedPhysicsGuardianContract:
    schema:str
    authority:str
    data_origin:str
    capabilities:tuple[str,...]
    prohibitions:tuple[str,...]

def advanced_physics_guardian_contract()->AdvancedPhysicsGuardianContract:
    return AdvancedPhysicsGuardianContract("JOE-GUARDIAN-ADVANCED-PHYSICS/1","READ_ONLY_ADVISORY","SOFTWARE/MODEL",
        ("curvature invariants","Maxwell stress-energy","Einstein source coupling","Casimir reference","squeezed-state reference","independent tensor cross-verification"),
        ("must not infer a physical wormhole","must not infer a macroscopic exotic-energy source","must not treat Einstein source coupling as a solved metric","must not promote model output to hardware evidence"))

def advanced_physics_release_readiness():
    checks=[];fail=[]
    for name,fn in (("Minkowski cross-verification",verify_minkowski_curvature),("Morris-Thorne analytic cross-verification",verify_morris_thorne_phi0)):
        try:
            result=fn()
            (checks if result.passed else fail).append(name)
        except Exception as exc:fail.append(f"{name}: {type(exc).__name__}: {exc}")
    try:
        em=electromagnetic_stress_energy((1,0,0),(0,1/C,0))
        if em.energy_density_j_m3>0 and np.allclose(np.asarray(em.contravariant_tensor_si),np.asarray(em.contravariant_tensor_si).T):checks.append("EM stress-energy sanity")
        else:fail.append("EM stress-energy sanity")
    except Exception as exc:fail.append(f"EM sanity: {exc}")
    return {"passed":not fail,"checks":tuple(checks),"failures":tuple(fail),
            "notes":("Software/model qualification only.","No physical exotic-matter or Einstein-Maxwell hardware claim.")}
