"""JOE durable storage/configuration foundation."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import json, os, tempfile, re, hashlib, shutil


def _config_checksum(revision: int, values: dict[str, Any], schema_version: int = 1) -> str:
    canonical=json.dumps(
        {"revision":revision,"schema_version":schema_version,"values":values},
        sort_keys=True,separators=(",",":"),ensure_ascii=False
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()

def _legacy_config_checksum(revision: int, values: dict[str, Any]) -> str:
    canonical=json.dumps(
        {"revision":revision,"values":values},
        sort_keys=True,separators=(",",":"),ensure_ascii=False
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


_NAME=re.compile(r"^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$")

def _name(value: str, label: str) -> str:
    value=str(value).strip()
    if not _NAME.fullmatch(value):
        raise ValueError(f"Invalid {label}: {value}")
    return value

@dataclass(frozen=True)
class StoragePaths:
    root: Path
    config: Path
    data: Path
    logs: Path

    @classmethod
    def from_root(cls, root: Path) -> "StoragePaths":
        root=Path(root).resolve()
        return cls(root, root/"config", root/"data", root/"logs")

    def ensure(self) -> None:
        for path in (self.config,self.data,self.logs):
            path.mkdir(parents=True,exist_ok=True)

@dataclass(frozen=True)
class ConfigDocument:
    namespace: str
    revision: int
    values: dict[str, Any]
    checksum: str | None = None
    schema_version: int = 1

class ConfigStore:
    """Namespaced JSON configuration with atomic replacement and revisions."""
    def __init__(self, config_dir: Path) -> None:
        self.config_dir=Path(config_dir)
        self.config_dir.mkdir(parents=True,exist_ok=True)
        self._schemas: dict[str, int] = {}
        self._migrations: dict[tuple[str, int], Any] = {}

    def register_schema(self, namespace: str, version: int) -> None:
        namespace=_name(namespace,"config namespace")
        if not isinstance(version,int) or isinstance(version,bool) or version < 1:
            raise ValueError("schema version must be a positive integer")
        existing=self._schemas.get(namespace)
        if existing is not None and existing != version:
            raise RuntimeError(f"Schema already registered for {namespace}: {existing}")
        self._schemas[namespace]=version

    def register_migration(self, namespace: str, from_version: int, migration) -> None:
        namespace=_name(namespace,"config namespace")
        if not isinstance(from_version,int) or isinstance(from_version,bool) or from_version < 1:
            raise ValueError("from_version must be a positive integer")
        if not callable(migration):
            raise TypeError("migration must be callable")
        key=(namespace,from_version)
        if key in self._migrations:
            raise RuntimeError(f"Migration already registered for {namespace} schema {from_version}")
        self._migrations[key]=migration

    def target_schema(self, namespace: str) -> int:
        return self._schemas.get(_name(namespace,"config namespace"),1)

    def _path(self, namespace: str) -> Path:
        return self.config_dir/f"{_name(namespace,'config namespace')}.json"

    def _backup_path(self, namespace: str) -> Path:
        return self.config_dir/f"{_name(namespace,'config namespace')}.json.bak"

    def load(self, namespace: str) -> ConfigDocument:
        namespace=_name(namespace,"config namespace")
        path=self._path(namespace)
        if not path.exists():
            return ConfigDocument(namespace,0,{})
        try:
            raw=json.loads(path.read_text(encoding="utf-8"))
        except (OSError,json.JSONDecodeError) as exc:
            raise RuntimeError(f"Cannot read configuration {namespace}: {exc}") from exc
        if not isinstance(raw,dict):
            raise RuntimeError(f"Configuration {namespace} root must be an object")
        revision=raw.get("revision")
        values=raw.get("values")
        if not isinstance(revision,int) or isinstance(revision,bool) or revision < 1:
            raise RuntimeError(f"Configuration {namespace} has invalid revision")
        if not isinstance(values,dict):
            raise RuntimeError(f"Configuration {namespace} values must be an object")
        schema_version=raw.get("schema_version",1)
        if not isinstance(schema_version,int) or isinstance(schema_version,bool) or schema_version < 1:
            raise RuntimeError(f"Configuration {namespace} has invalid schema version")
        checksum=raw.get("checksum")
        if checksum is not None:
            if not isinstance(checksum,str):
                raise RuntimeError(f"Configuration {namespace} failed integrity verification")
            expected=_config_checksum(revision,values,schema_version)
            legacy_expected=_legacy_config_checksum(revision,values)
            if checksum not in (expected,legacy_expected):
                raise RuntimeError(f"Configuration {namespace} failed integrity verification")
        return ConfigDocument(namespace,revision,values,checksum,schema_version)

    def _atomic_write_text(self, path: Path, payload: str) -> None:
        fd,tmp=tempfile.mkstemp(prefix=path.name+".",suffix=".tmp",dir=str(self.config_dir))
        tmp_path=Path(tmp)
        try:
            with os.fdopen(fd,"w",encoding="utf-8",newline="\n") as handle:
                handle.write(payload)
                if not payload.endswith("\n"):
                    handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_path,path)
        except Exception:
            try: tmp_path.unlink(missing_ok=True)
            finally: raise

    def has_backup(self, namespace: str) -> bool:
        return self._backup_path(namespace).is_file()

    def recover_backup(self, namespace: str) -> ConfigDocument:
        namespace=_name(namespace,"config namespace")
        backup=self._backup_path(namespace)
        if not backup.exists():
            raise FileNotFoundError(f"No configuration backup exists for {namespace}")
        try:
            raw=json.loads(backup.read_text(encoding="utf-8"))
        except (OSError,json.JSONDecodeError) as exc:
            raise RuntimeError(f"Cannot read configuration backup {namespace}: {exc}") from exc
        if not isinstance(raw,dict) or not isinstance(raw.get("revision"),int) or not isinstance(raw.get("values"),dict):
            raise RuntimeError(f"Configuration backup {namespace} is invalid")
        if isinstance(raw["revision"],bool) or raw["revision"] < 1:
            raise RuntimeError(f"Configuration backup {namespace} has invalid revision")
        schema_version=raw.get("schema_version",1)
        if not isinstance(schema_version,int) or isinstance(schema_version,bool) or schema_version < 1:
            raise RuntimeError(f"Configuration backup {namespace} has invalid schema version")
        checksum=raw.get("checksum")
        if checksum is not None:
            if not isinstance(checksum,str):
                raise RuntimeError(f"Configuration backup {namespace} failed integrity verification")
            expected=_config_checksum(raw["revision"],raw["values"],schema_version)
            legacy_expected=_legacy_config_checksum(raw["revision"],raw["values"])
            if checksum not in (expected,legacy_expected):
                raise RuntimeError(f"Configuration backup {namespace} failed integrity verification")
        payload=json.dumps(raw,indent=2,sort_keys=True,ensure_ascii=False)
        self._atomic_write_text(self._path(namespace),payload)
        return ConfigDocument(namespace,raw["revision"],raw["values"],checksum,schema_version)

    def save(self, namespace: str, values: dict[str, Any],
             expected_revision: int | None=None) -> ConfigDocument:
        namespace=_name(namespace,"config namespace")
        if not isinstance(values,dict):
            raise TypeError("Configuration values must be a dict")
        current=self.load(namespace)
        if expected_revision is not None:
            if not isinstance(expected_revision,int) or isinstance(expected_revision,bool) or expected_revision < 0:
                raise ValueError("expected_revision must be a non-negative integer")
            if expected_revision != current.revision:
                raise RuntimeError(
                    f"Stale configuration write for {namespace}: expected revision "
                    f"{expected_revision}, current revision {current.revision}"
                )
        # Validate serializability before touching disk.
        next_revision=current.revision+1
        schema_version=self.target_schema(namespace)
        document={
            "revision":next_revision,
            "schema_version":schema_version,
            "values":values,
            "checksum":_config_checksum(next_revision,values,schema_version),
        }
        try:
            payload=json.dumps(document,indent=2,sort_keys=True,ensure_ascii=False)
        except (TypeError,ValueError) as exc:
            raise TypeError(f"Configuration {namespace} is not JSON serializable") from exc

        path=self._path(namespace)
        if path.exists():
            # current.load() above proved the existing document is structurally valid.
            # Preserve those exact bytes as the immediately previous recoverable revision.
            try:
                previous=path.read_text(encoding="utf-8")
            except OSError as exc:
                raise RuntimeError(f"Cannot back up configuration {namespace}: {exc}") from exc
            self._atomic_write_text(self._backup_path(namespace),previous)
        self._atomic_write_text(path,payload)
        return ConfigDocument(
            namespace,next_revision,dict(values),document["checksum"],schema_version
        )

    def migrate(self, namespace: str) -> ConfigDocument:
        namespace=_name(namespace,"config namespace")
        current=self.load(namespace)
        if current.revision == 0:
            raise FileNotFoundError(f"No configuration exists for {namespace}")
        target=self.target_schema(namespace)
        if current.schema_version > target:
            raise RuntimeError(
                f"Configuration {namespace} schema {current.schema_version} is newer than supported {target}"
            )
        values=dict(current.values)
        version=current.schema_version
        while version < target:
            migration=self._migrations.get((namespace,version))
            if migration is None:
                raise RuntimeError(
                    f"No migration registered for {namespace} schema {version} -> {version+1}"
                )
            migrated=migration(dict(values))
            if not isinstance(migrated,dict):
                raise TypeError(
                    f"Migration for {namespace} schema {version} must return a dict"
                )
            values=migrated
            version += 1
        if version == current.schema_version:
            return current

        # Write the migrated values under the target schema through the normal
        # atomic/revision/backup path. No source document is modified unless
        # every migration step succeeds.
        return self.save(namespace,values,expected_revision=current.revision)

    def namespaces(self) -> tuple[str,...]:
        result=[]
        for path in self.config_dir.glob("*.json"):
            try:
                raw=json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(raw,dict) or "revision" not in raw or "values" not in raw:
                    continue
                namespace=_name(path.stem,"config namespace")
                self.load(namespace)
                result.append(namespace)
            except (OSError,json.JSONDecodeError,ValueError,RuntimeError):
                # Unrelated settings files and malformed non-ConfigStore JSON are not namespaces.
                continue
        return tuple(sorted(set(result)))



@dataclass(frozen=True)
class DataArtifact:
    namespace: str
    name: str
    path: Path
    size_bytes: int
    checksum: str

class DataStore:
    """Atomic durable storage for JOE-owned non-run data artifacts."""
    def __init__(self, data_dir: Path) -> None:
        self.data_dir=Path(data_dir)
        self.data_dir.mkdir(parents=True,exist_ok=True)

    def _namespace_dir(self, namespace: str) -> Path:
        namespace=_name(namespace,"data namespace")
        path=self.data_dir/namespace
        path.mkdir(parents=True,exist_ok=True)
        return path

    def _artifact_path(self, namespace: str, name: str) -> Path:
        directory=self._namespace_dir(namespace)
        name=_name(name,"artifact name")
        return directory/name

    def write_bytes(self, namespace: str, name: str, payload: bytes) -> DataArtifact:
        if not isinstance(payload,(bytes,bytearray,memoryview)):
            raise TypeError("artifact payload must be bytes-like")
        data=bytes(payload)
        path=self._artifact_path(namespace,name)
        fd,tmp=tempfile.mkstemp(prefix=path.name+".",suffix=".tmp",dir=str(path.parent))
        tmp_path=Path(tmp)
        try:
            with os.fdopen(fd,"wb") as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_path,path)
        except Exception:
            try: tmp_path.unlink(missing_ok=True)
            finally: raise
        return DataArtifact(
            namespace=_name(namespace,"data namespace"),
            name=_name(name,"artifact name"),
            path=path,
            size_bytes=len(data),
            checksum=hashlib.sha256(data).hexdigest(),
        )

    def write_text(self, namespace: str, name: str, text: str) -> DataArtifact:
        if not isinstance(text,str):
            raise TypeError("artifact text must be str")
        return self.write_bytes(namespace,name,text.encode("utf-8"))

    def read_bytes(self, namespace: str, name: str) -> bytes:
        path=self._artifact_path(namespace,name)
        if not path.is_file():
            raise FileNotFoundError(f"Data artifact does not exist: {namespace}/{name}")
        return path.read_bytes()

    def read_text(self, namespace: str, name: str) -> str:
        return self.read_bytes(namespace,name).decode("utf-8")

    def inspect(self, namespace: str, name: str) -> DataArtifact:
        path=self._artifact_path(namespace,name)
        if not path.is_file():
            raise FileNotFoundError(f"Data artifact does not exist: {namespace}/{name}")
        data=path.read_bytes()
        return DataArtifact(
            namespace=_name(namespace,"data namespace"),
            name=_name(name,"artifact name"),
            path=path,
            size_bytes=len(data),
            checksum=hashlib.sha256(data).hexdigest(),
        )

    def list_artifacts(self, namespace: str) -> tuple[DataArtifact,...]:
        directory=self._namespace_dir(namespace)
        result=[]
        for path in sorted(directory.iterdir(),key=lambda item:item.name):
            if path.is_file() and _NAME.fullmatch(path.name):
                data=path.read_bytes()
                result.append(DataArtifact(
                    namespace=_name(namespace,"data namespace"),
                    name=path.name,
                    path=path,
                    size_bytes=len(data),
                    checksum=hashlib.sha256(data).hexdigest(),
                ))
        return tuple(result)

    def delete(self, namespace: str, name: str) -> None:
        path=self._artifact_path(namespace,name)
        if not path.is_file():
            raise FileNotFoundError(f"Data artifact does not exist: {namespace}/{name}")
        path.unlink()

class StorageService:
    """JOE-owned entry point for durable storage facilities."""
    def __init__(self, root: Path) -> None:
        self.paths=StoragePaths.from_root(root)
        self.paths.ensure()
        self.config=ConfigStore(self.paths.config)
        self.data=DataStore(self.paths.data)


@dataclass(frozen=True)
class StorageQualification:
    passed: bool
    failures: tuple[str, ...]
    namespaces: tuple[str, ...]

def qualify_storage(service: StorageService) -> StorageQualification:
    failures: list[str] = []
    for label,path in (
        ("root",service.paths.root),
        ("config",service.paths.config),
        ("data",service.paths.data),
        ("logs",service.paths.logs),
    ):
        if not path.exists():
            failures.append(f"{label} path does not exist: {path}")
        elif not path.is_dir():
            failures.append(f"{label} path is not a directory: {path}")

    # Data root may contain only namespace directories created by owning subsystems.
    for entry in service.paths.data.iterdir():
        if entry.is_file():
            failures.append(f"Unexpected file at JOE data root: {entry.name}")

    namespaces=service.config.namespaces()
    for namespace in namespaces:
        try:
            document=service.config.load(namespace)
            # Legacy documents are valid but do not yet have cryptographic integrity metadata.
            if document.checksum is None:
                failures.append(
                    f"Configuration {namespace} is legacy and has no integrity checksum."
                )
            target=service.config.target_schema(namespace)
            if document.schema_version > target:
                failures.append(
                    f"Configuration {namespace} schema {document.schema_version} "
                    f"is newer than supported {target}."
                )
        except Exception as exc:
            failures.append(f"Configuration {namespace}: {exc}")

    return StorageQualification(not failures,tuple(failures),namespaces)


@dataclass(frozen=True)
class StorageHealth:
    passed: bool
    failures: tuple[str, ...]
    total_bytes: int
    used_bytes: int
    free_bytes: int
    config_writable: bool
    data_writable: bool
    logs_writable: bool

def _probe_writable(directory: Path) -> bool:
    try:
        fd,path=tempfile.mkstemp(prefix=".joe-write-probe-",dir=str(directory))
        try:
            with os.fdopen(fd,"wb") as handle:
                handle.write(b"JOE")
                handle.flush()
                os.fsync(handle.fileno())
        finally:
            Path(path).unlink(missing_ok=True)
        return True
    except OSError:
        return False

def storage_health(service: StorageService, minimum_free_bytes: int = 64 * 1024 * 1024) -> StorageHealth:
    if not isinstance(minimum_free_bytes,int) or isinstance(minimum_free_bytes,bool) or minimum_free_bytes < 0:
        raise ValueError("minimum_free_bytes must be a non-negative integer")
    failures: list[str] = []
    try:
        usage=shutil.disk_usage(service.paths.root)
        total,used,free=usage.total,usage.used,usage.free
    except OSError as exc:
        return StorageHealth(False,(f"Cannot read filesystem capacity: {exc}",),0,0,0,False,False,False)

    writable={}
    for label,path in (
        ("config",service.paths.config),
        ("data",service.paths.data),
        ("logs",service.paths.logs),
    ):
        ok=_probe_writable(path)
        writable[label]=ok
        if not ok:
            failures.append(f"{label} directory is not writable: {path}")

    if free < minimum_free_bytes:
        failures.append(
            f"Free storage {free} bytes is below required minimum {minimum_free_bytes} bytes."
        )

    return StorageHealth(
        passed=not failures,
        failures=tuple(failures),
        total_bytes=total,
        used_bytes=used,
        free_bytes=free,
        config_writable=writable["config"],
        data_writable=writable["data"],
        logs_writable=writable["logs"],
    )


@dataclass(frozen=True)
class StorageReleaseReadiness:
    passed: bool
    failures: tuple[str, ...]
    config_namespaces: tuple[str, ...]
    total_bytes: int
    free_bytes: int

def joe005_release_readiness(service: StorageService) -> StorageReleaseReadiness:
    failures: list[str] = []

    qualification=qualify_storage(service)
    failures.extend(qualification.failures)

    health=storage_health(service)
    failures.extend(health.failures)

    # Exercise the storage implementation in an isolated temporary JOE root so
    # the release gate never creates/deletes user artifacts or configuration.
    try:
        with tempfile.TemporaryDirectory(prefix="joe005-readiness-") as td:
            probe=StorageService(Path(td))

            first=probe.config.save("joe.readiness",{"phase":1})
            second=probe.config.save(
                "joe.readiness",{"phase":2},expected_revision=first.revision
            )
            if second.revision != first.revision + 1:
                failures.append("Configuration revision probe did not advance monotonically.")
            if not probe.config.has_backup("joe.readiness"):
                failures.append("Configuration backup probe did not create a recovery copy.")
            else:
                recovered=probe.config.recover_backup("joe.readiness")
                if recovered.revision != first.revision or recovered.values != first.values:
                    failures.append("Configuration recovery probe did not restore prior content.")

            artifact=probe.data.write_bytes("joe.readiness","probe.bin",b"JOE-005")
            readback=probe.data.read_bytes("joe.readiness","probe.bin")
            if readback != b"JOE-005":
                failures.append("Data artifact durability probe failed byte-for-byte readback.")
            if artifact.checksum != hashlib.sha256(readback).hexdigest():
                failures.append("Data artifact durability probe checksum mismatch.")
            probe.data.delete("joe.readiness","probe.bin")

            probe_health=storage_health(probe,minimum_free_bytes=0)
            if not probe_health.passed:
                failures.extend(
                    f"Isolated storage health probe: {item}"
                    for item in probe_health.failures
                )
    except Exception as exc:
        failures.append(f"Isolated JOE-005 durability probe failed: {exc}")

    return StorageReleaseReadiness(
        passed=not failures,
        failures=tuple(failures),
        config_namespaces=qualification.namespaces,
        total_bytes=health.total_bytes,
        free_bytes=health.free_bytes,
    )
