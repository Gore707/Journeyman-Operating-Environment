"""Scientific Object Registry module."""
from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.paths import REGISTRY_DIR
from journeyman.core.scientific_registry import ScientificObjectRegistry
REGISTRY_MODULE=ModuleDescriptor(module_id="journeyman.registry",name="Scientific Object Registry",version="1.0.0",
 description="Authoritative stable identity and revision registry for scientific objects.",
 requires=("joe.core",),provides=("joe.scientific-registry","joe.units",),consumes=("joe.state-events","joe.storage"))
class RegistryInstance(ModuleInstance):
    def __init__(self,registry):self.registry=registry;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_scientific_registry_module(runtime:ModuleRuntime):
    r=ScientificObjectRegistry(REGISTRY_DIR,runtime.service("joe.state-events"))
    runtime.register(REGISTRY_MODULE,RegistryInstance(r));runtime.activate("journeyman.registry")
    runtime.publish_service("journeyman.registry","joe.scientific-registry",r)
    from journeyman.core.units import DEFAULT_UNITS
    runtime.publish_service("journeyman.registry","joe.units",DEFAULT_UNITS)
    return r
