"""Pure workspace policies shared by the JOE window manager."""


def cycle_index(count: int, current: int, direction: int = 1):
    if count <= 0:
        return None
    step = 1 if direction >= 0 else -1
    if current < 0 or current >= count:
        return 0 if step > 0 else count - 1
    return (current + step) % count


def validate_workspace_title(title: str, *, max_length: int = 80) -> str:
    """Return a cleaned user-visible title or raise ValueError.

    Workspace titles are display metadata only.  Control characters are rejected
    so saved layouts and logs remain readable and deterministic.
    """
    cleaned = str(title).strip()
    if not cleaned:
        raise ValueError("Workspace title cannot be empty.")
    if len(cleaned) > max_length:
        raise ValueError(f"Workspace title cannot exceed {max_length} characters.")
    if any(ord(ch) < 32 for ch in cleaned):
        raise ValueError("Workspace title cannot contain control characters.")
    return cleaned


def normalize_display_index(count: int, requested: int) -> int:
    """Validate and return a zero-based display index."""
    if count <= 0:
        raise ValueError("No displays are available.")
    if requested < 0 or requested >= count:
        raise ValueError(f"Display index {requested} is outside the available range 0..{count - 1}.")
    return requested


def can_modify_workspace(locked: bool) -> bool:
    """Central policy used by UI actions that mutate workspace placement/lifecycle."""
    return not bool(locked)
