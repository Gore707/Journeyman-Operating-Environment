import logging
from logging.handlers import RotatingFileHandler
from .paths import LOG_DIR

LOG_FILE = LOG_DIR / "joe.log"


def configure_logging() -> logging.Logger:
    logger = logging.getLogger("journeyman")
    if logger.handlers:
        return logger
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    file_handler = RotatingFileHandler(LOG_FILE, maxBytes=2_000_000, backupCount=5, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger
