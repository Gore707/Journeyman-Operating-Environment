"""JOE 004B phase-space diagnostics and deterministic stress qualification.

All campaigns are SOFTWARE/SIMULATION.  They test numerical behavior and safety
contracts; they do not establish physical wormholes, CTCs, chronology protection,
or hardware qualification.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np
from journeyman.core.chronology import ctc_fixed_point_relaxation, CTCConsistencyStatus

@dataclass(frozen=True)
class BasinPoint:
    seed: tuple[float,...]
    status: str
    solution: tuple[float,...]
    residual: float
    iterations: int

@dataclass(frozen=True)
class BasinMap:
    x_values: tuple[float,...]
    y_values: tuple[float,...]
    labels: tuple[tuple[int,...],...]
    points: tuple[BasinPoint,...]
    fixed_points: tuple[tuple[float,...],...]
    provenance: str = "SIMULATION: numerical basin-of-attraction diagnostic"

def basin_of_attraction_2d(mapping, *, x_range=(-2.0,2.0), y_range=(-2.0,2.0), resolution=25,
                            damping=.5,tolerance=1e-9,max_iterations=300,merge_tolerance=1e-6)->BasinMap:
    if resolution < 2 or resolution > 250: raise ValueError("resolution must be in [2,250]")
    xs=np.linspace(*x_range,resolution); ys=np.linspace(*y_range,resolution); fixed=[]; points=[]; rows=[]
    for y in ys:
        row=[]
        for x in xs:
            r=ctc_fixed_point_relaxation(mapping,(float(x),float(y)),damping=damping,tolerance=tolerance,max_iterations=max_iterations,provenance="SIMULATION basin diagnostic")
            sol=tuple(float(v) for v in r.state); label=-1
            if r.status==CTCConsistencyStatus.SELF_CONSISTENT_FIXED_POINT:
                for i,f in enumerate(fixed):
                    if np.linalg.norm(np.asarray(sol)-np.asarray(f)) <= merge_tolerance: label=i; break
                else: fixed.append(sol); label=len(fixed)-1
            points.append(BasinPoint((float(x),float(y)),r.status.value,sol,float(r.residual),int(r.iterations))); row.append(label)
        rows.append(tuple(row))
    return BasinMap(tuple(map(float,xs)),tuple(map(float,ys)),tuple(rows),tuple(points),tuple(fixed))

def residual_trajectory(mapping, initial_state, *, damping=.5,steps=100):
    x=np.asarray(initial_state,dtype=np.float64); history=[]
    if not np.all(np.isfinite(x)): raise ValueError("finite initial state required")
    for n in range(steps):
        fx=np.asarray(mapping(tuple(map(float,x))),dtype=np.float64)
        if fx.shape!=x.shape or not np.all(np.isfinite(fx)): break
        res=float(np.linalg.norm(fx-x)); history.append((n,res,*map(float,x)))
        x=(1.0-damping)*x+damping*fx
    return tuple(history)

def uncertainty_box(center,sigma,k=3.0):
    c=np.asarray(center,dtype=float); s=np.asarray(sigma,dtype=float)
    if c.shape!=s.shape or np.any(s<0) or not np.all(np.isfinite(c)) or not np.all(np.isfinite(s)): raise ValueError("valid center/sigma required")
    return tuple(map(tuple,np.column_stack((c-k*s,c+k*s))))

def safe_state_reachability_series(states, safe_min, safe_max):
    lo=np.asarray(safe_min,dtype=float); hi=np.asarray(safe_max,dtype=float); out=[]
    for i,state in enumerate(states):
        x=np.asarray(state,dtype=float); dist=np.maximum(lo-x,0)+np.maximum(x-hi,0)
        out.append((i,float(np.linalg.norm(dist)),bool(np.all(x>=lo) and np.all(x<=hi))))
    return tuple(out)

def precision_sweep_fixed_point():
    # Same contraction evaluated in float32/float64; analytic solution is (2,-1).
    target=np.array([2.0,-1.0]); rows=[]
    for dtype in (np.float32,np.float64):
        x=np.array([9.0,-7.0],dtype=dtype)
        for n in range(500):
            fx=np.array([dtype(.5)*x[0]+dtype(1),dtype(.25)*x[1]-dtype(.75)],dtype=dtype)
            if float(np.linalg.norm((fx-x).astype(np.float64))) < (1e-6 if dtype==np.float32 else 1e-12): break
            x=fx
        rows.append((np.dtype(dtype).name,tuple(map(float,x)),float(np.linalg.norm(x.astype(float)-target)),n+1))
    return tuple(rows)

def pathological_numerical_campaign():
    checks=[]; failures=[]
    # Oscillating map should not be falsely promoted to a fixed point.
    r=ctc_fixed_point_relaxation(lambda x:(-x[0]+1.0,),(0.0,),damping=1.0,tolerance=1e-12,max_iterations=20,provenance="SIMULATION pathological oscillation")
    (checks if r.status!=CTCConsistencyStatus.SELF_CONSISTENT_FIXED_POINT else failures).append("oscillating boundary not falsely converged")
    # Divergent map must not be falsely converged.
    r=ctc_fixed_point_relaxation(lambda x:(1.5*x[0]+1.0,),(0.0,),damping=1.0,tolerance=1e-12,max_iterations=20,provenance="SIMULATION divergent map")
    (checks if r.status!=CTCConsistencyStatus.SELF_CONSISTENT_FIXED_POINT else failures).append("divergent feedback not falsely converged")
    # Near-singular linear algebra must be identified as ill-conditioned by condition number.
    a=np.array([[1.,1.],[1.,1.+1e-14]]); cond=float(np.linalg.cond(a))
    (checks if cond>1e12 else failures).append("near-singular matrix detected")
    # Extreme finite dynamic range: stable hypot remains finite where naive squaring may overflow.
    h=math.hypot(1e308,1e308)
    (checks if math.isfinite(h) else failures).append("stable extreme-range norm remains finite")
    # Precision agreement against analytic fixed point.
    sweep=precision_sweep_fixed_point(); ok=sweep[0][2]<2e-5 and sweep[1][2]<1e-10
    (checks if ok else failures).append("float32/float64 precision sweep agrees with analytic fixed point")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),"condition_number":cond,"precision_sweep":sweep,
            "truth_boundary":"SOFTWARE/SIMULATION numerical torture campaign; not physical qualification."}

def phase_space_diagnostics_readiness():
    failures=[]; checks=[]
    try:
        m=basin_of_attraction_2d(lambda x:(.5*x[0]+1,.5*x[1]-.5),resolution=7,damping=1)
        if len(m.fixed_points)==1 and len(m.labels)==7: checks.append("2D basin classification generated reproducibly")
        else: failures.append("basin classification benchmark failed")
        tr=residual_trajectory(lambda x:(.5*x[0]+1,.5*x[1]-.5),(0,0),damping=1,steps=20)
        if tr and tr[-1][1] < tr[0][1]: checks.append("residual trajectory decreases for contraction benchmark")
        else: failures.append("residual trajectory benchmark failed")
        if uncertainty_box((0,1),(.1,.2),3)==((-0.30000000000000004,0.30000000000000004),(0.3999999999999999,1.6)): checks.append("uncertainty bounding box generated")
        else: failures.append("uncertainty box benchmark failed")
    except Exception as exc: failures.append(type(exc).__name__+": "+str(exc))
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),"truth_boundary":"Visualization payloads are derived from declared SOFTWARE/SIMULATION models."}

def final_stress_release_readiness():
    a=phase_space_diagnostics_readiness(); b=pathological_numerical_campaign()
    return {"passed":a["passed"] and b["passed"],"checks":a["checks"]+b["checks"],"failures":a["failures"]+b["failures"],
            "truth_boundary":"Final JOE software/SIL stress qualification only; unresolved physics and physical hardware remain unqualified."}

def guardian_final_stress_contract():
    return {"contract":"JOE-GUARDIAN-FINAL-STRESS/1","authority":"READ_ONLY_ADVISORY","may_command":False,"may_override":False,
            "observes":("basin classifications","residual trajectories","uncertainty boxes","reachability series","precision sweeps","pathological numerical campaign"),
            "truth_boundary":"Guardian interprets software/model diagnostics only and cannot promote them to physical evidence or BUS-SAFE authority."}
