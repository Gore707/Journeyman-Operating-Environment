from pathlib import Path
from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.scientific_intelligence import ScientificIntelligenceService
DESC=ModuleDescriptor(module_id="journeyman.scientific-intelligence",name="Scientific Intelligence",version="1.0.0",requires=("joe.core","journeyman.scientific-reference"),provides=("joe.scientific-intelligence",),consumes=("joe.scientific-reference",))
class Instance(ModuleInstance):
    def __init__(self,svc):self.service=svc;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False

def register_scientific_intelligence_module(runtime:ModuleRuntime,root:Path):
    svc=ScientificIntelligenceService(root);runtime.register(DESC,Instance(svc));runtime.activate("journeyman.scientific-intelligence");runtime.publish_service("journeyman.scientific-intelligence","joe.scientific-intelligence",svc);return svc
