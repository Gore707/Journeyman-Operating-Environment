from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.experiment_designer import (parameter_snapshot,create_experiment_plan,revise_experiment_plan,
 validate_experiment_plan,validate_plan,ready_plan,SimulationSequencer,experiment_guardian_contract,experiment_core_readiness,evaluate_constraint,
 evaluate_decision_gate,validate_step_dependencies,bind_execution_context,supervisory_recommendation,
 expanded_experiment_guardian_contract,BranchingSimulationSequencer,create_run_manifest,
 synchronize_experiment_with_twin,execution_guardian_contract,experiment_v1_release_readiness)

EXP_MODULE=ModuleDescriptor(
    module_id="journeyman.experiment-designer",
    name="Experiment Designer / Sequencer",
    version="1.0.0",
    requires=("joe.core","journeyman.mpr","journeyman.digital-twin"),
    provides=("joe.experiment-designer",),
)

class ExperimentDesignerService:
    snapshot=staticmethod(parameter_snapshot)
    create_plan=staticmethod(create_experiment_plan)
    revise_plan=staticmethod(revise_experiment_plan)
    validate=staticmethod(validate_experiment_plan)
    validate_plan=staticmethod(validate_plan)
    ready_plan=staticmethod(ready_plan)
    create_sequencer=staticmethod(SimulationSequencer)
    guardian_contract=staticmethod(experiment_guardian_contract)
    release_readiness=staticmethod(experiment_v1_release_readiness)
    evaluate_constraint=staticmethod(evaluate_constraint)
    evaluate_gate=staticmethod(evaluate_decision_gate)
    validate_dependencies=staticmethod(validate_step_dependencies)
    bind_execution_context=staticmethod(bind_execution_context)
    supervisory_recommendation=staticmethod(supervisory_recommendation)
    expanded_guardian_contract=staticmethod(expanded_experiment_guardian_contract)
    create_branching_sequencer=staticmethod(BranchingSimulationSequencer)
    create_run_manifest=staticmethod(create_run_manifest)
    synchronize_twin=staticmethod(synchronize_experiment_with_twin)
    execution_guardian_contract=staticmethod(execution_guardian_contract)

class ExperimentDesignerInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False

def register_experiment_designer_module(runtime:ModuleRuntime):
    svc=ExperimentDesignerService();runtime.register(EXP_MODULE,ExperimentDesignerInstance(svc))
    runtime.activate("journeyman.experiment-designer")
    runtime.publish_service("journeyman.experiment-designer","joe.experiment-designer",svc)
    return svc
