"""Controlled scientific reference/algorithm library for JOE."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib,json
from typing import Any

REFERENCE_SCHEMA="JOE-SCIENTIFIC-REFERENCE/1"
ALGORITHM_SCHEMA="JOE-ALGORITHM-REGISTRY/1"
RULESET_SCHEMA="JOE-GUARDIAN-RULESET/1"

@dataclass(frozen=True)
class ReferenceDocument:
    path:Path
    document_id:str
    schema:str
    version:str
    sha256:str
    data:dict[str,Any]

def canonical_sha256(data):
    return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest()

class ScientificReferenceLibrary:
    def __init__(self,root:Path):
        self.root=Path(root).resolve()
    def _safe_files(self):
        if not self.root.exists():return ()
        return tuple(sorted(p for p in self.root.glob("*.json") if p.is_file() and p.resolve().parent==self.root))
    def load_all(self):
        docs=[]
        for p in self._safe_files():
            raw=json.loads(p.read_text(encoding="utf-8"))
            schema=raw.get("schema","")
            if schema not in (REFERENCE_SCHEMA,ALGORITHM_SCHEMA,RULESET_SCHEMA):raise ValueError(f"unsupported reference schema: {p.name}")
            did=raw.get("dataset_id") or raw.get("registry_id") or raw.get("ruleset_id")
            if not did or not raw.get("version"):raise ValueError(f"reference identity/version missing: {p.name}")
            docs.append(ReferenceDocument(p,did,schema,raw["version"],canonical_sha256(raw),raw))
        return tuple(docs)
    def index(self):
        docs=self.load_all()
        ids=[d.document_id for d in docs]
        if len(ids)!=len(set(ids)):raise ValueError("duplicate reference document ID")
        return {d.document_id:d for d in docs}
    def algorithm(self,algorithm_id):
        doc=self.index().get("joe.algorithms")
        if not doc:return None
        return next((x for x in doc.data.get("algorithms",[]) if x.get("algorithm_id")==algorithm_id),None)
    def search(self,text):
        q=text.lower().strip()
        if not q:return ()
        return tuple(d for d in self.load_all() if q in json.dumps(d.data,sort_keys=True).lower())
    def ruleset(self,ruleset_id):
        return self.index().get(ruleset_id)
    def guardian_query(self,text):
        return tuple({"id":d.document_id,"version":d.version,"sha256":d.sha256,"schema":d.schema,
                      "epistemic_class":d.data.get("epistemic_class"),"description":d.data.get("description","")}
                     for d in self.search(text))
    def guardian_contract(self):
        docs=self.load_all()
        return {"schema":"JOE-GUARDIAN-SCIENTIFIC-REFERENCE/1","authority":"READ_ONLY",
                "document_count":len(docs),
                "documents":tuple({"id":d.document_id,"version":d.version,"schema":d.schema,"sha256":d.sha256} for d in docs),
                "rules":("reference JSON is data/configuration, never executable code","simulation cannot be promoted to hardware evidence",
                         "unsupported domains must remain unavailable/invalid rather than silently extrapolated"),
                "provenance":"SOFTWARE: JOE scientific reference library"}
    def readiness(self):
        failures=[];docs=()
        try:
            docs=self.load_all();idx=self.index()
            required=("joe.constants.core","joe.relativity.reference","joe.wormhole.geometry","joe.energy.conditions",
                      "joe.qi.models","joe.chronology.criteria","joe.mouth.dynamics","joe.metrology.calibration",
                      "joe.frames.registry","joe.uncertainty.models","joe.solver.profiles","joe.verification.benchmarks",
                      "joe.epistemic.rules","joe.algorithms","joe.guardian.scientific-rules","joe.guardian.anomaly-profiles",
                      "joe.guardian.consistency-rules","joe.guardian.failure-modes","joe.guardian.diagnostic-rules",
                      "joe.guardian.parameter-constraints","joe.guardian.unit-dimension-rules","joe.guardian.model-disagreement-rules",
                      "joe.guardian.experiment-risk-rules","joe.qft.casimir-models","joe.qft.squeezed-state-models",
                      "joe.qft.semiclassical-models","joe.em.field-models","joe.geometry.curvature-invariants","joe.geometry.tensor-conventions")
            missing=tuple(x for x in required if x not in idx)
            if missing:failures.extend("missing:"+x for x in missing)
            if not self.algorithm("REL.SR.GAMMA"):failures.append("algorithm registry lookup failed")
        except Exception as exc:failures.append(type(exc).__name__+": "+str(exc))
        return {"passed":not failures,"documents":len(docs),"failures":tuple(failures),
                "notes":("Reference data is read-only scientific/configuration knowledge.","Python remains the executable algorithm authority.")}
