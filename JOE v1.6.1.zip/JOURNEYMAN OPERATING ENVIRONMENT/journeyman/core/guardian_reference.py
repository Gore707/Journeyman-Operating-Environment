"""Guardian deterministic scientific-reference reasoning layer."""
from __future__ import annotations
from dataclasses import dataclass
from math import sqrt,isfinite
from typing import Any

@dataclass(frozen=True)
class GuardianScientificFinding:
    finding_id:str
    severity:str
    conclusion:str
    evidence:tuple[str,...]
    recommendation:str|None
    authority:str="READ_ONLY_ADVISORY"
    provenance:str="SOFTWARE: Guardian scientific reference evaluator"

class GuardianScientificReferenceEvaluator:
    def __init__(self,library):self.library=library
    def evaluate_result(self,result:dict[str,Any]):
        out=[]
        epistemic=str(result.get("epistemic_class",""))
        origin=str(result.get("origin",""))
        status=str(result.get("solver_status","PASS"))
        if epistemic=="SPECULATIVE_UNRESOLVED_PHYSICS" and result.get("claimed_demonstrated"):
            out.append(GuardianScientificFinding("GSR-001","CRITICAL","Speculative result cannot be classified as demonstrated.",
                ("epistemic_class=SPECULATIVE_UNRESOLVED_PHYSICS","claimed_demonstrated=true"),"HOLD classification/publication"))
        if origin in ("SIMULATION","REPLAY") and result.get("target_origin")=="HARDWARE":
            out.append(GuardianScientificFinding("GSR-002","CRITICAL","Synthetic/replay data cannot be promoted to hardware telemetry.",
                (f"origin={origin}","target_origin=HARDWARE"),"HOLD data path"))
        if status in ("DOMAIN_INVALID","MODEL_UNAVAILABLE","UNKNOWN_PHYSICS"):
            out.append(GuardianScientificFinding("GSR-003","WARNING","Numerical conclusion must be withheld because the model is unavailable or out of domain.",
                (f"solver_status={status}",),"Withhold numerical conclusion"))
        if result.get("quantitative") and result.get("uncertainty") is None:
            out.append(GuardianScientificFinding("GSR-004","WARNING","Quantitative result lacks uncertainty.",
                ("quantitative=true","uncertainty missing"),"Require uncertainty before downstream scientific use"))
        return tuple(out)
    def compare_models(self,a,b,sigma_a,sigma_b,context=None):
        context=context or {}
        if not all(isfinite(float(x)) for x in (a,b,sigma_a,sigma_b)) or sigma_a<0 or sigma_b<0:
            return GuardianScientificFinding("MDR-INVALID","WARNING","Model disagreement inputs are invalid.",("non-finite or negative uncertainty",),"Reject comparison")
        if not context.get("compatible_units",True) or not context.get("compatible_frame_epoch",True):
            return GuardianScientificFinding("MDR-CONTEXT","WARNING","Model outputs are not directly comparable.",("unit/frame/epoch compatibility failed",),"Transform/convert before comparison")
        denom=sqrt(sigma_a*sigma_a+sigma_b*sigma_b)
        if denom==0:
            return GuardianScientificFinding("MDR-ZERO-U","WARNING","Model disagreement cannot be normalized with zero combined uncertainty.",("combined uncertainty=0",),"Provide valid uncertainty")
        z=abs(a-b)/denom
        sev="CRITICAL" if z>=5 else ("WARNING" if z>=3 else "INFO")
        rec="Investigate model/data disagreement" if z>=3 else None
        return GuardianScientificFinding("MDR-001",sev,f"Normalized model disagreement = {z:.6g} sigma.",
            (f"a={a}",f"b={b}",f"sigma_a={sigma_a}",f"sigma_b={sigma_b}"),rec)
    def parameter_check(self,name,value):
        rules={"beta":lambda x:0<=x<1,"uncertainty":lambda x:x>=0,"sampling_time":lambda x:x>0}
        if name not in rules:return GuardianScientificFinding("PAR-UNKNOWN","INFO","No deterministic parameter rule is registered.",(f"parameter={name}",),None)
        ok=rules[name](value)
        return GuardianScientificFinding("PAR-001" if name=="beta" else "PAR-CHECK","INFO" if ok else "WARNING",
            "Parameter satisfies registered constraint." if ok else "Parameter violates registered constraint.",(f"{name}={value}",),
            None if ok else "Reject or correct parameter")
    def contract(self):
        return {"schema":"JOE-GUARDIAN-SCIENTIFIC-EVALUATOR/1","authority":"READ_ONLY_ADVISORY","may_command":False,"may_override":False,
                "reference_contract":self.library.guardian_contract(),"provenance":"SOFTWARE: Guardian scientific reference evaluator"}
