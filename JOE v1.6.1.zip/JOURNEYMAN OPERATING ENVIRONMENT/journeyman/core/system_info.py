from dataclasses import dataclass
import platform
import psutil

@dataclass(frozen=True)
class SystemSnapshot:
    cpu_percent: float
    ram_percent: float
    ram_used_gb: float
    ram_total_gb: float
    process_ram_mb: float
    process_cpu_percent: float
    threads: int


def snapshot() -> SystemSnapshot:
    vm = psutil.virtual_memory()
    proc = psutil.Process()
    return SystemSnapshot(
        cpu_percent=psutil.cpu_percent(interval=None),
        ram_percent=vm.percent,
        ram_used_gb=vm.used / (1024 ** 3),
        ram_total_gb=vm.total / (1024 ** 3),
        process_ram_mb=proc.memory_info().rss / (1024 ** 2),
        process_cpu_percent=proc.cpu_percent(interval=None),
        threads=proc.num_threads(),
    )


def static_system_info() -> dict[str, str]:
    return {
        "Operating system": f"{platform.system()} {platform.release()} ({platform.version()})",
        "Machine": platform.machine() or "Unknown",
        "Processor": platform.processor() or "Unknown",
        "Logical CPUs": str(psutil.cpu_count(logical=True) or "Unknown"),
        "Physical CPUs": str(psutil.cpu_count(logical=False) or "Unknown"),
        "Python": platform.python_version(),
    }
