"""MPR application module registration."""
from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.mpr import MasterParameterRegister
from journeyman.core.paths import MPR_DIR

MPR_MODULE=ModuleDescriptor(
    module_id="journeyman.mpr",
    name="Master Parameter Register",
    version="1.0.0",
    description="Authoritative Journeyman scientific parameter and epistemic registry.",
    requires=("joe.core",),
    provides=("joe.mpr",),
    consumes=("joe.state-events","joe.storage"),
)

class MPRInstance(ModuleInstance):
    def __init__(self,register):self.register=register;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False

def register_mpr_module(runtime:ModuleRuntime)->MasterParameterRegister:
    backbone=runtime.service("joe.state-events")
    register=MasterParameterRegister(MPR_DIR,backbone)
    runtime.register(MPR_MODULE,MPRInstance(register))
    runtime.activate("journeyman.mpr")
    runtime.publish_service("journeyman.mpr","joe.mpr",register)
    return register
