"""D-1 mouth dynamics core.

All Mouth A/B states in this software-only implementation are declared MODEL/SIMULATION
objects unless a future authenticated hardware source is explicitly supplied. No mouth
existence, traversability or exotic stress-energy is inferred by this module.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .state_events import DataOrigin

C=299_792_458.0

class MouthDynamicsStatus(str,Enum):
    PASS="PASS"
    NONCONVERGED="NONCONVERGED"
    DOMAIN_INVALID="DOMAIN_INVALID"
    PRECISION_INSUFFICIENT="PRECISION_INSUFFICIENT"
    INPUT_INCONSISTENT="INPUT_INCONSISTENT"
    NUMERICAL_INSTABILITY="NUMERICAL_INSTABILITY"
    MODEL_UNAVAILABLE="MODEL_UNAVAILABLE"
    UNKNOWN_PHYSICS="UNKNOWN_PHYSICS"

class MouthRole(str,Enum):
    A="A"
    B="B"

@dataclass(frozen=True)
class MouthState:
    object_id:str
    role:MouthRole
    coordinate_time_s:float
    proper_time_s:float
    position_m:tuple[float,float,float]
    velocity_m_s:tuple[float,float,float]
    frame_id:str
    epoch_id:str
    time_scale:str
    position_standard_uncertainty_m:float
    proper_time_standard_uncertainty_s:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if not self.object_id.strip() or not self.frame_id.strip() or not self.epoch_id.strip() or not self.time_scale.strip() or not self.provenance.strip():
            raise ValueError("mouth identity/frame/epoch/time scale/provenance required")
        if len(self.position_m)!=3 or len(self.velocity_m_s)!=3:raise ValueError("3D position and velocity required")
        vals=(self.coordinate_time_s,self.proper_time_s,*self.position_m,*self.velocity_m_s,
              self.position_standard_uncertainty_m,self.proper_time_standard_uncertainty_s)
        if not all(math.isfinite(float(x)) for x in vals):raise ValueError("mouth-state numeric values must be finite")
        if self.position_standard_uncertainty_m<0 or self.proper_time_standard_uncertainty_s<0:raise ValueError("uncertainties must be nonnegative")
        speed=math.sqrt(sum(float(v)**2 for v in self.velocity_m_s))
        if speed>=C:raise ValueError("mouth transport state requires |v| < c")

@dataclass(frozen=True)
class MouthPairState:
    mouth_a:MouthState
    mouth_b:MouthState
    pair_id:str
    provenance:str
    def __post_init__(self):
        if self.mouth_a.role!=MouthRole.A or self.mouth_b.role!=MouthRole.B:raise ValueError("pair requires Mouth A and Mouth B roles")
        if self.mouth_a.object_id==self.mouth_b.object_id:raise ValueError("mouth identities must be distinct")
        if not self.pair_id.strip() or not self.provenance.strip():raise ValueError("pair identity/provenance required")

@dataclass(frozen=True)
class SeparationState:
    status:MouthDynamicsStatus
    separation_vector_m:tuple[float,float,float]|None
    separation_m:float|None
    relative_velocity_m_s:tuple[float,float,float]|None
    radial_separation_rate_m_s:float|None
    combined_position_standard_uncertainty_m:float|None
    frame_id:str|None
    message:str

def mouth_pair_separation(pair:MouthPairState)->SeparationState:
    a,b=pair.mouth_a,pair.mouth_b
    if a.frame_id!=b.frame_id or a.epoch_id!=b.epoch_id or a.time_scale!=b.time_scale:
        return SeparationState(MouthDynamicsStatus.INPUT_INCONSISTENT,None,None,None,None,None,None,
            "Mouth states require an explicit frame/epoch/time-scale transform before comparison.")
    dr=tuple(b.position_m[i]-a.position_m[i] for i in range(3))
    dv=tuple(b.velocity_m_s[i]-a.velocity_m_s[i] for i in range(3))
    r=math.sqrt(sum(x*x for x in dr))
    rdot=0.0 if r==0 else sum(dr[i]*dv[i] for i in range(3))/r
    u=math.hypot(a.position_standard_uncertainty_m,b.position_standard_uncertainty_m)
    return SeparationState(MouthDynamicsStatus.PASS,dr,r,dv,rdot,u,a.frame_id,
        "Euclidean separation in the declared common spatial frame; no spacetime shortcut is inferred.")

@dataclass(frozen=True)
class DesynchronizationState:
    status:MouthDynamicsStatus
    proper_time_offset_a_minus_b_s:float
    combined_standard_uncertainty_s:float
    significance_sigma:float|None
    coordinate_time_difference_s:float
    message:str
    provenance:str

def mouth_desynchronization(pair:MouthPairState)->DesynchronizationState:
    a,b=pair.mouth_a,pair.mouth_b
    if a.time_scale!=b.time_scale:
        return DesynchronizationState(MouthDynamicsStatus.INPUT_INCONSISTENT,math.nan,math.nan,None,math.nan,
            "Mouth clock states use different time scales and cannot be directly compared.",pair.provenance)
    d=a.proper_time_s-b.proper_time_s
    u=math.hypot(a.proper_time_standard_uncertainty_s,b.proper_time_standard_uncertainty_s)
    sig=None if u==0 else abs(d)/u
    return DesynchronizationState(MouthDynamicsStatus.PASS,d,u,sig,a.coordinate_time_s-b.coordinate_time_s,
        "Declared mouth-clock offset; in current JOE this is simulation/model state, not physical wormhole telemetry.",
        pair.provenance)

@dataclass(frozen=True)
class TransportSegment:
    coordinate_duration_s:float
    velocity_m_s:tuple[float,float,float]
    label:str
    def __post_init__(self):
        if not math.isfinite(self.coordinate_duration_s) or self.coordinate_duration_s<=0:raise ValueError("positive finite transport duration required")
        if len(self.velocity_m_s)!=3 or not all(math.isfinite(float(x)) for x in self.velocity_m_s):raise ValueError("finite 3D velocity required")
        if math.sqrt(sum(float(v)**2 for v in self.velocity_m_s))>=C:raise ValueError("transport speed must remain subluminal")
        if not self.label.strip():raise ValueError("transport segment label required")

@dataclass(frozen=True)
class TransportResult:
    status:MouthDynamicsStatus
    initial_state:MouthState
    final_state:MouthState
    coordinate_elapsed_s:float
    proper_elapsed_s:float
    relativistic_desynchronization_s:float
    distance_traveled_m:float
    segments:int
    provenance:str

def propagate_piecewise_inertial_transport(initial:MouthState,segments)->TransportResult:
    segs=tuple(segments)
    if not segs:raise ValueError("at least one transport segment required")
    t=initial.coordinate_time_s;tau=initial.proper_time_s
    x=list(initial.position_m);distance=0.0
    for seg in segs:
        speed=math.sqrt(sum(v*v for v in seg.velocity_m_s))
        dt=seg.coordinate_duration_s
        for i in range(3):x[i]+=seg.velocity_m_s[i]*dt
        t+=dt;tau+=dt*math.sqrt(1-(speed/C)**2);distance+=speed*dt
    final=MouthState(initial.object_id,initial.role,t,tau,tuple(x),segs[-1].velocity_m_s,
        initial.frame_id,initial.epoch_id,initial.time_scale,initial.position_standard_uncertainty_m,
        initial.proper_time_standard_uncertainty_s,initial.provenance,initial.origin)
    elapsed=t-initial.coordinate_time_s;proper=tau-initial.proper_time_s
    return TransportResult(MouthDynamicsStatus.PASS,initial,final,elapsed,proper,elapsed-proper,distance,len(segs),
        "piecewise-inertial special-relativistic transport; acceleration/gravity/backreaction are not modeled")

@dataclass(frozen=True)
class MouthDynamicsGuardianContract:
    schema:str
    status:str
    facts:dict
    provenance:str
    authority:str

def mouth_dynamics_guardian_contract(pair:MouthPairState,*,separation:SeparationState|None=None,
                                     desynchronization:DesynchronizationState|None=None,
                                     transport:TransportResult|None=None)->MouthDynamicsGuardianContract:
    facts={"pair_id":pair.pair_id,
           "mouth_a":{"object_id":pair.mouth_a.object_id,"origin":pair.mouth_a.origin.value,"frame_id":pair.mouth_a.frame_id},
           "mouth_b":{"object_id":pair.mouth_b.object_id,"origin":pair.mouth_b.origin.value,"frame_id":pair.mouth_b.frame_id}}
    status=MouthDynamicsStatus.PASS.value
    for name,obj in (("separation",separation),("desynchronization",desynchronization)):
        if obj is not None:
            d=dict(obj.__dict__)
            for k,v in tuple(d.items()):
                if isinstance(v,Enum):d[k]=v.value
            facts[name]=d
            if obj.status!=MouthDynamicsStatus.PASS:status=obj.status.value
    if transport is not None:
        facts["transport"]={"status":transport.status.value,"coordinate_elapsed_s":transport.coordinate_elapsed_s,
            "proper_elapsed_s":transport.proper_elapsed_s,"relativistic_desynchronization_s":transport.relativistic_desynchronization_s,
            "distance_traveled_m":transport.distance_traveled_m,"segments":transport.segments}
    return MouthDynamicsGuardianContract("JOE-GUARDIAN-MOUTH-DYNAMICS/1",status,facts,pair.provenance,
        "READ_ONLY_ADVISORY; cannot create/command a mouth, assert wormhole existence, or override deterministic control/BUS-SAFE")


@dataclass(frozen=True)
class AcceleratedTransportSegment:
    coordinate_duration_s:float
    initial_velocity_m_s:tuple[float,float,float]
    final_velocity_m_s:tuple[float,float,float]
    label:str
    def __post_init__(self):
        if not math.isfinite(self.coordinate_duration_s) or self.coordinate_duration_s<=0:raise ValueError("positive finite duration required")
        if len(self.initial_velocity_m_s)!=3 or len(self.final_velocity_m_s)!=3:raise ValueError("3D endpoint velocities required")
        vals=(*self.initial_velocity_m_s,*self.final_velocity_m_s)
        if not all(math.isfinite(float(x)) for x in vals):raise ValueError("finite endpoint velocities required")
        if max(math.sqrt(sum(v*v for v in self.initial_velocity_m_s)),math.sqrt(sum(v*v for v in self.final_velocity_m_s)))>=C:
            raise ValueError("endpoint speeds must remain subluminal")
        if not self.label.strip():raise ValueError("segment label required")

@dataclass(frozen=True)
class TrajectorySample:
    coordinate_time_s:float
    proper_time_s:float
    position_m:tuple[float,float,float]
    velocity_m_s:tuple[float,float,float]
    speed_m_s:float
    gamma:float
    segment_label:str

@dataclass(frozen=True)
class DynamicTransportResult:
    status:MouthDynamicsStatus
    initial_state:MouthState
    final_state:MouthState
    samples:tuple[TrajectorySample,...]
    coordinate_elapsed_s:float
    proper_elapsed_s:float
    relativistic_desynchronization_s:float
    distance_traveled_m:float
    integration_steps:int
    convergence_estimate_s:float
    provenance:str

def _integrate_accelerated_transport(initial:MouthState,segments,steps_per_segment:int):
    t=initial.coordinate_time_s;tau=initial.proper_time_s;x=list(initial.position_m);distance=0.0;samples=[]
    for seg in segments:
        n=steps_per_segment;dt=seg.coordinate_duration_s/n
        for k in range(n):
            f0=k/n;f1=(k+1)/n;fm=(k+.5)/n
            vm=tuple(seg.initial_velocity_m_s[i]+(seg.final_velocity_m_s[i]-seg.initial_velocity_m_s[i])*fm for i in range(3))
            speed=math.sqrt(sum(v*v for v in vm));gamma=1/math.sqrt(1-(speed/C)**2)
            if k==0:samples.append(TrajectorySample(t,tau,tuple(x),tuple(seg.initial_velocity_m_s),
                math.sqrt(sum(v*v for v in seg.initial_velocity_m_s)),
                1/math.sqrt(1-(sum(v*v for v in seg.initial_velocity_m_s)/C**2)),seg.label))
            for i in range(3):x[i]+=vm[i]*dt
            t+=dt;tau+=dt/gamma;distance+=speed*dt
            vend=tuple(seg.initial_velocity_m_s[i]+(seg.final_velocity_m_s[i]-seg.initial_velocity_m_s[i])*f1 for i in range(3))
            send=math.sqrt(sum(v*v for v in vend));gend=1/math.sqrt(1-(send/C)**2)
            samples.append(TrajectorySample(t,tau,tuple(x),vend,send,gend,seg.label))
    return t,tau,tuple(x),distance,tuple(samples)

def propagate_accelerated_transport(initial:MouthState,segments,*,steps_per_segment:int=128)->DynamicTransportResult:
    """Numerically integrate coordinate-linear velocity ramps using midpoint quadrature.

    This is a declared coordinate acceleration profile, not a force/propulsion model.
    """
    segs=tuple(segments);n=int(steps_per_segment)
    if not segs:raise ValueError("at least one accelerated segment required")
    if n<4:raise ValueError("steps_per_segment must be >= 4")
    fine=_integrate_accelerated_transport(initial,segs,n)
    coarse=_integrate_accelerated_transport(initial,segs,max(2,n//2))
    t,tau,x,distance,samples=fine
    conv=abs((tau-initial.proper_time_s)-(coarse[1]-initial.proper_time_s))
    final=MouthState(initial.object_id,initial.role,t,tau,x,segs[-1].final_velocity_m_s,
        initial.frame_id,initial.epoch_id,initial.time_scale,initial.position_standard_uncertainty_m,
        initial.proper_time_standard_uncertainty_s,initial.provenance,initial.origin)
    elapsed=t-initial.coordinate_time_s;proper=tau-initial.proper_time_s
    return DynamicTransportResult(MouthDynamicsStatus.PASS,initial,final,samples,elapsed,proper,elapsed-proper,
        distance,n*len(segs),conv,
        "numerical midpoint integration of declared coordinate-linear velocity ramps; not a propulsion/force model")

@dataclass(frozen=True)
class PairHistorySample:
    coordinate_time_s:float
    separation_m:float
    proper_time_offset_a_minus_b_s:float
    chronology_margin_s:float|None
    modeled_loop_condition:bool|None

@dataclass(frozen=True)
class PairEvolution:
    status:MouthDynamicsStatus
    samples:tuple[PairHistorySample,...]
    minimum_separation_m:float
    maximum_separation_m:float
    final_clock_offset_s:float
    chronology_coupled:bool
    provenance:str

def evolve_pair_with_transport(stationary:MouthState,moving:DynamicTransportResult,*,chronology_return_speed_m_s:float|None=None)->PairEvolution:
    if stationary.frame_id!=moving.initial_state.frame_id or stationary.epoch_id!=moving.initial_state.epoch_id or stationary.time_scale!=moving.initial_state.time_scale:
        raise ValueError("stationary and transported mouth require common frame/epoch/time scale")
    if chronology_return_speed_m_s is not None and (chronology_return_speed_m_s<=0 or chronology_return_speed_m_s>C):
        raise ValueError("chronology return speed must satisfy 0 < v <= c")
    out=[]
    for q in moving.samples:
        elapsed=q.coordinate_time_s-moving.initial_state.coordinate_time_s
        # Stationary mouth proper time advances with coordinate time in this inertial reference model.
        tau_stationary=stationary.proper_time_s+elapsed
        dr=tuple(q.position_m[i]-stationary.position_m[i] for i in range(3));sep=math.sqrt(sum(v*v for v in dr))
        offset=tau_stationary-q.proper_time_s
        if chronology_return_speed_m_s is None:
            margin=None;loop=None
        else:
            margin=offset-sep/chronology_return_speed_m_s;loop=margin>0
        out.append(PairHistorySample(q.coordinate_time_s,sep,offset,margin,loop))
    seps=[x.separation_m for x in out]
    return PairEvolution(MouthDynamicsStatus.PASS,tuple(out),min(seps),max(seps),out[-1].proper_time_offset_a_minus_b_s,
        chronology_return_speed_m_s is not None,
        "simulation evolution: stationary inertial Mouth A plus declared transported Mouth B; chronology coupling is kinematic only")

@dataclass(frozen=True)
class TransportUncertainty:
    nominal_proper_elapsed_s:float
    proper_time_standard_uncertainty_s:float
    desynchronization_standard_uncertainty_s:float
    method:str
    provenance:str

def transport_timing_uncertainty(result:DynamicTransportResult,*,initial_clock_uncertainty_s:float=0.0,
                                 velocity_standard_uncertainty_m_s:float=0.0)->TransportUncertainty:
    if initial_clock_uncertainty_s<0 or velocity_standard_uncertainty_m_s<0:raise ValueError("uncertainties must be nonnegative")
    # Conservative first-order envelope: |d(dτ)/dv| <= elapsed*vmax/(c² sqrt(1-vmax²/c²)).
    vmax=max((q.speed_m_s for q in result.samples),default=0.0)
    beta2=(vmax/C)**2
    sens=0.0 if vmax==0 else result.coordinate_elapsed_s*vmax/(C*C*math.sqrt(1-beta2))
    uv=abs(sens)*velocity_standard_uncertainty_m_s
    u=math.sqrt(initial_clock_uncertainty_s**2+uv**2+result.convergence_estimate_s**2)
    return TransportUncertainty(result.proper_elapsed_s,u,u,
        "first-order conservative velocity sensitivity combined with initial clock uncertainty and integration convergence estimate",
        result.provenance)

@dataclass(frozen=True)
class D1C1CouplingResult:
    status:MouthDynamicsStatus
    final_separation_m:float
    final_mouth_time_offset_s:float
    external_return_time_s:float
    chronology_margin_s:float
    modeled_closed_causal_loop_condition:bool
    message:str
    provenance:str

def couple_transport_to_chronology(evolution:PairEvolution,*,external_return_speed_m_s:float)->D1C1CouplingResult:
    if not evolution.samples:raise ValueError("pair evolution samples required")
    if external_return_speed_m_s<=0 or external_return_speed_m_s>C:raise ValueError("external return speed must satisfy 0 < v <= c")
    q=evolution.samples[-1];t_ext=q.separation_m/external_return_speed_m_s
    margin=q.proper_time_offset_a_minus_b_s-t_ext
    return D1C1CouplingResult(MouthDynamicsStatus.PASS,q.separation_m,q.proper_time_offset_a_minus_b_s,t_ext,margin,margin>0,
        "D-1 → C-1 kinematic coupling of SIMULATED transport state only; does not establish a physical mouth mapping or CTC.",
        evolution.provenance)


@dataclass(frozen=True)
class SymmetricMissionRequest:
    cruise_speed_m_s:float
    outbound_duration_s:float
    dwell_duration_s:float
    return_duration_s:float
    ramp_duration_s:float
    provenance:str="declared D-1 symmetric mission"
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        vals=(self.cruise_speed_m_s,self.outbound_duration_s,self.dwell_duration_s,self.return_duration_s,self.ramp_duration_s)
        if not all(math.isfinite(float(x)) for x in vals):raise ValueError("mission values must be finite")
        if self.cruise_speed_m_s<=0 or self.cruise_speed_m_s>=C:raise ValueError("cruise speed must satisfy 0 < v < c")
        if self.outbound_duration_s<=0 or self.return_duration_s<=0 or self.dwell_duration_s<0 or self.ramp_duration_s<=0:
            raise ValueError("outbound/return/ramp durations positive; dwell nonnegative")
        if self.outbound_duration_s<2*self.ramp_duration_s or self.return_duration_s<2*self.ramp_duration_s:
            raise ValueError("outbound and return durations must each accommodate two ramps")
        if not self.provenance.strip():raise ValueError("provenance required")

def symmetric_transport_profile(request:SymmetricMissionRequest)->tuple[AcceleratedTransportSegment,...]:
    v=request.cruise_speed_m_s;r=request.ramp_duration_s
    out_cruise=request.outbound_duration_s-2*r
    ret_cruise=request.return_duration_s-2*r
    seg=[
        AcceleratedTransportSegment(r,(0,0,0),(v,0,0),"outbound acceleration"),
    ]
    if out_cruise>0:seg.append(AcceleratedTransportSegment(out_cruise,(v,0,0),(v,0,0),"outbound cruise"))
    seg.append(AcceleratedTransportSegment(r,(v,0,0),(0,0,0),"outbound braking"))
    if request.dwell_duration_s>0:seg.append(AcceleratedTransportSegment(request.dwell_duration_s,(0,0,0),(0,0,0),"remote dwell"))
    seg.append(AcceleratedTransportSegment(r,(0,0,0),(-v,0,0),"return acceleration"))
    if ret_cruise>0:seg.append(AcceleratedTransportSegment(ret_cruise,(-v,0,0),(-v,0,0),"return cruise"))
    seg.append(AcceleratedTransportSegment(r,(-v,0,0),(0,0,0),"return braking"))
    return tuple(seg)

@dataclass(frozen=True)
class MissionAnalysis:
    status:MouthDynamicsStatus
    request:SymmetricMissionRequest
    transport:DynamicTransportResult
    final_displacement_m:float
    final_desynchronization_s:float
    returned_near_origin:bool
    message:str

def analyze_symmetric_mission(initial:MouthState,request:SymmetricMissionRequest,*,steps_per_segment:int=128)->MissionAnalysis:
    q=propagate_accelerated_transport(initial,symmetric_transport_profile(request),steps_per_segment=steps_per_segment)
    disp=math.sqrt(sum((q.final_state.position_m[i]-initial.position_m[i])**2 for i in range(3)))
    scale=max(q.distance_traveled_m,1.0)
    return MissionAnalysis(MouthDynamicsStatus.PASS,request,q,disp,q.relativistic_desynchronization_s,disp<=1e-9*scale,
        "symmetric coordinate-velocity mission analysis; acceleration is prescribed, not derived from propulsion physics")

@dataclass(frozen=True)
class TargetDesynchronizationSolution:
    status:MouthDynamicsStatus
    target_desynchronization_s:float
    cruise_speed_m_s:float|None
    achieved_desynchronization_s:float|None
    iterations:int
    residual_s:float|None
    message:str
    provenance:str

def solve_cruise_speed_for_target_desynchronization(initial:MouthState,template:SymmetricMissionRequest,
                                                     target_desynchronization_s:float,*,max_beta:float=.999,
                                                     tolerance_s:float=1e-9,max_iterations:int=80)->TargetDesynchronizationSolution:
    target=float(target_desynchronization_s)
    if not math.isfinite(target) or target<0:raise ValueError("finite nonnegative target desynchronization required")
    if not (0<max_beta<1):raise ValueError("max_beta must satisfy 0 < max_beta < 1")
    def eval_speed(v):
        req=SymmetricMissionRequest(v,template.outbound_duration_s,template.dwell_duration_s,template.return_duration_s,
                                    template.ramp_duration_s,template.provenance,template.origin)
        return analyze_symmetric_mission(initial,req,steps_per_segment=64).final_desynchronization_s
    lo=1e-12*C;hi=max_beta*C
    max_d=eval_speed(hi)
    if target>max_d:
        return TargetDesynchronizationSolution(MouthDynamicsStatus.DOMAIN_INVALID,target,None,None,0,None,
            f"target exceeds declared mission envelope maximum {max_d:.9e} s at beta={max_beta:g}",template.provenance)
    if target==0:
        return TargetDesynchronizationSolution(MouthDynamicsStatus.PASS,target,0.0,0.0,0,0.0,
            "zero target requires no relativistic transport speed",template.provenance)
    mid=lo;ach=0.0
    for i in range(1,max_iterations+1):
        mid=(lo+hi)/2;ach=eval_speed(mid)
        if abs(ach-target)<=tolerance_s:return TargetDesynchronizationSolution(MouthDynamicsStatus.PASS,target,mid,ach,i,ach-target,
            "bisection solution within declared kinematic mission model",template.provenance)
        if ach<target:lo=mid
        else:hi=mid
    return TargetDesynchronizationSolution(MouthDynamicsStatus.NONCONVERGED,target,mid,ach,max_iterations,ach-target,
        "bisection reached iteration limit without satisfying requested tolerance",template.provenance)

@dataclass(frozen=True)
class D1SensitivityPoint:
    cruise_speed_m_s:float
    beta:float
    desynchronization_s:float
    distance_traveled_m:float
    final_displacement_m:float

def mission_speed_sensitivity(initial:MouthState,template:SymmetricMissionRequest,speeds_m_s)->tuple[D1SensitivityPoint,...]:
    out=[]
    for v in speeds_m_s:
        req=SymmetricMissionRequest(float(v),template.outbound_duration_s,template.dwell_duration_s,
                                    template.return_duration_s,template.ramp_duration_s,template.provenance,template.origin)
        q=analyze_symmetric_mission(initial,req,steps_per_segment=96)
        out.append(D1SensitivityPoint(float(v),float(v)/C,q.final_desynchronization_s,q.transport.distance_traveled_m,q.final_displacement_m))
    return tuple(out)

@dataclass(frozen=True)
class MissionFeasibility:
    status:MouthDynamicsStatus
    kinematic_domain_valid:bool
    chronology_condition_at_max_separation:bool|None
    peak_separation_m:float
    final_desynchronization_s:float
    timing_standard_uncertainty_s:float
    warnings:tuple[str,...]
    provenance:str

def mission_feasibility(initial:MouthState,stationary:MouthState,request:SymmetricMissionRequest,*,
                        external_return_speed_m_s:float|None=None,clock_uncertainty_s:float=0.0,
                        velocity_uncertainty_m_s:float=0.0)->MissionFeasibility:
    analysis=analyze_symmetric_mission(initial,request)
    evolution=evolve_pair_with_transport(stationary,analysis.transport,chronology_return_speed_m_s=external_return_speed_m_s)
    unc=transport_timing_uncertainty(analysis.transport,initial_clock_uncertainty_s=clock_uncertainty_s,
                                     velocity_standard_uncertainty_m_s=velocity_uncertainty_m_s)
    loop=None
    if external_return_speed_m_s is not None:
        loop=any(bool(x.modeled_loop_condition) for x in evolution.samples)
    warnings=("KINEMATIC SIMULATION ONLY — no propulsion/force model.",
              "No wormhole existence, exotic stress-energy support, mouth stability, or physical CTC is established.",
              "Acceleration is prescribed as coordinate velocity ramps; proper acceleration limits are not qualified here.")
    return MissionFeasibility(MouthDynamicsStatus.PASS,True,loop,evolution.maximum_separation_m,
        analysis.final_desynchronization_s,unc.desynchronization_standard_uncertainty_s,warnings,request.provenance)

def expanded_mouth_dynamics_guardian_contract(*,mission:MissionAnalysis|None=None,
                                               feasibility:MissionFeasibility|None=None,
                                               target_solution:TargetDesynchronizationSolution|None=None,
                                               provenance:str="D-1 mission analysis")->MouthDynamicsGuardianContract:
    facts={}
    for name,obj in (("mission",mission),("feasibility",feasibility),("target_solution",target_solution)):
        if obj is not None:
            d={}
            for k,v in obj.__dict__.items():
                if k in ("request","transport"):continue
                d[k]=v.value if isinstance(v,Enum) else v
            facts[name]=d
    status=MouthDynamicsStatus.PASS.value
    if target_solution is not None and target_solution.status!=MouthDynamicsStatus.PASS:status=target_solution.status.value
    return MouthDynamicsGuardianContract("JOE-GUARDIAN-MOUTH-DYNAMICS/1",status,facts,provenance,
        "READ_ONLY_ADVISORY; mission feasibility is kinematic/model-only and cannot authorize transport, create a mouth, or override BUS-SAFE/control authority")


@dataclass(frozen=True)
class D1ConvergenceStudy:
    passed:bool
    step_counts:tuple[int,...]
    proper_times_s:tuple[float,...]
    successive_differences_s:tuple[float,...]
    final_difference_s:float
    tolerance_s:float
    provenance:str

def d1_transport_convergence(initial:MouthState,request:SymmetricMissionRequest,*,
                             step_counts=(32,64,128,256),tolerance_s:float=1e-4)->D1ConvergenceStudy:
    counts=tuple(int(x) for x in step_counts)
    if len(counts)<2 or any(x<4 for x in counts) or any(counts[i]>=counts[i+1] for i in range(len(counts)-1)):
        raise ValueError("step counts must contain at least two strictly increasing values >= 4")
    if tolerance_s<=0 or not math.isfinite(tolerance_s):raise ValueError("positive finite convergence tolerance required")
    vals=[]
    for n in counts:
        vals.append(analyze_symmetric_mission(initial,request,steps_per_segment=n).transport.proper_elapsed_s)
    diffs=tuple(abs(vals[i]-vals[i-1]) for i in range(1,len(vals)))
    return D1ConvergenceStudy(diffs[-1]<=tolerance_s,counts,tuple(vals),diffs,diffs[-1],tolerance_s,
        "D-1 midpoint-integration resolution study on the same declared mission profile")

@dataclass(frozen=True)
class D1ParameterSweepPoint:
    beta:float
    outbound_duration_s:float
    desynchronization_s:float
    peak_separation_m:float
    final_displacement_m:float

def d1_parameter_sweep(initial:MouthState,stationary:MouthState,template:SymmetricMissionRequest,*,
                       betas=(.1,.3,.5,.7,.9),outbound_durations_s=None)->tuple[D1ParameterSweepPoint,...]:
    bs=tuple(float(x) for x in betas)
    ds=tuple(float(x) for x in (outbound_durations_s if outbound_durations_s is not None else (template.outbound_duration_s,)))
    out=[]
    for beta in bs:
        if beta<=0 or beta>=1:raise ValueError("sweep beta values must satisfy 0 < beta < 1")
        for duration in ds:
            req=SymmetricMissionRequest(beta*C,duration,template.dwell_duration_s,duration,template.ramp_duration_s,
                                        template.provenance,template.origin)
            a=analyze_symmetric_mission(initial,req,steps_per_segment=96)
            e=evolve_pair_with_transport(stationary,a.transport)
            out.append(D1ParameterSweepPoint(beta,duration,a.final_desynchronization_s,e.maximum_separation_m,a.final_displacement_m))
    return tuple(out)

@dataclass(frozen=True)
class D1UncertaintySweepPoint:
    velocity_standard_uncertainty_m_s:float
    clock_standard_uncertainty_s:float
    timing_standard_uncertainty_s:float

def d1_uncertainty_sweep(result:DynamicTransportResult,velocity_uncertainties_m_s,clock_uncertainties_s)->tuple[D1UncertaintySweepPoint,...]:
    out=[]
    for uv in velocity_uncertainties_m_s:
        for uc in clock_uncertainties_s:
            q=transport_timing_uncertainty(result,initial_clock_uncertainty_s=float(uc),velocity_standard_uncertainty_m_s=float(uv))
            out.append(D1UncertaintySweepPoint(float(uv),float(uc),q.desynchronization_standard_uncertainty_s))
    return tuple(out)

@dataclass(frozen=True)
class D1C1CrossValidation:
    passed:bool
    d1_margin_s:float
    c1_margin_s:float
    absolute_difference_s:float
    tolerance_s:float
    message:str
    provenance:str

def d1_c1_cross_validate(evolution:PairEvolution,*,external_return_speed_m_s:float,tolerance_s:float=1e-12)->D1C1CrossValidation:
    from .chronology import ChronologyLoopRequest,assess_round_trip_loop_condition
    d1=couple_transport_to_chronology(evolution,external_return_speed_m_s=external_return_speed_m_s)
    c1=assess_round_trip_loop_condition(ChronologyLoopRequest(d1.final_separation_m,d1.final_mouth_time_offset_s,
        external_return_speed_m_s,provenance=evolution.provenance))
    err=abs(d1.chronology_margin_s-c1.chronology_margin_s)
    return D1C1CrossValidation(err<=tolerance_s,d1.chronology_margin_s,c1.chronology_margin_s,err,tolerance_s,
        "independent D-1/C-1 chronology-margin cross-check using the same final SIMULATION state",evolution.provenance)

@dataclass(frozen=True)
class D1ReleaseReadiness:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    notes:tuple[str,...]

def d1_release_readiness()->D1ReleaseReadiness:
    checks=[];fail=[];notes=[]
    try:
        a=MouthState("qual-A",MouthRole.A,0,0,(0,0,0),(0,0,0),"qual.inertial","J2000","TCB",.1,.01,"D-1 readiness")
        b=MouthState("qual-B",MouthRole.B,0,0,(0,0,0),(0,0,0),"qual.inertial","J2000","TCB",.1,.01,"D-1 readiness")
        req=SymmetricMissionRequest(.5*C,100,10,100,10,"D-1 readiness")
        mission=analyze_symmetric_mission(b,req,steps_per_segment=128)
        if mission.returned_near_origin:checks.append("symmetric transport return-to-origin benchmark passed")
        else:fail.append("symmetric transport return-to-origin benchmark failed")
        if mission.final_desynchronization_s>0:checks.append("special-relativistic desynchronization benchmark passed")
        else:fail.append("desynchronization benchmark failed")
        conv=d1_transport_convergence(b,req,tolerance_s=1e-3)
        if conv.passed:checks.append("transport integration convergence benchmark passed")
        else:fail.append("transport integration convergence benchmark failed")
        evo=evolve_pair_with_transport(a,mission.transport)
        cross=d1_c1_cross_validate(evo,external_return_speed_m_s=C)
        if cross.passed:checks.append("D-1/C-1 chronology-margin cross-validation passed")
        else:fail.append("D-1/C-1 chronology-margin cross-validation failed")
        unc=transport_timing_uncertainty(mission.transport,initial_clock_uncertainty_s=.01,velocity_standard_uncertainty_m_s=100)
        if unc.desynchronization_standard_uncertainty_s>=.01:checks.append("timing uncertainty propagation benchmark passed")
        else:fail.append("timing uncertainty propagation benchmark failed")
        g=expanded_mouth_dynamics_guardian_contract(mission=mission)
        if g.schema=="JOE-GUARDIAN-MOUTH-DYNAMICS/1" and "cannot authorize transport" in g.authority:
            checks.append("Guardian D-1 authority gate passed")
        else:fail.append("Guardian D-1 authority gate failed")
    except Exception as exc:fail.append(f"release-readiness exception: {type(exc).__name__}: {exc}")
    notes.append("D-1 qualification covers software kinematics, uncertainty and C-1 consistency only.")
    notes.append("Physical mouth creation/stability, exotic stress-energy, propulsion, acceleration tolerance and chronology viability remain outside this software qualification.")
    return D1ReleaseReadiness(not fail,tuple(checks),tuple(fail),tuple(notes))
