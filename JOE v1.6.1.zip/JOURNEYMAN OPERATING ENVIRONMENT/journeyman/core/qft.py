"""Q-1 semiclassical/QFT request contracts and quantum-inequality reference models.

This module does not claim that macroscopic negative energy can be engineered. Analytic
bounds are exposed only inside their declared domains; unsupported requests return typed
statuses rather than invented numbers.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .state_events import DataOrigin

HBAR=1.054_571_817e-34
C=299_792_458.0

class SolverStatus(str,Enum):
    PASS="PASS"
    NONCONVERGED="NONCONVERGED"
    DOMAIN_INVALID="DOMAIN_INVALID"
    PRECISION_INSUFFICIENT="PRECISION_INSUFFICIENT"
    INPUT_INCONSISTENT="INPUT_INCONSISTENT"
    NUMERICAL_INSTABILITY="NUMERICAL_INSTABILITY"
    MODEL_UNAVAILABLE="MODEL_UNAVAILABLE"
    UNKNOWN_PHYSICS="UNKNOWN_PHYSICS"

class SamplingFunction(str,Enum):
    LORENTZIAN="LORENTZIAN"

class FieldKind(str,Enum):
    MASSLESS_SCALAR="MASSLESS_SCALAR"

class QuantumState(str,Enum):
    VACUUM="VACUUM"
    DECLARED_OTHER="DECLARED_OTHER"

@dataclass(frozen=True)
class QFTRequest:
    geometry_id:str
    geometry_revision:str
    field:FieldKind
    state:QuantumState
    sampling:SamplingFunction
    sampling_time_s:float
    observer:str
    boundary_conditions:str
    renormalization:str
    requested_precision:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        for x in (self.geometry_id,self.geometry_revision,self.observer,self.boundary_conditions,self.renormalization,self.provenance):
            if not str(x).strip():raise ValueError("QFT request declarations must be nonempty")
        if not math.isfinite(self.sampling_time_s) or self.sampling_time_s<=0:raise ValueError("sampling time must be positive and finite")
        if not math.isfinite(self.requested_precision) or self.requested_precision<=0:raise ValueError("requested precision must be positive and finite")

@dataclass(frozen=True)
class QIResult:
    status:SolverStatus
    lower_bound_energy_density_j_m3:float|None
    sampling_time_s:float
    model_name:str
    assumptions:tuple[str,...]
    provenance:str
    origin:DataOrigin
    message:str

def ford_roman_lorentzian_massless_scalar_bound(request:QFTRequest)->QIResult:
    """Flat-spacetime Lorentzian-sampled massless-scalar reference inequality.

    Uses rho_bar >= -3 hbar / (32 pi^2 c^3 tau^4), expressed as energy density J/m^3.
    This is deliberately restricted to a declared flat Minkowski geometry, vacuum state,
    massless scalar field and Lorentzian sampling. It is a reference QI, not a universal
    bound for arbitrary curved spacetime or engineered wormhole sources.
    """
    assumptions=("4D flat Minkowski spacetime","free massless scalar field","vacuum state",
                 "inertial observer","Lorentzian sampling","renormalized expectation value")
    if request.geometry_id!="geometry.minkowski":
        return QIResult(SolverStatus.DOMAIN_INVALID,None,request.sampling_time_s,"Ford-Roman flat-space Lorentzian reference",
                        assumptions,request.provenance,request.origin,
                        "Reference inequality is not valid for arbitrary curved geometry.")
    if request.field!=FieldKind.MASSLESS_SCALAR or request.state!=QuantumState.VACUUM or request.sampling!=SamplingFunction.LORENTZIAN:
        return QIResult(SolverStatus.MODEL_UNAVAILABLE,None,request.sampling_time_s,"Ford-Roman flat-space Lorentzian reference",
                        assumptions,request.provenance,request.origin,
                        "No implemented reference model matches the declared field/state/sampling combination.")
    tau=request.sampling_time_s
    bound=-3.0*HBAR/(32.0*math.pi**2*C**3*tau**4)
    if not math.isfinite(bound):
        return QIResult(SolverStatus.NUMERICAL_INSTABILITY,None,tau,"Ford-Roman flat-space Lorentzian reference",
                        assumptions,request.provenance,request.origin,"Bound evaluation was non-finite.")
    return QIResult(SolverStatus.PASS,bound,tau,"Ford-Roman flat-space Lorentzian reference",assumptions,
                    request.provenance,request.origin,
                    "Analytic reference bound evaluated inside its declared domain.")

@dataclass(frozen=True)
class QIScalingPoint:
    sampling_time_s:float
    lower_bound_energy_density_j_m3:float

def qi_sampling_sweep(request:QFTRequest,sampling_times_s)->tuple[QIScalingPoint,...]:
    out=[]
    for tau in sampling_times_s:
        q=QFTRequest(request.geometry_id,request.geometry_revision,request.field,request.state,request.sampling,
                     float(tau),request.observer,request.boundary_conditions,request.renormalization,
                     request.requested_precision,request.provenance,request.origin)
        r=ford_roman_lorentzian_massless_scalar_bound(q)
        if r.status!=SolverStatus.PASS:raise ValueError(f"QI sweep request invalid: {r.status.value}: {r.message}")
        out.append(QIScalingPoint(float(tau),float(r.lower_bound_energy_density_j_m3)))
    return tuple(out)

@dataclass(frozen=True)
class QFTGuardianContract:
    schema:str
    request:dict
    result:dict
    authority:str

def qft_guardian_contract(request:QFTRequest,result:QIResult)->QFTGuardianContract:
    return QFTGuardianContract("JOE-GUARDIAN-QFT/1",
        {"geometry_id":request.geometry_id,"geometry_revision":request.geometry_revision,"field":request.field.value,
         "state":request.state.value,"sampling":request.sampling.value,"sampling_time_s":request.sampling_time_s,
         "observer":request.observer,"boundary_conditions":request.boundary_conditions,
         "renormalization":request.renormalization,"provenance":request.provenance,"origin":request.origin.value},
        {"status":result.status.value,"lower_bound_energy_density_j_m3":result.lower_bound_energy_density_j_m3,
         "model_name":result.model_name,"assumptions":result.assumptions,"message":result.message},
        "READ_ONLY_ADVISORY; cannot reinterpret DOMAIN_INVALID/MODEL_UNAVAILABLE as a numerical result or authorize hardware")

def unsupported_semiclassical_request(*,message:str,origin:DataOrigin=DataOrigin.SIMULATION)->QIResult:
    if not message.strip():raise ValueError("message required")
    return QIResult(SolverStatus.UNKNOWN_PHYSICS,None,math.nan,"unimplemented/unknown semiclassical physics",(),
                    "explicit unsupported request",origin,message)


@dataclass(frozen=True)
class NegativeEnergyExposure:
    energy_density_j_m3:float
    duration_s:float
    volume_m3:float
    energy_j:float
    time_integrated_density_j_s_m3:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def negative_energy_exposure(energy_density_j_m3:float,duration_s:float,volume_m3:float,
                             *,provenance:str="declared rectangular negative-energy exposure")->NegativeEnergyExposure:
    rho=float(energy_density_j_m3);dt=float(duration_s);vol=float(volume_m3)
    if not all(math.isfinite(x) for x in (rho,dt,vol)) or dt<=0 or vol<=0:
        raise ValueError("finite energy density and positive finite duration/volume required")
    if rho>=0:raise ValueError("negative-energy exposure requires energy_density_j_m3 < 0")
    return NegativeEnergyExposure(rho,dt,vol,rho*vol,rho*dt,provenance)

@dataclass(frozen=True)
class QIFeasibilityMargin:
    status:SolverStatus
    requested_energy_density_j_m3:float
    lower_bound_energy_density_j_m3:float|None
    margin_j_m3:float|None
    normalized_margin:float|None
    satisfies_reference_bound:bool|None
    message:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def qi_feasibility_margin(request:QFTRequest,requested_energy_density_j_m3:float)->QIFeasibilityMargin:
    rho=float(requested_energy_density_j_m3)
    if not math.isfinite(rho):raise ValueError("requested energy density must be finite")
    result=ford_roman_lorentzian_massless_scalar_bound(request)
    if result.status!=SolverStatus.PASS or result.lower_bound_energy_density_j_m3 is None:
        return QIFeasibilityMargin(result.status,rho,None,None,None,None,result.message,
            "No feasibility margin produced outside reference-model domain.",request.origin)
    lower=float(result.lower_bound_energy_density_j_m3)
    margin=rho-lower
    norm=margin/max(abs(lower),1e-300)
    return QIFeasibilityMargin(SolverStatus.PASS,rho,lower,margin,norm,rho>=lower,
        "Comparison to implemented flat-space reference QI only; not a macroscopic engineering verdict.",
        request.provenance,request.origin)

@dataclass(frozen=True)
class QIDurationLimit:
    status:SolverStatus
    requested_magnitude_j_m3:float
    maximum_sampling_time_s:float|None
    message:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def maximum_reference_sampling_time(request:QFTRequest,negative_energy_magnitude_j_m3:float)->QIDurationLimit:
    """Invert the implemented tau^-4 reference bound for a declared |rho|."""
    mag=float(negative_energy_magnitude_j_m3)
    if not math.isfinite(mag) or mag<=0:raise ValueError("negative-energy magnitude must be positive and finite")
    probe=ford_roman_lorentzian_massless_scalar_bound(request)
    if probe.status!=SolverStatus.PASS:
        return QIDurationLimit(probe.status,mag,None,probe.message,request.provenance,request.origin)
    coeff=3.0*HBAR/(32.0*math.pi**2*C**3)
    tau=(coeff/mag)**0.25
    return QIDurationLimit(SolverStatus.PASS,mag,tau,
        "Inversion of the implemented flat-space Lorentzian reference bound; not a universal duration limit.",
        request.provenance,request.origin)

@dataclass(frozen=True)
class Pulse:
    start_s:float
    duration_s:float
    energy_density_j_m3:float
    def __post_init__(self):
        if not all(math.isfinite(float(x)) for x in (self.start_s,self.duration_s,self.energy_density_j_m3)) or self.duration_s<=0:
            raise ValueError("pulse requires finite start/density and positive finite duration")

@dataclass(frozen=True)
class PulseAccounting:
    pulses:tuple[Pulse,...]
    net_time_integrated_density_j_s_m3:float
    negative_time_integrated_density_j_s_m3:float
    positive_time_integrated_density_j_s_m3:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def account_pulses(pulses)->PulseAccounting:
    ps=tuple(pulses)
    if not ps:raise ValueError("at least one pulse required")
    neg=sum(p.energy_density_j_m3*p.duration_s for p in ps if p.energy_density_j_m3<0)
    pos=sum(p.energy_density_j_m3*p.duration_s for p in ps if p.energy_density_j_m3>0)
    return PulseAccounting(ps,neg+pos,neg,pos,
        "rectangular declared pulse accounting; this is bookkeeping, not a quantum-interest theorem solver")

@dataclass(frozen=True)
class QIMagnitudeDurationPoint:
    sampling_time_s:float
    maximum_negative_magnitude_j_m3:float

def qi_magnitude_duration_curve(request:QFTRequest,sampling_times_s)->tuple[QIMagnitudeDurationPoint,...]:
    points=[]
    for x in qi_sampling_sweep(request,sampling_times_s):
        points.append(QIMagnitudeDurationPoint(x.sampling_time_s,abs(x.lower_bound_energy_density_j_m3)))
    return tuple(points)


EPSILON_0=8.854_187_8128e-12

@dataclass(frozen=True)
class CasimirRequest:
    separation_m:float
    plate_area_m2:float
    temperature_k:float
    material_model:str
    boundary_model:str
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        if not math.isfinite(self.separation_m) or self.separation_m<=0:raise ValueError("plate separation must be positive and finite")
        if not math.isfinite(self.plate_area_m2) or self.plate_area_m2<=0:raise ValueError("plate area must be positive and finite")
        if not math.isfinite(self.temperature_k) or self.temperature_k<0:raise ValueError("temperature must be finite and nonnegative")
        if not self.material_model.strip() or not self.boundary_model.strip() or not self.provenance.strip():raise ValueError("Casimir model declarations and provenance required")

@dataclass(frozen=True)
class CasimirResult:
    status:SolverStatus
    energy_density_j_m3:float|None
    pressure_pa:float|None
    total_energy_j:float|None
    assumptions:tuple[str,...]
    message:str
    provenance:str
    origin:DataOrigin

def ideal_parallel_plate_casimir(request:CasimirRequest)->CasimirResult:
    """Zero-temperature ideal-conductor parallel-plate reference model."""
    assumptions=("parallel plates","perfect conductors","zero-temperature analytic reference",
                 "vacuum between plates","edge effects neglected")
    if request.material_model!="IDEAL_PERFECT_CONDUCTOR" or request.boundary_model!="PARALLEL_PLATES":
        return CasimirResult(SolverStatus.MODEL_UNAVAILABLE,None,None,None,assumptions,
            "Implemented Casimir solver supports only ideal perfect-conductor parallel plates.",
            request.provenance,request.origin)
    if request.temperature_k!=0:
        return CasimirResult(SolverStatus.MODEL_UNAVAILABLE,None,None,None,assumptions,
            "Finite-temperature correction is not implemented; refusing to reuse the T=0 expression silently.",
            request.provenance,request.origin)
    a=request.separation_m
    rho=-(math.pi**2*HBAR*C)/(720*a**4)
    pressure=-(math.pi**2*HBAR*C)/(240*a**4)
    energy=rho*request.plate_area_m2*a
    return CasimirResult(SolverStatus.PASS,rho,pressure,energy,assumptions,
        "Ideal analytic Casimir reference evaluated inside declared model domain.",request.provenance,request.origin)

@dataclass(frozen=True)
class SqueezedVacuumRequest:
    mode_angular_frequency_rad_s:float
    squeeze_parameter:float
    squeeze_phase_rad:float
    mode_volume_m3:float
    spacetime_phase_rad:float
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION
    def __post_init__(self):
        vals=(self.mode_angular_frequency_rad_s,self.squeeze_parameter,self.squeeze_phase_rad,self.mode_volume_m3,self.spacetime_phase_rad)
        if not all(math.isfinite(float(x)) for x in vals):raise ValueError("squeezed-state inputs must be finite")
        if self.mode_angular_frequency_rad_s<=0 or self.mode_volume_m3<=0 or self.squeeze_parameter<0:
            raise ValueError("omega and mode volume must be positive; squeeze parameter nonnegative")
        if not self.provenance.strip():raise ValueError("provenance required")

@dataclass(frozen=True)
class SqueezedVacuumResult:
    status:SolverStatus
    normal_ordered_energy_density_j_m3:float|None
    mean_excitation_number:float|None
    assumptions:tuple[str,...]
    message:str
    provenance:str
    origin:DataOrigin

def single_mode_squeezed_vacuum_reference(request:SqueezedVacuumRequest)->SqueezedVacuumResult:
    """Pedagogical single-mode normal-ordered local-energy reference.

    Uses rho_N = (hbar omega / V)[sinh^2(r) - sinh(r)cosh(r) cos(theta)]
    with theta supplied explicitly as the combined local spacetime/squeeze phase.
    This is not a broadband cavity, renormalized curved-spacetime, or engineering model.
    """
    r=request.squeeze_parameter
    phase=request.spacetime_phase_rad-request.squeeze_phase_rad
    n=math.sinh(r)**2
    rho=(HBAR*request.mode_angular_frequency_rad_s/request.mode_volume_m3)*(n-math.sinh(r)*math.cosh(r)*math.cos(phase))
    assumptions=("single bosonic mode","normal ordering relative to unsqueezed vacuum",
                 "declared effective mode volume","no losses","no multimode coupling","flat-background pedagogical reference")
    return SqueezedVacuumResult(SolverStatus.PASS,rho,n,assumptions,
        "Single-mode squeezed-vacuum reference; local negative phase intervals do not imply arbitrary macroscopic negative energy.",
        request.provenance,request.origin)

@dataclass(frozen=True)
class NegativeEnergyMechanismComparison:
    mechanism:str
    status:SolverStatus
    energy_density_j_m3:float|None
    domain:str
    provenance:str

def compare_reference_mechanisms(*,casimir:CasimirResult|None=None,squeezed:SqueezedVacuumResult|None=None,
                                 qi:QIResult|None=None)->tuple[NegativeEnergyMechanismComparison,...]:
    out=[]
    if casimir is not None:out.append(NegativeEnergyMechanismComparison("CASIMIR",casimir.status,casimir.energy_density_j_m3,"ideal boundary-condition reference",casimir.provenance))
    if squeezed is not None:out.append(NegativeEnergyMechanismComparison("SQUEEZED_VACUUM",squeezed.status,squeezed.normal_ordered_energy_density_j_m3,"single-mode normal-ordered reference",squeezed.provenance))
    if qi is not None:out.append(NegativeEnergyMechanismComparison("QUANTUM_INEQUALITY_BOUND",qi.status,qi.lower_bound_energy_density_j_m3,"flat-spacetime sampling bound, not a generated state",qi.provenance))
    if not out:raise ValueError("at least one mechanism result required")
    return tuple(out)

def validate_qft_request_consistency(request:QFTRequest)->tuple[SolverStatus,str]:
    if request.geometry_id=="geometry.minkowski" and request.boundary_conditions.lower() not in ("none","unbounded"):
        return SolverStatus.INPUT_INCONSISTENT,"Minkowski reference request declares nontrivial boundaries not represented by the selected QI solver."
    if request.state==QuantumState.VACUUM and "vacuum" not in request.renormalization.lower():
        return SolverStatus.INPUT_INCONSISTENT,"Vacuum-state reference requires an explicit vacuum-related renormalization declaration."
    return SolverStatus.PASS,"Request declarations are internally consistent for implemented validation rules."


@dataclass(frozen=True)
class LocalCurvatureScale:
    kretschmann_m4:float
    characteristic_length_m:float|None
    provenance:str

def local_curvature_scale_from_riemann_covariant(riemann_covariant,metric_inverse,*,provenance:str)->LocalCurvatureScale:
    """Compute K=R_abcd R^abcd and L_K=|K|^-1/4 from covariant tensors."""
    import numpy as np
    R=np.asarray(riemann_covariant,dtype=float);gi=np.asarray(metric_inverse,dtype=float)
    if R.shape!=(4,4,4,4) or gi.shape!=(4,4):raise ValueError("expected 4D covariant Riemann tensor and 4x4 inverse metric")
    raised=np.einsum("ae,bf,cg,dh,efgh->abcd",gi,gi,gi,gi,R,optimize=True)
    K=float(np.einsum("abcd,abcd->",R,raised,optimize=True))
    if not math.isfinite(K):raise ValueError("non-finite curvature invariant")
    L=None if abs(K)<1e-300 else abs(K)**(-0.25)
    return LocalCurvatureScale(K,L,provenance)

@dataclass(frozen=True)
class LocalFlatnessDiagnostic:
    status:SolverStatus
    sampling_time_s:float
    sampling_length_m:float
    curvature_length_m:float|None
    scale_ratio:float
    threshold:float
    locally_flat_scale_separation:bool
    message:str
    provenance:str

def local_flatness_diagnostic(sampling_time_s:float,curvature_length_m:float|None,*,threshold:float=0.01,
                              provenance:str="declared curvature-scale diagnostic")->LocalFlatnessDiagnostic:
    tau=float(sampling_time_s);th=float(threshold)
    if not math.isfinite(tau) or tau<=0 or not math.isfinite(th) or th<=0:raise ValueError("positive finite sampling time/threshold required")
    ell=C*tau
    if curvature_length_m is None:
        return LocalFlatnessDiagnostic(SolverStatus.PASS,tau,ell,None,0.0,th,True,
            "Vanishing-curvature reference: no finite curvature length scale.",provenance)
    L=float(curvature_length_m)
    if not math.isfinite(L) or L<=0:raise ValueError("curvature length must be positive finite or None")
    ratio=ell/L
    ok=ratio<=th
    return LocalFlatnessDiagnostic(SolverStatus.PASS if ok else SolverStatus.DOMAIN_INVALID,tau,ell,L,ratio,th,ok,
        "Scale-separation diagnostic only; passing does not make a flat-space QI a rigorous curved-spacetime theorem.",
        provenance)

@dataclass(frozen=True)
class StressEnergyQIComparison:
    status:SolverStatus
    required_energy_density_j_m3:float
    qi_lower_bound_j_m3:float|None
    margin_j_m3:float|None
    satisfies_reference_bound:bool|None
    magnitude_ratio_to_bound:float|None
    message:str
    provenance:str

def compare_required_stress_energy_to_qi(required_energy_density_j_m3:float,request:QFTRequest)->StressEnergyQIComparison:
    rho=float(required_energy_density_j_m3)
    if not math.isfinite(rho):raise ValueError("required stress-energy density must be finite")
    qi=ford_roman_lorentzian_massless_scalar_bound(request)
    if qi.status!=SolverStatus.PASS or qi.lower_bound_energy_density_j_m3 is None:
        return StressEnergyQIComparison(qi.status,rho,None,None,None,None,
            "No comparison outside the implemented reference-QI domain.",request.provenance)
    b=float(qi.lower_bound_energy_density_j_m3)
    return StressEnergyQIComparison(SolverStatus.PASS,rho,b,rho-b,rho>=b,
        abs(rho)/max(abs(b),1e-300),
        "Numerical comparison to a flat-space reference bound only; not a proof of curved-spacetime admissibility.",
        request.provenance)

@dataclass(frozen=True)
class SemiclassicalConsistency:
    status:SolverStatus
    checks:tuple[str,...]
    failures:tuple[str,...]
    warnings:tuple[str,...]

def semiclassical_consistency(request:QFTRequest,*,local_flatness:LocalFlatnessDiagnostic|None=None)->SemiclassicalConsistency:
    checks=[];fail=[];warn=[]
    st,msg=validate_qft_request_consistency(request)
    if st==SolverStatus.PASS:checks.append(msg)
    else:fail.append(msg)
    if local_flatness is not None:
        if local_flatness.locally_flat_scale_separation:checks.append("Declared sampling scale is small relative to curvature scale.")
        else:fail.append("Sampling scale is not sufficiently separated from the declared curvature scale.")
        warn.append("Local scale separation is diagnostic and does not extend the implemented flat-space theorem to curved spacetime.")
    if request.origin not in (DataOrigin.SIMULATION,DataOrigin.IMPORTED,DataOrigin.SOFTWARE):
        warn.append("QFT request origin is unusual for the current software-only Q-1 implementation.")
    return SemiclassicalConsistency(SolverStatus.PASS if not fail else SolverStatus.INPUT_INCONSISTENT,
                                    tuple(checks),tuple(fail),tuple(warn))

@dataclass(frozen=True)
class QISensitivity:
    sampling_time_s:float
    bound_j_m3:float
    logarithmic_sensitivity_tau:float
    finite_difference_relative_error:float
    provenance:str

def qi_sampling_sensitivity(request:QFTRequest,*,fractional_step:float=1e-4)->QISensitivity:
    h=float(fractional_step)
    if not math.isfinite(h) or h<=0 or h>=1:raise ValueError("fractional_step must be in (0,1)")
    tau=request.sampling_time_s
    def at(t):
        q=QFTRequest(request.geometry_id,request.geometry_revision,request.field,request.state,request.sampling,t,
                     request.observer,request.boundary_conditions,request.renormalization,request.requested_precision,
                     request.provenance,request.origin)
        r=ford_roman_lorentzian_massless_scalar_bound(q)
        if r.status!=SolverStatus.PASS:raise ValueError(r.message)
        return float(r.lower_bound_energy_density_j_m3)
    y=at(tau);yp=at(tau*(1+h));ym=at(tau*(1-h))
    deriv=(math.log(abs(yp))-math.log(abs(ym)))/(math.log(tau*(1+h))-math.log(tau*(1-h)))
    return QISensitivity(tau,y,deriv,abs(deriv+4.0)/4.0,
        "centered log finite-difference sensitivity against analytic tau^-4 reference scaling")

@dataclass(frozen=True)
class QIUncertainty:
    bound_j_m3:float
    sampling_time_standard_uncertainty_s:float
    bound_standard_uncertainty_j_m3:float
    relative_standard_uncertainty:float
    provenance:str

def propagate_qi_sampling_time_uncertainty(request:QFTRequest,sampling_time_standard_uncertainty_s:float)->QIUncertainty:
    u=float(sampling_time_standard_uncertainty_s)
    if not math.isfinite(u) or u<0:raise ValueError("sampling-time uncertainty must be finite and nonnegative")
    r=ford_roman_lorentzian_massless_scalar_bound(request)
    if r.status!=SolverStatus.PASS or r.lower_bound_energy_density_j_m3 is None:raise ValueError(r.message)
    y=float(r.lower_bound_energy_density_j_m3)
    # y=-A*tau^-4, so |dy/dtau|=4|y|/tau.
    uy=4*abs(y)*u/request.sampling_time_s
    return QIUncertainty(y,u,uy,uy/max(abs(y),1e-300),
        "first-order propagation through analytic tau^-4 reference bound")

def expanded_qft_guardian_contract(request:QFTRequest,result:QIResult,*,flatness:LocalFlatnessDiagnostic|None=None,
                                   comparison:StressEnergyQIComparison|None=None,consistency:SemiclassicalConsistency|None=None)->QFTGuardianContract:
    base=qft_guardian_contract(request,result)
    rd=dict(base.result)
    if flatness is not None:rd["local_flatness"]={"status":flatness.status.value,"scale_ratio":flatness.scale_ratio,
        "threshold":flatness.threshold,"locally_flat_scale_separation":flatness.locally_flat_scale_separation}
    if comparison is not None:rd["stress_energy_comparison"]={"status":comparison.status.value,
        "required_energy_density_j_m3":comparison.required_energy_density_j_m3,"qi_lower_bound_j_m3":comparison.qi_lower_bound_j_m3,
        "satisfies_reference_bound":comparison.satisfies_reference_bound,"magnitude_ratio_to_bound":comparison.magnitude_ratio_to_bound}
    if consistency is not None:rd["semiclassical_consistency"]={"status":consistency.status.value,
        "checks":consistency.checks,"failures":consistency.failures,"warnings":consistency.warnings}
    return QFTGuardianContract(base.schema,base.request,rd,base.authority)


@dataclass(frozen=True)
class SamplingProfile:
    times_s:tuple[float,...]
    weights_per_s:tuple[float,...]
    name:str
    provenance:str
    def __post_init__(self):
        if len(self.times_s)!=len(self.weights_per_s) or len(self.times_s)<3:raise ValueError("sampling profile requires matching arrays with at least three points")
        if any(not math.isfinite(float(x)) for x in self.times_s+self.weights_per_s):raise ValueError("sampling profile values must be finite")
        if any(self.times_s[i]>=self.times_s[i+1] for i in range(len(self.times_s)-1)):raise ValueError("sampling times must be strictly increasing")
        if not self.name.strip() or not self.provenance.strip():raise ValueError("sampling profile name/provenance required")

@dataclass(frozen=True)
class SamplingIntegral:
    integral:float
    estimated_error:float
    normalized_integral:float
    converged:bool
    samples:int
    method:str
    provenance:str

def _trapz(x,y):
    return sum((x[i+1]-x[i])*(y[i+1]+y[i])*0.5 for i in range(len(x)-1))

def integrate_sampling_profile(profile:SamplingProfile,values,*,normalization_tolerance:float=5e-3)->SamplingIntegral:
    vals=tuple(float(v) for v in values)
    if len(vals)!=len(profile.times_s) or any(not math.isfinite(v) for v in vals):raise ValueError("finite values must match sampling profile")
    x=profile.times_s;w=profile.weights_per_s
    norm=_trapz(x,w)
    if abs(norm)<1e-300:raise ValueError("sampling profile has zero numerical normalization")
    fine=_trapz(x,tuple(wi*vi for wi,vi in zip(w,vals)))
    # Coarsen by taking alternating samples plus the endpoint for a deterministic quadrature estimate.
    idx=list(range(0,len(x),2))
    if idx[-1]!=len(x)-1:idx.append(len(x)-1)
    xc=tuple(x[i] for i in idx);yc=tuple(w[i]*vals[i] for i in idx)
    coarse=_trapz(xc,yc)
    err=abs(fine-coarse)
    return SamplingIntegral(fine,err,norm,abs(norm-1.0)<=normalization_tolerance,len(x),
        "composite trapezoid with alternating-grid difference estimate",profile.provenance)

def lorentzian_sampling_profile(tau_s:float,*,span_tau:float=50.0,samples:int=1001)->SamplingProfile:
    """Numerically normalized finite-window representation of g(t)=tau/[pi(t^2+tau^2)]."""
    tau=float(tau_s);span=float(span_tau)
    if tau<=0 or not math.isfinite(tau) or span<=0 or not math.isfinite(span) or samples<5:raise ValueError("valid tau/span and at least five samples required")
    if samples%2==0:samples+=1
    x=tuple(-span*tau+(2*span*tau)*i/(samples-1) for i in range(samples))
    raw=tuple(tau/(math.pi*(t*t+tau*tau)) for t in x)
    norm=_trapz(x,raw)
    w=tuple(v/norm for v in raw)
    return SamplingProfile(x,w,"Lorentzian finite-window numerical profile",
        f"analytic Lorentzian sampling truncated at +/-{span:g} tau and numerically renormalized")

@dataclass(frozen=True)
class SampledEnergyResult:
    sampled_energy_density_j_m3:float
    normalization:float
    quadrature_error_j_m3:float
    samples:int
    provenance:str
    origin:DataOrigin=DataOrigin.SIMULATION

def sample_energy_density(profile:SamplingProfile,energy_density_j_m3)->SampledEnergyResult:
    q=integrate_sampling_profile(profile,energy_density_j_m3)
    return SampledEnergyResult(q.integral,q.normalized_integral,q.estimated_error,q.samples,
        "declared energy-density samples integrated against "+profile.name)

@dataclass(frozen=True)
class QINumericalVerification:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    maximum_relative_error:float
    provenance:str

def verify_qi_reference_numerically(request:QFTRequest)->QINumericalVerification:
    checks=[];fail=[];errs=[]
    base=ford_roman_lorentzian_massless_scalar_bound(request)
    if base.status!=SolverStatus.PASS or base.lower_bound_energy_density_j_m3 is None:
        return QINumericalVerification(False,(),("reference request outside implemented domain",),math.inf,"Q-1 numerical verification")
    # Scaling at 1/2, 1, 2 tau against exact tau^-4 law.
    vals=[]
    for f in (.5,1.0,2.0):
        q=QFTRequest(request.geometry_id,request.geometry_revision,request.field,request.state,request.sampling,
            request.sampling_time_s*f,request.observer,request.boundary_conditions,request.renormalization,
            request.requested_precision,request.provenance,request.origin)
        vals.append(float(ford_roman_lorentzian_massless_scalar_bound(q).lower_bound_energy_density_j_m3))
    expected=(16*base.lower_bound_energy_density_j_m3,base.lower_bound_energy_density_j_m3,base.lower_bound_energy_density_j_m3/16)
    for a,e in zip(vals,expected):errs.append(abs(a-e)/max(abs(e),1e-300))
    if max(errs)<1e-12:checks.append("analytic tau^-4 scaling benchmark passed")
    else:fail.append("tau^-4 scaling benchmark failed")
    sens=qi_sampling_sensitivity(request)
    errs.append(sens.finite_difference_relative_error)
    if sens.finite_difference_relative_error<1e-6:checks.append("finite-difference logarithmic sensitivity benchmark passed")
    else:fail.append("finite-difference sensitivity benchmark failed")
    profile=lorentzian_sampling_profile(request.sampling_time_s,span_tau=100,samples=2001)
    integ=integrate_sampling_profile(profile,(1.0,)*len(profile.times_s))
    errs.append(abs(integ.normalized_integral-1))
    if abs(integ.normalized_integral-1)<1e-12:checks.append("numerical sampling normalization benchmark passed")
    else:fail.append("sampling normalization benchmark failed")
    return QINumericalVerification(not fail,tuple(checks),tuple(fail),max(errs),"independent Q-1 reference/scaling/quadrature benchmarks")

@dataclass(frozen=True)
class Q1ModelComparison:
    entries:tuple[NegativeEnergyMechanismComparison,...]
    warning:str

def q1_model_comparison(*,qi:QIResult|None=None,casimir:CasimirResult|None=None,squeezed:SqueezedVacuumResult|None=None)->Q1ModelComparison:
    entries=compare_reference_mechanisms(casimir=casimir,squeezed=squeezed,qi=qi)
    return Q1ModelComparison(entries,
        "Values are not interchangeable: boundary-condition energy, state-dependent local energy, and a sampling inequality bound have different physical meanings.")


@dataclass(frozen=True)
class Q1ReleaseReadiness:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    notes:tuple[str,...]

def q1_release_readiness()->Q1ReleaseReadiness:
    checks=[];fail=[];notes=[]
    try:
        req=QFTRequest("geometry.minkowski","qualification",FieldKind.MASSLESS_SCALAR,QuantumState.VACUUM,
            SamplingFunction.LORENTZIAN,1e-9,"inertial observer","none","vacuum subtraction",1e-8,
            "Q-1 v1.0 release qualification")
        r=ford_roman_lorentzian_massless_scalar_bound(req)
        if r.status==SolverStatus.PASS and r.lower_bound_energy_density_j_m3 is not None and r.lower_bound_energy_density_j_m3<0:
            checks.append("flat-space Lorentzian QI reference passed")
        else:fail.append("flat-space QI reference failed")
        bad=QFTRequest("geometry.morris-thorne","qualification",FieldKind.MASSLESS_SCALAR,QuantumState.VACUUM,
            SamplingFunction.LORENTZIAN,1e-9,"static observer","none","vacuum subtraction",1e-8,"qualification")
        if ford_roman_lorentzian_massless_scalar_bound(bad).status==SolverStatus.DOMAIN_INVALID:
            checks.append("curved-geometry domain rejection passed")
        else:fail.append("curved-geometry domain rejection failed")
        v=verify_qi_reference_numerically(req)
        if v.passed:checks.append("QI scaling/sensitivity/quadrature verification passed")
        else:fail.extend(v.failures)
        c=ideal_parallel_plate_casimir(CasimirRequest(1e-6,1,0,"IDEAL_PERFECT_CONDUCTOR","PARALLEL_PLATES","qualification"))
        if c.status==SolverStatus.PASS and c.energy_density_j_m3<0 and abs(c.pressure_pa/c.energy_density_j_m3-3)<1e-12:
            checks.append("ideal Casimir analytic benchmark passed")
        else:fail.append("Casimir benchmark failed")
        sq=single_mode_squeezed_vacuum_reference(SqueezedVacuumRequest(1e15,.5,0,1e-18,0,"qualification"))
        if sq.status==SolverStatus.PASS and sq.normal_ordered_energy_density_j_m3<0:
            checks.append("single-mode squeezed-vacuum phase benchmark passed")
        else:fail.append("squeezed-vacuum benchmark failed")
        g=qft_guardian_contract(req,r)
        if g.schema=="JOE-GUARDIAN-QFT/1" and "READ_ONLY_ADVISORY" in g.authority:
            checks.append("Guardian QFT authority/provenance contract passed")
        else:fail.append("Guardian QFT contract failed")
        inv=maximum_reference_sampling_time(req,abs(r.lower_bound_energy_density_j_m3))
        if inv.maximum_sampling_time_s is not None and abs(inv.maximum_sampling_time_s-req.sampling_time_s)/req.sampling_time_s<1e-12:
            checks.append("QI magnitude-duration inversion benchmark passed")
        else:fail.append("QI magnitude-duration inversion failed")
    except Exception as exc:fail.append(f"release-readiness exception: {type(exc).__name__}: {exc}")
    notes.append("Q-1 v1.0 contains reference models and applicability diagnostics, not a macroscopic negative-energy source design.")
    notes.append("DOMAIN_INVALID, MODEL_UNAVAILABLE and UNKNOWN_PHYSICS are valid scientific outcomes and must not be coerced into numbers.")
    return Q1ReleaseReadiness(not fail,tuple(checks),tuple(fail),tuple(notes))
