"""Report / Dossier Generator — RPT-001A typed reproducible report model."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Iterable
import hashlib, json, math

class EvidenceClass(str,Enum):
    ESTABLISHED_PHYSICS="ESTABLISHED_PHYSICS"
    DEMONSTRATED_TECHNOLOGY="DEMONSTRATED_TECHNOLOGY"
    EXTRAPOLATED_ENGINEERING="EXTRAPOLATED_ENGINEERING"
    SPECULATIVE_UNRESOLVED="SPECULATIVE_UNRESOLVED"
    SIMULATION_RESULT="SIMULATION_RESULT"
    IMPORTED_OBSERVATION="IMPORTED_OBSERVATION"

class ReportElementKind(str,Enum):
    PROSE="PROSE"
    EQUATION="EQUATION"
    FIGURE="FIGURE"
    TABLE="TABLE"
    CALLOUT="CALLOUT"

@dataclass(frozen=True)
class EvidenceReference:
    reference_id:str
    source_type:str
    source_id:str
    provenance:str
    evidence_class:EvidenceClass
    record_ids:tuple[str,...]=()
    artifact_sha256:str|None=None
    def __post_init__(self):
        if not all((self.reference_id.strip(),self.source_type.strip(),self.source_id.strip(),self.provenance.strip())):
            raise ValueError("complete evidence reference required")
        if self.artifact_sha256 is not None and (len(self.artifact_sha256)!=64 or any(c not in "0123456789abcdef" for c in self.artifact_sha256.lower())):
            raise ValueError("evidence artifact hash must be SHA-256")

@dataclass(frozen=True)
class ReportElement:
    element_id:str
    kind:ReportElementKind
    title:str
    content:str
    evidence_refs:tuple[str,...]
    provenance:str
    equation_id:str|None=None
    figure_id:str|None=None
    table_id:str|None=None
    units:str|None=None
    uncertainty_note:str|None=None
    def __post_init__(self):
        if not all((self.element_id.strip(),self.title.strip(),self.provenance.strip())):raise ValueError("element identity/title/provenance required")
        if self.kind==ReportElementKind.EQUATION and not self.equation_id:raise ValueError("equation element requires equation_id")
        if self.kind==ReportElementKind.FIGURE and not self.figure_id:raise ValueError("figure element requires figure_id")
        if self.kind==ReportElementKind.TABLE and not self.table_id:raise ValueError("table element requires table_id")

@dataclass(frozen=True)
class ReportSection:
    section_id:str
    number:str
    title:str
    elements:tuple[ReportElement,...]
    provenance:str
    def __post_init__(self):
        if not all((self.section_id.strip(),self.number.strip(),self.title.strip(),self.provenance.strip())):raise ValueError("complete report section required")
        ids=[e.element_id for e in self.elements]
        if len(ids)!=len(set(ids)):raise ValueError("duplicate element identity in section")

@dataclass(frozen=True)
class ScientificReportSpecification:
    schema:str
    report_id:str
    title:str
    subtitle:str
    project_name:str
    edition:str
    authoring_organization:str
    sections:tuple[ReportSection,...]
    evidence:tuple[EvidenceReference,...]
    software_build:str
    provenance:str
    parameter_revision:str|None=None
    configuration_revision:str|None=None
    run_ids:tuple[str,...]=()
    def __post_init__(self):
        if self.schema!="JOE-SCIENTIFIC-REPORT/1":raise ValueError("unsupported report schema")
        if not all((self.report_id.strip(),self.title.strip(),self.project_name.strip(),self.edition.strip(),
                    self.authoring_organization.strip(),self.software_build.strip(),self.provenance.strip())):
            raise ValueError("complete report identity/build/provenance required")
        sids=[s.section_id for s in self.sections]
        if len(sids)!=len(set(sids)):raise ValueError("duplicate report section identity")
        refs={r.reference_id for r in self.evidence}
        if len(refs)!=len(self.evidence):raise ValueError("duplicate evidence reference identity")
        used={x for s in self.sections for e in s.elements for x in e.evidence_refs}
        missing=used-refs
        if missing:raise ValueError("report elements reference unknown evidence: "+", ".join(sorted(missing)))

def report_specification_dict(spec:ScientificReportSpecification)->dict[str,Any]:
    d=asdict(spec)
    for e in d["evidence"]:e["evidence_class"]=e["evidence_class"].value if hasattr(e["evidence_class"],"value") else e["evidence_class"]
    for sec in d["sections"]:
        for el in sec["elements"]:el["kind"]=el["kind"].value if hasattr(el["kind"],"value") else el["kind"]
    return d

def canonical_report_bytes(spec:ScientificReportSpecification)->bytes:
    return (json.dumps(report_specification_dict(spec),sort_keys=True,separators=(",",":"),ensure_ascii=False)+"\n").encode("utf-8")

def report_specification_sha256(spec:ScientificReportSpecification)->str:
    return hashlib.sha256(canonical_report_bytes(spec)).hexdigest()

def write_report_specification(spec:ScientificReportSpecification,path:str|Path)->str:
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(report_specification_dict(spec),sort_keys=True,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    return hashlib.sha256(p.read_bytes()).hexdigest()

def _element(q):
    return ReportElement(q["element_id"],ReportElementKind(q["kind"]),q["title"],q["content"],tuple(q["evidence_refs"]),q["provenance"],
        q.get("equation_id"),q.get("figure_id"),q.get("table_id"),q.get("units"),q.get("uncertainty_note"))

def load_report_specification(path:str|Path)->ScientificReportSpecification:
    q=json.loads(Path(path).read_text(encoding="utf-8"))
    evidence=tuple(EvidenceReference(e["reference_id"],e["source_type"],e["source_id"],e["provenance"],EvidenceClass(e["evidence_class"]),
        tuple(e.get("record_ids",[])),e.get("artifact_sha256")) for e in q["evidence"])
    sections=tuple(ReportSection(s["section_id"],s["number"],s["title"],tuple(_element(e) for e in s["elements"]),s["provenance"]) for s in q["sections"])
    return ScientificReportSpecification(q["schema"],q["report_id"],q["title"],q["subtitle"],q["project_name"],q["edition"],
        q["authoring_organization"],sections,evidence,q["software_build"],q["provenance"],q.get("parameter_revision"),
        q.get("configuration_revision"),tuple(q.get("run_ids",[])))

@dataclass(frozen=True)
class ReportValidation:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]

def validate_report(spec:ScientificReportSpecification)->ReportValidation:
    checks=[];fail=[]
    eq=[];fig=[];tab=[]
    for sec in spec.sections:
        if not sec.elements:fail.append(f"section {sec.number} has no report elements")
        for e in sec.elements:
            if not e.evidence_refs:fail.append(f"{e.element_id}: no evidence/provenance reference")
            if e.kind==ReportElementKind.EQUATION:eq.append(e.equation_id)
            if e.kind==ReportElementKind.FIGURE:fig.append(e.figure_id)
            if e.kind==ReportElementKind.TABLE:tab.append(e.table_id)
    for label,ids in (("equation",eq),("figure",fig),("table",tab)):
        if len(ids)!=len(set(ids)):fail.append(f"duplicate {label} identifier")
        else:checks.append(f"{label} identifiers unique")
    if spec.evidence:checks.append("evidence registry present")
    if spec.software_build:checks.append("software build bound")
    if spec.provenance:checks.append("report provenance present")
    return ReportValidation(not fail,tuple(checks),tuple(fail))

@dataclass(frozen=True)
class ReportGuardianContract:
    schema:str
    status:str
    facts:dict[str,Any]
    provenance:str
    authority:str="READ_ONLY_ADVISORY"

def report_guardian_contract(spec:ScientificReportSpecification)->ReportGuardianContract:
    v=validate_report(spec)
    classes=tuple(sorted(set(e.evidence_class.value for e in spec.evidence)))
    return ReportGuardianContract("JOE-GUARDIAN-REPORT/1","PASS" if v.passed else "FAIL",
        {"report_id":spec.report_id,"section_count":len(spec.sections),"evidence_count":len(spec.evidence),
         "evidence_classes":classes,"specification_sha256":report_specification_sha256(spec),"validation_failures":v.failures},
        "Report Generator RPT-001A")

def report_core_readiness():
    ref=EvidenceReference("e","RUN","r","readiness",EvidenceClass.SIMULATION_RESULT,("rec",))
    el=ReportElement("x",ReportElementKind.PROSE,"Result","Synthetic qualification content.",("e",),"readiness")
    sec=ReportSection("s","1","Qualification",(el,),"readiness")
    spec=ScientificReportSpecification("JOE-SCIENTIFIC-REPORT/1","r","Report","","Journeyman","Technical","Sierra Kilo Labs",
        (sec,),(ref,),"test-build","readiness",run_ids=("r",))
    v=validate_report(spec)
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/"report.json";write_report_specification(spec,p);same=load_report_specification(p)==spec
    return {"passed":v.passed and same and len(report_specification_sha256(spec))==64,
            "checks":("typed report specification","evidence registry","element provenance","stable report hash","JSON round-trip","Guardian report contract")}


@dataclass(frozen=True)
class RenderedReport:
    schema:str
    report_id:str
    specification_sha256:str
    rendered_text:str
    evidence_index:tuple[tuple[str,str,str],...]
    provenance:str

def render_report_text(spec:ScientificReportSpecification)->RenderedReport:
    validation=validate_report(spec)
    if not validation.passed:
        raise ValueError("report specification failed validation: "+"; ".join(validation.failures))
    lines=[spec.title]
    if spec.subtitle:lines.append(spec.subtitle)
    lines += [f"Project: {spec.project_name}",f"Edition: {spec.edition}",
              f"Prepared by: {spec.authoring_organization}",f"Software build: {spec.software_build}",
              f"Specification SHA-256: {report_specification_sha256(spec)}",""]
    if spec.parameter_revision:lines.append(f"Parameter revision: {spec.parameter_revision}")
    if spec.configuration_revision:lines.append(f"Configuration revision: {spec.configuration_revision}")
    if spec.run_ids:lines.append("Bound run IDs: "+", ".join(spec.run_ids))
    lines.append("")
    evidence={e.reference_id:e for e in spec.evidence}
    for sec in spec.sections:
        lines += [f"{sec.number} — {sec.title}","="*(len(sec.number)+3+len(sec.title))]
        for el in sec.elements:
            label={"EQUATION":el.equation_id,"FIGURE":el.figure_id,"TABLE":el.table_id}.get(el.kind.value)
            heading=el.title+(f" [{label}]" if label else "")
            lines += ["",heading,el.content]
            if el.units:lines.append("Units: "+el.units)
            if el.uncertainty_note:lines.append("Uncertainty: "+el.uncertainty_note)
            refs=[]
            for rid in el.evidence_refs:
                e=evidence[rid];refs.append(f"{rid} ({e.evidence_class.value}; {e.source_type}:{e.source_id})")
            lines.append("Evidence: "+", ".join(refs))
        lines.append("")
    lines += ["Evidence Register","-----------------"]
    index=[]
    for e in spec.evidence:
        lines.append(f"{e.reference_id}: {e.evidence_class.value} | {e.source_type}:{e.source_id} | {e.provenance}")
        if e.record_ids:lines.append("  Records: "+", ".join(e.record_ids))
        if e.artifact_sha256:lines.append("  Artifact SHA-256: "+e.artifact_sha256)
        index.append((e.reference_id,e.evidence_class.value,e.source_id))
    lines += ["","REPORT PROVENANCE: "+spec.provenance,
              "This rendering preserves the report specification's declared evidence classes; rendering does not elevate epistemic status."]
    return RenderedReport("JOE-RENDERED-SCIENTIFIC-REPORT/1",spec.report_id,report_specification_sha256(spec),
                          "\n".join(lines).rstrip()+"\n",tuple(index),spec.provenance)

def write_rendered_text(report:RenderedReport,path:str|Path)->str:
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(report.rendered_text,encoding="utf-8")
    return hashlib.sha256(p.read_bytes()).hexdigest()

def render_report_html(spec:ScientificReportSpecification)->RenderedReport:
    import html
    base=render_report_text(spec)
    ev={e.reference_id:e for e in spec.evidence}
    parts=["<!doctype html><html><head><meta charset='utf-8'><title>"+html.escape(spec.title)+"</title>",
           "<style>body{font-family:system-ui,sans-serif;max-width:1100px;margin:3rem auto;line-height:1.5}"+
           "table{border-collapse:collapse}td,th{border:1px solid #888;padding:.35rem}.meta{color:#555}.evidence{font-size:.9em;color:#444}</style></head><body>",
           "<h1>"+html.escape(spec.title)+"</h1>"]
    if spec.subtitle:parts.append("<h2>"+html.escape(spec.subtitle)+"</h2>")
    parts.append("<div class='meta'>Project: "+html.escape(spec.project_name)+" | Edition: "+html.escape(spec.edition)+
                 " | Prepared by: "+html.escape(spec.authoring_organization)+" | Build: "+html.escape(spec.software_build)+"</div>")
    for sec in spec.sections:
        parts.append("<h2>"+html.escape(sec.number+" — "+sec.title)+"</h2>")
        for el in sec.elements:
            label=el.equation_id or el.figure_id or el.table_id
            parts.append("<h3>"+html.escape(el.title+(f" [{label}]" if label else ""))+"</h3>")
            parts.append("<pre style='white-space:pre-wrap'>"+html.escape(el.content)+"</pre>")
            refs="; ".join(f"{r} ({ev[r].evidence_class.value})" for r in el.evidence_refs)
            parts.append("<div class='evidence'>Evidence: "+html.escape(refs)+"</div>")
    parts.append("<h2>Evidence Register</h2><ul>")
    for e in spec.evidence:
        parts.append("<li>"+html.escape(f"{e.reference_id}: {e.evidence_class.value} | {e.source_type}:{e.source_id} | {e.provenance}")+"</li>")
    parts.append("</ul><p class='meta'>Specification SHA-256: "+base.specification_sha256+
                 "</p><p class='meta'>Rendering does not elevate epistemic status.</p></body></html>")
    return RenderedReport("JOE-RENDERED-SCIENTIFIC-REPORT/1",spec.report_id,base.specification_sha256,
                          "\n".join(parts),base.evidence_index,spec.provenance)

def report_rendering_readiness():
    ref=EvidenceReference("e","RUN","r","readiness",EvidenceClass.SIMULATION_RESULT,("rec",))
    eq=ReportElement("eq",ReportElementKind.EQUATION,"Kinematic relation","ΔT = τ_A − τ_B",("e",),"readiness",
                     equation_id="Equation (1-1)",units="s",uncertainty_note="Supplied by source record.")
    sec=ReportSection("s","1","Qualification",(eq,),"readiness")
    spec=ScientificReportSpecification("JOE-SCIENTIFIC-REPORT/1","r","Report","Qualification","Journeyman","Technical",
        "Sierra Kilo Labs",(sec,),(ref,),"test-build","readiness",run_ids=("r",))
    text=render_report_text(spec);html_report=render_report_html(spec)
    return {"passed":"Equation (1-1)" in text.rendered_text and "SIMULATION_RESULT" in text.rendered_text and
                     "<html>" in html_report.rendered_text and text.specification_sha256==report_specification_sha256(spec),
            "checks":("validated rendering gate","text dossier renderer","HTML dossier renderer","evidence register",
                      "equation/figure/table labels","specification SHA-256 binding","epistemic-status preservation")}


@dataclass(frozen=True)
class ReportArtifactManifest:
    schema:str
    report_id:str
    specification_sha256:str
    artifact_sha256:str
    byte_count:int
    media_type:str
    software_build:str
    provenance:str
    def __post_init__(self):
        if self.schema!="JOE-REPORT-ARTIFACT/1":raise ValueError("unsupported report artifact schema")
        for h in (self.specification_sha256,self.artifact_sha256):
            if len(h)!=64 or any(c not in "0123456789abcdef" for c in h.lower()):raise ValueError("report artifact hashes must be SHA-256")
        if self.byte_count<1:raise ValueError("report artifact must contain bytes")

def render_report_pdf(spec:ScientificReportSpecification,path:str|Path)->ReportArtifactManifest:
    """Render a validated scientific report through ReportLab Platypus."""
    validation=validate_report(spec)
    if not validation.passed:raise ValueError("report specification failed validation: "+"; ".join(validation.failures))
    try:
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_CENTER
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
        from reportlab.lib.units import inch
        from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,KeepTogether
    except ImportError as exc:raise RuntimeError("ReportLab is required for PDF rendering") from exc
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    styles=getSampleStyleSheet()
    title=ParagraphStyle("JOETitle",parent=styles["Title"],alignment=TA_CENTER,fontSize=20,leading=24,spaceAfter=12)
    subtitle=ParagraphStyle("JOESubtitle",parent=styles["Heading2"],alignment=TA_CENTER,fontSize=11,leading=14,spaceAfter=18)
    h2=ParagraphStyle("JOEH2",parent=styles["Heading2"],fontSize=14,leading=17,spaceBefore=10,spaceAfter=7)
    h3=ParagraphStyle("JOEH3",parent=styles["Heading3"],fontSize=11,leading=14,spaceBefore=7,spaceAfter=4)
    body=ParagraphStyle("JOEBody",parent=styles["BodyText"],fontSize=9.5,leading=13,spaceAfter=6)
    mono=ParagraphStyle("JOEEquation",parent=body,fontName="Courier",fontSize=9,leading=12,leftIndent=18,rightIndent=18,spaceBefore=5,spaceAfter=7)
    small=ParagraphStyle("JOESmall",parent=body,fontSize=7.5,leading=10,textColor=colors.HexColor("#444444"))
    def esc(x):
        import html
        return html.escape(str(x)).replace("\n","<br/>")
    def footer(canvas,doc):
        canvas.saveState();canvas.setFont("Helvetica",7)
        canvas.drawString(0.65*inch,0.42*inch,f"{spec.project_name} | {spec.edition} | {spec.software_build}")
        canvas.drawRightString(7.85*inch,0.42*inch,f"Page {doc.page}");canvas.restoreState()
    story=[Paragraph(esc(spec.title),title)]
    if spec.subtitle:story.append(Paragraph(esc(spec.subtitle),subtitle))
    meta=[[Paragraph("<b>Project</b>",small),Paragraph(esc(spec.project_name),small)],
          [Paragraph("<b>Edition</b>",small),Paragraph(esc(spec.edition),small)],
          [Paragraph("<b>Prepared by</b>",small),Paragraph(esc(spec.authoring_organization),small)],
          [Paragraph("<b>Software build</b>",small),Paragraph(esc(spec.software_build),small)],
          [Paragraph("<b>Specification SHA-256</b>",small),Paragraph(report_specification_sha256(spec),small)]]
    if spec.parameter_revision:meta.append([Paragraph("<b>Parameter revision</b>",small),Paragraph(esc(spec.parameter_revision),small)])
    if spec.configuration_revision:meta.append([Paragraph("<b>Configuration revision</b>",small),Paragraph(esc(spec.configuration_revision),small)])
    if spec.run_ids:meta.append([Paragraph("<b>Bound run IDs</b>",small),Paragraph(esc(", ".join(spec.run_ids)),small)])
    mt=Table(meta,colWidths=[1.45*inch,5.65*inch]);mt.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),("LINEBELOW",(0,0),(-1,-1),0.25,colors.HexColor("#dddddd")),("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4)]))
    story += [mt,Spacer(1,14)]
    evidence={e.reference_id:e for e in spec.evidence}
    for sec in spec.sections:
        story.append(Paragraph(esc(sec.number+" - "+sec.title),h2))
        for el in sec.elements:
            label=el.equation_id or el.figure_id or el.table_id
            story.append(Paragraph(esc(el.title+(f" [{label}]" if label else "")),h3))
            style=mono if el.kind==ReportElementKind.EQUATION else body
            story.append(Paragraph(esc(el.content),style))
            if el.units:story.append(Paragraph("<b>Units:</b> "+esc(el.units),small))
            if el.uncertainty_note:story.append(Paragraph("<b>Uncertainty:</b> "+esc(el.uncertainty_note),small))
            refs=[]
            for rid in el.evidence_refs:
                e=evidence[rid];refs.append(f"{rid} ({e.evidence_class.value}; {e.source_type}:{e.source_id})")
            story.append(Paragraph("<b>Evidence:</b> "+esc("; ".join(refs)),small))
    story += [PageBreak(),Paragraph("Evidence Register",h2)]
    rows=[[Paragraph("<b>ID</b>",small),Paragraph("<b>Class</b>",small),Paragraph("<b>Source</b>",small),Paragraph("<b>Provenance</b>",small)]]
    for e in spec.evidence:
        prov=e.provenance
        if e.record_ids:prov+=" | Records: "+", ".join(e.record_ids)
        if e.artifact_sha256:prov+=" | Artifact SHA-256: "+e.artifact_sha256
        rows.append([Paragraph(esc(e.reference_id),small),Paragraph(esc(e.evidence_class.value),small),
                     Paragraph(esc(e.source_type+":"+e.source_id),small),Paragraph(esc(prov),small)])
    table=Table(rows,colWidths=[.65*inch,1.55*inch,1.55*inch,3.35*inch],repeatRows=1)
    table.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.3,colors.HexColor("#bbbbbb")),("VALIGN",(0,0),(-1,-1),"TOP"),("BACKGROUND",(0,0),(-1,0),colors.HexColor("#eeeeee"))]))
    story += [table,Spacer(1,12),Paragraph("<b>REPORT PROVENANCE:</b> "+esc(spec.provenance),small),
              Paragraph("Rendering preserves declared evidence classes and does not elevate epistemic status.",small)]
    doc=SimpleDocTemplate(str(p),pagesize=letter,rightMargin=.65*inch,leftMargin=.65*inch,topMargin=.65*inch,bottomMargin=.65*inch,
                          title=spec.title,author=spec.authoring_organization,subject=spec.project_name)
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    data=p.read_bytes();h=hashlib.sha256(data).hexdigest()
    return ReportArtifactManifest("JOE-REPORT-ARTIFACT/1",spec.report_id,report_specification_sha256(spec),h,len(data),"application/pdf",spec.software_build,spec.provenance)

def write_report_artifact_manifest(manifest:ReportArtifactManifest,path:str|Path)->str:
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(asdict(manifest),sort_keys=True,indent=2)+"\n",encoding="utf-8")
    return hashlib.sha256(p.read_bytes()).hexdigest()

def verify_report_artifact(manifest:ReportArtifactManifest,path:str|Path)->bool:
    p=Path(path)
    return p.is_file() and p.stat().st_size==manifest.byte_count and hashlib.sha256(p.read_bytes()).hexdigest()==manifest.artifact_sha256

def report_v1_release_readiness():
    failures=[];checks=[]
    for name,fn in (("report model",report_core_readiness),("rendering pipeline",report_rendering_readiness)):
        try:
            q=fn()
            if q["passed"]:checks.append(name+" passed")
            else:failures.append(name+" failed")
        except Exception as exc:failures.append(f"{name}: {type(exc).__name__}: {exc}")
    try:
        ref=EvidenceReference("e","RUN","r","readiness",EvidenceClass.SIMULATION_RESULT,("rec",))
        el=ReportElement("x",ReportElementKind.PROSE,"Result","Qualification content.",("e",),"readiness")
        sec=ReportSection("s","1","Qualification",(el,),"readiness")
        spec=ScientificReportSpecification("JOE-SCIENTIFIC-REPORT/1","r","Journeyman Report","Qualification","Journeyman","Technical",
            "Sierra Kilo Labs",(sec,),(ref,),"test-build","readiness")
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"report.pdf";m=render_report_pdf(spec,p)
            if p.read_bytes()[:4]==b"%PDF" and verify_report_artifact(m,p):checks.append("PDF artifact render/hash verification passed")
            mp=Path(d)/"artifact.json";write_report_artifact_manifest(m,mp)
            if json.loads(mp.read_text())["schema"]=="JOE-REPORT-ARTIFACT/1":checks.append("report artifact manifest passed")
    except Exception as exc:failures.append(f"PDF artifact: {type(exc).__name__}: {exc}")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),
            "notes":("PDF rendering consumes only validated JOE-SCIENTIFIC-REPORT/1 specifications.",
                     "Evidence classes, provenance and specification hash remain bound to the publication artifact.",
                     "Rendering does not validate unresolved physics or convert simulation into measurement.")}
