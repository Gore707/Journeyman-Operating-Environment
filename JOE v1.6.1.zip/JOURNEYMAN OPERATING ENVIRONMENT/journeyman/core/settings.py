import base64
import json
from dataclasses import asdict, dataclass
from .paths import SETTINGS_FILE

@dataclass
class Settings:
    telemetry_interval_ms: int = 1000
    confirm_exit: bool = True
    window_geometry: str = ""
    active_workspace_id: str = ""

    @classmethod
    def load(cls) -> "Settings":
        try:
            raw = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
            return cls(
                telemetry_interval_ms=max(250, min(10000, int(raw.get("telemetry_interval_ms", 1000)))),
                confirm_exit=bool(raw.get("confirm_exit", True)),
                window_geometry=str(raw.get("window_geometry", "")),
                active_workspace_id=str(raw.get("active_workspace_id", "")),
            )
        except (FileNotFoundError, ValueError, TypeError, json.JSONDecodeError):
            return cls()

    def save(self) -> None:
        SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
        temp = SETTINGS_FILE.with_suffix(".tmp")
        temp.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
        temp.replace(SETTINGS_FILE)

    def set_geometry(self, data: bytes) -> None:
        self.window_geometry = base64.b64encode(data).decode("ascii")

    def geometry_bytes(self) -> bytes:
        if not self.window_geometry:
            return b""
        try:
            return base64.b64decode(self.window_geometry.encode("ascii"), validate=True)
        except Exception:
            return b""
