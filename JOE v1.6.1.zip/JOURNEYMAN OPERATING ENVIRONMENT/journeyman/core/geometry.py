"""Journeyman Geometry / Metric Workbench core.

Numerical spacetime metric representations and tensor primitives. This module
does not infer physical viability from a metric and does not fabricate missing
stress-energy or curvature results.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Sequence
import math
import numpy as np

@dataclass(frozen=True)
class CoordinateDomain:
    names:tuple[str,str,str,str]
    lower:tuple[float|None,...]=(None,None,None,None)
    upper:tuple[float|None,...]=(None,None,None,None)
    lower_inclusive:tuple[bool,...]=(True,True,True,True)
    upper_inclusive:tuple[bool,...]=(True,True,True,True)

    def __post_init__(self):
        if len(set(self.names))!=4 or any(not str(x).strip() for x in self.names):
            raise ValueError("A 4D coordinate domain requires four unique names")
        for seq in (self.lower,self.upper,self.lower_inclusive,self.upper_inclusive):
            if len(seq)!=4:raise ValueError("Coordinate-domain bounds must have length four")
        for lo,hi in zip(self.lower,self.upper):
            if lo is not None and hi is not None and not lo < hi:
                raise ValueError("Each finite lower bound must be less than its upper bound")

    def contains(self,coords:Sequence[float])->bool:
        if len(coords)!=4:return False
        try:values=tuple(float(x) for x in coords)
        except (TypeError,ValueError):return False
        if not all(math.isfinite(x) for x in values):return False
        for i,x in enumerate(values):
            lo,hi=self.lower[i],self.upper[i]
            if lo is not None and (x < lo or (x==lo and not self.lower_inclusive[i])):return False
            if hi is not None and (x > hi or (x==hi and not self.upper_inclusive[i])):return False
        return True

@dataclass(frozen=True)
class MetricEvaluation:
    model_id:str
    coordinates:tuple[float,float,float,float]
    coordinate_names:tuple[str,str,str,str]
    components:tuple[tuple[float,...],...]
    determinant:float
    signature:tuple[int,int,int,int]
    provenance:str
    model_revision:str

    def matrix(self)->np.ndarray:return np.asarray(self.components,dtype=float)

@dataclass(frozen=True)
class IntervalResult:
    ds_squared:float
    classification:str

class MetricModel:
    def __init__(self,model_id:str,domain:CoordinateDomain,evaluator:Callable[[tuple[float,...]],np.ndarray],
                 *,provenance:str,model_revision:str="1"):
        self.model_id=str(model_id).strip();self.domain=domain;self.evaluator=evaluator
        self.provenance=str(provenance).strip();self.model_revision=str(model_revision).strip()
        if not self.model_id or not self.provenance or not self.model_revision:
            raise ValueError("metric model ID, provenance, and revision are required")

    def evaluate(self,coordinates:Sequence[float])->MetricEvaluation:
        coords=tuple(float(x) for x in coordinates)
        if not self.domain.contains(coords):raise ValueError("coordinates lie outside the metric domain")
        g=np.asarray(self.evaluator(coords),dtype=float)
        if g.shape!=(4,4):raise ValueError("metric evaluator must return a 4x4 matrix")
        if not np.all(np.isfinite(g)):raise ValueError("metric contains non-finite components")
        if not np.allclose(g,g.T,rtol=1e-12,atol=1e-12):raise ValueError("metric tensor must be symmetric")
        eig=np.linalg.eigvalsh(g);tol=max(1.0,float(np.max(np.abs(eig))))*1e-12
        if np.any(np.abs(eig)<=tol):raise ValueError("metric is singular or numerically degenerate")
        signs=tuple(sorted((-1 if x<0 else 1) for x in eig))
        if signs!=(-1,1,1,1):raise ValueError(f"metric is not Lorentzian (-,+,+,+); signature={signs}")
        det=float(np.linalg.det(g))
        return MetricEvaluation(self.model_id,coords,self.domain.names,
            tuple(tuple(float(v) for v in row) for row in g),det,signs,self.provenance,self.model_revision)

def inverse_metric(metric:MetricEvaluation)->tuple[tuple[float,...],...]:
    inv=np.linalg.inv(metric.matrix())
    return tuple(tuple(float(v) for v in row) for row in inv)

def lower_vector(metric:MetricEvaluation,contravariant:Sequence[float])->tuple[float,...]:
    v=np.asarray(contravariant,dtype=float)
    if v.shape!=(4,) or not np.all(np.isfinite(v)):raise ValueError("vector must contain four finite components")
    return tuple(float(x) for x in metric.matrix()@v)

def raise_covector(metric:MetricEvaluation,covariant:Sequence[float])->tuple[float,...]:
    v=np.asarray(covariant,dtype=float)
    if v.shape!=(4,) or not np.all(np.isfinite(v)):raise ValueError("covector must contain four finite components")
    return tuple(float(x) for x in np.asarray(inverse_metric(metric))@v)

def spacetime_interval(metric:MetricEvaluation,displacement:Sequence[float])->IntervalResult:
    dx=np.asarray(displacement,dtype=float)
    if dx.shape!=(4,) or not np.all(np.isfinite(dx)):raise ValueError("displacement must contain four finite components")
    ds2=float(dx@metric.matrix()@dx)
    scale=max(1.0,float(np.linalg.norm(dx))**2);tol=1e-12*scale
    kind="null" if abs(ds2)<=tol else ("timelike" if ds2<0 else "spacelike")
    return IntervalResult(ds2,kind)

def minkowski_metric()->MetricModel:
    domain=CoordinateDomain(("ct","x","y","z"))
    return MetricModel("geometry.minkowski",domain,lambda _:np.diag([-1.0,1.0,1.0,1.0]),
                       provenance="Special-relativistic Minkowski metric; signature (-,+,+,+).")

def morris_thorne_metric(*,throat_radius:float,redshift:Callable[[float],float]|None=None,
                         shape:Callable[[float],float]|None=None,model_revision:str="1")->MetricModel:
    """Numerical Morris-Thorne line element in (ct,r,theta,phi).

    g = diag[-exp(2 Phi(r)), 1/(1-b(r)/r), r^2, r^2 sin^2(theta)].
    Default Phi=0 and b(r)=r0^2/r are explicit model choices, not empirical claims.
    The coordinate chart is restricted to r>r0 because g_rr diverges at the
    throat in this curvature-coordinate chart.
    """
    r0=float(throat_radius)
    if not math.isfinite(r0) or r0<=0:raise ValueError("throat_radius must be finite and positive")
    redshift=redshift or (lambda r:0.0)
    shape=shape or (lambda r:r0*r0/r)
    domain=CoordinateDomain(("ct","r","theta","phi"),
                            (None,r0,0.0,0.0),(None,None,math.pi,2*math.pi),
                            (True,False,False,True),(True,True,False,False))
    def evaluator(q):
        _,r,theta,_=q;phi=float(redshift(r));b=float(shape(r))
        if not math.isfinite(phi) or not math.isfinite(b):raise ValueError("metric functions must be finite")
        denom=1.0-b/r
        if denom<=0:raise ValueError("Morris-Thorne curvature chart requires 1-b(r)/r > 0")
        return np.diag([-math.exp(2*phi),1.0/denom,r*r,r*r*math.sin(theta)**2])
    return MetricModel("geometry.morris-thorne",domain,evaluator,
        provenance="Morris-Thorne static spherical metric; supplied redshift/shape functions are model inputs.",
        model_revision=model_revision)


@dataclass(frozen=True)
class CurvatureEvaluation:
    model_id:str
    coordinates:tuple[float,float,float,float]
    christoffel:tuple
    riemann:tuple
    ricci:tuple
    ricci_scalar:float
    einstein:tuple
    metric_derivative_step:tuple[float,float,float,float]
    provenance:str
    model_revision:str

    def ricci_matrix(self)->np.ndarray:return np.asarray(self.ricci,dtype=float)
    def einstein_matrix(self)->np.ndarray:return np.asarray(self.einstein,dtype=float)
    def riemann_array(self)->np.ndarray:return np.asarray(self.riemann,dtype=float)
    def christoffel_array(self)->np.ndarray:return np.asarray(self.christoffel,dtype=float)

def _fd_step(model:MetricModel,coords:tuple[float,...],axis:int,relative_step:float)->float:
    base=max(1.0,abs(coords[axis]));h=relative_step*base
    if not math.isfinite(h) or h<=0:raise ValueError("finite-difference step must be positive and finite")
    # Shrink until a symmetric stencil lies inside the declared chart.
    for _ in range(40):
        plus=list(coords);minus=list(coords);plus[axis]+=h;minus[axis]-=h
        if model.domain.contains(plus) and model.domain.contains(minus):return h
        h*=0.5
    raise ValueError(f"Cannot construct symmetric derivative stencil on coordinate axis {axis}")

def metric_derivatives(model:MetricModel,coordinates:Sequence[float],*,relative_step:float=1e-5):
    coords=tuple(float(x) for x in coordinates);model.evaluate(coords)
    relative_step=float(relative_step)
    if not math.isfinite(relative_step) or relative_step<=0:raise ValueError("relative_step must be positive and finite")
    deriv=np.zeros((4,4,4),dtype=float);steps=[]
    for a in range(4):
        h=_fd_step(model,coords,a,relative_step);steps.append(h)
        qp=list(coords);qm=list(coords);qp[a]+=h;qm[a]-=h
        gp=model.evaluate(qp).matrix();gm=model.evaluate(qm).matrix()
        deriv[a]=(gp-gm)/(2*h)
    return deriv,tuple(steps)

def christoffel_symbols(model:MetricModel,coordinates:Sequence[float],*,relative_step:float=1e-5):
    metric=model.evaluate(coordinates);dg,steps=metric_derivatives(model,coordinates,relative_step=relative_step)
    inv=np.asarray(inverse_metric(metric));gamma=np.zeros((4,4,4),dtype=float)
    # Gamma^rho_mu_nu = 1/2 g^rho_sigma (d_mu g_sigma_nu + d_nu g_sigma_mu - d_sigma g_mu_nu)
    for rho in range(4):
        for mu in range(4):
            for nu in range(4):
                gamma[rho,mu,nu]=0.5*sum(inv[rho,sig]*(dg[mu,sig,nu]+dg[nu,sig,mu]-dg[sig,mu,nu]) for sig in range(4))
    return gamma,steps

def curvature(model:MetricModel,coordinates:Sequence[float],*,relative_step:float=2e-5)->CurvatureEvaluation:
    """Numerically evaluate connection and curvature in a declared coordinate chart.

    Uses centered finite differences for metric and connection derivatives.
    Results are numerical approximations and retain the finite-difference steps.
    """
    coords=tuple(float(x) for x in coordinates);metric=model.evaluate(coords)
    gamma,steps=christoffel_symbols(model,coords,relative_step=relative_step)
    dgamma=np.zeros((4,4,4,4),dtype=float) # derivative axis, rho, mu, nu
    for a in range(4):
        h=_fd_step(model,coords,a,relative_step)
        qp=list(coords);qm=list(coords);qp[a]+=h;qm[a]-=h
        gp,_=christoffel_symbols(model,qp,relative_step=relative_step)
        gm,_=christoffel_symbols(model,qm,relative_step=relative_step)
        dgamma[a]=(gp-gm)/(2*h)
    R=np.zeros((4,4,4,4),dtype=float) # R^rho_sigma_mu_nu
    for rho in range(4):
        for sig in range(4):
            for mu in range(4):
                for nu in range(4):
                    R[rho,sig,mu,nu]=dgamma[mu,rho,nu,sig]-dgamma[nu,rho,mu,sig]
                    R[rho,sig,mu,nu]+=sum(gamma[rho,mu,lam]*gamma[lam,nu,sig]-gamma[rho,nu,lam]*gamma[lam,mu,sig] for lam in range(4))
    ricci=np.zeros((4,4),dtype=float)
    for sig in range(4):
        for nu in range(4):
            ricci[sig,nu]=sum(R[rho,sig,rho,nu] for rho in range(4))
    inv=np.asarray(inverse_metric(metric));scalar=float(np.einsum("ij,ij->",inv,ricci))
    einstein=ricci-0.5*metric.matrix()*scalar
    return CurvatureEvaluation(model.model_id,coords,
        tuple(tuple(tuple(float(x) for x in row) for row in plane) for plane in gamma),
        tuple(tuple(tuple(tuple(float(x) for x in line) for line in block) for block in slab) for slab in R),
        tuple(tuple(float(x) for x in row) for row in ricci),scalar,
        tuple(tuple(float(x) for x in row) for row in einstein),steps,
        model.provenance,model.model_revision)

def curvature_residuals(result:CurvatureEvaluation)->dict[str,float]:
    """Independent algebraic consistency residuals for a numerical curvature result."""
    R=result.riemann_array();ric=result.ricci_matrix();G=result.einstein_matrix()
    antisym=float(np.max(np.abs(R + np.swapaxes(R,2,3))))
    ricci_sym=float(np.max(np.abs(ric-ric.T)))
    return {"riemann_last_pair_antisymmetry":antisym,"ricci_symmetry":ricci_sym,
            "einstein_symmetry":float(np.max(np.abs(G-G.T)))}


# SI constants used by the Einstein equation. c is exact by SI definition;
# G carries measurement uncertainty and should ultimately be sourced from MPR.
SPEED_OF_LIGHT=299792458.0
NEWTON_G=6.67430e-11

@dataclass(frozen=True)
class StressEnergyEvaluation:
    model_id:str
    coordinates:tuple[float,float,float,float]
    covariant:tuple[tuple[float,...],...]
    orthonormal:tuple[tuple[float,...],...]
    energy_density_j_m3:float
    principal_pressures_pa:tuple[float,float,float]
    radial_nec_j_m3:float
    tangential_nec_j_m3:tuple[float,float]
    einstein_coupling_si:float
    provenance:str
    model_revision:str
    numerical_note:str
    def covariant_matrix(self)->np.ndarray:return np.asarray(self.covariant,dtype=float)
    def orthonormal_matrix(self)->np.ndarray:return np.asarray(self.orthonormal,dtype=float)

def _diagonal_orthonormal_coframe(metric:MetricEvaluation)->np.ndarray:
    g=metric.matrix()
    if not np.allclose(g,np.diag(np.diag(g)),rtol=1e-10,atol=1e-12):
        raise ValueError("automatic orthonormal-frame conversion currently requires a diagonal metric")
    diag=np.diag(g)
    if not (diag[0]<0 and np.all(diag[1:]>0)):
        raise ValueError("diagonal metric does not have expected (-,+,+,+) coordinate ordering")
    # theta^hat{a}_mu with eta_ab theta^a_mu theta^b_nu = g_mu_nu
    return np.diag(np.sqrt(np.abs(diag)))

def stress_energy_from_geometry(model:MetricModel,coordinates:Sequence[float],*,relative_step:float=2e-5,
                                c:float=SPEED_OF_LIGHT,G:float=NEWTON_G)->StressEnergyEvaluation:
    """Infer the effective T_{mu nu} required by a metric through Einstein's equation.

    Coordinates use x^0=ct, so curvature has inverse-length-squared units.
    T_{mu nu} = c^4/(8 pi G) G_{mu nu}, yielding SI energy density / pressure units.
    This is a required effective source for the specified geometry, not evidence
    that such matter can physically be constructed.
    """
    c=float(c);G=float(G)
    if not math.isfinite(c) or c<=0 or not math.isfinite(G) or G<=0:
        raise ValueError("c and G must be finite and positive")
    curv=curvature(model,coordinates,relative_step=relative_step)
    metric=model.evaluate(coordinates);coupling=c**4/(8*math.pi*G)
    T=coupling*curv.einstein_matrix()
    coframe=_diagonal_orthonormal_coframe(metric)
    inv_coframe=np.linalg.inv(coframe)
    # Tensor components in orthonormal basis: T_hat = e^mu_hat a e^nu_hat b T_mu nu.
    That=inv_coframe@T@inv_coframe.T
    rho=float(That[0,0]);pressures=tuple(float(That[i,i]) for i in (1,2,3))
    radial=rho+pressures[0];tang=(rho+pressures[1],rho+pressures[2])
    return StressEnergyEvaluation(model.model_id,tuple(float(x) for x in coordinates),
        tuple(tuple(float(x) for x in row) for row in T),
        tuple(tuple(float(x) for x in row) for row in That),rho,pressures,radial,tang,coupling,
        model.provenance,model.model_revision,
        f"Numerical curvature via centered finite differences; relative step {relative_step:g}.")

@dataclass(frozen=True)
class EnergyConditionAssessment:
    radial_nec_satisfied:bool
    tangential_nec_satisfied:tuple[bool,bool]
    minimum_nec_j_m3:float
    interpretation:str

def assess_nec(stress:StressEnergyEvaluation,*,absolute_tolerance_j_m3:float=0.0)->EnergyConditionAssessment:
    tol=float(absolute_tolerance_j_m3)
    if not math.isfinite(tol) or tol<0:raise ValueError("NEC tolerance must be finite and nonnegative")
    values=(stress.radial_nec_j_m3,*stress.tangential_nec_j_m3)
    return EnergyConditionAssessment(values[0]>=-tol,(values[1]>=-tol,values[2]>=-tol),min(values),
        "NEC violation is a property of the effective source required by this metric/model; it is not evidence of a realizable material.")

def morris_thorne_analytic_zero_redshift(*,throat_radius:float,radius:float,c:float=SPEED_OF_LIGHT,G:float=NEWTON_G):
    """Independent analytic reference for Phi=0, b=r0^2/r.

    In an orthonormal frame with x^0=ct:
      rho_E = c^4/(8 pi G) b'(r)/r^2
      p_r   = -c^4/(8 pi G) b(r)/r^3
      p_t   = c^4/(16 pi G) [b(r)-r b'(r)]/r^3
    Values are J/m^3 (numerically Pa for pressures).
    """
    r0=float(throat_radius);r=float(radius);c=float(c);G=float(G)
    if not all(math.isfinite(x) for x in (r0,r,c,G)) or r0<=0 or r<=r0 or c<=0 or G<=0:
        raise ValueError("analytic reference requires finite positive constants and r > r0")
    b=r0*r0/r;bp=-r0*r0/(r*r);k=c**4/(8*math.pi*G)
    rho=k*bp/(r*r);pr=-k*b/(r**3);pt=0.5*k*(b-r*bp)/(r**3)
    return {"energy_density_j_m3":rho,"radial_pressure_pa":pr,"tangential_pressure_pa":pt,
            "radial_nec_j_m3":rho+pr,"tangential_nec_j_m3":rho+pt}


@dataclass(frozen=True)
class RadialProfile:
    radii_m:tuple[float,...]
    energy_density_j_m3:tuple[float,...]
    radial_pressure_pa:tuple[float,...]
    tangential_pressure_pa:tuple[float,...]
    radial_nec_j_m3:tuple[float,...]
    provenance:str

def morris_thorne_radial_profile(*,throat_radius:float,radii:Sequence[float],
                                 relative_step:float=5e-5)->RadialProfile:
    model=morris_thorne_metric(throat_radius=throat_radius)
    rs=tuple(float(x) for x in radii)
    if not rs:raise ValueError("radial profile requires at least one radius")
    rho=[];pr=[];pt=[];nec=[]
    for r in rs:
        t=stress_energy_from_geometry(model,(0.0,r,math.pi/2,math.pi),relative_step=relative_step)
        rho.append(t.energy_density_j_m3);pr.append(t.principal_pressures_pa[0])
        pt.append(t.principal_pressures_pa[1]);nec.append(t.radial_nec_j_m3)
    return RadialProfile(rs,tuple(rho),tuple(pr),tuple(pt),tuple(nec),
        "Numerical Morris-Thorne effective stress-energy radial profile; SIMULATION/MODEL output, not measurement.")


@dataclass(frozen=True)
class ConvergenceResult:
    model_id:str
    coordinates:tuple[float,float,float,float]
    relative_steps:tuple[float,...]
    ricci_scalars:tuple[float,...]
    einstein_norms:tuple[float,...]
    successive_scalar_deltas:tuple[float,...]
    converged:bool
    tolerance:float
    provenance:str

def curvature_convergence(model:MetricModel,coordinates:Sequence[float],
                          *,relative_steps:Sequence[float]=(2e-4,1e-4,5e-5),
                          tolerance:float=5e-4)->ConvergenceResult:
    steps=tuple(float(x) for x in relative_steps)
    if len(steps)<3 or any((not math.isfinite(x) or x<=0) for x in steps):
        raise ValueError("convergence study requires at least three positive finite relative steps")
    if any(steps[i+1]>=steps[i] for i in range(len(steps)-1)):
        raise ValueError("relative steps must be strictly decreasing")
    tol=float(tolerance)
    if not math.isfinite(tol) or tol<=0:raise ValueError("convergence tolerance must be positive and finite")
    vals=[];norms=[]
    for h in steps:
        c=curvature(model,coordinates,relative_step=h);vals.append(c.ricci_scalar)
        norms.append(float(np.linalg.norm(c.einstein_matrix())))
    deltas=tuple(abs(vals[i+1]-vals[i]) for i in range(len(vals)-1))
    scale=max(1.0,abs(vals[-1]),norms[-1])
    converged=(deltas[-1]/scale)<=tol
    return ConvergenceResult(model.model_id,tuple(float(x) for x in coordinates),steps,tuple(vals),tuple(norms),
                             deltas,converged,tol,
                             "Centered finite-difference refinement study; numerical diagnostic, not physical uncertainty.")

@dataclass(frozen=True)
class GeometryGuardianContract:
    schema:str
    model_id:str
    model_revision:str
    coordinates:tuple[float,float,float,float]
    provenance:str
    data_origin:str
    ricci_scalar_m2_inv:float
    energy_density_j_m3:float
    principal_pressures_pa:tuple[float,float,float]
    radial_nec_j_m3:float
    radial_nec_satisfied:bool
    convergence_passed:bool
    numerical_method:str
    authority:str

def geometry_guardian_contract(model:MetricModel,coordinates:Sequence[float],*,relative_step:float=5e-5)->GeometryGuardianContract:
    c=curvature(model,coordinates,relative_step=relative_step)
    t=stress_energy_from_geometry(model,coordinates,relative_step=relative_step)
    n=assess_nec(t)
    # Keep refinement centered around the requested operational step.
    conv=curvature_convergence(model,coordinates,relative_steps=(relative_step*4,relative_step*2,relative_step))
    return GeometryGuardianContract("JOE-GUARDIAN-GEOMETRY/1",model.model_id,model.model_revision,
        tuple(float(x) for x in coordinates),model.provenance,"SIMULATION/MODEL",
        c.ricci_scalar,t.energy_density_j_m3,t.principal_pressures_pa,t.radial_nec_j_m3,
        n.radial_nec_satisfied,conv.converged,t.numerical_note,
        "READ_ONLY_ADVISORY; no control or safety authority")

@dataclass(frozen=True)
class GeometryReleaseReadiness:
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    notes:tuple[str,...]

def geometry_release_readiness()->GeometryReleaseReadiness:
    checks=[];failures=[];notes=[]
    try:
        flat=minkowski_metric();fc=curvature(flat,(0,0,0,0))
        if np.max(np.abs(fc.einstein_matrix()))<1e-10:checks.append("Minkowski Einstein tensor zero reference passed")
        else:failures.append("Minkowski curvature reference failed")
        r0=2.0;r=5.0;model=morris_thorne_metric(throat_radius=r0)
        numeric=stress_energy_from_geometry(model,(0,r,math.pi/2,math.pi),relative_step=5e-5)
        analytic=morris_thorne_analytic_zero_redshift(throat_radius=r0,radius=r)
        rel=abs(numeric.radial_nec_j_m3-analytic["radial_nec_j_m3"])/max(1.0,abs(analytic["radial_nec_j_m3"]))
        if rel<5e-5:checks.append("Morris-Thorne numerical/analytic radial NEC cross-check passed")
        else:failures.append(f"Morris-Thorne analytic cross-check relative error {rel:.3e}")
        residual=curvature_residuals(curvature(model,(0,r,math.pi/2,math.pi),relative_step=5e-5))
        if max(residual.values())<2e-7:checks.append("curvature algebraic residual checks passed")
        else:failures.append(f"curvature residual too large: {max(residual.values()):.3e}")
        conv=curvature_convergence(model,(0,r,math.pi/2,math.pi))
        if conv.converged:checks.append("finite-difference refinement study passed")
        else:failures.append("finite-difference refinement study did not converge")
        gc=geometry_guardian_contract(model,(0,r,math.pi/2,math.pi))
        if gc.schema=="JOE-GUARDIAN-GEOMETRY/1" and gc.data_origin=="SIMULATION/MODEL":
            checks.append("Guardian geometry contract labels model origin and advisory authority")
        else:failures.append("Guardian geometry contract invalid")
    except Exception as exc:failures.append(f"geometry release-readiness exception: {type(exc).__name__}: {exc}")
    notes.append("Effective stress-energy is a model requirement inferred from Einstein's equation, not evidence of realizable exotic matter.")
    notes.append("Numerical convergence diagnostics characterize discretization behavior, not experimental uncertainty.")
    return GeometryReleaseReadiness(not failures,tuple(checks),tuple(failures),tuple(notes))
