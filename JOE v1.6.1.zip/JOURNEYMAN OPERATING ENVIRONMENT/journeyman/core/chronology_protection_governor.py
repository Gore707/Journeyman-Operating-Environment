"""Integrated chronology/backreaction research protection governor.

Software/SIL scientific safety logic only. It combines independent model-health
indicators and fails closed when models disagree, age out, exceed uncertainty
budgets, or approach configured research envelopes. It does NOT detect Hawking
chronology protection, prove backreaction, or implement physical BUS-SAFE.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import IntEnum
import math,time
from typing import Iterable

class GovernorDisposition(IntEnum):
    NOMINAL=0; CAUTION=10; HOLD=20; ABORT=30; TRIP=40

@dataclass(frozen=True)
class ProtectionPolicy:
    disagreement_z_caution:float=2.0
    disagreement_z_hold:float=3.0
    uncertainty_fraction_hold:float=.25
    max_model_age_s:float=.25
    max_abs_rate:float|None=None
    max_abs_acceleration:float|None=None
    def __post_init__(self):
        vals=(self.disagreement_z_caution,self.disagreement_z_hold,self.uncertainty_fraction_hold,self.max_model_age_s)
        if any(not math.isfinite(x) or x<=0 for x in vals):raise ValueError("positive finite policy values required")
        if self.disagreement_z_hold<self.disagreement_z_caution:raise ValueError("disagreement thresholds must be monotonic")

@dataclass(frozen=True)
class ModelEstimate:
    model_id:str; value:float; uncertainty:float; unit:str; timestamp_s:float; provenance:str

@dataclass(frozen=True)
class ProtectionIndicator:
    indicator_id:str; disposition:GovernorDisposition; reason:str; provenance:str

@dataclass(frozen=True)
class GovernorAssessment:
    disposition:GovernorDisposition; indicators:tuple[ProtectionIndicator,...]; may_progress:bool
    epistemic_status:str; physical_chronology_protection_detected:bool=False


def normalized_model_disagreement(a:ModelEstimate,b:ModelEstimate)->float:
    if a.unit!=b.unit:raise ValueError("model units differ")
    if any(not math.isfinite(x) for x in (a.value,b.value,a.uncertainty,b.uncertainty)):raise ValueError("finite model estimates required")
    if a.uncertainty<0 or b.uncertainty<0:raise ValueError("uncertainty cannot be negative")
    denom=math.hypot(a.uncertainty,b.uncertainty)
    if denom==0:return 0.0 if a.value==b.value else math.inf
    return abs(a.value-b.value)/denom

class ChronologyProtectionGovernor:
    def __init__(self,policy:ProtectionPolicy=ProtectionPolicy()):self.policy=policy
    def assess(self,models:Iterable[ModelEstimate]=(),*,now_s:float|None=None,envelope_scale:float|None=None,
               value:float|None=None,uncertainty:float|None=None,rate:float|None=None,acceleration:float|None=None,
               hardware_trip_asserted:bool=False)->GovernorAssessment:
        now=time.time() if now_s is None else float(now_s);ms=tuple(models);ind=[]
        if hardware_trip_asserted:
            ind.append(ProtectionIndicator("hardware-trip",GovernorDisposition.TRIP,"qualified external hardware trip asserted; software may not clear it","HARDWARE/INTERFACE: external trip input"))
        for m in ms:
            if now-m.timestamp_s>self.policy.max_model_age_s:
                ind.append(ProtectionIndicator("stale-model:"+m.model_id,GovernorDisposition.HOLD,"model estimate is older than configured freshness limit",m.provenance))
        for i,a in enumerate(ms):
            for b in ms[i+1:]:
                try:z=normalized_model_disagreement(a,b)
                except ValueError as exc:
                    ind.append(ProtectionIndicator(f"model-disagreement:{a.model_id}:{b.model_id}",GovernorDisposition.HOLD,str(exc),"SOFTWARE: cross-model consistency"));continue
                if z>=self.policy.disagreement_z_hold:
                    ind.append(ProtectionIndicator(f"model-disagreement:{a.model_id}:{b.model_id}",GovernorDisposition.HOLD,f"normalized model disagreement z={z:.6g} exceeds HOLD threshold", "SOFTWARE: cross-model consistency"))
                elif z>=self.policy.disagreement_z_caution:
                    ind.append(ProtectionIndicator(f"model-disagreement:{a.model_id}:{b.model_id}",GovernorDisposition.CAUTION,f"normalized model disagreement z={z:.6g} exceeds CAUTION threshold","SOFTWARE: cross-model consistency"))
        if envelope_scale is not None and value is not None and uncertainty is not None:
            if not all(math.isfinite(x) for x in (envelope_scale,value,uncertainty)) or envelope_scale<=0 or uncertainty<0:
                ind.append(ProtectionIndicator("uncertainty-budget",GovernorDisposition.HOLD,"invalid uncertainty/envelope inputs","SOFTWARE: uncertainty interlock"))
            elif uncertainty/envelope_scale>=self.policy.uncertainty_fraction_hold:
                ind.append(ProtectionIndicator("uncertainty-budget",GovernorDisposition.HOLD,"uncertainty consumes configured fraction of the research envelope","SOFTWARE: uncertainty interlock"))
            elif abs(value)+uncertainty>=envelope_scale:
                ind.append(ProtectionIndicator("uncertainty-envelope",GovernorDisposition.ABORT,"represented uncertainty interval reaches/exceeds research envelope","SOFTWARE: uncertainty interlock"))
        if rate is not None and self.policy.max_abs_rate is not None and abs(rate)>=self.policy.max_abs_rate:
            ind.append(ProtectionIndicator("rate-limit",GovernorDisposition.ABORT,"configured model-conditional rate limit reached","SOFTWARE: rate interlock"))
        if acceleration is not None and self.policy.max_abs_acceleration is not None and abs(acceleration)>=self.policy.max_abs_acceleration:
            ind.append(ProtectionIndicator("acceleration-limit",GovernorDisposition.ABORT,"configured model-conditional acceleration limit reached","SOFTWARE: acceleration interlock"))
        disp=max((x.disposition for x in ind),default=GovernorDisposition.NOMINAL)
        return GovernorAssessment(disp,tuple(ind),disp<GovernorDisposition.HOLD,"CONJECTURAL_UNRESOLVED_PHYSICS",False)

def guardian_chronology_protection_contract(a:GovernorAssessment)->dict:
    return {"schema":"JOE-GUARDIAN-CHRONOLOGY-PROTECTION/1","authority":"READ_ONLY_ADVISORY","may_command":False,"may_override":False,
            "disposition":a.disposition.name,"may_progress":a.may_progress,"epistemic_status":a.epistemic_status,
            "physical_chronology_protection_detected":False,
            "indicators":[{"id":x.indicator_id,"disposition":x.disposition.name,"reason":x.reason,"provenance":x.provenance} for x in a.indicators],
            "truth_boundary":"Indicators are model-health/safety signals, not detections of Hawking chronology protection, physical CTC formation, or physical backreaction."}

def fault_injection_campaign()->dict:
    p=ProtectionPolicy(max_abs_rate=5,max_abs_acceleration=20,max_model_age_s=.1)
    g=ChronologyProtectionGovernor(p);now=10.0
    cases=[]
    cases.append(("stale",g.assess((ModelEstimate("A",0,.1,"1",9,"SIMULATION: injected stale model"),),now_s=now).disposition>=GovernorDisposition.HOLD))
    cases.append(("disagreement",g.assess((ModelEstimate("A",0,.1,"1",10,"SIMULATION"),ModelEstimate("B",1,.1,"1",10,"SIMULATION")),now_s=now).disposition>=GovernorDisposition.HOLD))
    cases.append(("uncertainty",g.assess(now_s=now,envelope_scale=1,value=.9,uncertainty=.2).disposition>=GovernorDisposition.HOLD))
    cases.append(("rate",g.assess(now_s=now,rate=6).disposition==GovernorDisposition.ABORT))
    cases.append(("acceleration",g.assess(now_s=now,acceleration=21).disposition==GovernorDisposition.ABORT))
    cases.append(("external-trip",g.assess(now_s=now,hardware_trip_asserted=True).disposition==GovernorDisposition.TRIP))
    return {"schema":"JOE-CHRONOLOGY-PROTECTION-FAULT-CAMPAIGN/1","passed":all(x[1] for x in cases),"cases":tuple(cases),"origin":"SIMULATION","physical_hardware_qualified":False}

def chronology_protection_release_readiness()->dict:
    failures=[];checks=[]
    try:
        c=fault_injection_campaign()
        if c["passed"]:checks.append("deterministic fault-injection campaign passed")
        a=ChronologyProtectionGovernor().assess(now_s=0)
        if a.disposition==GovernorDisposition.NOMINAL:checks.append("nominal governor assessment passed")
        gc=guardian_chronology_protection_contract(a)
        if gc["authority"]=="READ_ONLY_ADVISORY" and not gc["physical_chronology_protection_detected"]:checks.append("Guardian authority/truth boundary passed")
    except Exception as exc:failures.append(f"{type(exc).__name__}: {exc}")
    return {"passed":not failures and len(checks)==3,"checks":tuple(checks),"failures":tuple(failures),"notes":(
        "Hawking chronology protection remains conjectural/unresolved physics; no detection probability is assigned.",
        "Fault injection is SIMULATION qualification, not physical HIL.",
        "External BUS-SAFE remains final authority and is not implemented by this governor.")}
