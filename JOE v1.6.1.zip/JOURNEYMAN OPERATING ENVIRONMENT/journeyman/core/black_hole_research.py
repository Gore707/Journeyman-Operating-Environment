"""JOE black-hole and cross-model research extension.

Established GR reference geometries and diagnostics. No black-hole transit,
wormhole conversion, chronology violation, or new-physics claim is inferred.
Geometrized units G=c=1 are used unless an SI conversion is explicitly made.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np
from .geometry import CoordinateDomain, MetricModel

@dataclass(frozen=True)
class BlackHoleHorizons:
    model:str
    outer:float|None
    inner:float|None
    extremal:bool
    naked_singularity:bool
    provenance:str

@dataclass(frozen=True)
class KerrErgosphere:
    theta:float
    outer_static_limit:float
    event_horizon:float
    provenance:str

@dataclass(frozen=True)
class CrossModelRecord:
    quantity:str
    model_a:str
    model_b:str
    value_a:float
    value_b:float
    sigma_a:float
    sigma_b:float
    z_score:float
    status:str
    message:str


def schwarzschild_metric(*, mass:float, model_revision:str="1")->MetricModel:
    M=float(mass)
    if not math.isfinite(M) or M<=0: raise ValueError("mass must be finite and positive in geometrized units")
    domain=CoordinateDomain(("ct","r","theta","phi"),(None,2*M,0.0,0.0),(None,None,math.pi,2*math.pi),(True,False,False,True),(True,True,False,False))
    def ev(q):
        _,r,th,_=q; f=1-2*M/r
        return np.diag([-f,1/f,r*r,r*r*math.sin(th)**2])
    return MetricModel("geometry.schwarzschild",domain,ev,provenance="Schwarzschild exterior vacuum solution; geometrized units G=c=1.",model_revision=model_revision)


def reissner_nordstrom_metric(*, mass:float, charge_length:float, model_revision:str="1")->MetricModel:
    M,Q=float(mass),float(charge_length)
    if not all(math.isfinite(x) for x in (M,Q)) or M<=0: raise ValueError("finite M>0 and charge_length required")
    disc=M*M-Q*Q
    rplus=M+math.sqrt(disc) if disc>=0 else 0.0
    lower=max(rplus,0.0)
    domain=CoordinateDomain(("ct","r","theta","phi"),(None,lower,0.0,0.0),(None,None,math.pi,2*math.pi),(True,False,False,True),(True,True,False,False))
    def ev(q):
        _,r,th,_=q; f=1-2*M/r+Q*Q/(r*r)
        if f<=0: raise ValueError("reference chart restricted to exterior static region")
        return np.diag([-f,1/f,r*r,r*r*math.sin(th)**2])
    return MetricModel("geometry.reissner-nordstrom",domain,ev,provenance="Reissner-Nordstrom electrovac reference; geometrized units G=c=1; charge represented by geometric length.",model_revision=model_revision)


def kerr_metric(*, mass:float, spin:float, model_revision:str="1")->MetricModel:
    M,a=float(mass),float(spin)
    if not all(math.isfinite(x) for x in (M,a)) or M<=0 or abs(a)>M: raise ValueError("Kerr reference requires finite M>0 and |a|<=M")
    rp=M+math.sqrt(max(0.0,M*M-a*a))
    domain=CoordinateDomain(("ct","r","theta","phi"),(None,rp,0.0,0.0),(None,None,math.pi,2*math.pi),(True,False,False,True),(True,True,False,False))
    def ev(q):
        _,r,th,_=q; s=math.sin(th); c=math.cos(th); sig=r*r+a*a*c*c; delta=r*r-2*M*r+a*a
        g=np.zeros((4,4)); g[0,0]=-(1-2*M*r/sig); g[0,3]=g[3,0]=-2*M*a*r*s*s/sig
        g[1,1]=sig/delta; g[2,2]=sig; g[3,3]=(r*r+a*a+2*M*a*a*r*s*s/sig)*s*s
        return g
    return MetricModel("geometry.kerr",domain,ev,provenance="Kerr vacuum metric in Boyer-Lindquist coordinates; exterior r>r+; geometrized units G=c=1.",model_revision=model_revision)


def kerr_newman_metric(*, mass:float, spin:float, charge_length:float, model_revision:str="1")->MetricModel:
    M,a,Q=map(float,(mass,spin,charge_length)); disc=M*M-a*a-Q*Q
    if not all(math.isfinite(x) for x in (M,a,Q)) or M<=0 or disc<0: raise ValueError("Kerr-Newman reference requires M>0 and M^2>=a^2+Q^2")
    rp=M+math.sqrt(disc)
    domain=CoordinateDomain(("ct","r","theta","phi"),(None,rp,0.0,0.0),(None,None,math.pi,2*math.pi),(True,False,False,True),(True,True,False,False))
    def ev(q):
        _,r,th,_=q; s=math.sin(th); c=math.cos(th); sig=r*r+a*a*c*c; delta=r*r-2*M*r+a*a+Q*Q; A=2*M*r-Q*Q
        g=np.zeros((4,4)); g[0,0]=-(1-A/sig); g[0,3]=g[3,0]=-a*A*s*s/sig
        g[1,1]=sig/delta; g[2,2]=sig; g[3,3]=(r*r+a*a+a*a*A*s*s/sig)*s*s
        return g
    return MetricModel("geometry.kerr-newman",domain,ev,provenance="Kerr-Newman electrovac metric in Boyer-Lindquist coordinates; exterior chart; geometrized units G=c=1.",model_revision=model_revision)


def horizons(*, model:str, mass:float, spin:float=0.0, charge_length:float=0.0)->BlackHoleHorizons:
    M,a,Q=map(float,(mass,spin,charge_length)); disc=M*M-a*a-Q*Q
    if not all(math.isfinite(x) for x in (M,a,Q)) or M<=0: raise ValueError("finite M>0 required")
    if disc<0: return BlackHoleHorizons(model,None,None,False,True,"Classical GR horizon discriminant M^2-a^2-Q^2<0; no horizon in this idealized family.")
    root=math.sqrt(disc)
    return BlackHoleHorizons(model,M+root,M-root,math.isclose(disc,0.0,abs_tol=1e-14*max(1.0,M*M)),False,"Classical stationary black-hole reference in geometrized units.")


def kerr_ergosphere(*,mass:float,spin:float,theta:float)->KerrErgosphere:
    M,a,th=map(float,(mass,spin,theta)); h=horizons(model="Kerr",mass=M,spin=a)
    if h.outer is None or not 0<=th<=math.pi: raise ValueError("valid Kerr black hole and theta in [0,pi] required")
    rs=M+math.sqrt(max(0.0,M*M-a*a*math.cos(th)**2))
    return KerrErgosphere(th,rs,h.outer,"Outer Kerr static limit in Boyer-Lindquist coordinates; geometrized units.")


def schwarzschild_kretschmann(*,mass:float,radius:float)->float:
    M,r=float(mass),float(radius)
    if not all(math.isfinite(x) for x in (M,r)) or M<=0 or r<=0: raise ValueError("positive finite mass/radius required")
    return 48*M*M/(r**6)


def schwarzschild_redshift_factor(*,mass:float,radius:float)->float:
    M,r=float(mass),float(radius)
    if r<=2*M: raise ValueError("static Schwarzschild observer requires r>2M")
    return math.sqrt(1-2*M/r)


def cross_model_compare(*,quantity:str,model_a:str,value_a:float,sigma_a:float,model_b:str,value_b:float,sigma_b:float,warning_sigma:float=5.0)->CrossModelRecord:
    vals=tuple(map(float,(value_a,sigma_a,value_b,sigma_b,warning_sigma)))
    if not all(math.isfinite(x) for x in vals) or sigma_a<0 or sigma_b<0 or warning_sigma<=0: raise ValueError("finite values, nonnegative uncertainties, positive warning_sigma required")
    u=math.hypot(sigma_a,sigma_b); d=abs(value_a-value_b); z=d/u if u>0 else (0.0 if d==0 else math.inf)
    status="INVESTIGATE" if z>warning_sigma else "CONSISTENT_WITH_DECLARED_UNCERTAINTY"
    return CrossModelRecord(quantity,model_a,model_b,value_a,value_b,sigma_a,sigma_b,z,status,"Cross-model disagreement is diagnostic only; it does not establish new physics." if status=="INVESTIGATE" else "Models agree within the selected normalized-disagreement threshold.")


def guardian_contract(record:CrossModelRecord|None=None)->dict:
    return {"schema":"JOE-GUARDIAN-BLACK-HOLE-CROSS-MODEL/1","status":record.status if record else "READY","facts":({"quantity":record.quantity,"models":[record.model_a,record.model_b],"z_score":record.z_score} if record else {}),"authority":"READ_ONLY_ADVISORY","truth_boundary":"Black-hole calculations are established-GR/model diagnostics. Numerical anomalies or cross-model disagreement are not evidence of wormhole transit, CTCs, new physics, or safe horizon crossing."}
