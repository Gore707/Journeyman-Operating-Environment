"""Scientific Data & Provenance — DATA-001A immutable record/manifest core."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Iterable
import hashlib, json, math, os, tempfile, time
from uuid import uuid4

class ScientificDataOrigin(str,Enum):
    SOFTWARE="SOFTWARE"
    HOST="HOST"
    IMPORTED="IMPORTED"
    SIMULATION="SIMULATION"
    HARDWARE="HARDWARE"

class RecordQuality(str,Enum):
    GOOD="GOOD"
    DEGRADED="DEGRADED"
    STALE="STALE"
    UNAVAILABLE="UNAVAILABLE"
    INVALID="INVALID"

@dataclass(frozen=True)
class ScientificRecord:
    record_id:str
    variable:str
    value:float|int|str|bool|None
    unit:str
    standard_uncertainty:float|None
    timestamp_s:float
    source_module:str
    origin:ScientificDataOrigin
    provenance:str
    quality:RecordQuality=RecordQuality.GOOD
    frame_id:str|None=None
    epoch_id:str|None=None
    object_id:str|None=None
    parameter_revision:str|None=None
    algorithm_revision:str|None=None
    epistemic_status:str|None=None
    def __post_init__(self):
        if not all((self.record_id.strip(),self.variable.strip(),self.unit.strip(),self.source_module.strip(),self.provenance.strip())):
            raise ValueError("complete scientific record identity/units/source/provenance required")
        if not math.isfinite(self.timestamp_s):raise ValueError("finite timestamp required")
        if isinstance(self.value,float) and not math.isfinite(self.value):raise ValueError("finite numeric value required")
        if self.standard_uncertainty is not None and (not math.isfinite(self.standard_uncertainty) or self.standard_uncertainty<0):
            raise ValueError("uncertainty must be finite and nonnegative")

@dataclass(frozen=True)
class DataArtifact:
    artifact_id:str
    relative_path:str
    sha256:str
    byte_count:int
    media_type:str
    provenance:str
    def __post_init__(self):
        if not all((self.artifact_id.strip(),self.relative_path.strip(),self.media_type.strip(),self.provenance.strip())):
            raise ValueError("complete artifact metadata required")
        if len(self.sha256)!=64 or any(c not in "0123456789abcdef" for c in self.sha256.lower()):
            raise ValueError("artifact SHA-256 must be 64 hexadecimal characters")
        if self.byte_count<0:raise ValueError("artifact byte count cannot be negative")

@dataclass(frozen=True)
class RunDataManifest:
    schema:str
    run_id:str
    created_at_s:float
    project_id:str|None
    parameter_revision:str|None
    configuration_revision:str|None
    software_build:str
    records_sha256:str
    record_count:int
    artifacts:tuple[DataArtifact,...]
    provenance:str
    previous_manifest_sha256:str|None=None
    def __post_init__(self):
        if self.schema!="JOE-SCIENTIFIC-DATA-MANIFEST/1":raise ValueError("unsupported manifest schema")
        if not self.run_id.strip() or not self.software_build.strip() or not self.provenance.strip():raise ValueError("run/build/provenance required")
        if not math.isfinite(self.created_at_s):raise ValueError("finite manifest timestamp required")
        if self.record_count<0:raise ValueError("record count cannot be negative")
        for h in (self.records_sha256,self.previous_manifest_sha256):
            if h is not None and (len(h)!=64 or any(c not in "0123456789abcdef" for c in h.lower())):
                raise ValueError("manifest hashes must be SHA-256")

def sha256_bytes(data:bytes)->str:return hashlib.sha256(data).hexdigest()
def sha256_file(path:str|Path)->str:
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
    return h.hexdigest()

def canonical_record_bytes(records:Iterable[ScientificRecord])->bytes:
    rows=[]
    for r in records:
        d=asdict(r);d["origin"]=r.origin.value;d["quality"]=r.quality.value;rows.append(d)
    return (json.dumps(rows,sort_keys=True,separators=(",",":"),ensure_ascii=False)+"\n").encode("utf-8")

def write_records_jsonl(records:Iterable[ScientificRecord],path:str|Path)->tuple[int,str]:
    rows=tuple(records);target=Path(path);target.parent.mkdir(parents=True,exist_ok=True)
    with target.open("w",encoding="utf-8",newline="\n") as f:
        for r in rows:
            d=asdict(r);d["origin"]=r.origin.value;d["quality"]=r.quality.value
            f.write(json.dumps(d,sort_keys=True,separators=(",",":"),ensure_ascii=False)+"\n")
    return len(rows),sha256_file(target)

def register_artifact(path:str|Path,*,relative_path:str|None=None,media_type:str="application/octet-stream",
                      provenance:str)->DataArtifact:
    p=Path(path)
    if not p.is_file():raise FileNotFoundError(p)
    return DataArtifact(str(uuid4()),relative_path or p.name,sha256_file(p),p.stat().st_size,media_type,provenance)

def verify_artifact(artifact:DataArtifact,path:str|Path)->bool:
    p=Path(path)
    return p.is_file() and p.stat().st_size==artifact.byte_count and sha256_file(p)==artifact.sha256

def create_manifest(*,run_id:str,records:Iterable[ScientificRecord],software_build:str,artifacts:Iterable[DataArtifact]=(),
                    project_id:str|None=None,parameter_revision:str|None=None,configuration_revision:str|None=None,
                    provenance:str,created_at_s:float|None=None,previous_manifest_sha256:str|None=None)->RunDataManifest:
    rows=tuple(records)
    return RunDataManifest("JOE-SCIENTIFIC-DATA-MANIFEST/1",run_id,time.time() if created_at_s is None else created_at_s,
        project_id,parameter_revision,configuration_revision,software_build,sha256_bytes(canonical_record_bytes(rows)),
        len(rows),tuple(artifacts),provenance,previous_manifest_sha256)

def manifest_dict(m:RunDataManifest)->dict[str,Any]:
    d=asdict(m);return d

def manifest_bytes(m:RunDataManifest)->bytes:
    return (json.dumps(manifest_dict(m),sort_keys=True,separators=(",",":"),ensure_ascii=False)+"\n").encode("utf-8")

def manifest_sha256(m:RunDataManifest)->str:return sha256_bytes(manifest_bytes(m))

def write_manifest(m:RunDataManifest,path:str|Path)->str:
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(manifest_bytes(m));return sha256_file(p)

def verify_manifest_records(m:RunDataManifest,records:Iterable[ScientificRecord])->bool:
    rows=tuple(records)
    return len(rows)==m.record_count and sha256_bytes(canonical_record_bytes(rows))==m.records_sha256

class ImmutableRunDataStore:
    """Create-only scientific run store. Existing run directories are never overwritten."""
    def __init__(self,root:str|Path):self.root=Path(root)
    def create_run(self,manifest:RunDataManifest,records:Iterable[ScientificRecord])->Path:
        rows=tuple(records)
        if not verify_manifest_records(manifest,rows):raise ValueError("manifest does not match records")
        self.root.mkdir(parents=True,exist_ok=True);target=self.root/manifest.run_id
        if target.exists():raise FileExistsError(f"immutable run already exists: {manifest.run_id}")
        temp=Path(tempfile.mkdtemp(prefix=".joe-run-",dir=self.root))
        try:
            write_records_jsonl(rows,temp/"records.jsonl");write_manifest(manifest,temp/"manifest.json")
            os.replace(temp,target)
        except Exception:
            shutil_rmtree(temp);raise
        return target
    def verify_run(self,run_id:str)->tuple[bool,tuple[str,...]]:
        p=self.root/run_id;fail=[]
        try:
            q=json.loads((p/"manifest.json").read_text(encoding="utf-8"))
            m=RunDataManifest(q["schema"],q["run_id"],q["created_at_s"],q.get("project_id"),q.get("parameter_revision"),
                q.get("configuration_revision"),q["software_build"],q["records_sha256"],q["record_count"],
                tuple(DataArtifact(**a) for a in q.get("artifacts",[])),q["provenance"],q.get("previous_manifest_sha256"))
            lines=(p/"records.jsonl").read_text(encoding="utf-8").splitlines()
            if len(lines)!=m.record_count:fail.append("record count mismatch")
            # records_sha256 is canonical typed-record hash; JSONL file integrity is independently represented by actual content count here.
            for a in m.artifacts:
                if not verify_artifact(a,p/a.relative_path):fail.append(f"artifact integrity failed: {a.relative_path}")
        except Exception as exc:fail.append(f"{type(exc).__name__}: {exc}")
        return not fail,tuple(fail)

def shutil_rmtree(path:Path):
    import shutil
    if path.exists():shutil.rmtree(path)

@dataclass(frozen=True)
class DataGuardianContract:
    schema:str
    status:str
    facts:dict[str,Any]
    provenance:str
    authority:str="READ_ONLY_ADVISORY"

def data_guardian_contract(manifest:RunDataManifest)->DataGuardianContract:
    return DataGuardianContract("JOE-GUARDIAN-SCIENTIFIC-DATA/1","PASS",
        {"run_id":manifest.run_id,"record_count":manifest.record_count,"records_sha256":manifest.records_sha256,
         "artifact_count":len(manifest.artifacts),"immutable_manifest":True},"Scientific Data DATA-001A")

def scientific_data_core_readiness():
    r=ScientificRecord("r","x",1.0,"m",.1,0.0,"test",ScientificDataOrigin.SIMULATION,"readiness")
    m=create_manifest(run_id="run",records=(r,),software_build="test",provenance="readiness",created_at_s=0)
    with tempfile.TemporaryDirectory() as d:
        store=ImmutableRunDataStore(d);store.create_run(m,(r,));ok,fail=store.verify_run("run")
        duplicate=False
        try:store.create_run(m,(r,))
        except FileExistsError:duplicate=True
    return {"passed":ok and not fail and duplicate and verify_manifest_records(m,(r,)),
            "checks":("typed scientific records","canonical record hash","versioned manifest","create-only run store","duplicate-run rejection","Guardian provenance contract")}


@dataclass(frozen=True)
class RunIndexEntry:
    run_id:str
    created_at_s:float
    record_count:int
    artifact_count:int
    software_build:str
    origin_counts:dict[str,int]
    manifest_sha256:str
    previous_manifest_sha256:str|None
    provenance:str

@dataclass(frozen=True)
class IntegrityAudit:
    run_id:str
    passed:bool
    checks:tuple[str,...]
    failures:tuple[str,...]
    manifest_sha256:str|None

def _record_from_dict(q:dict[str,Any])->ScientificRecord:
    return ScientificRecord(q["record_id"],q["variable"],q.get("value"),q["unit"],q.get("standard_uncertainty"),
        float(q["timestamp_s"]),q["source_module"],ScientificDataOrigin(q["origin"]),q["provenance"],
        RecordQuality(q.get("quality","GOOD")),q.get("frame_id"),q.get("epoch_id"),q.get("object_id"),
        q.get("parameter_revision"),q.get("algorithm_revision"),q.get("epistemic_status"))

def load_records_jsonl(path:str|Path)->tuple[ScientificRecord,...]:
    rows=[]
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.strip():rows.append(_record_from_dict(json.loads(line)))
    return tuple(rows)

def load_manifest(path:str|Path)->RunDataManifest:
    q=json.loads(Path(path).read_text(encoding="utf-8"))
    return RunDataManifest(q["schema"],q["run_id"],q["created_at_s"],q.get("project_id"),q.get("parameter_revision"),
        q.get("configuration_revision"),q["software_build"],q["records_sha256"],q["record_count"],
        tuple(DataArtifact(**a) for a in q.get("artifacts",[])),q["provenance"],q.get("previous_manifest_sha256"))

def list_run_entries(store:ImmutableRunDataStore)->tuple[RunIndexEntry,...]:
    if not store.root.exists():return ()
    out=[]
    for p in store.root.iterdir():
        if not p.is_dir() or p.name.startswith("."):continue
        try:
            m=load_manifest(p/"manifest.json");records=load_records_jsonl(p/"records.jsonl");counts={}
            for r in records:counts[r.origin.value]=counts.get(r.origin.value,0)+1
            out.append(RunIndexEntry(m.run_id,m.created_at_s,m.record_count,len(m.artifacts),m.software_build,
                counts,sha256_file(p/"manifest.json"),m.previous_manifest_sha256,m.provenance))
        except Exception:
            continue
    return tuple(sorted(out,key=lambda e:(e.created_at_s,e.run_id),reverse=True))

def query_records(store:ImmutableRunDataStore,*,run_id:str|None=None,variable:str|None=None,
                  source_module:str|None=None,origin:ScientificDataOrigin|None=None,
                  quality:RecordQuality|None=None)->tuple[ScientificRecord,...]:
    runs=(run_id,) if run_id else tuple(e.run_id for e in list_run_entries(store));out=[]
    for rid in runs:
        p=store.root/rid/"records.jsonl"
        if not p.is_file():continue
        for r in load_records_jsonl(p):
            if variable is not None and r.variable!=variable:continue
            if source_module is not None and r.source_module!=source_module:continue
            if origin is not None and r.origin!=origin:continue
            if quality is not None and r.quality!=quality:continue
            out.append(r)
    return tuple(out)

def audit_run(store:ImmutableRunDataStore,run_id:str)->IntegrityAudit:
    p=store.root/run_id;checks=[];fail=[];mh=None
    try:
        m=load_manifest(p/"manifest.json");mh=sha256_file(p/"manifest.json");checks.append("manifest parsed and SHA-256 computed")
        records=load_records_jsonl(p/"records.jsonl")
        if verify_manifest_records(m,records):checks.append("canonical record hash and count match manifest")
        else:fail.append("canonical record hash/count mismatch")
        for a in m.artifacts:
            ap=p/a.relative_path
            if verify_artifact(a,ap):checks.append(f"artifact verified: {a.relative_path}")
            else:fail.append(f"artifact integrity failed: {a.relative_path}")
    except Exception as exc:fail.append(f"{type(exc).__name__}: {exc}")
    return IntegrityAudit(run_id,not fail,tuple(checks),tuple(fail),mh)

def verify_manifest_chain(store:ImmutableRunDataStore)->tuple[bool,tuple[str,...]]:
    entries=tuple(sorted(list_run_entries(store),key=lambda e:(e.created_at_s,e.run_id)))
    fail=[]
    for i,e in enumerate(entries):
        if e.previous_manifest_sha256 is None:continue
        if i==0:fail.append(f"{e.run_id}: previous manifest hash supplied but no predecessor exists");continue
        prior=entries[i-1]
        if e.previous_manifest_sha256!=prior.manifest_sha256:
            fail.append(f"{e.run_id}: previous manifest SHA-256 does not match predecessor {prior.run_id}")
    return not fail,tuple(fail)

def provenance_summary(store:ImmutableRunDataStore)->dict[str,Any]:
    entries=list_run_entries(store);origins={};builds={}
    for e in entries:
        builds[e.software_build]=builds.get(e.software_build,0)+1
        for k,v in e.origin_counts.items():origins[k]=origins.get(k,0)+v
    return {"run_count":len(entries),"record_count":sum(e.record_count for e in entries),
            "artifact_count":sum(e.artifact_count for e in entries),"origins":dict(sorted(origins.items())),
            "software_builds":dict(sorted(builds.items()))}

def scientific_data_archive_readiness():
    r1=ScientificRecord("r1","x",1.0,"m",.1,0.0,"test",ScientificDataOrigin.SIMULATION,"readiness")
    r2=ScientificRecord("r2","x",2.0,"m",.1,1.0,"test",ScientificDataOrigin.IMPORTED,"readiness")
    with tempfile.TemporaryDirectory() as d:
        store=ImmutableRunDataStore(d)
        m1=create_manifest(run_id="a",records=(r1,),software_build="b",provenance="readiness",created_at_s=1)
        store.create_run(m1,(r1,))
        h1=sha256_file(Path(d)/"a"/"manifest.json")
        m2=create_manifest(run_id="b",records=(r2,),software_build="b",provenance="readiness",created_at_s=2,previous_manifest_sha256=h1)
        store.create_run(m2,(r2,))
        audit=audit_run(store,"b");chain,cf=verify_manifest_chain(store);q=query_records(store,origin=ScientificDataOrigin.IMPORTED)
        summary=provenance_summary(store)
    return {"passed":audit.passed and chain and not cf and len(q)==1 and summary["run_count"]==2,
            "checks":("run archive indexing","typed record retrieval","integrity audit","manifest-chain verification","provenance summary")}


@dataclass(frozen=True)
class LineageEdge:
    parent_record_id:str
    child_record_id:str
    relation:str
    provenance:str
    def __post_init__(self):
        if not all((self.parent_record_id.strip(),self.child_record_id.strip(),self.relation.strip(),self.provenance.strip())):
            raise ValueError("complete lineage edge required")
        if self.parent_record_id==self.child_record_id:raise ValueError("record cannot derive from itself")

@dataclass(frozen=True)
class ProvenanceLineage:
    schema:str
    run_id:str
    edges:tuple[LineageEdge,...]
    provenance:str
    def __post_init__(self):
        if self.schema!="JOE-PROVENANCE-LINEAGE/1":raise ValueError("unsupported lineage schema")
        if not self.run_id.strip() or not self.provenance.strip():raise ValueError("lineage run/provenance required")
        seen=set()
        for e in self.edges:
            key=(e.parent_record_id,e.child_record_id,e.relation)
            if key in seen:raise ValueError("duplicate lineage edge")
            seen.add(key)

def validate_lineage(lineage:ProvenanceLineage,records:Iterable[ScientificRecord])->tuple[bool,tuple[str,...]]:
    ids={r.record_id for r in records};fail=[]
    graph={}
    for e in lineage.edges:
        if e.parent_record_id not in ids:fail.append(f"unknown parent record: {e.parent_record_id}")
        if e.child_record_id not in ids:fail.append(f"unknown child record: {e.child_record_id}")
        graph.setdefault(e.parent_record_id,set()).add(e.child_record_id)
    visiting=set();done=set()
    def visit(n):
        if n in visiting:return True
        if n in done:return False
        visiting.add(n)
        for q in graph.get(n,()):
            if visit(q):return True
        visiting.remove(n);done.add(n);return False
    if any(visit(n) for n in tuple(graph)):fail.append("lineage graph contains a cycle")
    return not fail,tuple(fail)

def write_lineage(lineage:ProvenanceLineage,path:str|Path)->str:
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    q={"schema":lineage.schema,"run_id":lineage.run_id,
       "edges":[asdict(e) for e in lineage.edges],"provenance":lineage.provenance}
    p.write_text(json.dumps(q,sort_keys=True,indent=2)+"\n",encoding="utf-8");return sha256_file(p)

def load_lineage(path:str|Path)->ProvenanceLineage:
    q=json.loads(Path(path).read_text(encoding="utf-8"))
    return ProvenanceLineage(q["schema"],q["run_id"],tuple(LineageEdge(**e) for e in q["edges"]),q["provenance"])

@dataclass(frozen=True)
class ProvenanceTrace:
    record_id:str
    ancestors:tuple[str,...]
    descendants:tuple[str,...]

def trace_record(lineage:ProvenanceLineage,record_id:str)->ProvenanceTrace:
    parents={};children={}
    for e in lineage.edges:
        parents.setdefault(e.child_record_id,set()).add(e.parent_record_id)
        children.setdefault(e.parent_record_id,set()).add(e.child_record_id)
    def walk(graph,start):
        found=set();stack=list(graph.get(start,()))
        while stack:
            q=stack.pop()
            if q in found:continue
            found.add(q);stack.extend(graph.get(q,()))
        return tuple(sorted(found))
    return ProvenanceTrace(record_id,walk(parents,record_id),walk(children,record_id))

def export_audit_report(audit:IntegrityAudit,path:str|Path)->str:
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    q={"schema":"JOE-DATA-INTEGRITY-AUDIT/1","run_id":audit.run_id,"passed":audit.passed,
       "checks":list(audit.checks),"failures":list(audit.failures),"manifest_sha256":audit.manifest_sha256}
    p.write_text(json.dumps(q,sort_keys=True,indent=2)+"\n",encoding="utf-8");return sha256_file(p)

def scientific_data_v1_release_readiness():
    failures=[];checks=[]
    for name,fn in (("data core",scientific_data_core_readiness),("archive and audit",scientific_data_archive_readiness)):
        try:
            q=fn()
            if q["passed"]:checks.append(name+" passed")
            else:failures.append(name+" failed")
        except Exception as exc:failures.append(f"{name}: {type(exc).__name__}: {exc}")
    try:
        a=ScientificRecord("a","raw",1.0,"V",.1,0,"sensor",ScientificDataOrigin.SIMULATION,"readiness")
        b=ScientificRecord("b","derived",2.0,"V",.2,1,"analysis",ScientificDataOrigin.SIMULATION,"readiness")
        lin=ProvenanceLineage("JOE-PROVENANCE-LINEAGE/1","r",(LineageEdge("a","b","DERIVED_FROM","readiness"),),"readiness")
        ok,lf=validate_lineage(lin,(a,b));tr=trace_record(lin,"b")
        if ok and not lf and tr.ancestors==("a",):checks.append("record lineage validation/trace passed")
        else:failures.append("record lineage validation/trace failed")
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"lineage.json";write_lineage(lin,p)
            if load_lineage(p)==lin:checks.append("lineage serialization round-trip passed")
    except Exception as exc:failures.append(f"lineage: {type(exc).__name__}: {exc}")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),
            "notes":("Scientific Data v1 uses create-only run archives; it does not silently rewrite prior runs.",
                     "Provenance records describe declared data lineage and do not independently validate unresolved physics.",
                     "Legacy JOE run stores remain separate until explicitly migrated through a qualified conversion path.")}
