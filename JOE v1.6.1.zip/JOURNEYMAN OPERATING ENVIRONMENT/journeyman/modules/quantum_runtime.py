from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.quantum_runtime import (discover_quantum_backends,builtin_basis_backend,execute_basis_simulation,
 quantum_guardian_contract,quantum_job_provenance,quantum_core_readiness,QuantumRuntimeManager,quantum_provider_readiness,
 PhysicalQuantumRuntime,verify_quantum_result,quantum_v1_release_readiness)
QUANTUM_MODULE=ModuleDescriptor(module_id="journeyman.quantum-runtime",name="QPU Adapter / Quantum Runtime",version="1.0.0",
 requires=("joe.core","journeyman.compute"),provides=("joe.quantum-runtime",),consumes=("joe.jobs","joe.compute"))
class QuantumRuntimeService:
    def discover(self):return (builtin_basis_backend(),)+discover_quantum_backends()
    execute_basis=staticmethod(execute_basis_simulation)
    provenance_record=staticmethod(quantum_job_provenance)
    guardian_contract=staticmethod(quantum_guardian_contract)
    release_readiness=staticmethod(quantum_v1_release_readiness)
    provider_readiness=staticmethod(quantum_provider_readiness)
    def create_manager(self):return QuantumRuntimeManager()
    def create_physical_runtime(self):return PhysicalQuantumRuntime()
    result_integrity=staticmethod(verify_quantum_result)
class QuantumRuntimeInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_quantum_runtime_module(runtime:ModuleRuntime):
    svc=QuantumRuntimeService();runtime.register(QUANTUM_MODULE,QuantumRuntimeInstance(svc));runtime.activate("journeyman.quantum-runtime")
    runtime.publish_service("journeyman.quantum-runtime","joe.quantum-runtime",svc);return svc
