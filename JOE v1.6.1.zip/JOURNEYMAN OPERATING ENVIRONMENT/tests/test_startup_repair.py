from pathlib import Path


def test_main_window_uses_canonical_core_paths_import():
    source = (Path(__file__).resolve().parents[1] / "journeyman" / "ui" / "main_window.py").read_text(encoding="utf-8")
    assert "from journeyman.paths import" not in source
    assert "from journeyman.core.paths import DATA_DIR" in source
