"""JOE controlled job and compute engine.

This first JOE-006 layer provides real process-local CPU job execution with
explicit lifecycle state, cancellation requests, progress reporting, result/
failure retention, and bounded audit history. It is not a real-time controller
and has no BUS-SAFE authority.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from concurrent.futures import Future
from queue import PriorityQueue
from threading import Thread
from threading import RLock, Event
from time import time
from typing import Any, Callable
from uuid import uuid4


class JobPriority(int, Enum):
    LOW=30
    NORMAL=20
    HIGH=10

class JobState(str, Enum):
    QUEUED="QUEUED"
    RUNNING="RUNNING"
    SUCCEEDED="SUCCEEDED"
    FAILED="FAILED"
    CANCELLED="CANCELLED"


@dataclass(frozen=True)
class JobTransition:
    sequence: int
    job_id: str
    old_state: JobState | None
    new_state: JobState
    timestamp: float
    detail: str = ""


@dataclass(frozen=True)
class JobSnapshot:
    job_id: str
    name: str
    owner: str
    priority: JobPriority
    state: JobState
    progress: float
    created_at: float
    started_at: float | None
    finished_at: float | None
    error: str | None


@dataclass
class _JobRecord:
    job_id: str
    name: str
    owner: str
    priority: JobPriority
    state: JobState
    created_at: float
    started_at: float | None = None
    finished_at: float | None = None
    progress: float = 0.0
    result: Any = None
    error: str | None = None
    cancel: Event = field(default_factory=Event)
    future: Future | None = None


class JobContext:
    """Cooperative context passed to a running JOE job."""
    def __init__(self, engine: "JobEngine", job_id: str):
        self._engine=engine
        self.job_id=job_id

    @property
    def cancellation_requested(self) -> bool:
        return self._engine._cancel_requested(self.job_id)

    def raise_if_cancelled(self) -> None:
        if self.cancellation_requested:
            raise JobCancelled("job cancellation requested")

    def report_progress(self, value: float) -> None:
        self._engine._set_progress(self.job_id,value)


class JobCancelled(RuntimeError):
    pass


@dataclass(frozen=True)
class JobOwnerPolicy:
    owner: str
    max_active: int

class JobEngine:
    def __init__(self, max_workers: int = 2, history_limit: int = 1000,
                 completed_limit: int = 500):
        if not isinstance(max_workers,int) or isinstance(max_workers,bool) or max_workers < 1:
            raise ValueError("max_workers must be a positive integer")
        if not isinstance(history_limit,int) or isinstance(history_limit,bool) or history_limit < 1:
            raise ValueError("history_limit must be a positive integer")
        if not isinstance(completed_limit,int) or isinstance(completed_limit,bool) or completed_limit < 1:
            raise ValueError("completed_limit must be a positive integer")
        self.max_workers=max_workers
        self._lock=RLock()
        self._queue: PriorityQueue=PriorityQueue()
        self._submit_sequence=0
        self._workers=[
            Thread(target=self._worker,name=f"JOE-{index+1}",daemon=True)
            for index in range(max_workers)
        ]
        self._records: dict[str,_JobRecord]={}
        self._terminal_snapshots: dict[str,JobSnapshot]={}
        self._transitions: list[JobTransition]=[]
        self._history_limit=history_limit
        self._completed_limit=completed_limit
        self._sequence=0
        self._closed=False
        self._owner_policies: dict[str,JobOwnerPolicy]={}
        for worker in self._workers:
            worker.start()

    def register_owner(self, owner: str, max_active: int = 4) -> None:
        if not isinstance(owner,str) or not owner.strip():
            raise ValueError("job owner must be non-empty")
        owner=owner.strip()
        if not isinstance(max_active,int) or isinstance(max_active,bool) or max_active < 1:
            raise ValueError("max_active must be a positive integer")
        with self._lock:
            existing=self._owner_policies.get(owner)
            policy=JobOwnerPolicy(owner,max_active)
            if existing is not None and existing != policy:
                raise RuntimeError(f"job owner already registered with different policy: {owner}")
            self._owner_policies[owner]=policy

    def owner_policies(self) -> tuple[JobOwnerPolicy,...]:
        with self._lock:
            return tuple(self._owner_policies[key] for key in sorted(self._owner_policies))

    def _owner_active_count(self, owner: str) -> int:
        return sum(
            1 for record in self._records.values()
            if record.owner == owner and record.state in (JobState.QUEUED,JobState.RUNNING)
        )

    def _prune_completed_locked(self) -> None:
        terminal=(JobState.SUCCEEDED,JobState.FAILED,JobState.CANCELLED)
        completed=[
            record for record in self._records.values()
            if record.state in terminal and record.finished_at is not None
        ]
        excess=len(completed)-self._completed_limit
        if excess <= 0:
            return
        completed.sort(key=lambda record:(record.finished_at or 0.0,record.created_at))
        for record in completed[:excess]:
            self._records.pop(record.job_id,None)

    def _transition(self, record: _JobRecord, state: JobState, detail: str="") -> None:
        old=record.state
        record.state=state
        self._sequence += 1
        self._transitions.append(JobTransition(
            self._sequence,record.job_id,old,state,time(),detail
        ))
        if len(self._transitions) > self._history_limit:
            del self._transitions[:-self._history_limit]
        if state in (JobState.SUCCEEDED,JobState.FAILED,JobState.CANCELLED):
            self._terminal_snapshots[record.job_id]=JobSnapshot(
                record.job_id,record.name,record.owner,record.priority,record.state,record.progress,
                record.created_at,record.started_at,record.finished_at,record.error)
            # Keep enough terminal snapshots for delayed waiters without retaining job payload/results forever.
            if len(self._terminal_snapshots)>self._history_limit:
                oldest=next(iter(self._terminal_snapshots))
                self._terminal_snapshots.pop(oldest,None)

    def submit(self, name: str, owner: str, function: Callable[[JobContext],Any],
               priority: JobPriority = JobPriority.NORMAL) -> str:
        if not isinstance(name,str) or not name.strip():
            raise ValueError("job name must be non-empty")
        if not isinstance(owner,str) or not owner.strip():
            raise ValueError("job owner must be non-empty")
        owner=owner.strip()
        if not callable(function):
            raise TypeError("job function must be callable")
        if not isinstance(priority,JobPriority):
            raise TypeError("priority must be a JobPriority")
        with self._lock:
            if self._closed:
                raise RuntimeError("job engine is shut down")
            policy=self._owner_policies.get(owner)
            if policy is None:
                raise PermissionError(f"job owner is not registered: {owner}")
            if self._owner_active_count(owner) >= policy.max_active:
                raise RuntimeError(
                    f"job owner active-job limit reached: {owner} ({policy.max_active})"
                )
            job_id=str(uuid4())
            record=_JobRecord(job_id,name.strip(),owner.strip(),priority,JobState.QUEUED,time())
            self._records[job_id]=record
            self._sequence += 1
            self._transitions.append(JobTransition(
                self._sequence,job_id,None,JobState.QUEUED,time(),"submitted"
            ))
            record.future=Future()
            self._submit_sequence += 1
            self._queue.put((priority.value,self._submit_sequence,job_id,function))
            return job_id

    def _worker(self) -> None:
        while True:
            item=self._queue.get()
            try:
                _,_,job_id,function=item
                if not job_id:
                    return
                self._run(job_id,function)
            finally:
                self._queue.task_done()

    def _run(self, job_id: str, function: Callable[[JobContext],Any]) -> None:
        with self._lock:
            record=self._records[job_id]
            if record.cancel.is_set():
                record.finished_at=time()
                self._transition(record,JobState.CANCELLED,"cancelled before execution")
                self._prune_completed_locked()
                if record.future and not record.future.done():
                    record.future.set_result(None)
                return
            record.started_at=time()
            self._transition(record,JobState.RUNNING,"execution started")
        try:
            result=function(JobContext(self,job_id))
        except JobCancelled as exc:
            with self._lock:
                record=self._records[job_id]
                record.error=str(exc)
                record.finished_at=time()
                self._transition(record,JobState.CANCELLED,str(exc))
                self._prune_completed_locked()
                if record.future and not record.future.done():
                    record.future.set_result(None)
        except Exception as exc:
            with self._lock:
                record=self._records[job_id]
                record.error=f"{type(exc).__name__}: {exc}"
                record.finished_at=time()
                self._transition(record,JobState.FAILED,record.error)
                self._prune_completed_locked()
                if record.future and not record.future.done():
                    record.future.set_result(None)
        else:
            with self._lock:
                record=self._records[job_id]
                if record.cancel.is_set():
                    record.finished_at=time()
                    self._transition(record,JobState.CANCELLED,"cancelled before result acceptance")
                    self._prune_completed_locked()
                    if record.future and not record.future.done():
                        record.future.set_result(None)
                else:
                    record.result=result
                    record.progress=1.0
                    record.finished_at=time()
                    self._transition(record,JobState.SUCCEEDED,"execution completed")
                    self._prune_completed_locked()
                    if record.future and not record.future.done():
                        record.future.set_result(None)

    def _set_progress(self, job_id: str, value: float) -> None:
        if not isinstance(value,(int,float)) or isinstance(value,bool):
            raise TypeError("progress must be numeric")
        value=float(value)
        if not 0.0 <= value <= 1.0:
            raise ValueError("progress must be between 0 and 1")
        with self._lock:
            record=self._records[job_id]
            if record.state is not JobState.RUNNING:
                raise RuntimeError("progress can only be reported by a running job")
            if value < record.progress:
                raise ValueError("job progress cannot move backwards")
            record.progress=value

    def _cancel_requested(self, job_id: str) -> bool:
        with self._lock:
            return self._records[job_id].cancel.is_set()

    def cancel(self, job_id: str) -> bool:
        with self._lock:
            record=self._records[job_id]
            if record.state in (JobState.SUCCEEDED,JobState.FAILED,JobState.CANCELLED):
                return False
            record.cancel.set()
            # Queued jobs remain in the priority queue and are converted to
            # CANCELLED by the worker before their callable is invoked.
            return True

    def snapshot(self, job_id: str) -> JobSnapshot:
        with self._lock:
            r=self._records[job_id]
            return JobSnapshot(r.job_id,r.name,r.owner,r.priority,r.state,r.progress,r.created_at,
                               r.started_at,r.finished_at,r.error)

    def snapshots(self) -> tuple[JobSnapshot,...]:
        with self._lock:
            ids=tuple(self._records)
        return tuple(self.snapshot(job_id) for job_id in ids)

    def wait(self, job_id: str, timeout: float | None = None) -> JobSnapshot:
        with self._lock:
            record=self._records.get(job_id)
            if record is None:
                cached=self._terminal_snapshots.get(job_id)
                if cached is None: raise KeyError(job_id)
                return cached
            future=record.future
        if future is None: raise RuntimeError("job has no execution future")
        future.result(timeout=timeout)
        with self._lock:
            cached=self._terminal_snapshots.get(job_id)
        return cached if cached is not None else self.snapshot(job_id)

    @property
    def completed_limit(self) -> int:
        return self._completed_limit

    def result(self, job_id: str) -> Any:
        with self._lock:
            r=self._records[job_id]
            if r.state is JobState.SUCCEEDED:
                return r.result
            if r.state is JobState.FAILED:
                raise RuntimeError(r.error or "job failed")
            if r.state is JobState.CANCELLED:
                raise JobCancelled(r.error or "job cancelled")
            raise RuntimeError(f"job is not complete: {r.state.value}")

    def transitions(self) -> tuple[JobTransition,...]:
        with self._lock:
            return tuple(self._transitions)

    def counts(self) -> dict[JobState,int]:
        result={state:0 for state in JobState}
        with self._lock:
            for record in self._records.values():
                result[record.state]+=1
        return result

    def shutdown(self, wait: bool=True, cancel_pending: bool=True) -> None:
        with self._lock:
            self._closed=True
            ids=tuple(self._records)
        if cancel_pending:
            for job_id in ids:
                self.cancel(job_id)
        # PriorityQueue cannot contain incomparable sentinels, so use a
        # numeric tuple that sorts after every real job.
        for index,_worker in enumerate(self._workers):
            self._queue.put((10**9,10**9+index,"",""))
        if wait:
            for worker in self._workers:
                worker.join()


@dataclass(frozen=True)
class JobEngineQualification:
    passed: bool
    failures: tuple[str, ...]
    known_jobs: int
    active_jobs: int
    registered_owners: int
    transition_count: int

def qualify_job_engine(engine: JobEngine) -> JobEngineQualification:
    failures: list[str] = []
    snapshots=engine.snapshots()
    policies=engine.owner_policies()
    transitions=engine.transitions()

    ids=[item.job_id for item in snapshots]
    if len(ids) != len(set(ids)):
        failures.append("Duplicate job identities detected.")

    policy_names=[item.owner for item in policies]
    if len(policy_names) != len(set(policy_names)):
        failures.append("Duplicate job-owner policies detected.")

    active_states=(JobState.QUEUED,JobState.RUNNING)
    active=sum(1 for item in snapshots if item.state in active_states)

    for item in snapshots:
        if not item.job_id or not item.name or not item.owner:
            failures.append("Job snapshot contains missing identity/name/owner.")
        if not isinstance(item.priority,JobPriority):
            failures.append(f"Job {item.job_id} has invalid priority.")
        if not 0.0 <= item.progress <= 1.0:
            failures.append(f"Job {item.job_id} has invalid progress {item.progress}.")
        if item.state is JobState.QUEUED and item.started_at is not None:
            failures.append(f"Queued job {item.job_id} already has a start timestamp.")
        if item.state is JobState.RUNNING and item.started_at is None:
            failures.append(f"Running job {item.job_id} lacks a start timestamp.")
        if item.state in (JobState.SUCCEEDED,JobState.FAILED,JobState.CANCELLED):
            if item.finished_at is None:
                failures.append(f"Terminal job {item.job_id} lacks a finish timestamp.")
        if item.state is JobState.FAILED and not item.error:
            failures.append(f"Failed job {item.job_id} lacks an error.")
        if item.state is JobState.SUCCEEDED and item.progress != 1.0:
            failures.append(f"Succeeded job {item.job_id} is not at 100% progress.")
        if item.owner not in policy_names:
            failures.append(f"Job {item.job_id} belongs to unregistered owner {item.owner}.")

    # Every retained transition sequence must be strictly increasing and unique.
    sequences=[item.sequence for item in transitions]
    if sequences != sorted(sequences) or len(sequences) != len(set(sequences)):
        failures.append("Job transition audit sequence is not strictly ordered and unique.")

    # Retained records must have at least one audit transition unless audit
    # retention has intentionally dropped older transitions; in that case only
    # check records whose creation sequence could still be represented.
    transition_ids={item.job_id for item in transitions}
    if len(transitions) < engine._history_limit:
        for item in snapshots:
            if item.job_id not in transition_ids:
                failures.append(f"Job {item.job_id} has no lifecycle audit transition.")

    return JobEngineQualification(
        passed=not failures,
        failures=tuple(failures),
        known_jobs=len(snapshots),
        active_jobs=active,
        registered_owners=len(policies),
        transition_count=len(transitions),
    )


@dataclass(frozen=True)
class JobEngineReleaseReadiness:
    passed: bool
    failures: tuple[str, ...]
    lifecycle_qualification: JobEngineQualification
    exercised_jobs: int

def joe006_release_readiness(engine: JobEngine) -> JobEngineReleaseReadiness:
    failures: list[str] = []
    live=qualify_job_engine(engine)
    failures.extend(live.failures)
    exercised=0

    # Exercise a separate engine so the release gate never adds synthetic/test
    # jobs to the user's live JOE compute history.
    probe=JobEngine(max_workers=1,history_limit=100,completed_limit=20)
    probe.register_owner("joe.readiness",max_active=4)
    try:
        # Success/result/progress path.
        def success(ctx):
            ctx.report_progress(0.25)
            ctx.report_progress(0.75)
            return 42
        success_id=probe.submit("success","joe.readiness",success,JobPriority.NORMAL)
        success_snap=probe.wait(success_id,2)
        exercised += 1
        if success_snap.state is not JobState.SUCCEEDED or probe.result(success_id) != 42:
            failures.append("Isolated successful-job probe failed.")

        # Explicit failure capture.
        def expected_failure(ctx):
            raise ValueError("JOE-006 readiness expected failure")
        failure_id=probe.submit("failure","joe.readiness",expected_failure,JobPriority.NORMAL)
        failure_snap=probe.wait(failure_id,2)
        exercised += 1
        if failure_snap.state is not JobState.FAILED or not failure_snap.error:
            failures.append("Isolated failed-job probe did not retain explicit failure state.")

        # Priority ordering while one worker is occupied.
        from threading import Event as _ProbeEvent
        entered=_ProbeEvent()
        release=_ProbeEvent()
        order=[]
        def blocker(ctx):
            entered.set()
            release.wait(2)
            order.append("blocker")
        blocker_id=probe.submit("blocker","joe.readiness",blocker,JobPriority.NORMAL)
        if not entered.wait(1):
            failures.append("Isolated scheduler blocker did not enter execution.")
        low_id=probe.submit("low","joe.readiness",lambda ctx: order.append("low"),JobPriority.LOW)
        high_id=probe.submit("high","joe.readiness",lambda ctx: order.append("high"),JobPriority.HIGH)
        release.set()
        for job_id in (blocker_id,low_id,high_id):
            probe.wait(job_id,2)
        exercised += 3
        if order != ["blocker","high","low"]:
            failures.append(f"Isolated priority-order probe failed: {order!r}")

        isolated=qualify_job_engine(probe)
        failures.extend(f"Isolated engine: {item}" for item in isolated.failures)
    except Exception as exc:
        failures.append(f"Isolated JOE-006 exercise failed: {type(exc).__name__}: {exc}")
    finally:
        probe.shutdown(wait=True,cancel_pending=True)

    return JobEngineReleaseReadiness(
        passed=not failures,
        failures=tuple(failures),
        lifecycle_qualification=live,
        exercised_jobs=exercised,
    )
