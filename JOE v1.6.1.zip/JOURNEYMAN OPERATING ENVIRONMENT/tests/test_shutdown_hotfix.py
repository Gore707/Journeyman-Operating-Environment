from pathlib import Path

ROOT = Path(__file__).parents[1]

def test_workspace_destroyed_callback_not_used_for_python_signal():
    src = (ROOT / "journeyman" / "ui" / "workspaces.py").read_text(encoding="utf-8")
    assert "sub.destroyed.connect(lambda _obj=None: self.workspace_changed.emit())" not in src

def test_save_and_quit_is_visible_and_uses_common_close_path():
    src = (ROOT / "journeyman" / "ui" / "main_window.py").read_text(encoding="utf-8")
    assert 'def save_and_quit(self):' in src
    assert '"Save & Quit", self.save_and_quit' in src
    assert 'save_quit = QAction("Save & Quit", self)' in src
    assert 'save_quit.triggered.connect(self.save_and_quit)' in src

def test_shutdown_is_idempotently_guarded():
    src = (ROOT / "journeyman" / "ui" / "main_window.py").read_text(encoding="utf-8")
    assert '_shutdown_in_progress' in src
    assert 'self._shutdown_in_progress = True' in src
