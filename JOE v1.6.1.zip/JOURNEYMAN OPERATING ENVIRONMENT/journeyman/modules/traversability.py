"""T-1 Human Traversability Analyzer module."""
from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.traversability import (evaluate_human_traversability,proper_radial_distance,
 estimate_constant_speed_transit,radial_traversability_profile,symmetric_accel_cruise_profile,
 propagate_scalar_margin_uncertainty,traversability_convergence,traversability_release_readiness)
T1_MODULE=ModuleDescriptor(module_id="journeyman.traversability",name="Human Traversability Analyzer [T-1]",version="1.0.0",
 description="Model-based proper-acceleration, tidal and transit constraints for candidate geometries.",
 requires=("joe.core","journeyman.registry","journeyman.navigation","journeyman.geometry"),
 provides=("joe.traversability",),consumes=("joe.geometry","joe.units","joe.navigation","joe.state-events"))
class TraversabilityService:
    evaluate=staticmethod(evaluate_human_traversability)
    proper_distance=staticmethod(proper_radial_distance)
    transit=staticmethod(estimate_constant_speed_transit)
    radial_profile=staticmethod(radial_traversability_profile)
    motion_profile=staticmethod(symmetric_accel_cruise_profile)
    uncertainty_margin=staticmethod(propagate_scalar_margin_uncertainty)
    convergence=staticmethod(traversability_convergence)
    release_readiness=staticmethod(traversability_release_readiness)
class TraversabilityInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_traversability_module(runtime:ModuleRuntime):
    svc=TraversabilityService();runtime.register(T1_MODULE,TraversabilityInstance(svc));runtime.activate("journeyman.traversability")
    runtime.publish_service("journeyman.traversability","joe.traversability",svc);return svc
