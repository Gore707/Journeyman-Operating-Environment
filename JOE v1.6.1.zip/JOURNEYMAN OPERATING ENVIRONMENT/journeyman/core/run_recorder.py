"""Persistent JOE scientific run lifecycle and event journal."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
import json
import hashlib
import os
from pathlib import Path
import threading
import uuid

class RunState(str, Enum):
    ACTIVE="ACTIVE"
    COMPLETED="COMPLETED"
    FAILED="FAILED"
    CANCELLED="CANCELLED"

@dataclass(frozen=True)
class RunRecord:
    run_id: str
    name: str
    mode: str
    source: str
    state: RunState
    started_at: str
    ended_at: str | None
    description: str
    metadata: dict
    event_count: int
    sample_count: int
    snapshot_count: int
    association_count: int
    directory: str

@dataclass(frozen=True)
class RunIntegrityReport:
    run_id: str
    passed: bool
    checked_files: int
    failures: tuple[str, ...]


@dataclass(frozen=True)
class RunRecorderStatus:
    total_runs: int
    active_runs: int
    completed_runs: int
    failed_runs: int
    cancelled_runs: int
    active_run_ids: tuple[str, ...]

@dataclass(frozen=True)
class RunRecoveryReport:
    run_id: str
    recovered: bool
    prior_state: str
    final_state: str
    reason: str

@dataclass(frozen=True)
class RunRecorderQualification:
    passed: bool
    checks: tuple[str, ...]
    failures: tuple[str, ...]

@dataclass(frozen=True)
class RunRecorderReleaseReadiness:
    passed: bool
    qualification: RunRecorderQualification
    exercise_events: int
    exercise_samples: int
    exercise_snapshots: int
    exercise_associations: int
    integrity_files: int
    notes: tuple[str, ...]

class RunRecorder:
    MANIFEST="manifest.json"
    EVENTS="events.jsonl"
    SCHEMA=1

    def __init__(self, root: Path):
        self.root=Path(root)
        self.root.mkdir(parents=True,exist_ok=True)
        self._lock=threading.RLock()

    @staticmethod
    def _now(): return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _validate_mode(mode):
        value=str(mode).strip().upper()
        allowed={"SOFTWARE","HOST","IMPORTED","SIMULATION","HARDWARE"}
        if value not in allowed: raise ValueError(f"run mode must be one of {sorted(allowed)}")
        return value

    def _dir(self,run_id):
        try: uuid.UUID(str(run_id))
        except (ValueError,TypeError,AttributeError) as exc: raise ValueError("invalid run_id") from exc
        return self.root/str(run_id)

    def _manifest(self,run_id): return self._dir(run_id)/self.MANIFEST
    def _events(self,run_id): return self._dir(run_id)/self.EVENTS

    @staticmethod
    def _atomic_json(path,payload):
        temp=path.with_suffix(path.suffix+".tmp")
        with temp.open("w",encoding="utf-8",newline="\n") as fh:
            fh.write(json.dumps(payload,indent=2,sort_keys=True)+"\n")
            fh.flush()
            os.fsync(fh.fileno())
        temp.replace(path)

    @staticmethod
    def _sha256(path):
        digest=hashlib.sha256()
        with Path(path).open("rb") as fh:
            for chunk in iter(lambda:fh.read(1024*1024),b""):
                digest.update(chunk)
        return digest.hexdigest()

    def _refresh_integrity(self,run_id,manifest=None):
        """Refresh hashes for immutable/current run payload files, excluding manifest."""
        if manifest is None:
            manifest=json.loads(self._manifest(run_id).read_text(encoding="utf-8"))
        directory=self._dir(run_id)
        files={}
        for path in sorted(directory.iterdir(),key=lambda p:p.name):
            if not path.is_file() or path.name in {self.MANIFEST} or path.name.endswith(".tmp"):
                continue
            files[path.name]=self._sha256(path)
        manifest["integrity"]={"algorithm":"sha256","files":files}
        manifest.pop("integrity_dirty",None)
        self._atomic_json(self._manifest(run_id),manifest)
        return manifest


    def start(self,name,*,mode,source,description="",metadata=None):
        name=str(name).strip(); source=str(source).strip()
        if not name: raise ValueError("run name is required")
        if not source: raise ValueError("run source is required")
        mode=self._validate_mode(mode)
        if metadata is not None and not isinstance(metadata,dict): raise TypeError("metadata must be a dict")
        run_id=str(uuid.uuid4()); directory=self._dir(run_id)
        with self._lock:
            directory.mkdir(parents=False,exist_ok=False)
            self._atomic_json(directory/self.MANIFEST,{
                "schema":self.SCHEMA,"run_id":run_id,"name":name,"mode":mode,"source":source,
                "state":RunState.ACTIVE.value,"started_at":self._now(),"ended_at":None,
                "description":str(description).strip(),"metadata":dict(metadata or {}),
                "event_count":0,"sample_count":0,"snapshot_count":0,"streams":{},"snapshots":[],
                "associations":[],"association_count":0,
                "integrity":{"algorithm":"sha256","files":{}},
            })
            (directory/self.EVENTS).touch()
            (directory/"samples.jsonl").touch()
            self._refresh_integrity(run_id)
        return self.get(run_id)

    def get(self,run_id):
        path=self._manifest(run_id)
        if not path.exists(): raise KeyError(run_id)
        data=json.loads(path.read_text(encoding="utf-8"))
        return RunRecord(data["run_id"],data["name"],data["mode"],data["source"],
                         RunState(data["state"]),data["started_at"],data.get("ended_at"),
                         data.get("description",""),dict(data.get("metadata",{})),
                         int(data.get("event_count",0)),int(data.get("sample_count",0)),
                         int(data.get("snapshot_count",0)),int(data.get("association_count",0)),
                         str(path.parent))

    def list_runs(self):
        rows=[]
        for path in self.root.iterdir():
            if not path.is_dir(): continue
            try: rows.append(self.get(path.name))
            except (KeyError,ValueError,json.JSONDecodeError,OSError): continue
        return tuple(sorted(rows,key=lambda row:row.started_at,reverse=True))

    def append_event(self,run_id,event_type,payload=None,*,source=None):
        event_type=str(event_type).strip()
        if not event_type: raise ValueError("event_type is required")
        if payload is not None and not isinstance(payload,dict): raise TypeError("payload must be a dict")
        with self._lock:
            record=self.get(run_id)
            if record.state is not RunState.ACTIVE: raise RuntimeError("events require an ACTIVE run")
            event={"sequence":record.event_count+1,"timestamp":self._now(),"type":event_type,
                   "source":str(source or record.source).strip(),"payload":dict(payload or {})}
            with self._events(run_id).open("a",encoding="utf-8",newline="\n") as fh:
                fh.write(json.dumps(event,sort_keys=True,separators=(",",":"))+"\n"); fh.flush(); os.fsync(fh.fileno())
            manifest=json.loads(self._manifest(run_id).read_text(encoding="utf-8"))
            manifest["event_count"]=event["sequence"]
            self._refresh_integrity(run_id,manifest)
        return event

    def events(self,run_id):
        self.get(run_id); rows=[]
        for line in self._events(run_id).read_text(encoding="utf-8").splitlines():
            if line.strip(): rows.append(json.loads(line))
        return tuple(rows)

    def associate(self,run_id,association_type,identifier,*,source=None,metadata=None):
        """Attach a durable provenance link to a job/module/session/configuration entity."""
        association_type=str(association_type).strip().upper()
        identifier=str(identifier).strip()
        if not association_type: raise ValueError("association_type is required")
        if not identifier: raise ValueError("association identifier is required")
        if metadata is not None and not isinstance(metadata,dict):
            raise TypeError("association metadata must be a dict")
        with self._lock:
            record=self.get(run_id)
            if record.state is not RunState.ACTIVE:
                raise RuntimeError("associations require an ACTIVE run")
            safe_metadata=self._json_safe(metadata or {})
            manifest=json.loads(self._manifest(run_id).read_text(encoding="utf-8"))
            associations=list(manifest.get("associations",[]))
            key=(association_type,identifier)
            if any((item.get("type"),item.get("identifier")) == key for item in associations):
                raise ValueError("association already exists")
            row={
                "sequence":len(associations)+1,"timestamp":self._now(),
                "type":association_type,"identifier":identifier,
                "source":str(source or record.source).strip(),
                "metadata":safe_metadata,
            }
            associations.append(row)
            manifest["associations"]=associations
            manifest["association_count"]=len(associations)
            self._refresh_integrity(run_id,manifest)
        return row

    def associations(self,run_id,association_type=None):
        self.get(run_id)
        manifest=json.loads(self._manifest(run_id).read_text(encoding="utf-8"))
        rows=list(manifest.get("associations",[]))
        if association_type is not None:
            wanted=str(association_type).strip().upper()
            rows=[row for row in rows if row.get("type") == wanted]
        return tuple(rows)

    @staticmethod
    def _json_safe(value):
        """Validate/copy a value through JSON without silently stringifying objects."""
        try:
            return json.loads(json.dumps(value,allow_nan=False))
        except (TypeError,ValueError) as exc:
            raise TypeError("snapshot payload must contain finite JSON-compatible values") from exc

    def capture_snapshot(self,run_id,snapshot_type,payload,*,source=None,revision=None):
        """Persist an immutable run snapshot such as configuration or parameter state."""
        snapshot_type=str(snapshot_type).strip().upper()
        if not snapshot_type: raise ValueError("snapshot_type is required")
        if not isinstance(payload,dict): raise TypeError("snapshot payload must be a dict")
        with self._lock:
            record=self.get(run_id)
            if record.state is not RunState.ACTIVE:
                raise RuntimeError("snapshots require an ACTIVE run")
            safe_payload=self._json_safe(payload)
            manifest=json.loads(self._manifest(run_id).read_text(encoding="utf-8"))
            sequence=int(manifest.get("snapshot_count",0))+1
            filename=f"snapshot_{sequence:04d}_{snapshot_type.lower()}.json"
            snapshot={
                "schema":1,"sequence":sequence,"timestamp":self._now(),
                "type":snapshot_type,"source":str(source or record.source).strip(),
                "revision":revision,"payload":safe_payload,
            }
            self._atomic_json(self._dir(run_id)/filename,snapshot)
            snapshots=list(manifest.get("snapshots",[]))
            snapshots.append({
                "sequence":sequence,"type":snapshot_type,"source":snapshot["source"],
                "revision":revision,"timestamp":snapshot["timestamp"],"file":filename,
            })
            manifest["snapshots"]=snapshots
            manifest["snapshot_count"]=sequence
            self._refresh_integrity(run_id,manifest)
        return snapshot

    def snapshots(self,run_id):
        record=self.get(run_id)
        manifest=json.loads(self._manifest(run_id).read_text(encoding="utf-8"))
        rows=[]
        for entry in manifest.get("snapshots",[]):
            path=self._dir(run_id)/entry["file"]
            if path.exists(): rows.append(json.loads(path.read_text(encoding="utf-8")))
        return tuple(rows)

    def _append_stream_sample_unlocked(self,run_id,definition,sample,manifest):
        if sample.stream_id != definition.stream_id:
            raise ValueError("sample/definition stream mismatch")
        origin=getattr(definition.origin,"value",str(definition.origin))
        sample_origin=getattr(sample.origin,"value",str(sample.origin))
        if origin != sample_origin or definition.source != sample.source:
            raise ValueError("sample provenance does not match stream definition")
        row={"stream_id":definition.stream_id,"name":definition.name,"unit":definition.unit,
             "origin":origin,"source":definition.source,"sequence":sample.sequence,
             "timestamp":sample.timestamp,"frame_id":sample.frame_id,"value":sample.value,
             "metadata":dict(sample.metadata or {})}
        sample_path=self._dir(run_id)/"samples.jsonl"
        with sample_path.open("a",encoding="utf-8",newline="\n") as fh:
            fh.write(json.dumps(row,sort_keys=True,separators=(",",":"))+"\n")
        streams=dict(manifest.get("streams",{}))
        streams[definition.stream_id]={"name":definition.name,"unit":definition.unit,"origin":origin,"source":definition.source}
        manifest["streams"]=streams
        manifest["sample_count"]=int(manifest.get("sample_count",0))+1
        return row

    def capture_stream_sample(self,run_id,definition,sample):
        """Persist one sample. Integrity is finalized after the append rather than rehashing the growing journal per byte."""
        with self._lock:
            record=self.get(run_id)
            if record.state is not RunState.ACTIVE: raise RuntimeError("samples require an ACTIVE run")
            manifest=json.loads(self._manifest(run_id).read_text(encoding="utf-8"))
            row=self._append_stream_sample_unlocked(run_id,definition,sample,manifest)
            # Keep manifest durable, but defer expensive journal hashing to integrity verification/finalization.
            manifest["integrity_dirty"]=True
            self._atomic_json(self._manifest(run_id),manifest)
        return row

    def capture_stream_since(self,run_id,engine,stream_id,after_sequence=0,limit=None):
        """Cursor-based retained-stream capture with explicit retention-gap evidence."""
        with self._lock:
            record=self.get(run_id)
            if record.state is not RunState.ACTIVE: raise RuntimeError("samples require an ACTIVE run")
            definition=engine.definition(stream_id)
            read=engine.read_since(stream_id,after_sequence=after_sequence,limit=limit)
            manifest=json.loads(self._manifest(run_id).read_text(encoding="utf-8"))
            rows=[self._append_stream_sample_unlocked(run_id,definition,x,manifest) for x in read.samples]
            manifest["integrity_dirty"]=bool(rows) or bool(manifest.get("integrity_dirty"))
            self._atomic_json(self._manifest(run_id),manifest)
            if rows:
                sample_path=self._dir(run_id)/"samples.jsonl"
                with sample_path.open("a",encoding="utf-8") as fh: fh.flush(); os.fsync(fh.fileno())
        if read.gap_detected:
            self.append_event(run_id,"STREAM_RETENTION_GAP",source="joe.run-recorder",
                payload={"stream_id":stream_id,"requested_after_sequence":after_sequence,
                          "oldest_available_sequence":read.oldest_available_sequence,
                          "newest_available_sequence":read.newest_available_sequence})
        return read

    def samples(self,run_id,stream_id=None):
        self.get(run_id)
        path=self._dir(run_id)/"samples.jsonl"
        if not path.exists(): return ()
        rows=[]
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip(): continue
            row=json.loads(line)
            if stream_id is None or row["stream_id"] == stream_id: rows.append(row)
        return tuple(rows)

    def capture_retained_streams(self,run_id,stream_engine,stream_ids):
        """Capture currently retained canonical samples; never synthesizes missing data."""
        count=0
        for stream_id in stream_ids:
            definition=stream_engine.definition(stream_id)
            for sample in stream_engine.history(stream_id):
                self.capture_stream_sample(run_id,definition,sample)
                count+=1
        return count

    def status(self):
        runs=self.list_runs()
        active=tuple(run.run_id for run in runs if run.state is RunState.ACTIVE)
        return RunRecorderStatus(
            len(runs),len(active),
            sum(run.state is RunState.COMPLETED for run in runs),
            sum(run.state is RunState.FAILED for run in runs),
            sum(run.state is RunState.CANCELLED for run in runs),
            active,
        )

    def recover_interrupted_run(self,run_id,*,reason="JOE restarted while run was ACTIVE"):
        """Close a stale ACTIVE record as FAILED without inventing scientific results."""
        with self._lock:
            record=self.get(run_id)
            if record.state is not RunState.ACTIVE:
                return RunRecoveryReport(record.run_id,False,record.state.value,record.state.value,
                                         "run is not ACTIVE")
            manifest=json.loads(self._manifest(run_id).read_text(encoding="utf-8"))
            event_path=self._dir(run_id)/self.EVENTS
            events=self.events(run_id)
            sequence=len(events)+1
            event={"sequence":sequence,"timestamp":self._now(),"type":"RUN_RECOVERED_INTERRUPTED",
                   "source":"joe.runs","payload":{"reason":str(reason)}}
            with event_path.open("a",encoding="utf-8",newline="\n") as fh:
                fh.write(json.dumps(event,sort_keys=True,separators=(",",":"))+"\n")
                fh.flush(); os.fsync(fh.fileno())
            manifest["event_count"]=sequence
            manifest["state"]=RunState.FAILED.value
            manifest["ended_at"]=self._now()
            metadata=dict(manifest.get("metadata",{}))
            metadata["recovery"]={"interrupted":True,"reason":str(reason)}
            manifest["metadata"]=metadata
            self._refresh_integrity(run_id,manifest)
            return RunRecoveryReport(record.run_id,True,record.state.value,RunState.FAILED.value,str(reason))

    def recover_all_interrupted(self,*,reason="JOE restarted while run was ACTIVE"):
        reports=[]
        for record in self.list_runs():
            if record.state is RunState.ACTIVE:
                reports.append(self.recover_interrupted_run(record.run_id,reason=reason))
        return tuple(reports)
    def finalize_integrity(self,run_id):
        """Recompute complete SHA-256 payload integrity at a deliberate checkpoint."""
        with self._lock:
            manifest=json.loads(self._manifest(run_id).read_text(encoding="utf-8"))
            manifest.pop("integrity_dirty",None)
            return self._refresh_integrity(run_id,manifest)


    def verify_integrity(self,run_id):
        """Verify indexed run payloads against manifest SHA-256 hashes."""
        self.get(run_id)
        manifest=json.loads(self._manifest(run_id).read_text(encoding="utf-8"))
        integrity=manifest.get("integrity",{})
        failures=[]
        if manifest.get("integrity_dirty"):
            failures.append("integrity checkpoint required: run payload changed since last full hash")
        if integrity.get("algorithm") != "sha256":
            failures.append("unsupported or missing integrity algorithm")
        expected=dict(integrity.get("files",{}))
        directory=self._dir(run_id)
        for filename,digest in expected.items():
            path=directory/filename
            if not path.exists():
                failures.append(f"missing file: {filename}")
            elif self._sha256(path) != digest:
                failures.append(f"hash mismatch: {filename}")
        actual={
            path.name for path in directory.iterdir()
            if path.is_file() and path.name != self.MANIFEST and not path.name.endswith(".tmp")
        }
        for filename in sorted(actual-set(expected)):
            failures.append(f"unindexed file: {filename}")
        return RunIntegrityReport(str(run_id),not failures,len(expected),tuple(failures))

    def finish(self,run_id,state=RunState.COMPLETED,*,metadata_update=None):
        if state not in {RunState.COMPLETED,RunState.FAILED,RunState.CANCELLED}:
            raise ValueError("finish state must be terminal")
        if metadata_update is not None and not isinstance(metadata_update,dict):
            raise TypeError("metadata_update must be a dict")
        with self._lock:
            record=self.get(run_id)
            if record.state is not RunState.ACTIVE: raise RuntimeError("run is already terminal")
            manifest=json.loads(self._manifest(run_id).read_text(encoding="utf-8"))
            metadata=dict(manifest.get("metadata",{})); metadata.update(metadata_update or {})
            manifest["metadata"]=metadata; manifest["state"]=state.value; manifest["ended_at"]=self._now()
            self._refresh_integrity(run_id,manifest)
        return self.get(run_id)


def qualify_run_recorder(recorder):
    checks=[]; failures=[]
    try:
        runs=recorder.list_runs(); checks.append("run enumeration")
    except Exception as exc:
        return RunRecorderQualification(False,tuple(checks),(f"run enumeration failed: {exc}",))
    for run in runs:
        try:
            if run.mode not in {"SOFTWARE","HOST","IMPORTED","SIMULATION","HARDWARE"}:
                failures.append(f"{run.run_id}: invalid provenance mode")
            else: checks.append(f"{run.run_id}: provenance mode")
            events=recorder.events(run.run_id)
            if tuple(e.get("sequence") for e in events) != tuple(range(1,len(events)+1)):
                failures.append(f"{run.run_id}: event sequence discontinuity")
            if len(events)!=run.event_count: failures.append(f"{run.run_id}: event count mismatch")
            if len(recorder.samples(run.run_id))!=run.sample_count: failures.append(f"{run.run_id}: sample count mismatch")
            if len(recorder.snapshots(run.run_id))!=run.snapshot_count: failures.append(f"{run.run_id}: snapshot count mismatch")
            if len(recorder.associations(run.run_id))!=run.association_count: failures.append(f"{run.run_id}: association count mismatch")
            report=recorder.verify_integrity(run.run_id)
            if not report.passed: failures.extend(f"{run.run_id}: {x}" for x in report.failures)
            else: checks.append(f"{run.run_id}: payload integrity")
        except Exception as exc: failures.append(f"{run.run_id}: qualification exception: {exc}")
    return RunRecorderQualification(not failures,tuple(checks),tuple(failures))

def joe010_release_readiness(live_recorder):
    import tempfile
    from .data_streams import ScientificDataStreamEngine
    from .state_events import DataOrigin
    qualification=qualify_run_recorder(live_recorder); notes=list(qualification.failures)
    events=samples=snapshots=associations=integrity_files=0
    try:
        with tempfile.TemporaryDirectory() as td:
            isolated=RunRecorder(Path(td))
            run=isolated.start("JOE-010 isolated qualification",mode="SIMULATION",
                               source="joe010.qualification",metadata={"isolated":True})
            isolated.associate(run.run_id,"JOB","qualification-job",source="joe.jobs")
            isolated.associate(run.run_id,"MODULE","joe.core",source="joe.runtime")
            isolated.capture_snapshot(run.run_id,"CONFIGURATION",{"solver":{"step_s":0.001}},
                                      source="joe010.qualification",revision="qualification-1")
            streams=ScientificDataStreamEngine()
            definition=streams.register("qualification.signal","Signal","1",float,
                                        DataOrigin.SIMULATION,"joe010.qualification")
            for i in range(128):
                sample=streams.publish("qualification.signal",float(i),
                                       source="joe010.qualification",timestamp=1.0+i*0.001)
                isolated.capture_stream_sample(run.run_id,definition,sample)
            isolated.append_event(run.run_id,"START",{"phase":"qualification"})
            isolated.append_event(run.run_id,"COMPLETE",{"result":"pass"})
            finished=isolated.finish(run.run_id,RunState.COMPLETED)
            events,samples=finished.event_count,finished.sample_count
            snapshots,associations=finished.snapshot_count,finished.association_count
            integrity=isolated.verify_integrity(run.run_id); integrity_files=integrity.checked_files
            if not integrity.passed: notes.extend(integrity.failures)
            if (events,samples,snapshots,associations)!=(2,128,1,2):
                notes.append("isolated recorder counts did not match expected exercise")
            q=qualify_run_recorder(isolated)
            if not q.passed: notes.extend(f"isolated: {x}" for x in q.failures)
            interrupted=isolated.start("Interrupted qualification",mode="SOFTWARE",source="joe010.qualification")
            if isolated.status().active_runs != 1:
                notes.append("active-run status did not report isolated interrupted run")
            recovery=isolated.recover_interrupted_run(interrupted.run_id,reason="qualification restart")
            if not recovery.recovered or isolated.status().active_runs != 0:
                notes.append("interrupted-run recovery/status exercise failed")
            q2=qualify_run_recorder(isolated)
            if not q2.passed: notes.extend(f"post-recovery: {x}" for x in q2.failures)
    except Exception as exc: notes.append(f"isolated recorder exercise failed: {exc}")
    return RunRecorderReleaseReadiness(qualification.passed and not notes,qualification,events,samples,
                                       snapshots,associations,integrity_files,tuple(notes))
