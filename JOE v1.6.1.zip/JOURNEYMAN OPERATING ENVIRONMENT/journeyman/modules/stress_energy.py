"""Stress-Energy / Einstein Tensor Workbench module."""
from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.stress_energy import (
    energy_conditions, radial_exoticity, morris_thorne_sweep, integrate_spherical_shell,
    morris_thorne_proper_volume_integral, morris_thorne_nec_sensitivity,
    propagate_throat_radius_uncertainty, morris_thorne_condition_map, stress_energy_guardian_contract,
)

STRESS_ENERGY_MODULE=ModuleDescriptor(
    module_id="journeyman.stress-energy",name="Stress-Energy / Einstein Tensor Workbench",version="1.0.0",
    description="Energy-condition, exoticity, integration, and W-1 parameter-sweep analysis.",
    requires=("joe.core","journeyman.mpr","journeyman.geometry"),provides=("joe.stress-energy",),
    consumes=("joe.mpr","joe.geometry","joe.state-events"),
)
class StressEnergyService:
    def __init__(self,mpr,geometry):self.mpr=mpr;self.geometry=geometry
    def conditions(self,stress,*,tolerance_j_m3=0):return energy_conditions(stress,tolerance_j_m3=tolerance_j_m3)
    def exoticity(self,stress):return radial_exoticity(stress)
    def shell_integral(self,radii,energy_density,radial_nec):return integrate_spherical_shell(radii,energy_density,radial_nec)
    def sweep(self,throat_radii,radius_ratios,*,relative_step=5e-5):return morris_thorne_sweep(throat_radii,radius_ratios,relative_step=relative_step)
    def proper_volume(self,throat_radius,r_outer,**kwargs):return morris_thorne_proper_volume_integral(throat_radius=throat_radius,r_outer=r_outer,**kwargs)
    def sensitivity(self,throat_radius,radius_ratio=2.0):return morris_thorne_nec_sensitivity(throat_radius=throat_radius,radius_ratio=radius_ratio)
    def uncertainty(self,throat_radius,standard_uncertainty_m,radius_ratio=2.0):return propagate_throat_radius_uncertainty(throat_radius=throat_radius,standard_uncertainty_m=standard_uncertainty_m,radius_ratio=radius_ratio)
    def condition_map(self,throat_radii,radius_ratios):return morris_thorne_condition_map(throat_radii,radius_ratios)
    def guardian_contract(self,stress):return stress_energy_guardian_contract(stress)
class StressEnergyInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_stress_energy_module(runtime:ModuleRuntime):
    service=StressEnergyService(runtime.service("joe.mpr"),runtime.service("joe.geometry"))
    runtime.register(STRESS_ENERGY_MODULE,StressEnergyInstance(service));runtime.activate("journeyman.stress-energy")
    runtime.publish_service("journeyman.stress-energy","joe.stress-energy",service);return service
