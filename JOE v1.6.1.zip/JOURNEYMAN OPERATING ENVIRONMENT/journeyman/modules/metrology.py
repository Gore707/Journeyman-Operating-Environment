from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.metrology import (clock_offset,estimate_clock_drift,assess_synchronization,
 metrology_guardian_contract,metrology_core_readiness,allan_deviation,ensemble_time,
 synchronization_network,mouth_temporal_measurement,temporal_navigation_from_twin,
 expanded_metrology_guardian_contract,synchronization_anomalies,append_temporal_navigation,
 special_relativistic_proper_time,cross_check_proper_time,couple_metrology_d1_c1,
 metrology_001c_guardian_contract,metrology_v1_release_readiness)

MET_MODULE=ModuleDescriptor(
    module_id="journeyman.metrology",
    name="Metrology & Temporal Navigation",
    version="1.0.0",
    requires=("joe.core","journeyman.navigation"),
    provides=("joe.metrology",),
)

class MetrologyService:
    clock_offset=staticmethod(clock_offset)
    estimate_drift=staticmethod(estimate_clock_drift)
    assess_synchronization=staticmethod(assess_synchronization)
    guardian_contract=staticmethod(metrology_guardian_contract)
    release_readiness=staticmethod(metrology_v1_release_readiness)
    allan_deviation=staticmethod(allan_deviation)
    ensemble_time=staticmethod(ensemble_time)
    synchronization_network=staticmethod(synchronization_network)
    mouth_temporal_measurement=staticmethod(mouth_temporal_measurement)
    temporal_navigation_from_twin=staticmethod(temporal_navigation_from_twin)
    expanded_guardian_contract=staticmethod(expanded_metrology_guardian_contract)
    synchronization_anomalies=staticmethod(synchronization_anomalies)
    append_temporal_navigation=staticmethod(append_temporal_navigation)
    proper_time_prediction=staticmethod(special_relativistic_proper_time)
    cross_check_proper_time=staticmethod(cross_check_proper_time)
    couple_d1_c1=staticmethod(couple_metrology_d1_c1)
    guardian_contract_001c=staticmethod(metrology_001c_guardian_contract)

class MetrologyInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False

def register_metrology_module(runtime:ModuleRuntime):
    svc=MetrologyService();runtime.register(MET_MODULE,MetrologyInstance(svc));runtime.activate("journeyman.metrology")
    runtime.publish_service("journeyman.metrology","joe.metrology",svc);return svc
