from __future__ import annotations

import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path

from journeyman import __build__, __version__


@dataclass(frozen=True)
class RuntimeIdentity:
    build: str
    version: str
    pid: int
    started_monotonic: float
    executable: str
    working_directory: str


_STARTED = time.monotonic()


def identity() -> RuntimeIdentity:
    return RuntimeIdentity(
        build=__build__,
        version=__version__,
        pid=os.getpid(),
        started_monotonic=_STARTED,
        executable=sys.executable,
        working_directory=str(Path.cwd()),
    )


def uptime_seconds() -> float:
    return max(0.0, time.monotonic() - _STARTED)


def format_uptime(seconds: float | None = None) -> str:
    total = int(uptime_seconds() if seconds is None else max(0.0, seconds))
    hours, rem = divmod(total, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return f"{hours:d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"
