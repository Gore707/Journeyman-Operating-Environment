"""JOE-011 Run/Data Review Workbench core read model."""
from dataclasses import dataclass
from typing import Any
import csv
import io
import json
from .data_streams import ScientificDataStreamEngine
from .state_events import DataOrigin
from .visualization import VisualizationEngine

@dataclass(frozen=True)
class RunReviewStatus:
    total_runs: int
    readable_runs: int
    integrity_passed_runs: int
    integrity_failed_runs: int
    states: tuple[tuple[str, int], ...]

@dataclass(frozen=True)
class RunReviewQualification:
    passed: bool
    checks: tuple[str, ...]
    failures: tuple[str, ...]

@dataclass(frozen=True)
class RunReviewReleaseReadiness:
    passed: bool
    qualification_passed: bool
    isolated_exercise_passed: bool
    checks: tuple[str, ...]
    failures: tuple[str, ...]

@dataclass(frozen=True)
class ReviewPlotSpec:
    run_id: str
    stream_ids: tuple[str, ...]
    limit: int = 5000
    title: str = ""

    def __post_init__(self):
        if not str(self.run_id).strip():
            raise ValueError("run_id is required")
        if not self.stream_ids or any(not str(x).strip() for x in self.stream_ids):
            raise ValueError("at least one valid stream_id is required")
        if len(set(self.stream_ids)) != len(self.stream_ids):
            raise ValueError("stream_ids must be unique")
        if not isinstance(self.limit,int) or isinstance(self.limit,bool) or self.limit < 2:
            raise ValueError("limit must be an integer >= 2")

    def to_dict(self):
        return {"schema_version":1,"run_id":self.run_id,"stream_ids":list(self.stream_ids),
                "limit":self.limit,"title":self.title}

    @classmethod
    def from_dict(cls,payload):
        if int(payload.get("schema_version",0)) != 1:
            raise ValueError("unsupported review plot specification schema")
        return cls(str(payload["run_id"]),tuple(str(x) for x in payload["stream_ids"]),
                   int(payload.get("limit",5000)),str(payload.get("title","")))

@dataclass(frozen=True)
class RunComparison:
    left_run_id: str
    right_run_id: str
    common_stream_ids: tuple[str, ...]
    left_only_stream_ids: tuple[str, ...]
    right_only_stream_ids: tuple[str, ...]
    lifecycle_equal: bool
    mode_equal: bool
    source_equal: bool
    left_counts: tuple[int, int, int, int]
    right_counts: tuple[int, int, int, int]

@dataclass(frozen=True)
class RunReviewSummary:
    run: Any
    events: tuple[dict, ...]
    samples: tuple[dict, ...]
    snapshots: tuple[dict, ...]
    associations: tuple[dict, ...]
    integrity: Any
    stream_ids: tuple[str, ...]

class RunReviewService:
    """Read-only projection over canonical JOE run records."""
    def __init__(self, recorder): self._recorder=recorder
    def list_runs(self): return self._recorder.list_runs()

    def status(self):
        runs=self.list_runs(); readable=0; passed=0; failed=0; states={}
        for run in runs:
            states[run.state.value]=states.get(run.state.value,0)+1
            try:
                report=self._recorder.verify_integrity(run.run_id)
            except Exception:
                failed+=1
                continue
            if not report.passed:
                failed+=1
                continue
            passed+=1
            try:
                self.open_run(run.run_id); readable+=1
            except Exception:
                pass
        return RunReviewStatus(len(runs),readable,passed,failed,tuple(sorted(states.items())))

    def open_run(self,run_id):
        run=self._recorder.get(run_id)
        events=tuple(self._recorder.events(run_id)); samples=tuple(self._recorder.samples(run_id))
        snapshots=tuple(self._recorder.snapshots(run_id)); associations=tuple(self._recorder.associations(run_id))
        integrity=self._recorder.verify_integrity(run_id)
        stream_ids=tuple(sorted({str(x.get("stream_id")) for x in samples if x.get("stream_id")}))
        return RunReviewSummary(run,events,samples,snapshots,associations,integrity,stream_ids)
    def samples_for_stream(self,run_id,stream_id):
        if not str(stream_id).strip(): raise ValueError("stream_id is required")
        return tuple(self._recorder.samples(run_id,stream_id=str(stream_id)))
    def event_types(self,run_id):
        return tuple(sorted({str(x.get("type")) for x in self._recorder.events(run_id) if x.get("type")}))
    def snapshot_types(self,run_id):
        return tuple(sorted({str(x.get("type")) for x in self._recorder.snapshots(run_id) if x.get("type")}))
    def association_types(self,run_id):
        return tuple(sorted({str(x.get("type")) for x in self._recorder.associations(run_id) if x.get("type")}))

    def filter_events(self,run_id,*,event_type=None,source=None,limit=None):
        rows=list(self._recorder.events(run_id))
        if event_type is not None:
            wanted=str(event_type).strip()
            rows=[x for x in rows if str(x.get("type",""))==wanted]
        if source is not None:
            wanted=str(source).strip()
            rows=[x for x in rows if str(x.get("source",""))==wanted]
        if limit is not None:
            limit=int(limit)
            if limit < 0: raise ValueError("limit must be >= 0")
            rows=rows[-limit:] if limit else []
        return tuple(rows)

    def filter_samples(self,run_id,*,stream_id=None,origin=None,source=None,start_timestamp=None,end_timestamp=None,limit=None):
        rows=list(self._recorder.samples(run_id,stream_id=stream_id) if stream_id else self._recorder.samples(run_id))
        if origin is not None:
            wanted=getattr(origin,"value",origin)
            rows=[x for x in rows if str(x.get("origin",""))==str(wanted)]
        if source is not None:
            wanted=str(source).strip()
            rows=[x for x in rows if str(x.get("source",""))==wanted]
        if start_timestamp is not None:
            rows=[x for x in rows if float(x.get("timestamp",0))>=float(start_timestamp)]
        if end_timestamp is not None:
            rows=[x for x in rows if float(x.get("timestamp",0))<=float(end_timestamp)]
        if start_timestamp is not None and end_timestamp is not None and float(start_timestamp)>float(end_timestamp):
            raise ValueError("start_timestamp must be <= end_timestamp")
        if limit is not None:
            limit=int(limit)
            if limit < 0: raise ValueError("limit must be >= 0")
            rows=rows[-limit:] if limit else []
        return tuple(rows)

    def sources(self,run_id):
        summary=self.open_run(run_id)
        values={str(x.get("source")) for x in summary.events+summary.samples+summary.associations if x.get("source")}
        return tuple(sorted(values))

    def visualization_for_run(self,run_id):
        """Build an isolated visualization engine from recorded samples only."""
        summary=self.open_run(run_id)
        engine=ScientificDataStreamEngine(history_limit_per_stream=max(1,len(summary.samples)+1))
        grouped={}
        for row in summary.samples:
            grouped.setdefault(row["stream_id"],[]).append(row)
        for stream_id,rows in grouped.items():
            first=rows[0]
            values=[row.get("value") for row in rows]
            if not values or not all(isinstance(v,(int,float)) and not isinstance(v,bool) for v in values):
                continue
            value_type=float if any(isinstance(v,float) for v in values) else int
            origin=DataOrigin(str(first["origin"]))
            definition=engine.register(stream_id,str(first.get("name") or stream_id),
                                       str(first.get("unit") or ""),value_type,origin,
                                       str(first["source"]),description="Recorded JOE run data")
            for row in rows:
                engine.publish(stream_id,row["value"],source=definition.source,
                               timestamp=float(row["timestamp"]),
                               metadata={"recorded_sequence":str(row["sequence"]),
                                         "recorded_run_id":run_id})
        return VisualizationEngine(engine)

    def recorded_time_series(self,run_id,stream_ids,*,limit=5000,title=None):
        engine=self.visualization_for_run(run_id)
        return engine.time_series(list(stream_ids),limit=limit,
                                  title=title or f"Recorded Run {run_id}")

    def create_plot_spec(self,run_id,stream_ids,*,limit=5000,title=""):
        available=set(self.open_run(run_id).stream_ids)
        selected=tuple(str(x) for x in stream_ids)
        missing=tuple(x for x in selected if x not in available)
        if missing:
            raise KeyError(f"recorded stream(s) not present in run: {', '.join(missing)}")
        return ReviewPlotSpec(run_id,selected,limit,str(title))

    def render_plot_spec(self,spec):
        if not isinstance(spec,ReviewPlotSpec):
            raise TypeError("spec must be ReviewPlotSpec")
        return self.recorded_time_series(spec.run_id,spec.stream_ids,limit=spec.limit,
                                         title=spec.title or f"Recorded Run {spec.run_id}")

    @staticmethod
    def export_plot_spec_json(spec):
        if not isinstance(spec,ReviewPlotSpec):
            raise TypeError("spec must be ReviewPlotSpec")
        return json.dumps(spec.to_dict(),sort_keys=True,indent=2)+"\n"

    @staticmethod
    def import_plot_spec_json(text):
        payload=json.loads(text)
        if not isinstance(payload,dict):
            raise ValueError("review plot specification must be a JSON object")
        return ReviewPlotSpec.from_dict(payload)

    def compare_runs(self,left_run_id,right_run_id):
        left=self.open_run(left_run_id); right=self.open_run(right_run_id)
        ls=set(left.stream_ids); rs=set(right.stream_ids)
        return RunComparison(
            left_run_id,right_run_id,tuple(sorted(ls&rs)),tuple(sorted(ls-rs)),tuple(sorted(rs-ls)),
            left.run.state==right.run.state,left.run.mode==right.run.mode,left.run.source==right.run.source,
            (len(left.events),len(left.samples),len(left.snapshots),len(left.associations)),
            (len(right.events),len(right.samples),len(right.snapshots),len(right.associations)),
        )

    def export_samples_csv(self,run_id,*,stream_id=None):
        rows=self.filter_samples(run_id,stream_id=stream_id)
        out=io.StringIO(newline="")
        fields=("sequence","timestamp","stream_id","name","unit","value","origin","source","frame_id","metadata")
        writer=csv.DictWriter(out,fieldnames=fields,extrasaction="ignore",lineterminator="\n")
        writer.writeheader()
        for row in rows:
            item=dict(row)
            item["metadata"]=json.dumps(item.get("metadata",{}),sort_keys=True,separators=(",",":"))
            writer.writerow(item)
        return out.getvalue()

    def export_events_csv(self,run_id):
        rows=self.filter_events(run_id)
        out=io.StringIO(newline="")
        fields=("sequence","timestamp","type","source","payload")
        writer=csv.DictWriter(out,fieldnames=fields,extrasaction="ignore",lineterminator="\n")
        writer.writeheader()
        for row in rows:
            item=dict(row); item["payload"]=json.dumps(item.get("payload",{}),sort_keys=True,separators=(",",":"))
            writer.writerow(item)
        return out.getvalue()


def qualify_run_review(review):
    checks=[]; failures=[]
    try:
        runs=review.list_runs()
        checks.append("run repository readable")
        for run in runs:
            try:
                integrity=review._recorder.verify_integrity(run.run_id)
            except Exception as exc:
                failures.append(f"integrity verification error for {run.run_id}: {exc}")
                continue
            if not integrity.passed:
                failures.append(f"integrity failed for {run.run_id}")
                continue
            try:
                summary=review.open_run(run.run_id)
            except Exception as exc:
                failures.append(f"review parse failed for {run.run_id}: {exc}")
                continue
            if summary.run.run_id != run.run_id:
                failures.append(f"identity mismatch for {run.run_id}")
        if not failures:
            checks.append("all persisted run identities, journals, and integrity reports valid")
    except Exception as exc:
        failures.append(f"repository qualification failed: {exc}")
    return RunReviewQualification(not failures,tuple(checks),tuple(failures))

def joe011_release_readiness(review):
    import tempfile
    from pathlib import Path
    from .run_recorder import RunRecorder
    from .data_streams import ScientificDataStreamEngine
    checks=[]; failures=[]
    qualification=qualify_run_review(review)
    if qualification.passed: checks.append("live repository qualification passed")
    else: failures.extend(qualification.failures)
    isolated_ok=False
    try:
        with tempfile.TemporaryDirectory() as td:
            recorder=RunRecorder(Path(td))
            run=recorder.start("JOE-011 isolated review qualification",mode="SIMULATION",source="joe011.qualification")
            streams=ScientificDataStreamEngine()
            definition=streams.register("qualification.signal","Qualification Signal","arb",float,
                                        DataOrigin.SIMULATION,"joe011.qualification")
            for i in range(16):
                recorder.capture_stream_sample(
                    run.run_id,definition,
                    streams.publish("qualification.signal",float(i),source="joe011.qualification",timestamp=1000.0+i)
                )
            recorder.append_event(run.run_id,"QUALIFICATION_EVENT",{"samples":16},source="joe011.qualification")
            recorder.capture_snapshot(run.run_id,"CONFIGURATION",{"qualification":True},source="joe011.qualification")
            recorder.associate(run.run_id,"MODULE","JOE_CORE",source="joe011.qualification")
            recorder.finish(run.run_id)
            isolated=RunReviewService(recorder)
            summary=isolated.open_run(run.run_id)
            spec=isolated.create_plot_spec(run.run_id,("qualification.signal",),limit=16,title="Qualification")
            view=isolated.render_plot_spec(spec)
            csv_text=isolated.export_samples_csv(run.run_id)
            isolated_ok=(summary.integrity.passed and len(summary.samples)==16 and
                         len(view.traces)==1 and len(view.traces[0].values)==16 and
                         "qualification.signal" in csv_text and
                         isolated.import_plot_spec_json(isolated.export_plot_spec_json(spec))==spec)
            if isolated_ok: checks.append("isolated record→review→visualize→export→reproduce exercise passed")
            else: failures.append("isolated review exercise returned inconsistent evidence")
    except Exception as exc:
        failures.append(f"isolated review exercise failed: {exc}")
    return RunReviewReleaseReadiness(not failures,qualification.passed,isolated_ok,tuple(checks),tuple(failures))
