from pathlib import Path
from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.scientific_reference import ScientificReferenceLibrary
REF_MODULE=ModuleDescriptor(module_id="journeyman.scientific-reference",name="Scientific Reference Library",version="1.0.0",
 requires=("joe.core",),provides=("joe.scientific-reference",),consumes=())
class ReferenceInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_scientific_reference_module(runtime:ModuleRuntime,root:Path):
    svc=ScientificReferenceLibrary(root);runtime.register(REF_MODULE,ReferenceInstance(svc));runtime.activate("journeyman.scientific-reference")
    runtime.publish_service("journeyman.scientific-reference","joe.scientific-reference",svc);return svc
