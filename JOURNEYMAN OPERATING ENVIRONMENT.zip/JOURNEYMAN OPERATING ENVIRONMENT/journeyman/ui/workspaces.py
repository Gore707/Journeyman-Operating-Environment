from PySide6.QtWidgets import QGroupBox
from PySide6.QtWidgets import QAbstractItemView
from PySide6.QtWidgets import QDialogButtonBox
from PySide6.QtWidgets import QFormLayout
from PySide6.QtWidgets import QDialog
from PySide6.QtWidgets import QLineEdit
import time
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QComboBox, QPushButton, QFileDialog, QMessageBox, QVBoxLayout, QHBoxLayout, QLabel
import pyqtgraph as pg
import pyqtgraph.exporters
import base64
import logging
from pathlib import Path
from uuid import uuid4

from PySide6.QtCore import QByteArray, Qt, QTimer, Signal, QEvent
from PySide6.QtGui import QAction, QCloseEvent, QFont
from PySide6.QtWidgets import (
    QGridLayout, QLabel, QMainWindow, QMdiArea, QMdiSubWindow, QPlainTextEdit, QDoubleSpinBox, QTableWidget, QTableWidgetItem,
    QPushButton, QVBoxLayout, QWidget
)

from journeyman import __build__, __version__
from journeyman.core.logging_service import LOG_FILE
from journeyman.core.runtime import format_uptime
from journeyman.core.system_info import snapshot

log = logging.getLogger("journeyman.workspaces")


def geometry_to_b64(widget: QWidget) -> str:
    return base64.b64encode(bytes(widget.saveGeometry())).decode("ascii")


def restore_geometry_b64(widget: QWidget, encoded: str) -> bool:
    if not encoded:
        return False
    try:
        data = base64.b64decode(encoded.encode("ascii"), validate=True)
        return bool(widget.restoreGeometry(QByteArray(data)))
    except Exception:
        return False


class WorkspaceArea(QMdiArea):
    """JOE-owned desktop for simultaneously active workspace windows."""
    workspace_changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setActivationOrder(QMdiArea.ActivationHistoryOrder)
        self.setViewMode(QMdiArea.SubWindowView)
        self.setOption(QMdiArea.DontMaximizeSubWindowOnActivation, True)
        self.subWindowActivated.connect(lambda _window: self.workspace_changed.emit())

    def add_workspace(self, widget: QWidget, title: str, *, kind: str, width: int = 760, height: int = 500, workspace_id: str | None = None) -> QMdiSubWindow:
        sub = QMdiSubWindow(self)
        sub.setAttribute(Qt.WA_DeleteOnClose, True)
        sub.setProperty("joe_workspace_kind", kind)
        sub.setProperty("joe_workspace_id", workspace_id or str(uuid4()))
        sub.setWidget(widget)
        sub.setWindowTitle(title)
        sub.resize(width, height)
        self.addSubWindow(sub)
        sub.destroyed.connect(lambda _obj=None: self.workspace_changed.emit())
        sub.show()
        self.workspace_changed.emit()
        log.info("Workspace opened: %s [%s]", title, kind)
        return sub

    def close_all_workspaces(self) -> None:
        self.closeAllSubWindows()
        self.workspace_changed.emit()

    def detach_active(self):
        sub = self.activeSubWindow()
        if sub is None:
            return None
        widget = sub.widget()
        if widget is None:
            return None
        kind = str(sub.property("joe_workspace_kind") or "")
        title = sub.windowTitle()
        was_maximized = sub.isMaximized()
        workspace_id = str(sub.property("joe_workspace_id") or str(uuid4()))
        widget.setParent(None)
        sub.close()
        self.workspace_changed.emit()
        log.info("Workspace detached: %s [%s]", title, kind)
        return widget, title, kind, was_maximized, workspace_id


class ExternalWorkspaceWindow(QMainWindow):
    """Top-level workspace window that can move independently across monitors."""
    reattach_requested = Signal(object)
    closed = Signal(object)
    activated = Signal(object)

    def __init__(self, widget: QWidget, title: str, kind: str, parent=None, workspace_id: str | None = None):
        super().__init__(parent)
        self.workspace_kind = kind
        self.workspace_id = workspace_id or str(uuid4())
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.setWindowTitle(f"{title} — JOE")
        self.setCentralWidget(widget)
        self.resize(820, 540)
        menu = self.menuBar().addMenu("&Workspace")
        reattach = QAction("Reattach to JOE", self)
        reattach.setShortcut("Ctrl+Shift+R")
        reattach.triggered.connect(lambda: self.reattach_requested.emit(self))
        menu.addAction(reattach)

    def take_workspace(self) -> QWidget:
        widget = self.takeCentralWidget()
        if widget is not None:
            widget.setParent(None)
        return widget

    def base_title(self) -> str:
        suffix = " — JOE"
        title = self.windowTitle()
        return title[:-len(suffix)] if title.endswith(suffix) else title

    def activateWindow(self) -> None:
        super().activateWindow()
        self.activated.emit(self)

    def event(self, event) -> bool:
        result = super().event(event)
        if event.type() == QEvent.WindowActivate:
            self.activated.emit(self)
        return result

    def closeEvent(self, event: QCloseEvent) -> None:
        self.closed.emit(self)
        super().closeEvent(event)


class OverviewWorkspace(QWidget):
    """A real JOE overview window backed by current host/process telemetry."""

    def __init__(self, refresh_ms: int = 1000, parent=None):
        super().__init__(parent)
        self.refresh_ms = max(250, int(refresh_ms))
        layout = QVBoxLayout(self)
        heading = QLabel("JOE OVERVIEW")
        heading.setStyleSheet("font-size: 22px; font-weight: 700;")
        detail = QLabel(f"{__build__}  •  Version {__version__}")
        layout.addWidget(heading)
        layout.addWidget(detail)
        grid = QGridLayout()
        self.cpu = self._value_label(); self.ram = self._value_label(); self.proc = self._value_label()
        self.threads = self._value_label(); self.uptime = self._value_label(); self.health = self._value_label()
        values = [("Host CPU", self.cpu), ("Host RAM", self.ram), ("JOE Memory", self.proc),
                  ("JOE Threads", self.threads), ("JOE Uptime", self.uptime), ("Environment", self.health)]
        for i, (name, value) in enumerate(values):
            box = QWidget(); box_layout = QVBoxLayout(box); label = QLabel(name); label.setStyleSheet("font-weight: 600;")
            box_layout.addWidget(label); box_layout.addWidget(value); grid.addWidget(box, i // 2, i % 2)
        layout.addLayout(grid)
        note = QLabel("Values in this workspace are current measurements from the host operating system. Unsupported measurements are not synthesized.")
        note.setWordWrap(True); layout.addWidget(note); layout.addStretch(1)
        self.timer = QTimer(self); self.timer.timeout.connect(self.refresh); self.timer.start(self.refresh_ms); self.refresh()

    @staticmethod
    def _value_label() -> QLabel:
        label = QLabel("—"); label.setStyleSheet("font-size: 18px;"); return label

    def refresh(self) -> None:
        try:
            s = snapshot(); self.cpu.setText(f"{s.cpu_percent:.1f}%")
            self.ram.setText(f"{s.ram_used_gb:.1f} / {s.ram_total_gb:.1f} GB  ({s.ram_percent:.1f}%)")
            self.proc.setText(f"{s.process_ram_mb:.1f} MB"); self.threads.setText(str(s.threads))
            self.uptime.setText(format_uptime()); self.health.setText("JOE responsive")
        except Exception:
            log.exception("Overview telemetry refresh failed"); self.health.setText("Telemetry warning — see JOE log")


class LogWorkspace(QWidget):
    """Non-modal workspace for inspecting JOE's actual rotating application log."""

    def __init__(self, log_file: Path = LOG_FILE, parent=None):
        super().__init__(parent); self.log_file = Path(log_file); layout = QVBoxLayout(self)
        heading = QLabel("JOE APPLICATION LOG"); heading.setStyleSheet("font-size: 20px; font-weight: 700;"); layout.addWidget(heading)
        self.viewer = QPlainTextEdit(); self.viewer.setReadOnly(True); self.viewer.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.viewer.setFont(QFont("Consolas", 9)); layout.addWidget(self.viewer, 1)
        refresh = QPushButton("Refresh"); refresh.clicked.connect(self.reload); layout.addWidget(refresh, alignment=Qt.AlignRight); self.reload()

    def reload(self) -> None:
        try:
            text = self.log_file.read_text(encoding="utf-8", errors="replace") if self.log_file.exists() else "JOE log file does not exist yet."
            self.viewer.setPlainText(text); cursor = self.viewer.textCursor(); cursor.movePosition(cursor.End); self.viewer.setTextCursor(cursor)
        except Exception as exc:
            self.viewer.setPlainText(f"Unable to read JOE log:\n{exc}")



class LiveTimeSeriesWorkspace(QWidget):
    """Live multi-trace plot over canonical JOE numeric streams."""
    workspace_kind = "live_time_series"

    def __init__(self, visualization, parent=None):
        super().__init__(parent)
        self.visualization=visualization
        self._curves={}
        self._segment_curves={}

        root=QVBoxLayout(self)
        controls=QHBoxLayout()
        controls.addWidget(QLabel("Add stream:"))
        self.stream_combo=QComboBox()
        controls.addWidget(self.stream_combo,1)
        self.add_button=QPushButton("Add")
        controls.addWidget(self.add_button)
        self.remove_button=QPushButton("Remove Selected")
        controls.addWidget(self.remove_button)
        self.refresh_button=QPushButton("Refresh Streams")
        controls.addWidget(self.refresh_button)
        controls.addWidget(QLabel("Window:"))
        self.window_combo=QComboBox()
        self.window_combo.addItem("30 s",30.0)
        self.window_combo.addItem("60 s",60.0)
        self.window_combo.addItem("5 min",300.0)
        self.window_combo.addItem("All retained",None)
        controls.addWidget(self.window_combo)
        self.pause_button=QPushButton("Pause")
        self.pause_button.setCheckable(True)
        controls.addWidget(self.pause_button)
        self.autorange_button=QPushButton("Auto Range")
        controls.addWidget(self.autorange_button)
        self.export_button=QPushButton("Export CSV")
        controls.addWidget(self.export_button)
        self.export_png_button=QPushButton("Export PNG")
        controls.addWidget(self.export_png_button)
        self.export_svg_button=QPushButton("Export SVG")
        controls.addWidget(self.export_svg_button)
        root.addLayout(controls)

        self.selected_combo=QComboBox()
        root.addWidget(self.selected_combo)
        self.provenance_label=QLabel("No stream selected")
        self.provenance_label.setWordWrap(True)
        root.addWidget(self.provenance_label)

        self.plot=pg.PlotWidget()
        self.plot.showGrid(x=True,y=True,alpha=0.25);self.plot.setLabel("bottom","Time","s");self.plot.addLegend()
        self.plot_secondary=pg.PlotWidget()
        self.plot_secondary.showGrid(x=True,y=True,alpha=0.25);self.plot_secondary.setLabel("bottom","Time","s");self.plot_secondary.addLegend()
        self.plot_secondary.setXLink(self.plot)
        self.cursor_primary=pg.InfiniteLine(angle=90,movable=True,label="{value:0.6g} s")
        self.cursor_secondary=pg.InfiniteLine(angle=90,movable=False)
        self.plot.addItem(self.cursor_primary,ignoreBounds=True);self.plot_secondary.addItem(self.cursor_secondary,ignoreBounds=True)
        self.cursor_primary.sigPositionChanged.connect(lambda line:self.cursor_secondary.setValue(line.value()))
        root.addWidget(self.plot,1);root.addWidget(self.plot_secondary,1)

        self.status_label=QLabel("Waiting for stream data")
        root.addWidget(self.status_label)

        self.add_button.clicked.connect(self.add_stream)
        self.remove_button.clicked.connect(self.remove_stream)
        self.refresh_button.clicked.connect(self.refresh_streams)
        self.selected_combo.currentIndexChanged.connect(self._selection_changed)
        self.window_combo.currentIndexChanged.connect(self.refresh_plot)
        self.pause_button.toggled.connect(self._pause_changed)
        self.autorange_button.clicked.connect(self.plot.enableAutoRange)
        self.export_button.clicked.connect(self.export_csv)
        self.export_png_button.clicked.connect(lambda:self.export_figure("png"))
        self.export_svg_button.clicked.connect(lambda:self.export_figure("svg"))

        self.timer=QTimer(self)
        self.timer.setInterval(250)
        self.timer.timeout.connect(self.refresh_plot)
        self.refresh_streams()
        self.timer.start()

    def refresh_streams(self):
        current=self.stream_combo.currentData()
        self.stream_combo.blockSignals(True)
        self.stream_combo.clear()
        for stream_id in self.visualization.numeric_stream_ids():
            definition=self.visualization.streams.definition(stream_id)
            self.stream_combo.addItem(
                f"{definition.name} [{definition.unit or 'unitless'}] — {definition.origin.value}",
                stream_id
            )
        if current:
            index=self.stream_combo.findData(current)
            if index >= 0:
                self.stream_combo.setCurrentIndex(index)
        self.stream_combo.blockSignals(False)

    def _selected_ids(self):
        return tuple(self.selected_combo.itemData(i) for i in range(self.selected_combo.count()))

    def add_stream(self):
        stream_id=self.stream_combo.currentData()
        if not stream_id or stream_id in self._selected_ids():
            return
        definition=self.visualization.streams.definition(stream_id)
        selected=self._selected_ids()
        if selected:
            first=self.visualization.streams.definition(selected[0])
            if definition.unit != first.unit:
                from PySide6.QtWidgets import QMessageBox
                QMessageBox.warning(
                    self,"Unit mismatch",
                    f"Cannot overlay {definition.name} [{definition.unit or 'unitless'}] with "
                    f"{first.name} [{first.unit or 'unitless'}] on one Y axis."
                )
                return
        self.selected_combo.addItem(definition.name,stream_id)
        self.selected_combo.setCurrentIndex(self.selected_combo.count()-1)
        self.refresh_plot()

    def remove_stream(self):
        index=self.selected_combo.currentIndex()
        if index >= 0:
            self.selected_combo.removeItem(index)
            self.refresh_plot()

    def _selection_changed(self,*_):
        ids=self._selected_ids()
        if not ids:
            self.provenance_label.setText("No plotted stream selected")
            return
        selected=self.selected_combo.currentData()
        definition=self.visualization.streams.definition(selected)
        self.provenance_label.setText(
            f"Selected trace — Origin: {definition.origin.value} | Source: {definition.source} | "
            f"Stream: {definition.stream_id} | Unit: {definition.unit or 'unitless'}"
        )

    def _pause_changed(self, paused):
        self.pause_button.setText("Resume" if paused else "Pause")
        if paused:
            self.timer.stop()
            self.status_label.setText(self.status_label.text() + " | PAUSED")
        else:
            self.timer.start()
            self.refresh_plot()

    def refresh_plot(self):
        ids=self._selected_ids()
        cursor_value=self.cursor_primary.value()
        self.plot.clear();self.plot_secondary.clear()
        self.plot.addLegend();self.plot_secondary.addLegend()
        self.cursor_primary=pg.InfiniteLine(pos=cursor_value,angle=90,movable=True,label="{value:0.6g} s")
        self.cursor_secondary=pg.InfiniteLine(pos=cursor_value,angle=90,movable=False)
        self.cursor_primary.sigPositionChanged.connect(lambda line:self.cursor_secondary.setValue(line.value()))
        self.plot.addItem(self.cursor_primary,ignoreBounds=True);self.plot_secondary.addItem(self.cursor_secondary,ignoreBounds=True)
        if not ids:
            self.status_label.setText("Add one or more numeric streams to begin plotting.")
            return
        window_seconds=self.window_combo.currentData()
        view=self.visualization.time_series(
            ids,limit=5000,window_seconds=window_seconds
        )
        first_timestamp=view.window_start
        if first_timestamp is None:
            first_timestamp=min(
                (trace.timestamps[0] for trace in view.traces if trace.timestamps),
                default=None
            )
        gaps=[]
        decimated=[]
        for trace_index,trace in enumerate(view.traces):
            if not trace.timestamps or first_timestamp is None:
                continue
            display=self.visualization.display_trace(
                trace.stream_id,limit=5000,max_points=1200,
                start_timestamp=view.window_start,end_timestamp=view.window_end
            )
            definition=self.visualization.streams.definition(trace.stream_id)
            for seg_index,(start,end) in enumerate(display.segments):
                x=[stamp-first_timestamp for stamp in display.timestamps[start:end]]
                y=list(display.values[start:end])
                name=definition.name if seg_index == 0 else None
                target_plot=self.plot if trace_index % 2 == 0 else self.plot_secondary
                target_plot.plot(x,y,name=name)
            if trace.gap_detected:
                gaps.append(trace.name)
            if display.decimated:
                decimated.append(
                    f"{definition.name} {display.source_count}->{display.displayed_count}"
                )
        unit=view.common_unit
        if unit is not None:
            self.plot.setLabel("left","Value",units=unit or None);self.plot_secondary.setLabel("left","Value",units=unit or None)
        else:
            self.plot.setLabel("left","Value");self.plot_secondary.setLabel("left","Value")
        window_text=(
            f"{window_seconds:g} s synchronized window"
            if window_seconds is not None else "all retained data"
        )
        status=(
            f"{len(view.traces)} trace(s) | {window_text} | "
            + (f"DATA GAP: {', '.join(gaps)}" if gaps else "No retained sequence gaps detected")
        )
        if decimated:
            status += " | DISPLAY DECIMATION: " + ", ".join(decimated)
        status += " | Mouse wheel/drag: zoom/pan; Auto Range resets view"
        self.status_label.setText(status)
        self._selection_changed()



    def export_figure(self,kind):
        if not self._selected_ids():
            QMessageBox.information(self,"Export","Select at least one stream before exporting.");return
        suffix=".png" if kind=="png" else ".svg"
        filt="PNG files (*.png)" if kind=="png" else "SVG files (*.svg)"
        path,_=QFileDialog.getSaveFileName(self,f"Export {kind.upper()} Figure","joe_timeseries"+suffix,filt)
        if not path:return
        if not path.lower().endswith(suffix):path+=suffix
        try:
            if kind=="png":
                from pyqtgraph.exporters import ImageExporter
                exporter=ImageExporter(self.plot.plotItem);exporter.export(path)
            else:
                from pyqtgraph.exporters import SVGExporter
                exporter=SVGExporter(self.plot.plotItem);exporter.export(path)
        except Exception as exc:
            QMessageBox.critical(self,"Export Failed",str(exc));return
        QMessageBox.information(self,"Export Complete",f"Exported visible primary panel to {path}")

    def export_csv(self):
        ids=self._selected_ids()
        if not ids:
            QMessageBox.information(self,"Export","Select at least one stream before exporting.")
            return
        window_seconds=self.window_combo.currentData()
        end_timestamp=None
        start_timestamp=None
        if window_seconds is not None:
            latest=[
                self.visualization.streams.latest(stream_id)
                for stream_id in ids
            ]
            latest=[sample.timestamp for sample in latest if sample is not None]
            if latest:
                end_timestamp=max(latest)
                start_timestamp=end_timestamp-float(window_seconds)
        export=self.visualization.export_time_series(
            ids,limit=5000,start_timestamp=start_timestamp,end_timestamp=end_timestamp,
            title="JOE Live Time-Series Export"
        )
        path,_=QFileDialog.getSaveFileName(
            self,"Export Time-Series CSV","joe_timeseries.csv","CSV files (*.csv)"
        )
        if not path: return
        if not path.lower().endswith(".csv"): path += ".csv"
        csv_path=Path(path)
        meta_path=csv_path.with_suffix(".metadata.json")
        try:
            csv_path.write_text(self.visualization.export_csv_text(export),encoding="utf-8",newline="")
            meta_path.write_text(self.visualization.export_metadata_json(export),encoding="utf-8")
        except OSError as exc:
            QMessageBox.critical(self,"Export Failed",str(exc))
            return
        QMessageBox.information(
            self,"Export Complete",
            f"Exported {export.metadata['sample_count']} actual retained sample(s).\\n"
            f"CSV: {csv_path}\\nMetadata: {meta_path}"
        )

    def export_workspace_state(self):
        return {
            "streams": list(self._selected_ids()),
            "window_seconds": self.window_combo.currentData(),
            "paused": self.pause_button.isChecked(),
        }

    def restore_workspace_state(self, state):
        if not isinstance(state,dict): return
        self.selected_combo.clear()
        available=set(self.visualization.numeric_stream_ids())
        for stream_id in state.get("streams",[]):
            if stream_id in available:
                d=self.visualization.streams.definition(stream_id)
                self.selected_combo.addItem(d.name,stream_id)
        target=state.get("window_seconds")
        for i in range(self.window_combo.count()):
            if self.window_combo.itemData(i) == target:
                self.window_combo.setCurrentIndex(i); break
        self.pause_button.setChecked(bool(state.get("paused",False)))
        self.refresh_plot()


class AnalysisPlotWorkspace(QWidget):
    """Functional scatter and histogram analysis over retained JOE streams."""
    workspace_kind = "analysis_plot"

    def __init__(self, visualization, parent=None):
        super().__init__(parent)
        self.visualization=visualization
        root=QVBoxLayout(self)
        controls=QHBoxLayout()
        controls.addWidget(QLabel("View:"))
        self.kind_combo=QComboBox()
        self.kind_combo.addItem("Scatter","scatter")
        self.kind_combo.addItem("Histogram","histogram")
        controls.addWidget(self.kind_combo)
        controls.addWidget(QLabel("X / Stream:"))
        self.x_combo=QComboBox()
        controls.addWidget(self.x_combo,1)
        self.y_label=QLabel("Y:")
        controls.addWidget(self.y_label)
        self.y_combo=QComboBox()
        controls.addWidget(self.y_combo,1)
        self.refresh_button=QPushButton("Refresh")
        controls.addWidget(self.refresh_button)
        root.addLayout(controls)
        self.provenance_label=QLabel()
        self.provenance_label.setWordWrap(True)
        root.addWidget(self.provenance_label)
        self.plot=pg.PlotWidget()
        self.plot.showGrid(x=True,y=True,alpha=0.25)
        root.addWidget(self.plot,1)
        self.status_label=QLabel()
        root.addWidget(self.status_label)

        for stream_id in self.visualization.numeric_stream_ids():
            definition=self.visualization.streams.definition(stream_id)
            text=f"{definition.name} [{definition.unit or 'unitless'}] — {definition.origin.value}"
            self.x_combo.addItem(text,stream_id)
            self.y_combo.addItem(text,stream_id)
        if self.y_combo.count()>1: self.y_combo.setCurrentIndex(1)

        self.kind_combo.currentIndexChanged.connect(self._kind_changed)
        self.x_combo.currentIndexChanged.connect(self.refresh_plot)
        self.y_combo.currentIndexChanged.connect(self.refresh_plot)
        self.refresh_button.clicked.connect(self.refresh_plot)
        self._kind_changed()

    def _kind_changed(self,*_):
        scatter=self.kind_combo.currentData()=="scatter"
        self.y_label.setVisible(scatter)
        self.y_combo.setVisible(scatter)
        self.refresh_plot()

    def refresh_plot(self,*_):
        self.plot.clear()
        x_id=self.x_combo.currentData()
        if not x_id:
            self.status_label.setText("No numeric streams available.")
            return
        if self.kind_combo.currentData()=="histogram":
            view=self.visualization.histogram(x_id,bins=20,limit=600)
            definition=self.visualization.streams.definition(x_id)
            self.plot.setLabel("bottom",definition.name,units=definition.unit or None)
            self.plot.setLabel("left","Count")
            if view.counts:
                centers=[(view.bin_edges[i]+view.bin_edges[i+1])/2 for i in range(len(view.counts))]
                widths=[view.bin_edges[i+1]-view.bin_edges[i] for i in range(len(view.counts))]
                self.plot.addItem(pg.BarGraphItem(x=centers,height=list(view.counts),width=widths))
            self.provenance_label.setText(
                f"Origin: {definition.origin.value} | Source: {definition.source} | Stream: {x_id}"
            )
            self.status_label.setText(f"{view.sample_count} finite retained sample(s)")
        else:
            y_id=self.y_combo.currentData()
            if not y_id: return
            view=self.visualization.scatter(x_id,y_id,limit=600)
            xdef=self.visualization.streams.definition(x_id)
            ydef=self.visualization.streams.definition(y_id)
            self.plot.setLabel("bottom",xdef.name,units=xdef.unit or None)
            self.plot.setLabel("left",ydef.name,units=ydef.unit or None)
            self.plot.plot(list(view.x_values),list(view.y_values),pen=None,symbol="o")
            self.provenance_label.setText(
                f"X: {xdef.origin.value}/{xdef.source}/{x_id} | "
                f"Y: {ydef.origin.value}/{ydef.source}/{y_id}"
            )
            self.status_label.setText(
                f"{len(view.x_values)} exact-timestamp paired sample(s); no interpolation performed"
            )


    def export_workspace_state(self):
        return {
            "kind": self.kind_combo.currentData(),
            "x_stream": self.x_combo.currentData(),
            "y_stream": self.y_combo.currentData(),
        }

    def restore_workspace_state(self, state):
        if not isinstance(state,dict): return
        for combo,key in ((self.kind_combo,"kind"),(self.x_combo,"x_stream"),(self.y_combo,"y_stream")):
            value=state.get(key)
            index=combo.findData(value)
            if index >= 0: combo.setCurrentIndex(index)
        self._kind_changed()


class NumericInstrumentWorkspace(QWidget):
    """Live numeric instrument sourced only from canonical JOE streams."""
    workspace_kind = "numeric_instrument"

    def __init__(self, visualization, parent=None):
        super().__init__(parent)
        self.visualization=visualization
        root=QVBoxLayout(self)
        controls=QHBoxLayout()
        controls.addWidget(QLabel("Stream:"))
        self.stream_combo=QComboBox()
        controls.addWidget(self.stream_combo,1)
        self.refresh_button=QPushButton("Refresh Streams")
        controls.addWidget(self.refresh_button)
        root.addLayout(controls)

        self.value_label=QLabel("UNAVAILABLE")
        self.value_label.setStyleSheet("font-size: 42px; font-weight: 600;")
        root.addWidget(self.value_label)
        self.identity_label=QLabel()
        self.identity_label.setWordWrap(True)
        root.addWidget(self.identity_label)
        self.sample_label=QLabel()
        root.addWidget(self.sample_label)

        self.refresh_button.clicked.connect(self.refresh_streams)
        self.stream_combo.currentIndexChanged.connect(self.refresh_value)
        self.gauge_min.valueChanged.connect(self.refresh_value)
        self.gauge_max.valueChanged.connect(self.refresh_value)
        self.timer=QTimer(self)
        self.timer.setInterval(250)
        self.timer.timeout.connect(self.refresh_value)
        self.refresh_streams()
        self.timer.start()

    def refresh_streams(self):
        current=self.stream_combo.currentData()
        self.stream_combo.blockSignals(True)
        self.stream_combo.clear()
        for stream_id in self.visualization.numeric_stream_ids():
            definition=self.visualization.streams.definition(stream_id)
            self.stream_combo.addItem(
                f"{definition.name} [{definition.unit or 'unitless'}] — {definition.origin.value}",
                stream_id
            )
        if current:
            index=self.stream_combo.findData(current)
            if index >= 0: self.stream_combo.setCurrentIndex(index)
        self.stream_combo.blockSignals(False)
        self.refresh_value()

    def refresh_value(self,*_):
        stream_id=self.stream_combo.currentData()
        if not stream_id:
            self.value_label.setText("UNAVAILABLE")
            self.identity_label.setText("No numeric stream available")
            self.sample_label.setText("")
            return
        view=self.visualization.numeric_instrument(stream_id)
        try:
            gauge=self.visualization.gauge(stream_id,self.gauge_min.value(),self.gauge_max.value())
            self.gauge_bar.setValue(0 if gauge.fraction is None else int(round(gauge.fraction*1000)))
            self.gauge_bar.setFormat(f"{gauge.minimum:.6g} … {gauge.maximum:.6g}   %p%")
        except Exception:
            self.gauge_bar.setValue(0);self.gauge_bar.setFormat("INVALID RANGE")
        unit=view.unit or ""
        self.value_label.setText(
            f"{view.value:.6g} {unit}".strip() if view.available else "UNAVAILABLE"
        )
        self.identity_label.setText(
            f"Origin: {view.origin} | Source: {view.source} | Stream: {view.stream_id}"
        )
        if view.timestamp is None:
            self.sample_label.setText("No retained sample; no value synthesized.")
        else:
            self.sample_label.setText(
                f"Timestamp: {view.timestamp:.6f} | Sequence: {view.sequence}"
            )


    def export_workspace_state(self):
        return {"stream": self.stream_combo.currentData()}

    def restore_workspace_state(self, state):
        if not isinstance(state,dict): return
        index=self.stream_combo.findData(state.get("stream"))
        if index >= 0: self.stream_combo.setCurrentIndex(index)
        self.refresh_value()


class MatrixHeatmapWorkspace(QWidget):
    """Frame-coherent matrix/heatmap view of selected numeric streams."""
    workspace_kind = "matrix_heatmap"

    def __init__(self, visualization, parent=None):
        super().__init__(parent)
        self.visualization=visualization
        root=QVBoxLayout(self)
        controls=QHBoxLayout()
        controls.addWidget(QLabel("Add channel:"))
        self.available_combo=QComboBox()
        controls.addWidget(self.available_combo,1)
        self.add_button=QPushButton("Add")
        controls.addWidget(self.add_button)
        self.remove_button=QPushButton("Remove Selected")
        controls.addWidget(self.remove_button)
        self.refresh_button=QPushButton("Refresh")
        controls.addWidget(self.refresh_button)
        root.addLayout(controls)

        self.selected_combo=QComboBox()
        root.addWidget(self.selected_combo)
        self.provenance_label=QLabel()
        self.provenance_label.setWordWrap(True)
        root.addWidget(self.provenance_label)

        self.plot=pg.PlotWidget()
        self.image=pg.ImageItem()
        self.plot.addItem(self.image)
        root.addWidget(self.plot,1)
        self.status_label=QLabel()
        root.addWidget(self.status_label)

        self.add_button.clicked.connect(self.add_stream)
        self.remove_button.clicked.connect(self.remove_stream)
        self.refresh_button.clicked.connect(self.refresh_streams)
        self.selected_combo.currentIndexChanged.connect(self._selection_changed)
        self.timer=QTimer(self)
        self.timer.setInterval(500)
        self.timer.timeout.connect(self.refresh_plot)
        self.refresh_streams()
        self.timer.start()

    def refresh_streams(self):
        current=self.available_combo.currentData()
        self.available_combo.blockSignals(True)
        self.available_combo.clear()
        for stream_id in self.visualization.numeric_stream_ids():
            definition=self.visualization.streams.definition(stream_id)
            self.available_combo.addItem(
                f"{definition.name} [{definition.unit or 'unitless'}] — {definition.origin.value}",
                stream_id
            )
        if current:
            index=self.available_combo.findData(current)
            if index >= 0: self.available_combo.setCurrentIndex(index)
        self.available_combo.blockSignals(False)
        self.refresh_plot()

    def _selected_ids(self):
        return tuple(self.selected_combo.itemData(i) for i in range(self.selected_combo.count()))

    def add_stream(self):
        stream_id=self.available_combo.currentData()
        if stream_id and stream_id not in self._selected_ids():
            definition=self.visualization.streams.definition(stream_id)
            self.selected_combo.addItem(definition.name,stream_id)
            self.selected_combo.setCurrentIndex(self.selected_combo.count()-1)
            self.refresh_plot()

    def remove_stream(self):
        index=self.selected_combo.currentIndex()
        if index >= 0:
            self.selected_combo.removeItem(index)
            self.refresh_plot()

    def _selection_changed(self,*_):
        stream_id=self.selected_combo.currentData()
        if not stream_id:
            self.provenance_label.setText("No channel selected")
            return
        definition=self.visualization.streams.definition(stream_id)
        self.provenance_label.setText(
            f"Selected channel — Origin: {definition.origin.value} | Source: {definition.source} | "
            f"Stream: {definition.stream_id} | Unit: {definition.unit or 'unitless'}"
        )

    def refresh_plot(self,*_):
        ids=self._selected_ids()
        if not ids:
            self.image.clear()
            self.status_label.setText("Add numeric channels to build a frame-coherent heatmap.")
            return
        view=self.visualization.matrix_heatmap(ids,frame_limit=200)
        if not view.values:
            self.image.clear()
            self.status_label.setText(
                "No complete shared frames available; no matrix values synthesized."
            )
            self._selection_changed()
            return
        import numpy as np
        array=np.asarray(view.values,dtype=float).T
        self.image.setImage(array,autoLevels=True)
        self.plot.setLabel("bottom","Coherent frame index")
        self.plot.setLabel("left","Selected channel index")
        self.status_label.setText(
            f"{len(view.frame_ids)} complete coherent frame(s) × {len(view.stream_ids)} channel(s)"
        )
        self._selection_changed()


    def export_workspace_state(self):
        return {"streams": list(self._selected_ids())}

    def restore_workspace_state(self, state):
        if not isinstance(state,dict): return
        self.selected_combo.clear()
        available=set(self.visualization.numeric_stream_ids())
        for stream_id in state.get("streams",[]):
            if stream_id in available:
                d=self.visualization.streams.definition(stream_id)
                self.selected_combo.addItem(d.name,stream_id)
        self.refresh_plot()


class ScientificTableWorkspace(QWidget):
    """Live sparse scientific table sourced from canonical retained streams."""
    workspace_kind="scientific_table"
    def __init__(self,visualization,parent=None):
        super().__init__(parent);self.visualization=visualization
        root=QVBoxLayout(self);controls=QHBoxLayout();controls.addWidget(QLabel("Stream:"))
        self.combo=QComboBox();controls.addWidget(self.combo,1)
        self.add=QPushButton("Add Column");self.remove=QPushButton("Remove Column");controls.addWidget(self.add);controls.addWidget(self.remove)
        root.addLayout(controls);self.selected=QComboBox();root.addWidget(self.selected)
        self.table=QTableWidget();root.addWidget(self.table,1);self.status=QLabel();root.addWidget(self.status)
        self.add.clicked.connect(self.add_stream);self.remove.clicked.connect(self.remove_stream)
        self.timer=QTimer(self);self.timer.setInterval(500);self.timer.timeout.connect(self.refresh_table)
        for sid in self.visualization.numeric_stream_ids():
            d=self.visualization.streams.definition(sid);self.combo.addItem(f"{d.name} [{d.unit or 'unitless'}] — {d.origin.value}",sid)
        self.timer.start()
    def add_stream(self):
        sid=self.combo.currentData()
        if sid and self.selected.findData(sid)<0:self.selected.addItem(self.combo.currentText(),sid)
        self.refresh_table()
    def remove_stream(self):
        if self.selected.currentIndex()>=0:self.selected.removeItem(self.selected.currentIndex())
        self.refresh_table()
    def refresh_table(self):
        ids=[self.selected.itemData(i) for i in range(self.selected.count())]
        if not ids:self.table.setRowCount(0);self.table.setColumnCount(0);self.status.setText("No streams selected");return
        view=self.visualization.scientific_table(ids,limit=200)
        self.table.setColumnCount(len(view.columns));self.table.setHorizontalHeaderLabels(list(view.columns))
        self.table.setRowCount(len(view.rows))
        for r,row in enumerate(view.rows):
            for c,val in enumerate(row):self.table.setItem(r,c,QTableWidgetItem("" if val is None else str(val)))
        self.status.setText(" | ".join(f"{sid}: {origin}/{source}" for sid,origin,source in zip(view.stream_ids,view.origins,view.sources)))
    def export_workspace_state(self):return {"stream_ids":[self.selected.itemData(i) for i in range(self.selected.count())]}
    def restore_workspace_state(self,state):
        for sid in state.get("stream_ids",[]):
            ix=self.combo.findData(sid)
            if ix>=0 and self.selected.findData(sid)<0:self.selected.addItem(self.combo.itemText(ix),sid)
        self.refresh_table()

class ScientificFieldWorkspace(QWidget):
    """Coherent X/Y/Z scientific field-point viewer without interpolation."""
    workspace_kind = "scientific_field"

    def __init__(self, visualization, parent=None):
        super().__init__(parent)
        self.visualization=visualization
        root=QVBoxLayout(self)
        controls=QHBoxLayout()
        self.x_combo=QComboBox()
        self.y_combo=QComboBox()
        self.z_combo=QComboBox()
        for label,combo in (("X:",self.x_combo),("Y:",self.y_combo),("Z / field:",self.z_combo)):
            controls.addWidget(QLabel(label))
            controls.addWidget(combo,1)
        self.refresh_button=QPushButton("Refresh")
        controls.addWidget(self.refresh_button)
        root.addLayout(controls)

        self.provenance_label=QLabel()
        self.provenance_label.setWordWrap(True)
        root.addWidget(self.provenance_label)
        self.plot=pg.PlotWidget()
        self.plot.showGrid(x=True,y=True,alpha=0.25)
        root.addWidget(self.plot,1)
        self.status_label=QLabel()
        root.addWidget(self.status_label)

        for stream_id in self.visualization.numeric_stream_ids():
            d=self.visualization.streams.definition(stream_id)
            text=f"{d.name} [{d.unit or 'unitless'}] — {d.origin.value}"
            for combo in (self.x_combo,self.y_combo,self.z_combo):
                combo.addItem(text,stream_id)
        if self.y_combo.count()>1:self.y_combo.setCurrentIndex(1)
        if self.z_combo.count()>2:self.z_combo.setCurrentIndex(2)

        self.refresh_button.clicked.connect(self.refresh_plot)
        self.x_combo.currentIndexChanged.connect(self.refresh_plot)
        self.y_combo.currentIndexChanged.connect(self.refresh_plot)
        self.z_combo.currentIndexChanged.connect(self.refresh_plot)
        self.refresh_plot()

    def refresh_plot(self,*_):
        self.plot.clear()
        ids=(self.x_combo.currentData(),self.y_combo.currentData(),self.z_combo.currentData())
        if not all(ids):
            self.status_label.setText("Three numeric streams are required.")
            return
        if len(set(ids)) != 3:
            self.status_label.setText("X, Y, and field value must be three distinct streams.")
            return
        view=self.visualization.field_points(*ids,limit=1000)
        defs=[self.visualization.streams.definition(i) for i in ids]
        self.plot.setLabel("bottom",defs[0].name,units=defs[0].unit or None)
        self.plot.setLabel("left",defs[1].name,units=defs[1].unit or None)
        if not view.points:
            self.status_label.setText(
                "No complete coherent X/Y/Z frames available; no field synthesized."
            )
        else:
            xs=[p.x for p in view.points]
            ys=[p.y for p in view.points]
            zs=[p.z for p in view.points]
            lo=min(zs); hi=max(zs)
            span=hi-lo
            sizes=[10.0 if span == 0 else 7.0+13.0*((z-lo)/span) for z in zs]
            spots=[{"pos":(x,y),"size":size} for x,y,size in zip(xs,ys,sizes)]
            scatter=pg.ScatterPlotItem()
            scatter.addPoints(spots)
            self.plot.addItem(scatter)
            self.status_label.setText(
                f"{len(view.points)} coherent field point(s). Marker size encodes "
                f"{defs[2].name} [{defs[2].unit or 'unitless'}]; no interpolation."
            )
        self.provenance_label.setText(
            " | ".join(
                f"{axis}: {d.origin.value}/{d.source}/{d.stream_id}"
                for axis,d in zip(("X","Y","Z"),defs)
            )
        )

    def export_workspace_state(self):
        return {
            "x_stream": self.x_combo.currentData(),
            "y_stream": self.y_combo.currentData(),
            "z_stream": self.z_combo.currentData(),
        }

    def restore_workspace_state(self, state):
        if not isinstance(state,dict): return
        for combo,key in ((self.x_combo,"x_stream"),(self.y_combo,"y_stream"),(self.z_combo,"z_stream")):
            index=combo.findData(state.get(key))
            if index >= 0: combo.setCurrentIndex(index)
        self.refresh_plot()



class MPRWorkspace(QWidget):
    workspace_kind="mpr"
    def __init__(self,register,parent=None):
        super().__init__(parent);self.register=register
        root=QVBoxLayout(self);bar=QHBoxLayout()
        self.search_box=QLineEdit();self.search_box.setPlaceholderText("Search ID, symbol, name, provenance…")
        self.class_filter=QComboBox();self.class_filter.addItem("All evidence classes",None)
        from journeyman.core.mpr import EpistemicClass
        for x in EpistemicClass:self.class_filter.addItem(x.value,x.value)
        self.new_button=QPushButton("New");self.edit_button=QPushButton("Edit");self.snapshot_button=QPushButton("Snapshot")
        self.export_json_button=QPushButton("Export JSON");self.export_csv_button=QPushButton("Export CSV")
        for x in (self.search_box,self.class_filter,self.new_button,self.edit_button,self.snapshot_button,self.export_json_button,self.export_csv_button):bar.addWidget(x)
        root.addLayout(bar)
        self.table=QTableWidget(0,9);self.table.setHorizontalHeaderLabels(["ID","Symbol","Name","Value","Unit","Uncertainty","Evidence","Rev","Provenance"])
        self.table.setSelectionBehavior(QTableWidget.SelectRows);self.table.setSelectionMode(QTableWidget.SingleSelection);root.addWidget(self.table,2)
        lower=QSplitter(Qt.Horizontal)
        self.history=QTableWidget(0,5);self.history.setHorizontalHeaderLabels(["Rev","Registry","Value","Unit","Changed"])
        self.dependencies=QPlainTextEdit();self.dependencies.setReadOnly(True);lower.addWidget(self.history);lower.addWidget(self.dependencies);root.addWidget(lower,1)
        self.status=QLabel();root.addWidget(self.status)
        self.search_box.textChanged.connect(self.refresh);self.class_filter.currentIndexChanged.connect(self.refresh);self.table.itemSelectionChanged.connect(self.refresh_detail)
        self.new_button.clicked.connect(lambda:self._edit_dialog(None));self.edit_button.clicked.connect(self.edit_selected);self.snapshot_button.clicked.connect(self.create_snapshot)
        self.export_json_button.clicked.connect(lambda:self.export_data("json"));self.export_csv_button.clicked.connect(lambda:self.export_data("csv"));self.refresh()
    def _selected_id(self):
        row=self.table.currentRow();return self.table.item(row,0).text() if row>=0 and self.table.item(row,0) else None
    def refresh(self,*_):
        current=self._selected_id();records=self.register.search(self.search_box.text(),epistemic_class=self.class_filter.currentData());self.table.setRowCount(len(records))
        for row,r in enumerate(records):
            vals=[r.parameter_id,r.symbol,r.name,f"{r.value:.12g}",r.unit,"—" if r.uncertainty is None else f"{r.uncertainty:.6g} {r.uncertainty_unit or r.unit}",r.epistemic_class.value,str(r.revision),r.provenance]
            for col,value in enumerate(vals):self.table.setItem(row,col,QTableWidgetItem(value))
            if r.parameter_id==current:self.table.selectRow(row)
        st=self.register.status();self.status.setText(f"Registry revision {st.registry_revision} | {st.parameter_count} parameters | integrity {'OK' if st.integrity_ok else 'FAILED'}");self.refresh_detail()
    def refresh_detail(self):
        pid=self._selected_id();self.history.setRowCount(0)
        if not pid:self.dependencies.setPlainText("Select a parameter to inspect history and dependencies.");return
        revisions=self.register.history(pid);self.history.setRowCount(len(revisions))
        for row,h in enumerate(revisions):
            vals=[str(h.revision),str(h.registry_revision),f"{h.record.value:.12g}",h.record.unit,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(h.changed_at))]
            for col,value in enumerate(vals):self.history.setItem(row,col,QTableWidgetItem(value))
        try:d=self.register.derived(pid);definition=f"Derived expression: {d.expression}\nDependencies: {', '.join(d.dependencies)}\n"
        except KeyError:definition="Derived expression: none\n"
        self.dependencies.setPlainText(definition+f"Direct dependents: {', '.join(self.register.dependents(pid,transitive=False)) or 'none'}\nTransitive dependents: {', '.join(self.register.dependents(pid)) or 'none'}")
    def edit_selected(self):
        pid=self._selected_id()
        if pid:self._edit_dialog(self.register.get(pid))
    def _edit_dialog(self,record):
        from journeyman.core.mpr import EpistemicClass
        dlg=QDialog(self);dlg.setWindowTitle("Edit MPR Parameter" if record else "New MPR Parameter");form=QFormLayout(dlg)
        f={k:QLineEdit() for k in ("id","symbol","name","value","unit","uncertainty","provenance")};e=QComboBox()
        for x in EpistemicClass:e.addItem(x.value,x.value)
        desc=QTextEdit();desc.setMaximumHeight(80)
        for label,key in (("Parameter ID","id"),("Symbol","symbol"),("Name","name"),("Value","value"),("Unit","unit"),("Uncertainty","uncertainty")):form.addRow(label,f[key])
        form.addRow("Evidence",e);form.addRow("Provenance",f["provenance"]);form.addRow("Description",desc)
        if record:
            f["id"].setText(record.parameter_id);f["id"].setReadOnly(True);f["symbol"].setText(record.symbol);f["name"].setText(record.name);f["value"].setText(str(record.value));f["unit"].setText(record.unit);f["uncertainty"].setText("" if record.uncertainty is None else str(record.uncertainty));f["provenance"].setText(record.provenance);desc.setPlainText(record.description);e.setCurrentIndex(e.findData(record.epistemic_class.value))
        buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.accepted.connect(dlg.accept);buttons.rejected.connect(dlg.reject);form.addRow(buttons)
        if dlg.exec()!=QDialog.Accepted:return
        try:
            uncertainty=None if not f["uncertainty"].text().strip() else float(f["uncertainty"].text())
            args=dict(symbol=f["symbol"].text(),name=f["name"].text(),value=float(f["value"].text()),unit=f["unit"].text(),uncertainty=uncertainty,epistemic_class=e.currentData(),provenance=f["provenance"].text(),description=desc.toPlainText())
            self.register.update(record.parameter_id,expected_revision=record.revision,**args) if record else self.register.define(f["id"].text(),**args)
        except Exception as exc:QMessageBox.critical(self,"MPR Write Rejected",str(exc));return
        self.refresh()
    def create_snapshot(self):
        sid,ok=QInputDialog.getText(self,"MPR Snapshot","Snapshot ID:")
        if not ok:return
        name,ok=QInputDialog.getText(self,"MPR Snapshot","Snapshot name:")
        if not ok:return
        try:snap=self.register.create_snapshot(sid,name=name)
        except Exception as exc:QMessageBox.critical(self,"Snapshot Rejected",str(exc));return
        QMessageBox.information(self,"Snapshot Created",f"{snap.snapshot_id}\nRegistry revision: {snap.registry_revision}\nChecksum: {snap.checksum}")
    def export_data(self,kind):
        path,_=QFileDialog.getSaveFileName(self,"Export MPR",f"mpr.{kind}",f"{kind.upper()} files (*.{kind})")
        if not path:return
        if not path.lower().endswith("."+kind):path+="."+kind
        try:
            text=self.register.export_json() if kind=="json" else self.register.export_csv()
            Path(path).write_text(text,encoding="utf-8")
        except Exception as exc:QMessageBox.critical(self,"Export Failed",str(exc));return
        QMessageBox.information(self,"Export Complete",path)
    def export_workspace_state(self):return {"search":self.search_box.text(),"epistemic_class":self.class_filter.currentData(),"selected_id":self._selected_id()}
    def restore_workspace_state(self,state):
        if not isinstance(state,dict):return
        self.search_box.setText(str(state.get("search","")));i=self.class_filter.findData(state.get("epistemic_class"));self.class_filter.setCurrentIndex(max(0,i));self.refresh()
        for row in range(self.table.rowCount()):
            if self.table.item(row,0).text()==state.get("selected_id"):self.table.selectRow(row);break


class GeometryWorkspace(QWidget):
    workspace_kind="geometry"
    def __init__(self,geometry_service,parent=None):
        super().__init__(parent);self.geometry=geometry_service
        root=QVBoxLayout(self);top=QHBoxLayout()
        self.metric=QComboBox();self.metric.addItem("Minkowski","minkowski");self.metric.addItem("Morris–Thorne (MPR throat radius)","morris")
        self.r0_id=QLineEdit("design.throat-radius");self.r=QDoubleSpinBox();self.r.setRange(1e-6,1e12);self.r.setDecimals(6);self.r.setValue(10.0)
        self.theta=QDoubleSpinBox();self.theta.setRange(1e-6,3.141591);self.theta.setDecimals(6);self.theta.setValue(1.570796)
        self.evaluate_button=QPushButton("Evaluate Geometry")
        for label,widget in (("Metric",self.metric),("MPR r₀ ID",self.r0_id),("r (m)",self.r),("θ (rad)",self.theta)):
            top.addWidget(QLabel(label));top.addWidget(widget)
        top.addWidget(self.evaluate_button);root.addLayout(top)
        self.summary=QPlainTextEdit();self.summary.setReadOnly(True);root.addWidget(self.summary,1)
        self.tensor=QTableWidget(4,4);self.tensor.setHorizontalHeaderLabels(["0","1","2","3"]);self.tensor.setVerticalHeaderLabels(["0","1","2","3"]);root.addWidget(self.tensor,1)
        self.profile=QTableWidget(0,5);self.profile.setHorizontalHeaderLabels(["r (m)","ρE (J/m³)","pᵣ (Pa)","pₜ (Pa)","ρE+pᵣ (J/m³)"]);root.addWidget(self.profile,1)
        self.evaluate_button.clicked.connect(self.evaluate);self.metric.currentIndexChanged.connect(self._mode);self._mode()
    def _mode(self,*_):
        morris=self.metric.currentData()=="morris";self.r0_id.setEnabled(morris);self.r.setEnabled(morris);self.theta.setEnabled(morris)
    def evaluate(self):
        import math
        try:
            if self.metric.currentData()=="minkowski":
                model=self.geometry.model("geometry.minkowski");coords=(0,0,0,0);curv=self.geometry.evaluate_curvature(model.model_id,coords)
                stress=self.geometry.evaluate_stress_energy(model.model_id,coords);profile=None
            else:
                model=self.geometry.morris_thorne_from_mpr(self.r0_id.text().strip());r0=self.geometry.mpr.get(self.r0_id.text().strip()).value
                r=self.r.value()
                if r<=r0:raise ValueError(f"Evaluation radius must be greater than throat radius r₀={r0:g} m")
                coords=(0,r,self.theta.value(),math.pi);curv=__import__("journeyman.core.geometry",fromlist=["curvature"]).curvature(model,coords)
                stress=__import__("journeyman.core.geometry",fromlist=["stress_energy_from_geometry"]).stress_energy_from_geometry(model,coords)
                radii=[r0*(1.01+(4.99*i/24)) for i in range(25)]
                profile=self.geometry.morris_thorne_profile_from_mpr(radii,self.r0_id.text().strip())
            nec=__import__("journeyman.core.geometry",fromlist=["assess_nec"]).assess_nec(stress)
            self.summary.setPlainText(
                f"MODEL / SIMULATION RESULT — NOT PHYSICAL TELEMETRY\n"
                f"Metric: {model.model_id} | revision: {model.model_revision}\nCoordinates: {coords}\n"
                f"Ricci scalar: {curv.ricci_scalar:.8e} m⁻²\n"
                f"Energy density ρE: {stress.energy_density_j_m3:.8e} J/m³\n"
                f"Principal pressures: {stress.principal_pressures_pa}\n"
                f"Radial NEC ρE+pᵣ: {stress.radial_nec_j_m3:.8e} J/m³ — {'SATISFIED' if nec.radial_nec_satisfied else 'VIOLATED'}\n"
                f"Provenance: {stress.provenance}\nNumerics: {stress.numerical_note}")
            G=curv.einstein_matrix()
            for i in range(4):
                for j in range(4):self.tensor.setItem(i,j,QTableWidgetItem(f"{G[i,j]:.8e}"))
            if profile:
                self.profile.setRowCount(len(profile.radii_m))
                cols=(profile.radii_m,profile.energy_density_j_m3,profile.radial_pressure_pa,profile.tangential_pressure_pa,profile.radial_nec_j_m3)
                for row in range(len(profile.radii_m)):
                    for col,data in enumerate(cols):self.profile.setItem(row,col,QTableWidgetItem(f"{data[row]:.8e}"))
            else:self.profile.setRowCount(0)
        except Exception as exc:QMessageBox.critical(self,"Geometry Evaluation Rejected",str(exc))
    def export_workspace_state(self):
        return {"metric":self.metric.currentData(),"r0_id":self.r0_id.text(),"r":self.r.value(),"theta":self.theta.value()}
    def restore_workspace_state(self,state):
        if not isinstance(state,dict):return
        i=self.metric.findData(state.get("metric"));self.metric.setCurrentIndex(max(0,i));self.r0_id.setText(str(state.get("r0_id","design.throat-radius")))
        self.r.setValue(float(state.get("r",10)));self.theta.setValue(float(state.get("theta",1.570796)))


class StressEnergyWorkspace(QWidget):
    workspace_kind="stress-energy"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service
        root=QVBoxLayout(self);controls=QHBoxLayout()
        self.r0=QDoubleSpinBox();self.r0.setRange(.001,1e9);self.r0.setDecimals(4);self.r0.setValue(2)
        self.q=QDoubleSpinBox();self.q.setRange(1.001,100);self.q.setDecimals(4);self.q.setValue(2)
        self.rmax=QDoubleSpinBox();self.rmax.setRange(1.002,100);self.rmax.setDecimals(3);self.rmax.setValue(4)
        self.run=QPushButton("Analyze W-1 Source")
        for label,widget in (("r₀ (m)",self.r0),("r/r₀",self.q),("Integral outer r/r₀",self.rmax)):
            controls.addWidget(QLabel(label));controls.addWidget(widget)
        controls.addWidget(self.run);root.addLayout(controls)
        self.summary=QPlainTextEdit();self.summary.setReadOnly(True);root.addWidget(self.summary,1)
        self.map=QTableWidget(0,8);self.map.setHorizontalHeaderLabels(["r₀ m","r/r₀","ρE J/m³","pᵣ Pa","NEC J/m³","NEC","WEC","DEC"]);root.addWidget(self.map,1)
        self.run.clicked.connect(self.analyze)
    def analyze(self):
        import math
        from journeyman.core.geometry import morris_thorne_metric,stress_energy_from_geometry
        try:
            r0=self.r0.value();q=self.q.value();r=r0*q
            t=stress_energy_from_geometry(morris_thorne_metric(throat_radius=r0),(0,r,math.pi/2,math.pi),relative_step=5e-5)
            c=self.service.conditions(t);x=self.service.exoticity(t);sens=self.service.sensitivity(r0,q)
            proper=self.service.proper_volume(r0,r0*self.rmax.value(),samples=101,throat_offset_fraction=1e-3)
            gc=self.service.guardian_contract(t)
            self.summary.setPlainText(
                "MODEL / SIMULATION RESULT — NOT PHYSICAL TELEMETRY\n"
                f"r₀={r0:.8g} m | r/r₀={q:.8g} | r={r:.8g} m\n"
                f"ρE={t.energy_density_j_m3:.8e} J/m³ | pᵣ={t.principal_pressures_pa[0]:.8e} Pa\n"
                f"NEC axes={c.nec_axes}\nNEC={c.nec_satisfied} | WEC={c.wec_satisfied} | SEC={c.sec_satisfied} | DEC={c.dec_satisfied}\n"
                f"Radial exoticity={x.radial_exoticity_j_m3:.8e} J/m³\n"
                f"d ln|NEC| / d ln r₀={sens.logarithmic_sensitivity_r0:.8f}\n"
                f"Proper-volume energy [{proper.r_inner_m:.6g},{proper.r_outer_m:.6g}] m = {proper.integrated_energy_j:.8e} J\n"
                f"Proper-volume radial NEC integral = {proper.integrated_radial_nec_j:.8e} J\n"
                f"Guardian origin={gc.data_origin} | authority={gc.authority}")
            r0s=[r0*.5,r0,r0*2];qs=[1.25,1.5,2,3]
            pts=self.service.sweep(r0s,qs);conds=self.service.condition_map(r0s,qs)
            self.map.setRowCount(len(pts))
            for row,(a,b) in enumerate(zip(pts,conds)):
                vals=(a.throat_radius_m,a.radius_ratio,a.energy_density_j_m3,a.radial_pressure_pa,a.radial_nec_j_m3,
                      "PASS" if b.nec else "VIOLATED","PASS" if b.wec else "VIOLATED","PASS" if b.dec else "VIOLATED")
                for col,val in enumerate(vals):self.map.setItem(row,col,QTableWidgetItem(f"{val:.7e}" if isinstance(val,float) else str(val)))
        except Exception as exc:QMessageBox.critical(self,"Stress-Energy Analysis Rejected",str(exc))
    def export_workspace_state(self):return {"r0":self.r0.value(),"q":self.q.value(),"rmax":self.rmax.value()}
    def restore_workspace_state(self,state):
        if isinstance(state,dict):
            self.r0.setValue(float(state.get("r0",2)));self.q.setValue(float(state.get("q",2)));self.rmax.setValue(float(state.get("rmax",4)))


class ScientificRegistryWorkspace(QWidget):
    workspace_kind="scientific-registry"
    def __init__(self,registry,units,parent=None):
        super().__init__(parent);self.registry=registry;self.units=units
        root=QVBoxLayout(self);bar=QHBoxLayout()
        self.search=QLineEdit();self.search.setPlaceholderText("Filter by name, UUID, type, provenance, tag…")
        self.type_filter=QComboBox();self.type_filter.addItem("ALL")
        from journeyman.core.scientific_registry import ObjectType
        self.type_filter.addItems([x.value for x in ObjectType])
        self.origin_filter=QComboBox();self.origin_filter.addItems(["ALL","SOFTWARE","HOST","IMPORTED","SIMULATION","HARDWARE"])
        self.new_btn=QPushButton("Create Object");self.edit_btn=QPushButton("Edit Selected");self.refresh_btn=QPushButton("Refresh")
        for x in (self.search,self.type_filter,self.origin_filter,self.new_btn,self.edit_btn,self.refresh_btn):bar.addWidget(x)
        root.addLayout(bar)
        self.table=QTableWidget(0,7);self.table.setHorizontalHeaderLabels(["Name","Type","Origin","Config Rev","UUID","Provenance","Tags"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows);self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.table,2)
        bottom=QHBoxLayout();self.history=QPlainTextEdit();self.history.setReadOnly(True);bottom.addWidget(self.history,2)
        unitsbox=QVBoxLayout();unitsbox.addWidget(QLabel("Units / Dimensional Tool"))
        row=QHBoxLayout();self.uval=QDoubleSpinBox();self.uval.setRange(-1e15,1e15);self.uval.setDecimals(9);self.uval.setValue(1)
        self.usrc=QLineEdit("km");self.udst=QLineEdit("m");self.uconvert=QPushButton("Convert / Validate")
        for x in (self.uval,self.usrc,self.udst,self.uconvert):row.addWidget(x)
        unitsbox.addLayout(row);self.uout=QPlainTextEdit();self.uout.setReadOnly(True);unitsbox.addWidget(self.uout)
        bottom.addLayout(unitsbox,1);root.addLayout(bottom,1)
        self.search.textChanged.connect(self.refresh);self.type_filter.currentTextChanged.connect(self.refresh);self.origin_filter.currentTextChanged.connect(self.refresh)
        self.refresh_btn.clicked.connect(self.refresh);self.table.itemSelectionChanged.connect(self.show_history)
        self.new_btn.clicked.connect(self.create_object);self.edit_btn.clicked.connect(self.edit_object);self.uconvert.clicked.connect(self.convert_unit)
        self.refresh()
    def _selected(self):
        row=self.table.currentRow()
        if row<0:return None
        item=self.table.item(row,4)
        if item is None:return None
        try:return self.registry.get(item.text())
        except Exception:return None
    def refresh(self,*_):
        q=self.search.text().strip().lower();typ=self.type_filter.currentText();origin=self.origin_filter.currentText()
        records=[]
        for r in self.registry.list():
            hay=" ".join((r.name,r.object_id,r.object_type.value,r.origin.value,r.provenance," ".join(r.tags))).lower()
            if q and q not in hay:continue
            if typ!="ALL" and r.object_type.value!=typ:continue
            if origin!="ALL" and r.origin.value!=origin:continue
            records.append(r)
        self.table.setRowCount(len(records))
        for row,r in enumerate(records):
            vals=(r.name,r.object_type.value,r.origin.value,str(r.config_revision),r.object_id,r.provenance,", ".join(r.tags))
            for col,val in enumerate(vals):self.table.setItem(row,col,QTableWidgetItem(val))
    def show_history(self):
        r=self._selected()
        if not r:self.history.clear();return
        lines=[f"{h.operation} | registry rev {h.registry_revision} | object rev {h.object_revision} | {h.timestamp:.6f} | {h.record.name}" for h in self.registry.history(r.object_id)]
        self.history.setPlainText("\n".join(lines))
    def _object_dialog(self,current=None):
        from journeyman.core.scientific_registry import ObjectType
        dlg=QDialog(self);dlg.setWindowTitle("Scientific Object");lay=QFormLayout(dlg)
        name=QLineEdit(current.name if current else "");typ=QComboBox();typ.addItems([x.value for x in ObjectType])
        origin=QComboBox();origin.addItems(["SOFTWARE","HOST","IMPORTED","SIMULATION","HARDWARE"])
        prov=QLineEdit(current.provenance if current else "");desc=QLineEdit(current.description if current else "")
        tags=QLineEdit(", ".join(current.tags) if current else "")
        if current:typ.setCurrentText(current.object_type.value);origin.setCurrentText(current.origin.value)
        lay.addRow("Name",name);lay.addRow("Type",typ);lay.addRow("Origin",origin);lay.addRow("Provenance",prov);lay.addRow("Description",desc);lay.addRow("Tags",tags)
        buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.accepted.connect(dlg.accept);buttons.rejected.connect(dlg.reject);lay.addRow(buttons)
        if dlg.exec()!=QDialog.Accepted:return None
        return dict(name=name.text(),object_type=typ.currentText(),origin=origin.currentText(),provenance=prov.text(),description=desc.text(),tags=tuple(x.strip() for x in tags.text().split(",") if x.strip()))
    def create_object(self):
        data=self._object_dialog()
        if data is None:return
        try:self.registry.create(**data);self.refresh()
        except Exception as exc:QMessageBox.critical(self,"Object Creation Rejected",str(exc))
    def edit_object(self):
        r=self._selected()
        if not r:QMessageBox.information(self,"Scientific Registry","Select an object first.");return
        data=self._object_dialog(r)
        if data is None:return
        try:self.registry.update(r.object_id,expected_config_revision=r.config_revision,**data);self.refresh();self.show_history()
        except Exception as exc:QMessageBox.critical(self,"Object Update Rejected",str(exc))
    def convert_unit(self):
        try:
            v=self.units.convert(self.uval.value(),self.usrc.text(),self.udst.text())
            a=self.units.parse(self.usrc.text());b=self.units.parse(self.udst.text())
            self.uout.setPlainText(f"{self.uval.value():.12g} {self.usrc.text()} = {v:.12g} {self.udst.text()}\nDimension signature: {a.dimension.signature()}\nCompatible: {a.dimension==b.dimension}")
        except Exception as exc:self.uout.setPlainText(f"REJECTED: {exc}")
    def export_workspace_state(self):return {"search":self.search.text(),"type":self.type_filter.currentText(),"origin":self.origin_filter.currentText()}
    def restore_workspace_state(self,state):
        if isinstance(state,dict):
            self.search.setText(str(state.get("search","")));self.type_filter.setCurrentText(str(state.get("type","ALL")));self.origin_filter.setCurrentText(str(state.get("origin","ALL")));self.refresh()


class NavigationWorkspace(QWidget):
    workspace_kind="navigation"
    def __init__(self,navigation,parent=None):
        super().__init__(parent);self.navigation=navigation
        root=QVBoxLayout(self)
        banner=QLabel("NAVIGATION WORKBENCH — computed coordinate products only; no physical telemetry is implied")
        root.addWidget(banner)
        top=QHBoxLayout()
        geo=QGroupBox("WGS-84 Geodetic ↔ ECEF");gl=QGridLayout(geo)
        self.lat=QDoubleSpinBox();self.lat.setRange(-90,90);self.lat.setDecimals(9)
        self.lon=QDoubleSpinBox();self.lon.setRange(-180,180);self.lon.setDecimals(9)
        self.alt=QDoubleSpinBox();self.alt.setRange(-1e6,1e9);self.alt.setDecimals(4)
        self.geo_btn=QPushButton("Geodetic → ECEF");self.geo_out=QPlainTextEdit();self.geo_out.setReadOnly(True)
        for i,(lab,wdg) in enumerate((("Latitude °",self.lat),("Longitude °",self.lon),("Ellipsoid height m",self.alt))):gl.addWidget(QLabel(lab),i,0);gl.addWidget(wdg,i,1)
        gl.addWidget(self.geo_btn,3,0,1,2);gl.addWidget(self.geo_out,4,0,1,2);top.addWidget(geo)
        sph=QGroupBox("Cartesian ↔ Spherical");sl=QGridLayout(sph)
        self.x=QDoubleSpinBox();self.y=QDoubleSpinBox();self.z=QDoubleSpinBox()
        for q in (self.x,self.y,self.z):q.setRange(-1e15,1e15);q.setDecimals(6)
        self.sph_btn=QPushButton("XYZ → Spherical");self.sph_out=QPlainTextEdit();self.sph_out.setReadOnly(True)
        for i,(lab,wdg) in enumerate((("X m",self.x),("Y m",self.y),("Z m",self.z))):sl.addWidget(QLabel(lab),i,0);sl.addWidget(wdg,i,1)
        sl.addWidget(self.sph_btn,3,0,1,2);sl.addWidget(self.sph_out,4,0,1,2);top.addWidget(sph)
        root.addLayout(top)
        mid=QHBoxLayout()
        frames=QGroupBox("Authoritative Coordinate Frames");fl=QVBoxLayout(frames)
        self.frame_table=QTableWidget(0,5);self.frame_table.setHorizontalHeaderLabels(["Name","Kind","Frame UUID","Origin","Provenance"]);self.frame_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.frame_refresh=QPushButton("Refresh Frames");fl.addWidget(self.frame_table);fl.addWidget(self.frame_refresh);mid.addWidget(frames,2)
        diag=QGroupBox("Guardian / Contract Diagnostics");dl=QVBoxLayout(diag);self.diag=QPlainTextEdit();self.diag.setReadOnly(True);self.diag_btn=QPushButton("Evaluate Navigation Contract");dl.addWidget(self.diag);dl.addWidget(self.diag_btn);mid.addWidget(diag,1)
        root.addLayout(mid,1)
        self.geo_btn.clicked.connect(self.calc_geo);self.sph_btn.clicked.connect(self.calc_sph);self.frame_refresh.clicked.connect(self.refresh_frames);self.diag_btn.clicked.connect(self.evaluate_contract)
        self.refresh_frames();self.evaluate_contract()
    def calc_geo(self):
        from journeyman.core.navigation import geodetic_to_ecef,ecef_to_geodetic
        try:
            xyz=geodetic_to_ecef(self.lat.value(),self.lon.value(),self.alt.value());back=ecef_to_geodetic(*xyz)
            self.geo_out.setPlainText(f"ECEF X = {xyz[0]:.6f} m\nECEF Y = {xyz[1]:.6f} m\nECEF Z = {xyz[2]:.6f} m\n\nRound-trip:\nlat = {back[0]:.9f}°\nlon = {back[1]:.9f}°\nh = {back[2]:.6f} m\nReference: WGS 84 / ellipsoid height")
        except Exception as exc:self.geo_out.setPlainText(f"REJECTED: {exc}")
    def calc_sph(self):
        from journeyman.core.navigation import cartesian_to_spherical
        try:
            q=cartesian_to_spherical((self.x.value(),self.y.value(),self.z.value()))
            self.sph_out.setPlainText(f"r = {q.radius_m:.9g} m\nazimuth = {q.azimuth_rad:.12g} rad\nelevation = {q.elevation_rad:.12g} rad")
        except Exception as exc:self.sph_out.setPlainText(f"REJECTED: {exc}")
    def refresh_frames(self):
        rows=self.navigation.frames.list();self.frame_table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,v in enumerate((r.name,r.kind.value,r.frame_id,r.origin.value,r.provenance)):self.frame_table.setItem(i,j,QTableWidgetItem(str(v)))
    def evaluate_contract(self):
        from journeyman.core.navigation import navigation_guardian_contract,navigation_release_readiness
        g=navigation_guardian_contract(self.navigation.frames);r=navigation_release_readiness()
        lines=[f"Schema: {g.schema}",f"Known runtime frames: {g.frame_count}",f"Authority: {g.authority}","Requirements: "+", ".join(g.requirements),"",f"Release readiness: {'PASS' if r.passed else 'FAIL'}"]
        lines.extend("✓ "+x for x in r.checks);lines.extend("✗ "+x for x in r.failures);self.diag.setPlainText("\n".join(lines))
    def export_workspace_state(self):
        return {"lat":self.lat.value(),"lon":self.lon.value(),"alt":self.alt.value(),"x":self.x.value(),"y":self.y.value(),"z":self.z.value()}
    def restore_workspace_state(self,state):
        if not isinstance(state,dict):return
        for key,widget in (("lat",self.lat),("lon",self.lon),("alt",self.alt),("x",self.x),("y",self.y),("z",self.z)):
            if key in state:
                try:widget.setValue(float(state[key]))
                except Exception:pass


class TraversabilityWorkspace(QWidget):
    workspace_kind="traversability"
    def __init__(self,service,geometry,parent=None):
        super().__init__(parent);self.service=service;self.geometry=geometry
        root=QVBoxLayout(self)
        root.addWidget(QLabel("T-1 HUMAN TRAVERSABILITY — MODEL / SIMULATION ONLY — NOT PHYSICAL TELEMETRY"))
        controls=QHBoxLayout()
        self.r0_id=QLineEdit("design.throat-radius");self.ratio=QDoubleSpinBox();self.ratio.setRange(1.01,100);self.ratio.setValue(2);self.ratio.setDecimals(4)
        self.speed=QDoubleSpinBox();self.speed.setRange(0,299000000);self.speed.setValue(100);self.speed.setDecimals(3)
        self.body=QDoubleSpinBox();self.body.setRange(.01,10);self.body.setValue(2);self.body.setDecimals(3)
        self.accel=QDoubleSpinBox();self.accel.setRange(.001,1000);self.accel.setValue(9.80665);self.accel.setDecimals(5)
        self.tidal=QDoubleSpinBox();self.tidal.setRange(.001,1000);self.tidal.setValue(9.80665);self.tidal.setDecimals(5)
        self.run=QPushButton("Evaluate T-1")
        for label,widget in (("MPR r₀ ID",self.r0_id),("r/r₀",self.ratio),("Speed m/s",self.speed),("Body length m",self.body),("Max proper a m/s²",self.accel),("Max tidal Δa m/s²",self.tidal)):
            controls.addWidget(QLabel(label));controls.addWidget(widget)
        controls.addWidget(self.run);root.addLayout(controls)
        self.summary=QPlainTextEdit();self.summary.setReadOnly(True);root.addWidget(self.summary,1)
        self.profile=QTableWidget(0,8);self.profile.setHorizontalHeaderLabels(["r m","r/r₀","Proper a","Radial tidal","Lateral tidal","Margin","PASS","Origin"]);self.profile.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.profile,2)
        self.run.clicked.connect(self.analyze)
    def analyze(self):
        import math
        from journeyman.core.traversability import HumanTolerance,throat_approach_radii,traversability_margin,traversability_guardian_contract
        try:
            rec=self.geometry.mpr.get(self.r0_id.text().strip())
            if rec.unit!="m":raise ValueError("T-1 throat-radius MPR parameter must currently be expressed in meters")
            model=self.geometry.morris_thorne_from_mpr(rec.parameter_id);r0=rec.value;r=r0*self.ratio.value()
            tol=HumanTolerance(self.body.value(),self.accel.value(),self.tidal.value())
            point=self.service.evaluate(model,(0,r,math.pi/2,math.pi),speed_m_s=self.speed.value(),tolerance=tol)
            margin=traversability_margin(point,tol);conv=self.service.convergence(model,(0,r,math.pi/2,math.pi),speed_m_s=self.speed.value(),tolerance=tol)
            gc=traversability_guardian_contract(point)
            rs=throat_approach_radii(r0,max(2.0,self.ratio.value()),.05,12)
            prof=self.service.radial_profile(model,rs,speed_m_s=self.speed.value(),tolerance=tol,relative_step=2e-5)
            self.summary.setPlainText(
                "MODEL / SIMULATION RESULT — NOT PHYSICAL TELEMETRY\n"
                f"Model: {point.model_id} | revision: {point.model_revision}\nMPR: {rec.parameter_id}@{rec.revision} = {r0:.9g} m\n"
                f"Evaluation r={r:.9g} m ({self.ratio.value():.6g} r₀), speed={point.speed_m_s:.9g} m/s, γ={point.lorentz_factor:.12g}\n"
                f"Proper acceleration={point.proper_acceleration_m_s2:.8e} m/s² | limit={tol.max_proper_acceleration_m_s2:.8e}\n"
                f"Radial tidal Δa={point.radial_tidal_acceleration_m_s2:.8e} m/s² | Lateral tidal Δa={point.lateral_tidal_acceleration_m_s2:.8e} m/s² | limit={tol.max_tidal_acceleration_m_s2:.8e}\n"
                f"Minimum normalized margin={margin.minimum_normalized_margin:.8e} | T-1={'PASS' if point.overall_pass else 'FAIL'}\n"
                f"Convergence={'PASS' if conv.converged else 'FAIL'} | terminal relative change={conv.terminal_relative_change:.6e}\n"
                f"Profile worst r={prof.worst_radius_m:.9g} m | worst normalized margin={prof.worst_normalized_margin:.8e}\n"
                f"Guardian: {gc.schema} | {gc.authority}")
            self.profile.setRowCount(len(prof.points))
            for i,p in enumerate(prof.points):
                mm=traversability_margin(p,tol).minimum_normalized_margin
                vals=(p.radius_m,p.radius_m/r0,p.proper_acceleration_m_s2,p.radial_tidal_acceleration_m_s2,p.lateral_tidal_acceleration_m_s2,mm,"PASS" if p.overall_pass else "FAIL",p.origin.value)
                for j,v in enumerate(vals):self.profile.setItem(i,j,QTableWidgetItem(f"{v:.8g}" if isinstance(v,float) else str(v)))
        except Exception as exc:self.summary.setPlainText(f"T-1 EVALUATION REJECTED\n{type(exc).__name__}: {exc}")
    def export_workspace_state(self):
        return {"r0_id":self.r0_id.text(),"ratio":self.ratio.value(),"speed":self.speed.value(),"body":self.body.value(),"accel":self.accel.value(),"tidal":self.tidal.value()}
    def restore_workspace_state(self,state):
        if not isinstance(state,dict):return
        self.r0_id.setText(str(state.get("r0_id","design.throat-radius")))
        for k,w in (("ratio",self.ratio),("speed",self.speed),("body",self.body),("accel",self.accel),("tidal",self.tidal)):
            if k in state:
                try:w.setValue(float(state[k]))
                except Exception:pass


class QFTWorkspace(QWidget):
    workspace_kind="qft"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service
        root=QVBoxLayout(self)
        root.addWidget(QLabel("Q-1 QFT / SEMICLASSICAL / QUANTUM INEQUALITY — MODEL / SIMULATION REFERENCES"))
        top=QHBoxLayout()
        self.mode=QComboBox();self.mode.addItem("Quantum Inequality","qi");self.mode.addItem("Ideal Casimir","casimir");self.mode.addItem("Single-Mode Squeezed Vacuum","squeezed")
        self.p1=QDoubleSpinBox();self.p1.setDecimals(12);self.p1.setRange(1e-15,1e6);self.p1.setValue(1e-9)
        self.p2=QDoubleSpinBox();self.p2.setDecimals(12);self.p2.setRange(1e-18,1e12);self.p2.setValue(1e-6)
        self.run=QPushButton("Evaluate Q-1")
        top.addWidget(QLabel("Mechanism"));top.addWidget(self.mode);top.addWidget(QLabel("Parameter 1"));top.addWidget(self.p1);top.addWidget(QLabel("Parameter 2"));top.addWidget(self.p2);top.addWidget(self.run)
        root.addLayout(top)
        self.help=QLabel();root.addWidget(self.help)
        self.summary=QPlainTextEdit();self.summary.setReadOnly(True);root.addWidget(self.summary,1)
        self.table=QTableWidget(0,4);self.table.setHorizontalHeaderLabels(["x","Value","Status","Physical meaning"]);self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.table,2)
        self.mode.currentIndexChanged.connect(self._mode);self.run.clicked.connect(self.evaluate);self._mode()
    def _mode(self,*_):
        m=self.mode.currentData()
        if m=="qi":
            self.help.setText("Parameter 1 = sampling time τ (s). Parameter 2 = requested negative-energy magnitude |ρ| (J/m³).")
            self.p1.setValue(1e-9);self.p2.setValue(1.0)
        elif m=="casimir":
            self.help.setText("Parameter 1 = plate separation a (m). Parameter 2 = plate area (m²). Ideal perfect conductors, T=0 only.")
            self.p1.setValue(1e-6);self.p2.setValue(.01)
        else:
            self.help.setText("Parameter 1 = squeeze parameter r. Parameter 2 = effective mode volume (m³). ω fixed at 1e15 rad/s for this declared workspace run.")
            self.p1.setValue(.5);self.p2.setValue(1e-18)
    def evaluate(self):
        try:
            from journeyman.core.state_events import DataOrigin
            from journeyman.core.qft import (QFTRequest,FieldKind,QuantumState,SamplingFunction,CasimirRequest,
                SqueezedVacuumRequest,ford_roman_lorentzian_massless_scalar_bound,qi_feasibility_margin,
                maximum_reference_sampling_time,ideal_parallel_plate_casimir,single_mode_squeezed_vacuum_reference,
                qft_guardian_contract,qi_magnitude_duration_curve)
            mode=self.mode.currentData();rows=[]
            if mode=="qi":
                tau=self.p1.value();mag=self.p2.value()
                req=QFTRequest("geometry.minkowski","workspace-reference",FieldKind.MASSLESS_SCALAR,QuantumState.VACUUM,
                    SamplingFunction.LORENTZIAN,tau,"inertial observer","none","vacuum subtraction",1e-8,
                    "Q-1 operational workspace",DataOrigin.SIMULATION)
                res=ford_roman_lorentzian_massless_scalar_bound(req);margin=qi_feasibility_margin(req,-mag)
                inv=maximum_reference_sampling_time(req,mag);gc=qft_guardian_contract(req,res)
                curve=qi_magnitude_duration_curve(req,(tau/4,tau/2,tau,2*tau,4*tau))
                self.summary.setPlainText("MODEL / SIMULATION REFERENCE — NOT PHYSICAL TELEMETRY\n"
                    f"Status={res.status.value}\nτ={tau:.8e} s\nQI lower bound={res.lower_bound_energy_density_j_m3:.8e} J/m³\n"
                    f"Requested ρ={-mag:.8e} J/m³ | margin={margin.margin_j_m3:.8e} J/m³ | satisfies reference bound={margin.satisfies_reference_bound}\n"
                    f"Inverted reference maximum τ for |ρ|={mag:.8e}: {inv.maximum_sampling_time_s:.8e} s\n"
                    f"Guardian={gc.schema}\nAuthority={gc.authority}\n\nAssumptions:\n- "+"\n- ".join(res.assumptions))
                rows=[(x.sampling_time_s,x.maximum_negative_magnitude_j_m3,"REFERENCE BOUND","|ρ|min bound magnitude vs τ") for x in curve]
            elif mode=="casimir":
                req=CasimirRequest(self.p1.value(),self.p2.value(),0,"IDEAL_PERFECT_CONDUCTOR","PARALLEL_PLATES","Q-1 operational workspace")
                res=ideal_parallel_plate_casimir(req)
                self.summary.setPlainText("MODEL / SIMULATION REFERENCE — NOT PHYSICAL TELEMETRY\n"
                    f"Status={res.status.value}\na={req.separation_m:.8e} m | area={req.plate_area_m2:.8e} m²\n"
                    f"Energy density={res.energy_density_j_m3:.8e} J/m³\nPressure={res.pressure_pa:.8e} Pa\nTotal cavity energy={res.total_energy_j:.8e} J\n\nAssumptions:\n- "+"\n- ".join(res.assumptions))
                rows=[(req.separation_m,res.energy_density_j_m3,res.status.value,"ideal boundary-condition energy density"),
                      (req.separation_m,res.pressure_pa,res.status.value,"ideal Casimir pressure")]
            else:
                req=SqueezedVacuumRequest(1e15,self.p1.value(),0,self.p2.value(),0,"Q-1 operational workspace")
                res=single_mode_squeezed_vacuum_reference(req)
                self.summary.setPlainText("MODEL / SIMULATION REFERENCE — NOT PHYSICAL TELEMETRY\n"
                    f"Status={res.status.value}\nω=1.00000000e15 rad/s | r={req.squeeze_parameter:.8g} | V={req.mode_volume_m3:.8e} m³\n"
                    f"Normal-ordered local energy density={res.normal_ordered_energy_density_j_m3:.8e} J/m³\n"
                    f"Mean excitation number={res.mean_excitation_number:.8e}\n\nAssumptions:\n- "+"\n- ".join(res.assumptions))
                rows=[(req.squeeze_parameter,res.normal_ordered_energy_density_j_m3,res.status.value,"single-mode normal-ordered local energy"),
                      (req.squeeze_parameter,res.mean_excitation_number,res.status.value,"mean mode excitation number")]
            self.table.setRowCount(len(rows))
            for i,row in enumerate(rows):
                for j,v in enumerate(row):self.table.setItem(i,j,QTableWidgetItem(f"{v:.8e}" if isinstance(v,float) else str(v)))
        except Exception as exc:self.summary.setPlainText(f"Q-1 EVALUATION REJECTED\n{type(exc).__name__}: {exc}");self.table.setRowCount(0)
    def export_workspace_state(self):
        return {"mode":self.mode.currentData(),"p1":self.p1.value(),"p2":self.p2.value()}
    def restore_workspace_state(self,state):
        if not isinstance(state,dict):return
        idx=self.mode.findData(state.get("mode","qi"))
        if idx>=0:self.mode.setCurrentIndex(idx)
        for k,w in (("p1",self.p1),("p2",self.p2)):
            if k in state:
                try:w.setValue(float(state[k]))
                except Exception:pass


class ChronologyWorkspace(QWidget):
    workspace_kind="chronology"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service
        root=QVBoxLayout(self)
        root.addWidget(QLabel("C-1 CHRONOLOGY ANALYZER — DECLARED / SIMULATED KINEMATIC MODEL"))
        form=QHBoxLayout()
        self.separation=QDoubleSpinBox();self.separation.setDecimals(6);self.separation.setRange(0,1e15);self.separation.setValue(100)
        self.offset=QDoubleSpinBox();self.offset.setDecimals(9);self.offset.setRange(-1e12,1e12);self.offset.setValue(2)
        self.speed=QDoubleSpinBox();self.speed.setDecimals(6);self.speed.setRange(1e-9,299792458.0);self.speed.setValue(100)
        self.u_offset=QDoubleSpinBox();self.u_offset.setDecimals(9);self.u_offset.setRange(0,1e9);self.u_offset.setValue(.1)
        self.u_sep=QDoubleSpinBox();self.u_sep.setDecimals(6);self.u_sep.setRange(0,1e12);self.u_sep.setValue(1)
        self.u_speed=QDoubleSpinBox();self.u_speed.setDecimals(6);self.u_speed.setRange(0,1e8);self.u_speed.setValue(1)
        self.run=QPushButton("Analyze C-1")
        for label,widget in (("Separation L (m)",self.separation),("Mouth offset Δt (s)",self.offset),
                             ("External return v (m/s)",self.speed),("u(Δt) (s)",self.u_offset),
                             ("u(L) (m)",self.u_sep),("u(v) (m/s)",self.u_speed)):
            form.addWidget(QLabel(label));form.addWidget(widget)
        form.addWidget(self.run);root.addLayout(form)
        self.summary=QPlainTextEdit();self.summary.setReadOnly(True);root.addWidget(self.summary,1)
        self.table=QTableWidget(0,4);self.table.setHorizontalHeaderLabels(["Mouth offset (s)","Chronology margin (s)","Modeled loop condition","Classification"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.table,2)
        self.run.clicked.connect(self.evaluate)
    def evaluate(self):
        try:
            from journeyman.core.chronology import ChronologyLoopRequest,chronology_margin_sweep
            req=ChronologyLoopRequest(self.separation.value(),self.offset.value(),self.speed.value(),
                self.u_offset.value(),self.u_sep.value(),self.u_speed.value(),
                "C-1 operational workspace declared scenario",DataOrigin.SIMULATION)
            ex=self.service.analyze_experiment("C1-workspace",req)
            g=self.service.expanded_guardian_contract(loop=ex.loop_assessment,horizon=ex.horizon)
            l=ex.loop_assessment;u=ex.uncertainty;h=ex.horizon;p=ex.protection
            self.summary.setPlainText(
                "DECLARED / SIMULATED MODEL — NOT PHYSICAL WORMHOLE OR CTC TELEMETRY\n"
                f"Epistemic classification: {ex.epistemic_classification}\n"
                f"External return time: {l.external_return_time_s:.9e} s\n"
                f"Declared mouth offset: {l.mouth_time_offset_s:.9e} s\n"
                f"Chronology margin: {l.chronology_margin_s:.9e} ± {l.chronology_margin_standard_uncertainty_s:.9e} s (1σ)\n"
                f"Uncertainty envelope ({u.confidence_factor:g}σ): [{u.lower_margin_s:.9e}, {u.upper_margin_s:.9e}] s\n"
                f"Envelope classification: {u.classification}\n"
                f"Modeled loop condition: {l.modeled_closed_causal_loop_condition}\n"
                f"Kinematic threshold: {h.threshold_offset_s:.9e} s | threshold crossed: {h.horizon_crossed_in_declared_model}\n"
                f"Chronology-protection status: {p.status.value}\n{p.conclusion}\n"
                f"Verification: {'PASS' if ex.verification.passed else 'FAIL'}\n"
                f"Guardian: {g.schema}\nAuthority: {g.authority}\n\n"
                "Scientific boundary:\n"
                "- The mouth mapping is an assumed simulation input.\n"
                "- Positive chronology margin is not evidence of a physical CTC.\n"
                "- Semiclassical backreaction at a chronology threshold remains unresolved."
            )
            t=l.external_return_time_s
            span=max(abs(t),abs(req.mouth_time_offset_s),1e-9)
            offsets=(req.mouth_time_offset_s-2*span,req.mouth_time_offset_s-span,
                     req.mouth_time_offset_s,req.mouth_time_offset_s+span,req.mouth_time_offset_s+2*span)
            sweep=chronology_margin_sweep(req,offsets)
            self.table.setRowCount(len(sweep))
            for i,pt in enumerate(sweep):
                classification="MODELED LOOP" if pt.modeled_closed_causal_loop_condition else "NO MODELED LOOP"
                vals=(pt.mouth_time_offset_s,pt.chronology_margin_s,str(pt.modeled_closed_causal_loop_condition),classification)
                for j,v in enumerate(vals):self.table.setItem(i,j,QTableWidgetItem(f"{v:.9e}" if isinstance(v,float) else str(v)))
        except Exception as exc:
            self.summary.setPlainText(f"C-1 ANALYSIS REJECTED\n{type(exc).__name__}: {exc}");self.table.setRowCount(0)
    def export_workspace_state(self):
        return {"separation":self.separation.value(),"offset":self.offset.value(),"speed":self.speed.value(),
                "u_offset":self.u_offset.value(),"u_sep":self.u_sep.value(),"u_speed":self.u_speed.value()}
    def restore_workspace_state(self,state):
        if not isinstance(state,dict):return
        for key,widget in (("separation",self.separation),("offset",self.offset),("speed",self.speed),
                           ("u_offset",self.u_offset),("u_sep",self.u_sep),("u_speed",self.u_speed)):
            if key in state:
                try:widget.setValue(float(state[key]))
                except Exception:pass


class MouthDynamicsWorkspace(QWidget):
    workspace_kind="mouth-dynamics"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service
        root=QVBoxLayout(self)
        root.addWidget(QLabel("D-1 MOUTH DYNAMICS — SIMULATION / KINEMATIC MODEL ONLY"))
        form=QHBoxLayout()
        self.beta=QDoubleSpinBox();self.beta.setDecimals(6);self.beta.setRange(.000001,.999);self.beta.setValue(.5)
        self.outbound=QDoubleSpinBox();self.outbound.setRange(.001,1e9);self.outbound.setValue(100)
        self.dwell=QDoubleSpinBox();self.dwell.setRange(0,1e9);self.dwell.setValue(10)
        self.ramp=QDoubleSpinBox();self.ramp.setRange(.001,1e8);self.ramp.setValue(10)
        self.clock_u=QDoubleSpinBox();self.clock_u.setDecimals(9);self.clock_u.setRange(0,1e6);self.clock_u.setValue(.01)
        self.velocity_u=QDoubleSpinBox();self.velocity_u.setDecimals(3);self.velocity_u.setRange(0,1e8);self.velocity_u.setValue(100)
        self.return_speed_beta=QDoubleSpinBox();self.return_speed_beta.setDecimals(6);self.return_speed_beta.setRange(.000001,1.0);self.return_speed_beta.setValue(1.0)
        self.run=QPushButton("Analyze D-1 Mission")
        for label,widget in (("Cruise β",self.beta),("Outbound/return (s)",self.outbound),("Dwell (s)",self.dwell),
                             ("Ramp (s)",self.ramp),("Clock u (s)",self.clock_u),("Velocity u (m/s)",self.velocity_u),
                             ("C-1 return β",self.return_speed_beta)):
            form.addWidget(QLabel(label));form.addWidget(widget)
        form.addWidget(self.run);root.addLayout(form)
        self.summary=QPlainTextEdit();self.summary.setReadOnly(True);root.addWidget(self.summary,1)
        self.table=QTableWidget(0,6)
        self.table.setHorizontalHeaderLabels(["t (s)","Separation (m)","A−B clock offset (s)","C-1 margin (s)","Modeled loop","Origin"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.table,2)
        self.run.clicked.connect(self.evaluate)
    def evaluate(self):
        try:
            from journeyman.core.mouth_dynamics import MouthState,MouthRole,SymmetricMissionRequest,C
            from journeyman.core.state_events import DataOrigin
            provenance="D-1 operational workspace declared simulation"
            a=MouthState("D1-workspace-mouth-A",MouthRole.A,0,0,(0,0,0),(0,0,0),"D1.workspace.inertial","J2000","TCB",
                         .1,self.clock_u.value(),provenance,DataOrigin.SIMULATION)
            b=MouthState("D1-workspace-mouth-B",MouthRole.B,0,0,(0,0,0),(0,0,0),"D1.workspace.inertial","J2000","TCB",
                         .1,self.clock_u.value(),provenance,DataOrigin.SIMULATION)
            req=SymmetricMissionRequest(self.beta.value()*C,self.outbound.value(),self.dwell.value(),self.outbound.value(),
                                        self.ramp.value(),provenance,DataOrigin.SIMULATION)
            mission=self.service.analyze_mission(b,req)
            evolution=self.service.evolve_pair(a,mission.transport,chronology_return_speed_m_s=self.return_speed_beta.value()*C)
            uncertainty=self.service.timing_uncertainty(mission.transport,initial_clock_uncertainty_s=self.clock_u.value(),
                                                        velocity_standard_uncertainty_m_s=self.velocity_u.value())
            cross=self.service.c1_cross_validate(evolution,external_return_speed_m_s=self.return_speed_beta.value()*C)
            feasibility=self.service.mission_feasibility(b,a,req,external_return_speed_m_s=self.return_speed_beta.value()*C,
                                                         clock_uncertainty_s=self.clock_u.value(),velocity_uncertainty_m_s=self.velocity_u.value())
            guardian=self.service.expanded_guardian_contract(mission=mission,feasibility=feasibility)
            self.summary.setPlainText(
                "SIMULATION / KINEMATIC MODEL — NOT PHYSICAL MOUTH TELEMETRY\n"
                f"Cruise beta: {self.beta.value():.6f}\n"
                f"Coordinate elapsed: {mission.transport.coordinate_elapsed_s:.9e} s\n"
                f"Transported-mouth proper elapsed: {mission.transport.proper_elapsed_s:.9e} s\n"
                f"Relativistic desynchronization: {mission.final_desynchronization_s:.9e} s\n"
                f"Timing standard uncertainty: {uncertainty.desynchronization_standard_uncertainty_s:.9e} s\n"
                f"Distance traveled: {mission.transport.distance_traveled_m:.9e} m\n"
                f"Peak Mouth A/B separation: {evolution.maximum_separation_m:.9e} m\n"
                f"Final displacement: {mission.final_displacement_m:.9e} m\n"
                f"Returned near origin: {mission.returned_near_origin}\n"
                f"D-1/C-1 cross-validation: {'PASS' if cross.passed else 'FAIL'} | Δ={cross.absolute_difference_s:.3e} s\n"
                f"Modeled chronology condition encountered: {feasibility.chronology_condition_at_max_separation}\n"
                f"Guardian: {guardian.schema}\nAuthority: {guardian.authority}\n\n"
                "SCIENTIFIC BOUNDARY:\n- Prescribed kinematic motion is not a propulsion solution.\n"
                "- Mouth A/B are simulation objects, not measured hardware.\n"
                "- No exotic stress-energy, mouth stability, traversability, or physical CTC is established."
            )
            samples=evolution.samples
            stride=max(1,len(samples)//100)
            shown=samples[::stride]
            if samples and shown[-1] is not samples[-1]:shown=shown+(samples[-1],)
            self.table.setRowCount(len(shown))
            for i,q in enumerate(shown):
                vals=(q.coordinate_time_s,q.separation_m,q.proper_time_offset_a_minus_b_s,
                      q.chronology_margin_s,str(q.modeled_loop_condition),"SIMULATION")
                for j,v in enumerate(vals):
                    self.table.setItem(i,j,QTableWidgetItem(f"{v:.9e}" if isinstance(v,float) else str(v)))
        except Exception as exc:
            self.summary.setPlainText(f"D-1 ANALYSIS REJECTED\n{type(exc).__name__}: {exc}");self.table.setRowCount(0)
    def export_workspace_state(self):
        return {"beta":self.beta.value(),"outbound":self.outbound.value(),"dwell":self.dwell.value(),"ramp":self.ramp.value(),
                "clock_u":self.clock_u.value(),"velocity_u":self.velocity_u.value(),"return_speed_beta":self.return_speed_beta.value()}
    def restore_workspace_state(self,state):
        if not isinstance(state,dict):return
        for key,widget in (("beta",self.beta),("outbound",self.outbound),("dwell",self.dwell),("ramp",self.ramp),
                           ("clock_u",self.clock_u),("velocity_u",self.velocity_u),("return_speed_beta",self.return_speed_beta)):
            if key in state:
                try:widget.setValue(float(state[key]))
                except Exception:pass


class RingLaserWorkspace(QWidget):
    workspace_kind="ring-laser"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service
        root=QVBoxLayout(self)
        root.addWidget(QLabel("METHOD B / RING-LASER — REFERENCE PHYSICS + SPECULATIVE HYPOTHESIS GATE"))
        form=QGridLayout()
        self.area=QDoubleSpinBox();self.area.setDecimals(6);self.area.setRange(1e-9,1e9);self.area.setValue(1)
        self.perimeter=QDoubleSpinBox();self.perimeter.setDecimals(6);self.perimeter.setRange(1e-9,1e9);self.perimeter.setValue(4)
        self.wavelength_nm=QDoubleSpinBox();self.wavelength_nm.setDecimals(6);self.wavelength_nm.setRange(.001,1e9);self.wavelength_nm.setValue(632.8)
        self.power=QDoubleSpinBox();self.power.setDecimals(3);self.power.setRange(0,1e15);self.power.setValue(1e6)
        self.omega=QDoubleSpinBox();self.omega.setDecimals(9);self.omega.setRange(-1e9,1e9);self.omega.setValue(1)
        self.mode_area=QDoubleSpinBox();self.mode_area.setDecimals(9);self.mode_area.setRange(1e-12,1e9);self.mode_area.setValue(.001)
        self.radius=QDoubleSpinBox();self.radius.setDecimals(6);self.radius.setRange(1e-9,1e9);self.radius.setValue(1)
        self.observation_radius=QDoubleSpinBox();self.observation_radius.setDecimals(6);self.observation_radius.setRange(1e-9,1e12);self.observation_radius.setValue(2)
        self.model_id=QLineEdit("declared-speculative-model")
        self.model_revision=QLineEdit("r1")
        self.indicator=QDoubleSpinBox();self.indicator.setDecimals(9);self.indicator.setRange(-1e15,1e15);self.indicator.setValue(0)
        self.threshold=QDoubleSpinBox();self.threshold.setDecimals(9);self.threshold.setRange(-1e15,1e15);self.threshold.setValue(1)
        controls=(("Ring area (m²)",self.area),("Perimeter/path (m)",self.perimeter),("Vacuum λ (nm)",self.wavelength_nm),
                  ("Circulating power (W)",self.power),("Ω·n (rad/s)",self.omega),("Mode area (m²)",self.mode_area),
                  ("Ring radius (m)",self.radius),("Observation radius (m)",self.observation_radius),
                  ("Hypothesis model",self.model_id),("Model revision",self.model_revision),
                  ("Declared indicator",self.indicator),("Declared threshold",self.threshold))
        for i,(label,widget) in enumerate(controls):
            form.addWidget(QLabel(label),i//4*2,i%4);form.addWidget(widget,i//4*2+1,i%4)
        root.addLayout(form)
        self.run=QPushButton("Analyze Method B");root.addWidget(self.run)
        self.summary=QPlainTextEdit();self.summary.setReadOnly(True);root.addWidget(self.summary,2)
        self.table=QTableWidget(0,5);self.table.setHorizontalHeaderLabels(["Power (W)","Stored E (J)","Angular momentum","Compactness","Weak-field Ω (rad/s)"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.table,1)
        self.run.clicked.connect(self.evaluate)
    def evaluate(self):
        try:
            from journeyman.core.ring_laser import (RingGeometry,OpticalState,RotationState,RingOpticalEnergyRequest,
                ChronologyHypothesisRequest,C)
            from journeyman.core.state_events import DataOrigin
            prov="Method-B operational workspace simulation"
            lam=self.wavelength_nm.value()*1e-9
            geo=RingGeometry("RLA-workspace-ring",self.area.value(),self.perimeter.value(),(0,0,1),0,0,"RLA.workspace.inertial",prov,DataOrigin.SIMULATION)
            opt=OpticalState(lam,C/lam,self.power.value(),0,0,prov,DataOrigin.SIMULATION)
            rot=RotationState((0,0,self.omega.value()),0,"RLA.workspace.inertial","J2000",prov,DataOrigin.SIMULATION)
            sag=self.service.sagnac(geo,opt,rot)
            energy=self.service.optical_energy(RingOpticalEnergyRequest(self.power.value(),self.perimeter.value(),self.mode_area.value(),prov,DataOrigin.SIMULATION))
            ang=self.service.angular_momentum(energy.stored_energy_j,self.radius.value(),provenance=prov)
            drag=self.service.weak_field_dragging(ang.angular_momentum_kg_m2_s,self.observation_radius.value(),provenance=prov)
            gravity=self.service.gravitational_scale(energy.stored_energy_j,self.radius.value(),provenance=prov)
            hyp=self.service.assess_chronology_hypothesis(ChronologyHypothesisRequest(self.model_id.text(),self.model_revision.text(),
                "declared_user_indicator",self.indicator.value(),self.threshold.value(),prov,DataOrigin.SIMULATION))
            guard=self.service.hypothesis_guardian_contract(hyp,provenance=prov)
            ready=self.service.release_readiness()
            self.summary.setPlainText(
                "SIMULATION / MODEL VALUES — NOT PHYSICAL RING-LASER TELEMETRY\n\n"
                f"Sagnac Δt: {sag.time_difference_s:.9e} s\nSagnac beat Δf: {sag.beat_frequency_hz:.9e} Hz\n"
                f"Stored optical energy: {energy.stored_energy_j:.9e} J\nMean energy density: {energy.mean_energy_density_j_m3:.9e} J/m³\n"
                f"Circulating angular momentum scale: {ang.angular_momentum_kg_m2_s:.9e} kg·m²/s\n"
                f"Compactness: {gravity.compactness:.9e}\nWeak-field comparison Ω: {drag.angular_rate_rad_s:.9e} rad/s\n\n"
                f"Declared hypothesis threshold crossed: {hyp.threshold_crossed}\nChronology claim status: {hyp.status.value}\n"
                f"{hyp.message}\n\nGuardian: {guard.schema}\nAuthority: {guard.authority}\n"
                f"Method-B software release readiness: {'PASS' if ready.passed else 'FAIL'}\n\n"
                "BOUNDARY: Sagnac rotation physics and electromagnetic gravity are established reference physics. "
                "A usable circulating-light chronology mechanism remains unresolved physics."
            )
            powers=(self.power.value()*.01,self.power.value()*.1,self.power.value(),self.power.value()*10,self.power.value()*100)
            pts=self.service.gravity_scaling(powers,path_length_m=self.perimeter.value(),mode_area_m2=self.mode_area.value(),
                                             ring_radius_m=self.radius.value(),observation_radius_m=self.observation_radius.value(),provenance=prov)
            self.table.setRowCount(len(pts))
            for i,q in enumerate(pts):
                for j,v in enumerate((q.circulating_power_w,q.stored_energy_j,q.angular_momentum_kg_m2_s,q.compactness,q.weak_field_drag_rate_rad_s)):
                    self.table.setItem(i,j,QTableWidgetItem(f"{v:.9e}"))
        except Exception as exc:
            self.summary.setPlainText(f"METHOD-B ANALYSIS REJECTED\n{type(exc).__name__}: {exc}");self.table.setRowCount(0)
    def export_workspace_state(self):
        return {k:w.value() for k,w in (("area",self.area),("perimeter",self.perimeter),("wavelength_nm",self.wavelength_nm),
            ("power",self.power),("omega",self.omega),("mode_area",self.mode_area),("radius",self.radius),
            ("observation_radius",self.observation_radius),("indicator",self.indicator),("threshold",self.threshold))}|{"model_id":self.model_id.text(),"model_revision":self.model_revision.text()}
    def restore_workspace_state(self,state):
        if not isinstance(state,dict):return
        for k,w in (("area",self.area),("perimeter",self.perimeter),("wavelength_nm",self.wavelength_nm),("power",self.power),
                    ("omega",self.omega),("mode_area",self.mode_area),("radius",self.radius),("observation_radius",self.observation_radius),
                    ("indicator",self.indicator),("threshold",self.threshold)):
            if k in state:
                try:w.setValue(float(state[k]))
                except Exception:pass
        if "model_id" in state:self.model_id.setText(str(state["model_id"]))
        if "model_revision" in state:self.model_revision.setText(str(state["model_revision"]))


class VerificationWorkspace(QWidget):
    workspace_kind="verification"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service
        root=QVBoxLayout(self)
        root.addWidget(QLabel("VERIFICATION & UNCERTAINTY — SOFTWARE/IMPORTED/MODEL EVIDENCE; NO PHYSICAL CLAIM IS CREATED BY PASS"))
        form=QGridLayout()
        self.primary=QDoubleSpinBox();self.independent=QDoubleSpinBox()
        self.u_primary=QDoubleSpinBox();self.u_independent=QDoubleSpinBox()
        self.abs_tol=QDoubleSpinBox();self.rel_tol=QDoubleSpinBox();self.sigma=QDoubleSpinBox()
        for q in (self.primary,self.independent):q.setRange(-1e300,1e300);q.setDecimals(12)
        for q in (self.u_primary,self.u_independent,self.abs_tol,self.rel_tol):
            q.setRange(0,1e300);q.setDecimals(12)
        self.sigma.setRange(.001,1000);self.sigma.setDecimals(4);self.sigma.setValue(3)
        self.unit=QLineEdit("1");self.source_a=QLineEdit("primary-source");self.source_b=QLineEdit("independent-source")
        self.algorithm_a=QLineEdit("primary-algorithm");self.algorithm_b=QLineEdit("independent-algorithm")
        controls=(("Primary value",self.primary),("Independent value",self.independent),
                  ("Primary u",self.u_primary),("Independent u",self.u_independent),
                  ("Absolute tolerance",self.abs_tol),("Relative tolerance",self.rel_tol),("Sigma envelope",self.sigma),
                  ("Unit",self.unit),("Primary source",self.source_a),("Independent source",self.source_b),
                  ("Primary algorithm",self.algorithm_a),("Independent algorithm",self.algorithm_b))
        for i,(label,widget) in enumerate(controls):
            r=(i//4)*2;c=i%4;form.addWidget(QLabel(label),r,c);form.addWidget(widget,r+1,c)
        root.addLayout(form)
        buttons=QHBoxLayout();self.compare_btn=QPushButton("Run Independent Verification");self.readiness_btn=QPushButton("V&V v1 Release Readiness")
        buttons.addWidget(self.compare_btn);buttons.addWidget(self.readiness_btn);root.addLayout(buttons)
        self.summary=QPlainTextEdit();self.summary.setReadOnly(True);root.addWidget(self.summary,2)
        self.matrix=QTableWidget(0,5);self.matrix.setHorizontalHeaderLabels(["Check","Status","Difference","Allowed","Evidence"])
        self.matrix.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.matrix,1)
        self.compare_btn.clicked.connect(self.evaluate);self.readiness_btn.clicked.connect(self.show_readiness)
    def _values(self):
        from journeyman.core.verification import VerificationValue,VerificationTolerance
        from journeyman.core.state_events import DataOrigin
        prov="V&V operational workspace"
        a=VerificationValue(self.primary.value(),self.unit.text(),self.u_primary.value(),self.source_a.text(),
                            self.algorithm_a.text(),"workspace-r1",prov,DataOrigin.SOFTWARE)
        b=VerificationValue(self.independent.value(),self.unit.text(),self.u_independent.value(),self.source_b.text(),
                            self.algorithm_b.text(),"workspace-r1",prov,DataOrigin.SOFTWARE)
        tol=VerificationTolerance(self.abs_tol.value(),self.rel_tol.value(),self.sigma.value())
        return a,b,tol
    def evaluate(self):
        try:
            a,b,tol=self._values()
            record=self.service.compare(a,b,tol);ind=self.service.check_independence(a,b)
            cross=self.service.cross_validate(a,b,tol);guardian=self.service.guardian_contract(record,ind,provenance="V&V operational workspace")
            self.summary.setPlainText(
                f"Verification status: {record.status.value}\nDiscrepancy class: {record.discrepancy_class.value}\n"
                f"Difference: {record.difference}\nCombined standard uncertainty: {record.combined_standard_uncertainty}\n"
                f"Normalized difference: {record.normalized_difference_sigma} sigma\nAllowed difference: {record.allowed_difference}\n"
                f"Independent sources: {ind.independent_sources}\nIndependent algorithms: {ind.independent_algorithms}\n"
                f"Cross-validation qualification: {cross.status.value}\n\n{record.message}\n{ind.message}\n\n"
                f"Guardian schema: {guardian.schema}\nGuardian status: {guardian.status}\nAuthority: {guardian.authority}\n\n"
                "PASS qualifies agreement under the declared software verification contract. It does not validate an unresolved physical theory."
            )
            rows=(("Result comparison",record.status.value,record.difference,record.allowed_difference,record.message),
                  ("Independence gate",ind.status.value,"—","—",ind.message),
                  ("Cross-validation",cross.status.value,"—","—",cross.message))
            self.matrix.setRowCount(len(rows))
            for i,row in enumerate(rows):
                for j,v in enumerate(row):self.matrix.setItem(i,j,QTableWidgetItem(str(v)))
        except Exception as exc:
            self.summary.setPlainText(f"VERIFICATION REJECTED\n{type(exc).__name__}: {exc}");self.matrix.setRowCount(0)
    def show_readiness(self):
        q=self.service.release_readiness()
        body=("PASS" if q.passed else "FAIL")+"\n\nChecks:\n- "+"\n- ".join(q.checks or ("none",))
        if q.failures:body+="\n\nFailures:\n- "+"\n- ".join(q.failures)
        if q.notes:body+="\n\nNotes:\n- "+"\n- ".join(q.notes)
        self.summary.setPlainText(body)
    def export_workspace_state(self):
        return {"primary":self.primary.value(),"independent":self.independent.value(),"u_primary":self.u_primary.value(),
                "u_independent":self.u_independent.value(),"abs_tol":self.abs_tol.value(),"rel_tol":self.rel_tol.value(),
                "sigma":self.sigma.value(),"unit":self.unit.text(),"source_a":self.source_a.text(),"source_b":self.source_b.text(),
                "algorithm_a":self.algorithm_a.text(),"algorithm_b":self.algorithm_b.text()}
    def restore_workspace_state(self,state):
        if not isinstance(state,dict):return
        for k,q in (("primary",self.primary),("independent",self.independent),("u_primary",self.u_primary),
                    ("u_independent",self.u_independent),("abs_tol",self.abs_tol),("rel_tol",self.rel_tol),("sigma",self.sigma)):
            if k in state:
                try:q.setValue(float(state[k]))
                except Exception:pass
        for k,q in (("unit",self.unit),("source_a",self.source_a),("source_b",self.source_b),
                    ("algorithm_a",self.algorithm_a),("algorithm_b",self.algorithm_b)):
            if k in state:q.setText(str(state[k]))


class DigitalTwinWorkspace(QWidget):
    workspace_kind="digital-twin"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service;self.engine=service.create_engine(step_size_s=.1,provenance="JOE Digital Twin workspace")
        self.mouth_a=None;self.mouth_b=None;self.history=service.worldline_history();self.session=None
        root=QVBoxLayout(self)
        self.banner=QLabel("DIGITAL TWIN — SIMULATION/SYNTHETIC ONLY — NOT PHYSICAL WORMHOLE OR HARDWARE TELEMETRY")
        root.addWidget(self.banner)
        cfg=QGridLayout()
        self.step_size=QDoubleSpinBox();self.step_size.setRange(.000001,1e6);self.step_size.setDecimals(6);self.step_size.setValue(.1)
        self.ax=QDoubleSpinBox();self.ay=QDoubleSpinBox();self.az=QDoubleSpinBox()
        self.bx=QDoubleSpinBox();self.by=QDoubleSpinBox();self.bz=QDoubleSpinBox()
        for q in (self.ax,self.ay,self.az,self.bx,self.by,self.bz):
            q.setRange(-1e15,1e15);q.setDecimals(3)
        self.bx.setValue(1000)
        self.frame=QLineEdit("SIM-LOCAL-CARTESIAN");self.epoch=QLineEdit("SIM-EPOCH-0")
        self.offset=QDoubleSpinBox();self.offset.setRange(-1e12,1e12);self.offset.setDecimals(9);self.offset.setValue(1.0)
        self.return_speed=QDoubleSpinBox();self.return_speed.setRange(.001,299792458.0);self.return_speed.setDecimals(3);self.return_speed.setValue(1000.0)
        labels=(("Step (s)",self.step_size),("Frame",self.frame),("Epoch",self.epoch),
                ("Mouth time offset (s)",self.offset),("External return speed (m/s)",self.return_speed),
                ("Mouth A X (m)",self.ax),("A Y",self.ay),("A Z",self.az),
                ("Mouth B X (m)",self.bx),("B Y",self.by),("B Z",self.bz))
        for i,(label,q) in enumerate(labels):
            r=(i//3)*2;c=i%3;cfg.addWidget(QLabel(label),r,c);cfg.addWidget(q,r+1,c)
        root.addLayout(cfg)
        buttons=QHBoxLayout()
        self.configure_btn=QPushButton("Configure Mouth A/B");self.start_btn=QPushButton("Start")
        self.pause_btn=QPushButton("Pause");self.step_btn=QPushButton("Step");self.stop_btn=QPushButton("Stop")
        for q in (self.configure_btn,self.start_btn,self.pause_btn,self.step_btn,self.stop_btn):buttons.addWidget(q)
        root.addLayout(buttons)
        self.status=QPlainTextEdit();self.status.setReadOnly(True);root.addWidget(self.status,1)
        self.scene=QTableWidget(0,8);self.scene.setHorizontalHeaderLabels(
            ["Object","Type","X (m)","Y (m)","Z (m)","|v| (m/s)","u_pos (m)","Origin"])
        self.scene.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.scene,2)
        self.telemetry=QTableWidget(0,7);self.telemetry.setHorizontalHeaderLabels(
            ["Channel","Variable","Value","Unit","u","Quality","Origin"])
        self.telemetry.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.telemetry,1)
        self.live_plot=pg.PlotWidget();self.live_plot.setLabel("bottom","Simulation time","s");self.live_plot.setLabel("left","Mouth offset","s")
        self.live_curve=self.live_plot.plot([],[]);self._plot_t=[];self._plot_v=[];root.addWidget(self.live_plot,2)
        self.configure_btn.clicked.connect(self.configure_pair);self.start_btn.clicked.connect(self.start)
        self.pause_btn.clicked.connect(self.pause);self.step_btn.clicked.connect(self.step);self.stop_btn.clicked.connect(self.stop)
        self._refresh()
    def _positions(self):
        return ((self.ax.value(),self.ay.value(),self.az.value()),(self.bx.value(),self.by.value(),self.bz.value()))
    def configure_pair(self):
        from journeyman.core.digital_twin import (create_twin_object,TwinObjectType,DigitalTwinEngine,TwinWorldlineHistory,
                DigitalTwinSession,TelemetryChannel,DeterministicSource)
        try:
            self.engine=DigitalTwinEngine(step_size_s=self.step_size.value(),provenance="JOE Digital Twin workspace")
            self.history=TwinWorldlineHistory();a,b=self._positions()
            self.mouth_a=create_twin_object("Mouth A",TwinObjectType.MOUTH_A,self.frame.text(),self.epoch.text(),a,provenance="JOE workspace SIMULATION")
            self.mouth_b=create_twin_object("Mouth B",TwinObjectType.MOUTH_B,self.frame.text(),self.epoch.text(),b,provenance="JOE workspace SIMULATION")
            self.engine.add_object(self.mouth_a);self.engine.add_object(self.mouth_b);self.engine.ready()
            self.session=DigitalTwinSession(self.engine,provenance="JOE Digital Twin workspace")
            ch=TelemetryChannel("mouth-time-offset",self.mouth_a.object_id,"mouth_time_offset","s",1e-6,max(self.step_size.value()*2,1e-6),"JOE workspace SIMULATION")
            src=DeterministicSource("mouth-offset-source","mouth_time_offset","s",self.offset.value(),0,0,0,"JOE workspace SIMULATION")
            self.session.bind_source(ch,src);self.history=self.session.history;self._plot_t=[];self._plot_v=[];self._record();self._refresh()
        except Exception as exc:self.status.setPlainText(f"CONFIGURATION REJECTED\n{type(exc).__name__}: {exc}")
    def start(self):
        try:self.engine.start();self._refresh()
        except Exception as exc:self.status.setPlainText(f"START REJECTED\n{type(exc).__name__}: {exc}")
    def pause(self):
        try:self.engine.pause();self._refresh()
        except Exception as exc:self.status.setPlainText(f"PAUSE REJECTED\n{type(exc).__name__}: {exc}")
    def stop(self):
        try:self.engine.stop();self._refresh()
        except Exception as exc:self.status.setPlainText(f"STOP REJECTED\n{type(exc).__name__}: {exc}")
    def _record(self):
        if self.session:
            self.session.record_worldlines();return
        from journeyman.core.digital_twin import TwinWorldlinePoint
        for obj in self.engine.state.objects:
            pts=self.history.points(obj.object_id)
            if pts and self.engine.state.clock.simulation_time_s<=pts[-1].simulation_time_s:continue
            self.history.append(TwinWorldlinePoint(obj.object_id,self.engine.state.clock.simulation_time_s,
                self.engine.state.clock.simulation_time_s,self.engine.state.clock.simulation_time_s,obj.position_m,obj.velocity_m_s,
                obj.frame_id,obj.epoch_id,obj.provenance))
    def step(self):
        try:self.engine.step();self._record();self._refresh()
        except Exception as exc:self.status.setPlainText(f"STEP REJECTED\n{type(exc).__name__}: {exc}")
    def _refresh(self):
        from journeyman.core.digital_twin import monitor_simulated_mouth_pair,SceneReference,SceneScale,build_spatial_scene,scene_bounds
        st=self.engine.state;objects=st.objects
        self.scene.setRowCount(len(objects))
        for i,x in enumerate(objects):
            speed=sum(v*v for v in x.velocity_m_s)**.5
            vals=(x.name,x.object_type.value,*x.position_m,speed,x.position_standard_uncertainty_m,x.origin.value)
            for j,v in enumerate(vals):self.scene.setItem(i,j,QTableWidgetItem(str(v)))
        lines=[f"Lifecycle: {st.lifecycle.value}",f"Simulation time: {st.clock.simulation_time_s:.9f} s",
               f"Step index: {st.clock.step_index}",f"Revision: {st.revision}",f"Origin: SIMULATION"]
        if len(objects)==2:
            try:
                mon=monitor_simulated_mouth_pair(objects[0],objects[1]);lines+=["",f"Mouth separation: {mon.separation_m} m",
                    f"Relative speed: {mon.relative_speed_m_s} m/s",f"Combined position u: {mon.combined_position_standard_uncertainty_m} m"]
                ref=SceneReference("workspace-scene","Digital Twin Scene",objects[0].frame_id,objects[0].epoch_id,(0,0,0),SceneScale.FACILITY,"JOE workspace")
                sc=build_spatial_scene(ref,objects,simulation_time_s=st.clock.simulation_time_s,histories=self.history,revision=st.revision)
                bounds=scene_bounds(sc);lines += [f"Scene trajectories: {len(sc.trajectories)}",f"Scene span XYZ (m): {bounds.span_m}"]
            except Exception as exc:lines+=["",f"Spatial monitor unavailable: {type(exc).__name__}: {exc}"]
        if self.session and len(objects)==2:
            try:
                from journeyman.core.digital_twin import TwinMouthTemporalState,mouth_pair_temporal_state
                t=st.clock.simulation_time_s
                ta=TwinMouthTemporalState(objects[0].object_id,"A",t,t+self.offset.value(),1e-6,t,"JOE workspace SIMULATION")
                tb=TwinMouthTemporalState(objects[1].object_id,"B",t,t,1e-6,t,"JOE workspace SIMULATION")
                pair=mouth_pair_temporal_state(ta,tb,provenance="JOE workspace SIMULATION")
                mf=self.session.monitor(predictions={"mouth-time-offset":(self.offset.value(),1e-6)},
                    mouth_temporal_pair=pair,external_return_speed_m_s=self.return_speed.value())
                if mf.telemetry:
                    self.telemetry.setRowCount(len(mf.telemetry.samples))
                    for i,x in enumerate(mf.telemetry.samples):
                        vals=(x.channel_id,x.variable,x.value,x.unit,x.standard_uncertainty,x.quality.value,x.origin.value)
                        for j,v in enumerate(vals):self.telemetry.setItem(i,j,QTableWidgetItem(str(v)))
                    sample=mf.telemetry.samples[0]
                    if not self._plot_t or sample.simulation_time_s>self._plot_t[-1]:
                        self._plot_t.append(sample.simulation_time_s);self._plot_v.append(sample.value)
                        self.live_curve.setData(self._plot_t,self._plot_v)
                if mf.chronology:
                    lines+=["",f"C-1 modeled chronology margin: {mf.chronology.chronology_margin_s} s",
                        f"C-1 modeled loop condition: {mf.chronology.modeled_closed_causal_loop_condition}",
                        "Chronology status is SIMULATION/MODEL ONLY; it is not evidence of a physical CTC."]
                lines += [f"Guardian: {mf.guardian.status}",f"Telemetry anomalies: {len(mf.anomaly_channels)}",
                          f"Stale channels: {len(mf.stale_channels)}"]
            except Exception as exc:lines+=["",f"Integrated monitor unavailable: {type(exc).__name__}: {exc}"]
        lines+=["","All values above are synthetic/model state. No physical mouth or hardware telemetry is connected."]
        self.status.setPlainText("\n".join(lines))
    def export_workspace_state(self):
        a,b=self._positions()
        return {"step_size":self.step_size.value(),"frame":self.frame.text(),"epoch":self.epoch.text(),"a":a,"b":b}
    def restore_workspace_state(self,state):
        if not isinstance(state,dict):return
        try:
            self.step_size.setValue(float(state.get("step_size",.1)));self.frame.setText(str(state.get("frame","SIM-LOCAL-CARTESIAN")))
            self.epoch.setText(str(state.get("epoch","SIM-EPOCH-0")))
            for q,v in zip((self.ax,self.ay,self.az),state.get("a",(0,0,0))):q.setValue(float(v))
            for q,v in zip((self.bx,self.by,self.bz),state.get("b",(1000,0,0))):q.setValue(float(v))
        except Exception:pass


class ExperimentDesignerWorkspace(QWidget):
    workspace_kind="experiment-designer"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service;self.plan=None;self.sequencer=None;self.checkpoint=None
        root=QVBoxLayout(self)
        root.addWidget(QLabel("EXPERIMENT DESIGNER / SEQUENCER — RESEARCH SIMULATION ONLY — NO PHYSICAL ACTUATOR AUTHORITY"))
        form=QGridLayout()
        self.name=QLineEdit("Journeyman Simulation Experiment")
        self.param_revision=QLineEdit("MPR-DECLARED")
        self.param_json=QLineEdit('{"mode":"simulation"}')
        self.step_name=QLineEdit("Initial Hold")
        self.step_kind=QComboBox();self.step_kind.addItems(["CONFIGURE","CHECK","WAIT","SAMPLE","COMPUTE","MARK"])
        self.duration=QDoubleSpinBox();self.duration.setRange(0,1e9);self.duration.setDecimals(6);self.duration.setValue(1.0)
        fields=(("Experiment",self.name),("Parameter revision",self.param_revision),("Parameter JSON",self.param_json),
                ("Step name",self.step_name),("Step kind",self.step_kind),("Duration (s)",self.duration))
        for i,(lab,widget) in enumerate(fields):form.addWidget(QLabel(lab),i,0);form.addWidget(widget,i,1)
        root.addLayout(form)
        row=QHBoxLayout()
        self.build_btn=QPushButton("Build + Validate");self.start_btn=QPushButton("Start")
        self.advance_btn=QPushButton("Advance Step");self.pause_btn=QPushButton("Pause/Resume")
        self.checkpoint_btn=QPushButton("Checkpoint");self.abort_btn=QPushButton("Abort")
        for x in (self.build_btn,self.start_btn,self.advance_btn,self.pause_btn,self.checkpoint_btn,self.abort_btn):row.addWidget(x)
        root.addLayout(row)
        self.summary=QPlainTextEdit();self.summary.setReadOnly(True);root.addWidget(self.summary,1)
        self.events=QTableWidget(0,6);self.events.setHorizontalHeaderLabels(["Seq","Type","Phase","Step","Sim t (s)","Message"])
        self.events.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.events,2)
        self.build_btn.clicked.connect(self.build_plan);self.start_btn.clicked.connect(self.start)
        self.advance_btn.clicked.connect(self.advance);self.pause_btn.clicked.connect(self.pause_resume)
        self.checkpoint_btn.clicked.connect(self.make_checkpoint);self.abort_btn.clicked.connect(self.abort)
        self._refresh()
    def build_plan(self):
        import json
        from journeyman.core.experiment_designer import (parameter_snapshot,ExperimentStep,StepKind,ExperimentPhase,
            create_experiment_plan,validate_plan,ready_plan,bind_execution_context,BranchingSimulationSequencer)
        try:
            vals=json.loads(self.param_json.text())
            if not isinstance(vals,dict):raise ValueError("Parameter JSON must be an object")
            snap=parameter_snapshot(vals,revision_id=self.param_revision.text(),provenance="JOE Experiment Designer workspace")
            step=ExperimentStep("step-1",self.step_name.text(),StepKind(self.step_kind.currentText()),self.duration.value(),
                                provenance="JOE Experiment Designer workspace")
            plan=create_experiment_plan(self.name.text(),snap,(ExperimentPhase("phase-1","Primary Phase",(step,),
                                        "JOE Experiment Designer workspace"),),provenance="JOE Experiment Designer workspace")
            self.plan=ready_plan(validate_plan(plan));binding=bind_execution_context(self.plan,provenance="JOE Experiment Designer workspace")
            self.sequencer=BranchingSimulationSequencer(self.plan,binding,provenance="JOE Experiment Designer workspace");self.checkpoint=None
            self._refresh()
        except Exception as exc:self.summary.setPlainText(f"PLAN REJECTED\n{type(exc).__name__}: {exc}")
    def start(self):
        try:self.sequencer.start();self._refresh()
        except Exception as exc:self.summary.setPlainText(f"START REJECTED\n{type(exc).__name__}: {exc}")
    def advance(self):
        try:
            phase,step=self.sequencer.current()
            if step:self.sequencer.advance(max(step.duration_s-self.sequencer.state.cursor.elapsed_in_step_s,1e-9))
            self.sequencer.advance(1e-9);self._refresh()
        except Exception as exc:self.summary.setPlainText(f"ADVANCE REJECTED\n{type(exc).__name__}: {exc}")
    def pause_resume(self):
        try:
            from journeyman.core.experiment_designer import ExperimentLifecycle
            if self.sequencer.state.plan.lifecycle==ExperimentLifecycle.RUNNING:self.sequencer.pause()
            elif self.sequencer.state.plan.lifecycle==ExperimentLifecycle.PAUSED:self.sequencer.resume()
            else:raise ValueError("sequencer must be RUNNING or PAUSED")
            self._refresh()
        except Exception as exc:self.summary.setPlainText(f"PAUSE/RESUME REJECTED\n{type(exc).__name__}: {exc}")
    def make_checkpoint(self):
        try:self.checkpoint=self.sequencer.checkpoint();self._refresh()
        except Exception as exc:self.summary.setPlainText(f"CHECKPOINT REJECTED\n{type(exc).__name__}: {exc}")
    def abort(self):
        try:self.sequencer.abort("operator requested SIMULATION abort");self._refresh()
        except Exception as exc:self.summary.setPlainText(f"ABORT REJECTED\n{type(exc).__name__}: {exc}")
    def _refresh(self):
        if not self.sequencer:
            self.summary.setPlainText("No experiment plan loaded.\nBuild + Validate creates a revisioned SIMULATION plan.");self.events.setRowCount(0);return
        from journeyman.core.experiment_designer import execution_guardian_contract
        st=self.sequencer.state;g=execution_guardian_contract(self.sequencer);phase,step=self.sequencer.current()
        lines=[f"Experiment: {st.plan.name}",f"Experiment ID: {st.plan.experiment_id}",f"Plan revision: {st.plan.revision}",
               f"Lifecycle: {st.plan.lifecycle.value}",f"Parameter revision: {st.plan.parameter_snapshot.revision_id}",
               f"Parameter SHA-256: {st.plan.parameter_snapshot.digest_sha256}",f"Run ID: {self.sequencer.manifest.run_id}",
               f"Simulation time: {st.simulation_time_s:.9f} s",f"Current phase: {phase.name if phase else 'N/A'}",
               f"Current step: {step.name if step else 'N/A'}",f"Completed steps: {len(self.sequencer.completed)}",
               f"Evidence records: {len(self.sequencer.evidence)}",f"Guardian: {g.status}",
               f"Checkpoint: {'AVAILABLE' if self.checkpoint else 'NONE'}","",
               "Authority: RESEARCH/SIMULATION ONLY. BUS-SAFE and deterministic hardware interlocks remain external."]
        self.summary.setPlainText("\n".join(lines))
        self.events.setRowCount(len(st.events))
        for i,e in enumerate(st.events):
            vals=(e.sequence,e.event_type,e.phase_id or "",e.step_id or "",e.simulation_time_s,e.message)
            for j,v in enumerate(vals):self.events.setItem(i,j,QTableWidgetItem(str(v)))
    def export_workspace_state(self):
        return {"name":self.name.text(),"parameter_revision":self.param_revision.text(),"parameter_json":self.param_json.text(),
                "step_name":self.step_name.text(),"step_kind":self.step_kind.currentText(),"duration_s":self.duration.value()}
    def restore_workspace_state(self,state):
        if not isinstance(state,dict):return
        self.name.setText(str(state.get("name",self.name.text())));self.param_revision.setText(str(state.get("parameter_revision",self.param_revision.text())))
        self.param_json.setText(str(state.get("parameter_json",self.param_json.text())));self.step_name.setText(str(state.get("step_name",self.step_name.text())))
        self.step_kind.setCurrentText(str(state.get("step_kind",self.step_kind.currentText())));self.duration.setValue(float(state.get("duration_s",self.duration.value())))


class MetrologyWorkspace(QWidget):
    workspace_kind="metrology"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service;self.history_a=[];self.history_b=[];self.sequence=0
        root=QVBoxLayout(self)
        root.addWidget(QLabel("METROLOGY & TEMPORAL NAVIGATION — SIMULATION/SYNTHETIC CLOCKS — NOT PHYSICAL TELEMETRY"))
        form=QGridLayout()
        self.a_read=QDoubleSpinBox();self.b_read=QDoubleSpinBox()
        self.a_read.setRange(-1e12,1e12);self.b_read.setRange(-1e12,1e12);self.a_read.setDecimals(9);self.b_read.setDecimals(9)
        self.unc=QDoubleSpinBox();self.unc.setRange(0,1e6);self.unc.setDecimals(9);self.unc.setValue(.000001)
        self.now=QDoubleSpinBox();self.now.setRange(0,1e12);self.now.setDecimals(6)
        self.max_offset=QDoubleSpinBox();self.max_offset.setRange(0,1e9);self.max_offset.setDecimals(9);self.max_offset.setValue(.001)
        self.max_age=QDoubleSpinBox();self.max_age.setRange(0,1e9);self.max_age.setDecimals(6);self.max_age.setValue(10)
        for i,(lab,x) in enumerate((("Mouth A proper time (s)",self.a_read),("Mouth B proper time (s)",self.b_read),
                                    ("Standard uncertainty (s)",self.unc),("Simulation observation time (s)",self.now),
                                    ("Maximum offset (s)",self.max_offset),("Maximum age (s)",self.max_age))):
            form.addWidget(QLabel(lab),i,0);form.addWidget(x,i,1)
        root.addLayout(form)
        row=QHBoxLayout();self.sample_btn=QPushButton("Record Synthetic Sample");self.clear_btn=QPushButton("Clear History")
        row.addWidget(self.sample_btn);row.addWidget(self.clear_btn);root.addLayout(row)
        self.summary=QPlainTextEdit();self.summary.setReadOnly(True);root.addWidget(self.summary,1)
        try:
            import pyqtgraph as pg
            self.plot=pg.PlotWidget();self.plot.setLabel("bottom","Simulation time","s");self.plot.setLabel("left","A − B proper-time offset","s")
            self.curve=self.plot.plot([],[]);root.addWidget(self.plot,2)
        except Exception:self.plot=None;self.curve=None
        self.table=QTableWidget(0,7);self.table.setHorizontalHeaderLabels(["Seq","Sim t (s)","A (s)","B (s)","A−B (s)","u (s)","Sync"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.table,2)
        self.sample_btn.clicked.connect(self.record_sample);self.clear_btn.clicked.connect(self.clear_history);self._refresh(None,None)
    def _clock(self,cid,name):
        from journeyman.core.metrology import ClockIdentity,TimeDomain
        from journeyman.core.state_events import DataOrigin
        return ClockIdentity(cid,name,TimeDomain.PROPER_TIME,"PROPER","SIM-FRAME","SIM-EPOCH","Metrology workspace synthetic source",DataOrigin.SIMULATION)
    def record_sample(self):
        from journeyman.core.metrology import ClockObservation,ClockQuality,SynchronizationPolicy,assess_synchronization,mouth_temporal_measurement
        from journeyman.core.state_events import DataOrigin
        try:
            self.sequence+=1;now=self.now.value();u=self.unc.value()
            a=ClockObservation(self._clock("mouth-a-clock","Mouth A Clock"),self.a_read.value(),u,now,self.sequence,ClockQuality.GOOD,"Metrology workspace synthetic sample",DataOrigin.SIMULATION)
            b=ClockObservation(self._clock("mouth-b-clock","Mouth B Clock"),self.b_read.value(),u,now,self.sequence,ClockQuality.GOOD,"Metrology workspace synthetic sample",DataOrigin.SIMULATION)
            pol=SynchronizationPolicy(self.max_offset.value(),max(u*3,1e-15),self.max_age.value(),1)
            q=assess_synchronization(a,b,pol,now_s=now,provenance="Metrology workspace")
            mouth=mouth_temporal_measurement(a,b,pol,now_s=now,provenance="Metrology workspace")
            self.history_a.append(a);self.history_b.append(b);self._refresh(q,mouth)
        except Exception as exc:self.summary.setPlainText(f"SAMPLE REJECTED\n{type(exc).__name__}: {exc}")
    def clear_history(self):
        self.history_a.clear();self.history_b.clear();self.sequence=0;self._refresh(None,None)
    def _refresh(self,q,mouth):
        if q is None:
            self.summary.setPlainText("No synthetic clock samples recorded.\nAll workspace observations are explicitly SIMULATION/SYNTHETIC.")
        else:
            g=self.service.guardian_contract(q)
            lines=[f"Synchronization: {'PASS' if q.synchronized else 'FAIL'}",f"Status: {q.status.value}",
                   f"Mouth A − B offset: {q.offset.offset_a_minus_b_s:.12g} s",
                   f"Combined standard uncertainty: {q.offset.standard_uncertainty_s:.12g} s",
                   f"Significance: {q.offset.significance_sigma:.6g} σ",f"Guardian: {g.status}",
                   f"Failures: {', '.join(q.failures) if q.failures else 'none'}","",
                   "Origin: SIMULATION/SYNTHETIC — NOT PHYSICAL MOUTH OR CLOCK TELEMETRY"]
            self.summary.setPlainText("\n".join(lines))
        n=len(self.history_a);self.table.setRowCount(n);xs=[];ys=[]
        for i,(a,b) in enumerate(zip(self.history_a,self.history_b)):
            off=a.reading_s-b.reading_s;u=(a.standard_uncertainty_s*a.standard_uncertainty_s+b.standard_uncertainty_s*b.standard_uncertainty_s)**.5
            sync=abs(off)<=self.max_offset.value()
            vals=(a.sequence,a.observed_at_s,a.reading_s,b.reading_s,off,u,"PASS" if sync else "FAIL")
            for j,v in enumerate(vals):self.table.setItem(i,j,QTableWidgetItem(str(v)))
            xs.append(a.observed_at_s);ys.append(off)
        if self.curve is not None:self.curve.setData(xs,ys)
    def export_workspace_state(self):
        return {"uncertainty_s":self.unc.value(),"maximum_offset_s":self.max_offset.value(),"maximum_age_s":self.max_age.value()}
    def restore_workspace_state(self,state):
        if not isinstance(state,dict):return
        self.unc.setValue(float(state.get("uncertainty_s",self.unc.value())))
        self.max_offset.setValue(float(state.get("maximum_offset_s",self.max_offset.value())))
        self.max_age.setValue(float(state.get("maximum_age_s",self.max_age.value())))


class GuardianWorkspace(QWidget):
    workspace_kind="guardian"
    def __init__(self,service,module_runtime=None,parent=None):
        super().__init__(parent);self.service=service;self.module_runtime=module_runtime;self.envelopes=[]
        root=QVBoxLayout(self)
        banner=QLabel("GUARDIAN AI GOVERNOR — READ-ONLY ADVISORY\nBUS-SAFE > DETERMINISTIC CONTROL/INTERLOCKS > GUARDIAN > OPERATOR/RESEARCH ASSISTANCE")
        root.addWidget(banner)
        row=QHBoxLayout()
        self.refresh_btn=QPushButton("Refresh Guardian State");self.clear_btn=QPushButton("Clear Imported Contracts")
        row.addWidget(self.refresh_btn);row.addWidget(self.clear_btn);root.addLayout(row)
        self.summary=QPlainTextEdit();self.summary.setReadOnly(True);root.addWidget(self.summary,1)
        self.modules=QTableWidget(0,5);self.modules.setHorizontalHeaderLabels(["Module","Schema","Status","Authority","Provenance"])
        self.modules.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.modules,2)
        self.findings=QTableWidget(0,5);self.findings.setHorizontalHeaderLabels(["Severity","Source","Check/Rule","Recommendation","Explanation"])
        self.findings.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.findings,2)
        self.refresh_btn.clicked.connect(self.refresh_state);self.clear_btn.clicked.connect(self.clear_contracts)
        self.refresh_state()
    def import_contract(self,module_id,contract,observed_at_s=None):
        env=self.service.ingest_contract(module_id,contract,observed_at_s=observed_at_s)
        self.envelopes=[e for e in self.envelopes if e.module_id!=module_id]+[env];self.refresh_state();return env
    def clear_contracts(self):
        self.envelopes.clear();self.refresh_state()
    def refresh_state(self):
        from journeyman.core.guardian import standard_cross_module_checks,scientific_consistency_report,consistency_findings
        checks=standard_cross_module_checks(tuple(self.envelopes),provenance="Guardian operational workspace")
        report=scientific_consistency_report(checks,provenance="Guardian operational workspace")
        fs=consistency_findings(report)
        self.summary.setPlainText("\n".join((
            f"Guardian recommendation: {report.recommendation.value}",
            f"Imported Guardian contracts: {len(self.envelopes)}",
            f"Scientific consistency checks: {len(checks)}",
            f"Failed checks: {len(report.failed_check_ids)}",
            "AI backend: NOT BUNDLED — deterministic Guardian remains operational",
            "Authority: READ_ONLY_ADVISORY",
            "Guardian cannot command actuators, clear trips, mask permissives, rewrite safety thresholds, or override BUS-SAFE/interlocks.")))
        self.modules.setRowCount(len(self.envelopes))
        for i,e in enumerate(sorted(self.envelopes,key=lambda x:x.module_id)):
            for j,v in enumerate((e.module_id,e.schema,e.status,e.authority,e.provenance)):
                self.modules.setItem(i,j,QTableWidgetItem(str(v)))
        self.findings.setRowCount(len(fs))
        for i,f in enumerate(fs):
            for j,v in enumerate((f.severity.value,f.source_module,f.rule_id,f.recommendation.value,f.message)):
                self.findings.setItem(i,j,QTableWidgetItem(str(v)))
    def export_workspace_state(self):
        return {"guardian_authority":"READ_ONLY_ADVISORY"}
    def restore_workspace_state(self,state):
        self.refresh_state()


class AdvancedVisualizationWorkspace(QWidget):
    workspace_kind="advanced-visualization"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service;self._cursor=None;self._plots={}
        root=QVBoxLayout(self)
        root.addWidget(QLabel("ADVANCED ANALYSIS & VISUALIZATION — supplied data only; origin/provenance retained"))
        controls=QHBoxLayout()
        self.series_combo=QComboBox();self.kind_combo=QComboBox()
        self.kind_combo.addItems(["TIME_SERIES","SCATTER","HISTOGRAM"])
        self.add_btn=QPushButton("Render Primary");self.secondary_btn=QPushButton("Render Secondary");self.clear_btn=QPushButton("Clear View")
        self.export_data_btn=QPushButton("Export Series CSV");self.export_figure_btn=QPushButton("Export Figure PNG")
        controls.addWidget(QLabel("Series"));controls.addWidget(self.series_combo,1)
        controls.addWidget(QLabel("Plot"));controls.addWidget(self.kind_combo)
        controls.addWidget(self.add_btn);controls.addWidget(self.secondary_btn);controls.addWidget(self.clear_btn)
        controls.addWidget(self.export_data_btn);controls.addWidget(self.export_figure_btn);root.addLayout(controls)
        self.plot_grid=QGridLayout();root.addLayout(self.plot_grid,3)
        self.plot=pg.PlotWidget();self.plot.showGrid(x=True,y=True,alpha=.25);self.plot.setMouseEnabled(x=True,y=True)
        self.plot2=pg.PlotWidget();self.plot2.showGrid(x=True,y=True,alpha=.25);self.plot2.setMouseEnabled(x=True,y=True)
        self.plot_grid.addWidget(self.plot,0,0);self.plot_grid.addWidget(self.plot2,0,1)
        self.plot2.setXLink(self.plot)
        self.cursor_label=QLabel("Cursor: —");root.addWidget(self.cursor_label)
        self.table=QTableWidget(0,7);self.table.setHorizontalHeaderLabels(
            ["Series","Variable","X Unit","Y Unit","Origin","Source","Provenance"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.table,2)
        self.add_btn.clicked.connect(self.render_selected);self.secondary_btn.clicked.connect(self.render_selected_secondary);self.clear_btn.clicked.connect(self.clear_view)
        self.export_data_btn.clicked.connect(self.export_selected_csv);self.export_figure_btn.clicked.connect(self.export_figure_png)
        self.plot.scene().sigMouseMoved.connect(self._mouse_moved)
        self.plot2.scene().sigMouseMoved.connect(self._mouse_moved_secondary)
        self.refresh_catalog()
    def refresh_catalog(self):
        series=self.service.store.all_series();self.series_combo.clear()
        self.table.setRowCount(len(series))
        for i,s in enumerate(series):
            self.series_combo.addItem(s.name,s.series_id)
            for j,v in enumerate((s.name,s.variable,s.x_unit,s.y_unit,s.origin,s.source_module,s.provenance)):
                self.table.setItem(i,j,QTableWidgetItem(str(v)))
    def render_selected(self):
        sid=self.series_combo.currentData()
        if not sid:return
        s=self.service.store.series(sid);kind=self.kind_combo.currentText()
        if kind=="HISTOGRAM":
            h=self.service.histogram(s,bins=20,provenance="Advanced Visualization workspace")
            if not h.counts:return
            centers=[(h.bin_edges[i]+h.bin_edges[i+1])/2 for i in range(len(h.counts))]
            widths=[h.bin_edges[i+1]-h.bin_edges[i] for i in range(len(h.counts))]
            item=pg.BarGraphItem(x=centers,height=list(h.counts),width=widths[0]*.9)
            self.plot.addItem(item);self._plots[sid]=item
        else:
            xs=[p.x for p in s.points if p.quality.value not in ("INVALID","UNAVAILABLE")]
            ys=[p.y for p in s.points if p.quality.value not in ("INVALID","UNAVAILABLE")]
            if kind=="SCATTER":item=self.plot.plot(xs,ys,pen=None,symbol="o",name=s.name)
            else:item=self.plot.plot(xs,ys,name=s.name)
            self._plots[sid]=item
            # Uncertainty is rendered only when explicitly present.
            errx=[];erry=[];err=[]
            for p in s.points:
                if p.standard_uncertainty is not None and p.quality.value not in ("INVALID","UNAVAILABLE"):
                    errx.append(p.x);erry.append(p.y);err.append(p.standard_uncertainty)
            if err:
                self.plot.addItem(pg.ErrorBarItem(x=errx,y=erry,height=[2*u for u in err],beam=.05))
        self.plot.setLabel("bottom",s.variable,units=s.x_unit);self.plot.setLabel("left",s.name,units=s.y_unit)
    def render_matrix(self,dataset):
        import numpy as np
        image=pg.ImageItem(np.array(dataset.values,dtype=float));self.plot.addItem(image);return image
    def render_selected_secondary(self):
        sid=self.series_combo.currentData()
        if not sid:return
        s=self.service.store.series(sid)
        xs=[p.x for p in s.points if p.quality.value not in ("INVALID","UNAVAILABLE")]
        ys=[p.y for p in s.points if p.quality.value not in ("INVALID","UNAVAILABLE")]
        self.plot2.plot(xs,ys,name=s.name);self.plot2.setLabel("bottom",s.variable,units=s.x_unit);self.plot2.setLabel("left",s.name,units=s.y_unit)
    def clear_view(self):
        self.plot.clear();self.plot2.clear();self._plots.clear()
    def _update_cursor_label(self,x):
        self._cursor=float(x);vals=self.service.synchronized_cursor_values(self.service.store.all_series(),self._cursor)
        shown=[f"{sid}={p.y:.6g}" for sid,p in vals.items() if p is not None]
        self.cursor_label.setText(f"Cursor x={self._cursor:.6g}" + (" | "+"; ".join(shown) if shown else ""))
    def _mouse_moved(self,pos):
        if self.plot.sceneBoundingRect().contains(pos):self._update_cursor_label(self.plot.getViewBox().mapSceneToView(pos).x())
    def _mouse_moved_secondary(self,pos):
        if self.plot2.sceneBoundingRect().contains(pos):self._update_cursor_label(self.plot2.getViewBox().mapSceneToView(pos).x())
    def append_live_sample(self,series_id,point,policy=None):
        from journeyman.core.advanced_visualization import StreamPolicy
        s=self.service.store.series(series_id)
        updated=self.service.append_stream_point(s,point,policy or StreamPolicy())
        self.service.store.replace_series(updated);self.refresh_catalog();return updated
    def export_selected_csv(self):
        sid=self.series_combo.currentData()
        if not sid:return
        path,_=QFileDialog.getSaveFileName(self,"Export Scientific Series","series.csv","CSV Files (*.csv)")
        if not path:return
        try:
            result=self.service.export_series_csv(self.service.store.series(sid),path)
            QMessageBox.information(self,"Export Complete",f"Exported {result.rows} supplied data points.\n{result.path}")
        except Exception as exc:QMessageBox.critical(self,"Export Failed",str(exc))
    def export_figure_png(self):
        path,_=QFileDialog.getSaveFileName(self,"Export Figure","figure.png","PNG Images (*.png)")
        if not path:return
        try:
            exporter=pg.exporters.ImageExporter(self.plot.plotItem)
            exporter.export(path)
            QMessageBox.information(self,"Export Complete",path)
        except Exception as exc:QMessageBox.critical(self,"Export Failed",str(exc))
    def export_workspace_state(self):
        return {"selected_series":self.series_combo.currentData(),"plot_kind":self.kind_combo.currentText()}
    def restore_workspace_state(self,state):
        kind=state.get("plot_kind")
        if kind:
            i=self.kind_combo.findText(kind)
            if i>=0:self.kind_combo.setCurrentIndex(i)
        sid=state.get("selected_series")
        if sid:
            i=self.series_combo.findData(sid)
            if i>=0:self.series_combo.setCurrentIndex(i)


class ScientificDataWorkspace(QWidget):
    workspace_kind="scientific-data"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service
        root=QVBoxLayout(self)
        root.addWidget(QLabel("SCIENTIFIC DATA & PROVENANCE — immutable archive inspection"))
        controls=QHBoxLayout();self.refresh_btn=QPushButton("Refresh Archive");self.audit_btn=QPushButton("Audit Selected Run")
        self.chain_btn=QPushButton("Verify Manifest Chain");self.export_audit_btn=QPushButton("Export Audit JSON")
        controls.addWidget(self.refresh_btn);controls.addWidget(self.audit_btn);controls.addWidget(self.chain_btn);controls.addWidget(self.export_audit_btn);controls.addStretch(1);root.addLayout(controls)
        self.summary=QLabel();root.addWidget(self.summary)
        self.runs=QTableWidget(0,8);self.runs.setHorizontalHeaderLabels(["Run","Created","Records","Artifacts","Build","Origins","Manifest SHA-256","Provenance"])
        self.runs.setEditTriggers(QAbstractItemView.NoEditTriggers);self.runs.setSelectionBehavior(QAbstractItemView.SelectRows);root.addWidget(self.runs,2)
        self.records=QTableWidget(0,10);self.records.setHorizontalHeaderLabels(["Record","Variable","Value","Unit","Uncertainty","Origin","Quality","Source","Time","Provenance"])
        self.records.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.records,3)
        self.status=QPlainTextEdit();self.status.setReadOnly(True);root.addWidget(self.status,1)
        self.refresh_btn.clicked.connect(self.refresh_archive);self.audit_btn.clicked.connect(self.audit_selected);self.chain_btn.clicked.connect(self.verify_chain)
        self.export_audit_btn.clicked.connect(self.export_audit)
        self.runs.itemSelectionChanged.connect(self.refresh_records);self.refresh_archive()
    def refresh_archive(self):
        entries=self.service.list_runs();q=self.service.provenance_summary()
        self.summary.setText(f"Runs: {q['run_count']} | Records: {q['record_count']} | Artifacts: {q['artifact_count']} | Origins: {q['origins']}")
        self.runs.setRowCount(len(entries))
        for i,e in enumerate(entries):
            vals=(e.run_id,f"{e.created_at_s:.6f}",e.record_count,e.artifact_count,e.software_build,str(e.origin_counts),e.manifest_sha256,e.provenance)
            for j,v in enumerate(vals):self.runs.setItem(i,j,QTableWidgetItem(str(v)))
        if entries:self.runs.selectRow(0)
    def selected_run_id(self):
        row=self.runs.currentRow();return None if row<0 or self.runs.item(row,0) is None else self.runs.item(row,0).text()
    def refresh_records(self):
        rid=self.selected_run_id()
        rows=() if rid is None else self.service.query_records(run_id=rid);self.records.setRowCount(len(rows))
        for i,r in enumerate(rows):
            vals=(r.record_id,r.variable,r.value,r.unit,r.standard_uncertainty,r.origin.value,r.quality.value,r.source_module,r.timestamp_s,r.provenance)
            for j,v in enumerate(vals):self.records.setItem(i,j,QTableWidgetItem("" if v is None else str(v)))
    def audit_selected(self):
        rid=self.selected_run_id()
        if not rid:return
        a=self.service.audit_run(rid);lines=[f"{rid}: {'PASS' if a.passed else 'FAIL'}",f"Manifest: {a.manifest_sha256}"]
        lines+=["CHECK: "+x for x in a.checks];lines+=["FAIL: "+x for x in a.failures];self.status.setPlainText("\n".join(lines))
    def verify_chain(self):
        ok,fail=self.service.verify_manifest_chain();self.status.setPlainText("MANIFEST CHAIN: "+("PASS" if ok else "FAIL")+
            ("" if not fail else "\n"+"\n".join(fail)))
    def export_audit(self):
        rid=self.selected_run_id()
        if not rid:return
        path,_=QFileDialog.getSaveFileName(self,"Export Integrity Audit","integrity_audit.json","JSON Files (*.json)")
        if not path:return
        try:
            self.service.export_audit_report(self.service.audit_run(rid),path)
            QMessageBox.information(self,"Audit Exported",path)
        except Exception as exc:QMessageBox.critical(self,"Export Failed",str(exc))


class ReportGeneratorWorkspace(QWidget):
    workspace_kind="report-generator"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service;self.spec=None;self.rendered=None
        root=QVBoxLayout(self)
        root.addWidget(QLabel("REPORT / DOSSIER GENERATOR — provenance-controlled rendering"))
        controls=QHBoxLayout()
        self.load_btn=QPushButton("Load Report Specification")
        self.validate_btn=QPushButton("Validate")
        self.render_btn=QPushButton("Render Preview")
        self.export_text_btn=QPushButton("Export Text")
        self.export_html_btn=QPushButton("Export HTML")
        self.export_pdf_btn=QPushButton("Export PDF")
        for b in (self.load_btn,self.validate_btn,self.render_btn,self.export_text_btn,self.export_html_btn,self.export_pdf_btn):controls.addWidget(b)
        controls.addStretch(1);root.addLayout(controls)
        self.meta=QLabel("No report specification loaded.");root.addWidget(self.meta)
        self.preview=QPlainTextEdit();self.preview.setReadOnly(True);root.addWidget(self.preview,1)
        self.load_btn.clicked.connect(self.load_specification);self.validate_btn.clicked.connect(self.validate_specification)
        self.render_btn.clicked.connect(self.render_preview);self.export_text_btn.clicked.connect(self.export_text)
        self.export_html_btn.clicked.connect(self.export_html);self.export_pdf_btn.clicked.connect(self.export_pdf)
    def load_specification(self):
        path,_=QFileDialog.getOpenFileName(self,"Load Scientific Report Specification","","JSON Files (*.json)")
        if not path:return
        try:
            self.spec=self.service.load_specification(path);self.rendered=None
            self.meta.setText(f"{self.spec.title} | {self.spec.edition} | Build {self.spec.software_build} | SHA-256 {self.service.specification_sha256(self.spec)}")
            self.preview.setPlainText("Specification loaded. Validate or render preview.")
        except Exception as exc:QMessageBox.critical(self,"Load Failed",str(exc))
    def validate_specification(self):
        if self.spec is None:return
        q=self.service.validate(self.spec);text=("PASS" if q.passed else "FAIL")+"\n"
        text+="\n".join("CHECK: "+x for x in q.checks)
        if q.failures:text+="\n"+"\n".join("FAIL: "+x for x in q.failures)
        self.preview.setPlainText(text)
    def render_preview(self):
        if self.spec is None:return
        try:self.rendered=self.service.render_text(self.spec);self.preview.setPlainText(self.rendered.rendered_text)
        except Exception as exc:QMessageBox.critical(self,"Render Failed",str(exc))
    def export_text(self):
        if self.spec is None:return
        path,_=QFileDialog.getSaveFileName(self,"Export Scientific Report","report.txt","Text Files (*.txt)")
        if not path:return
        try:self.service.write_rendered_text(self.service.render_text(self.spec),path);QMessageBox.information(self,"Export Complete",path)
        except Exception as exc:QMessageBox.critical(self,"Export Failed",str(exc))
    def export_html(self):
        if self.spec is None:return
        path,_=QFileDialog.getSaveFileName(self,"Export Scientific Report","report.html","HTML Files (*.html)")
        if not path:return
        try:self.service.write_rendered_text(self.service.render_html(self.spec),path);QMessageBox.information(self,"Export Complete",path)
        except Exception as exc:QMessageBox.critical(self,"Export Failed",str(exc))
    def export_pdf(self):
        if self.spec is None:return
        path,_=QFileDialog.getSaveFileName(self,"Export Scientific Report","report.pdf","PDF Files (*.pdf)")
        if not path:return
        try:
            manifest=self.service.render_pdf(self.spec,path)
            self.service.write_artifact_manifest(manifest,path+".manifest.json")
            QMessageBox.information(self,"PDF Export Complete",path+"\nArtifact SHA-256: "+manifest.artifact_sha256)
        except Exception as exc:QMessageBox.critical(self,"PDF Export Failed",str(exc))


class ComputeBackendWorkspace(QWidget):
    workspace_kind="compute-backends"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service
        root=QVBoxLayout(self)
        root.addWidget(QLabel("COMPUTE BACKEND MANAGER — HOST capability inventory; no synthetic hardware"))
        controls=QHBoxLayout();self.refresh_btn=QPushButton("Refresh Host Backends");self.run_check_btn=QPushButton("Run CPU Qualification")
        self.profile=QComboBox();self.profile.addItems(["AUTO","CONSERVATIVE","PERFORMANCE"]);self.resource_btn=QPushButton("Assess Safe Local Resources")
        self.external=QComboBox();self.external.addItems(["LOCAL","HPC / CLUSTER","HYBRID / PHYSICAL QPU"]);self.verify_external_btn=QPushButton("Verify External Compute")
        controls.addWidget(self.refresh_btn);controls.addWidget(self.run_check_btn);controls.addWidget(QLabel("Compute Profile:"));controls.addWidget(self.profile);controls.addWidget(self.resource_btn);controls.addWidget(QLabel("External:"));controls.addWidget(self.external);controls.addWidget(self.verify_external_btn);controls.addStretch(1);root.addLayout(controls)
        self.table=QTableWidget(0,9);self.table.setHorizontalHeaderLabels(["Backend","Kind","Status","Provider","Device","Logical Units","Memory","Capabilities","Diagnostic"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.table,1)
        self.note=QLabel("Research compute only. BUS-SAFE and deterministic real-time control remain outside this manager.");root.addWidget(self.note)
        self.health_table=QTableWidget(0,7);self.health_table.setHorizontalHeaderLabels(["Backend","Status","Utilization %","Memory Used","Memory Total","Temperature C","Power W"])
        self.health_table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.health_table)
        self.execution=QPlainTextEdit();self.execution.setReadOnly(True);root.addWidget(self.execution)
        self.refresh_btn.clicked.connect(self.refresh_backends);self.run_check_btn.clicked.connect(self.run_cpu_qualification);self.resource_btn.clicked.connect(self.assess_local_resources);self.verify_external_btn.clicked.connect(self.verify_external_compute);self.refresh_backends()
    def refresh_backends(self):
        rows=self.service.discover();self.table.setRowCount(len(rows))
        for i,b in enumerate(rows):
            vals=(b.backend_id,b.kind.value,b.status.value,b.provider,b.device_name,b.logical_units,
                  "N/A" if b.memory_bytes is None else str(b.memory_bytes),", ".join(b.capabilities),b.diagnostic)
            for j,v in enumerate(vals):self.table.setItem(i,j,QTableWidgetItem("" if v is None else str(v)))
        health=self.service.health();self.health_table.setRowCount(len(health))
        for i,h in enumerate(health):
            vals=(h.backend_id,h.status,h.utilization_percent,h.memory_used_bytes,h.memory_total_bytes,h.temperature_c,h.power_w)
            for j,v in enumerate(vals):self.health_table.setItem(i,j,QTableWidgetItem("N/A" if v is None else str(v)))
    def run_cpu_qualification(self):
        from journeyman.core.compute_backends import WorkloadRequest,ComputeRequirement,ResourceBudget
        q=WorkloadRequest("ui-qualification","sum_squares",(1.0,2.0,3.0),ComputeRequirement(required_capabilities=("scalar",)),
                          ResourceBudget(1,timeout_s=5.0),"SIMULATION: explicit operator qualification")
        r=self.service.execute(q,self.service.discover())
        self.execution.setPlainText(str(self.service.provenance_record(q,r)))

    def assess_local_resources(self):
        sample=self.service.sample_host_resources();env=self.service.resource_envelope(sample,self.profile.currentText());assessment=self.service.resource_assessment(sample,env)
        temp="AVAILABLE" if sample.temperature_available else "UNAVAILABLE"
        self.execution.setPlainText(f"JOE {__version__} | {__build__}\nOPERATING ENVIRONMENT: DEVELOPMENT / SIMULATION\nCOMPUTE PROFILE: {env.profile.value} — LOCAL WORKSTATION\nWorkers allowed: {env.maximum_workers}/{env.detected_logical_cpus} logical CPUs detected\nJOE memory ceiling: {env.maximum_joe_memory_bytes/1024**3:.2f} GiB\nTemperature telemetry: {temp}\nGPU detected by telemetry: {env.gpu_detected}\nDisposition: {assessment.disposition.value}\nRecommended workers now: {assessment.recommended_workers}\n"+"\n".join("- "+x for x in assessment.reasons)+"\n\nFull scientific/simulation functionality remains available. This profile changes workload aggressiveness only.")

    def verify_external_compute(self):
        h=self.service.external_handshake(self.external.currentText())
        self.execution.setPlainText(f"JOE {__version__} | {__build__}\nEXTERNAL COMPUTE REQUEST: {h.requested_kind}\nSTATUS: {h.status.value}\nADMITTED: {h.admitted}\nBACKEND: {h.backend_id or 'NONE'}\n"+"\n".join("- "+x for x in h.reasons)+"\n\nSelecting a backend never creates hardware capability. Rejected requests leave governed local simulation active.")


class QuantumRuntimeWorkspace(QWidget):
    workspace_kind="quantum-runtime"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service
        root=QVBoxLayout(self)
        root.addWidget(QLabel("QPU ADAPTER / QUANTUM RUNTIME — software simulation is not physical QPU access"))
        controls=QHBoxLayout();self.refresh_btn=QPushButton("Refresh Quantum Backends");self.qualify_btn=QPushButton("Run Basis-Simulator Qualification")
        self.providers_btn=QPushButton("Qualify Local Simulator Providers")
        controls.addWidget(self.refresh_btn);controls.addWidget(self.qualify_btn);controls.addWidget(self.providers_btn);controls.addStretch(1);root.addLayout(controls)
        self.table=QTableWidget(0,8);self.table.setHorizontalHeaderLabels(["Backend","Kind","Status","Provider","Name","Qubits","Capabilities","Diagnostic"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.table,1)
        self.output=QPlainTextEdit();self.output.setReadOnly(True);root.addWidget(self.output)
        self.refresh_btn.clicked.connect(self.refresh_backends);self.qualify_btn.clicked.connect(self.run_qualification)
        self.providers_btn.clicked.connect(self.qualify_providers);self.refresh_backends()
    def refresh_backends(self):
        rows=self.service.discover();self.table.setRowCount(len(rows))
        for i,b in enumerate(rows):
            vals=(b.backend_id,b.kind.value,b.status.value,b.provider,b.name,"N/A" if b.qubit_count is None else b.qubit_count,
                  ", ".join(b.capabilities),b.diagnostic)
            for j,v in enumerate(vals):self.table.setItem(i,j,QTableWidgetItem(str(v)))
    def run_qualification(self):
        from journeyman.core.quantum_runtime import QuantumCircuit,QuantumJobRequest
        c=QuantumCircuit("ui-q",(2),(("X",(0,)),("CX",(0,1)),("MEASURE",(0,)),("MEASURE",(1,))),"SIMULATION: explicit operator qualification")
        q=QuantumJobRequest("ui-job","joe.basis-simulator",c,128,"SIMULATION: explicit operator qualification")
        r=self.service.execute_basis(q);self.output.setPlainText(str(self.service.provenance_record(q,r))+"\\nCounts: "+str(r.counts))

    def qualify_providers(self):
        q=self.service.provider_readiness()
        text=("PASS" if q["passed"] else "FAIL")+"\n"+"\n".join("- "+x for x in q["checks"])
        if q["failures"]:text+="\nFailures:\n"+"\n".join("- "+x for x in q["failures"])
        text+="\nNotes:\n"+"\n".join("- "+x for x in q["notes"]);self.output.setPlainText(text)


class RTControlWorkspace(QWidget):
    workspace_kind="rt-control"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service
        root=QVBoxLayout(self)
        root.addWidget(QLabel("RT / CONTROL / BUS-SAFE — SOFTWARE QUALIFICATION INTERFACE; NOT PHYSICAL HARDWARE CONTROL"))
        self.state=QLabel();root.addWidget(self.state)
        self.table=QTableWidget(0,5);self.table.setHorizontalHeaderLabels(["Interlock","State","Source","Reason","Provenance"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.table,1)
        self.refresh_btn=QPushButton("Refresh Deterministic State");self.qualify_btn=QPushButton("Run Supervision Qualification")
        self.boundary_btn=QPushButton("Qualify SIL/HIL & BUS-SAFE Boundary");self.physics_btn=QPushButton("Qualify Physics Envelope Failsafe");self.horizon_btn=QPushButton("Qualify Predictive Horizon");self.recovery_btn=QPushButton("Qualify Safe-State Recovery");self.chronology_protection_btn=QPushButton("Qualify Chronology Protection Governor");self.final_stress_btn=QPushButton("Run Final Stress Qualification");self.release_btn=QPushButton("Run RT v1.0 Release Gate")
        controls=QHBoxLayout();controls.addWidget(self.refresh_btn);controls.addWidget(self.qualify_btn);controls.addWidget(self.boundary_btn);controls.addWidget(self.physics_btn);controls.addWidget(self.horizon_btn);controls.addWidget(self.recovery_btn);controls.addWidget(self.chronology_protection_btn);controls.addWidget(self.final_stress_btn);controls.addWidget(self.release_btn);controls.addStretch(1);root.addLayout(controls)
        self.output=QPlainTextEdit();self.output.setReadOnly(True);root.addWidget(self.output)
        self.note=QLabel("BUS-SAFE > deterministic RT control/interlocks > Guardian > operator/research. Guardian cannot command or clear trips.")
        root.addWidget(self.note);self.refresh_btn.clicked.connect(self.refresh_state);self.qualify_btn.clicked.connect(self.run_supervision_qualification);self.boundary_btn.clicked.connect(self.run_boundary_qualification);self.physics_btn.clicked.connect(self.run_physics_safety_qualification);self.horizon_btn.clicked.connect(self.run_predictive_horizon_qualification);self.recovery_btn.clicked.connect(self.run_safe_state_qualification);self.chronology_protection_btn.clicked.connect(self.run_chronology_protection_qualification);self.final_stress_btn.clicked.connect(self.run_final_stress_qualification);self.release_btn.clicked.connect(self.run_release_gate);self.refresh_state()
    def refresh_state(self):
        k=self.service.kernel;self.state.setText("Control state: "+k.state.value+" | Software kernel sequence: "+str(k.sequence))
        rows=tuple(k.interlocks.values());self.table.setRowCount(len(rows))
        for i,x in enumerate(rows):
            for j,v in enumerate((x.interlock_id,x.state.value,x.source,x.reason,x.provenance)):self.table.setItem(i,j,QTableWidgetItem(str(v)))
    def run_supervision_qualification(self):
        q=self.service.supervision_readiness()
        text=("PASS" if q["passed"] else "FAIL")+"\n"+"\n".join("- "+x for x in q["checks"])
        text+="\nNotes:\n"+"\n".join("- "+x for x in q["notes"]);self.output.setPlainText(text)
    def run_boundary_qualification(self):
        q=self.service.hardware_boundary_readiness()
        text=("PASS" if q["passed"] else "FAIL")+"\n"+"\n".join("- "+x for x in q["checks"])
        if q["failures"]:text+="\nFailures:\n"+"\n".join("- "+x for x in q["failures"])
        text+="\nNotes:\n"+"\n".join("- "+x for x in q["notes"]);self.output.setPlainText(text)
    def run_physics_safety_qualification(self):
        q=self.service.physics_safety_readiness()
        text=("PASS" if q["passed"] else "FAIL")+"\n"+"\n".join("- "+x for x in q["checks"])
        if q["failures"]:text+="\nFailures:\n"+"\n".join("- "+x for x in q["failures"])
        text+="\nNotes:\n"+"\n".join("- "+x for x in q["notes"]);self.output.setPlainText(text)
    def run_predictive_horizon_qualification(self):
        q=self.service.predictive_horizon_readiness()
        text=("PASS" if q["passed"] else "FAIL")+"\n"+"\n".join("- "+x for x in q["checks"])
        if q["failures"]:text+="\nFailures:\n"+"\n".join("- "+x for x in q["failures"])
        text+="\nNotes:\n"+"\n".join("- "+x for x in q["notes"]);self.output.setPlainText(text)
    def run_safe_state_qualification(self):
        q=self.service.safe_state_readiness()
        text=("PASS" if q["passed"] else "FAIL")+"\n"+"\n".join("- "+x for x in q["checks"])
        if q["failures"]:text+="\nFailures:\n"+"\n".join("- "+x for x in q["failures"])
        text+="\nNotes:\n"+"\n".join("- "+x for x in q["notes"]);self.output.setPlainText(text)
    def run_chronology_protection_qualification(self):
        q=self.service.chronology_protection_readiness()
        text=("PASS" if q["passed"] else "FAIL")+"\n"+"\n".join("- "+x for x in q["checks"])
        if q["failures"]:text+="\nFailures:\n"+"\n".join("- "+x for x in q["failures"])
        text+="\nNotes:\n"+"\n".join("- "+x for x in q["notes"]);self.output.setPlainText(text)
    def run_final_stress_qualification(self):
        q=self.service.final_stress_readiness()
        text=("PASS" if q["passed"] else "FAIL")+"\n"+"\n".join("- "+x for x in q["checks"])
        if q["failures"]:text+="\nFailures:\n"+"\n".join("- "+x for x in q["failures"])
        text+="\nTruth boundary:\n- "+q["truth_boundary"];self.output.setPlainText(text)
    def run_release_gate(self):
        q=self.service.release_readiness()
        text=("PASS" if q["passed"] else "FAIL")+"\n"+"\n".join("- "+x for x in q["checks"])
        if q["failures"]:text+="\nFailures:\n"+"\n".join("- "+x for x in q["failures"])
        text+="\nNotes:\n"+"\n".join("- "+x for x in q["notes"]);self.output.setPlainText(text)


class IntegratedQualificationWorkspace(QWidget):
    workspace_kind="integrated-qualification"
    def __init__(self,service,parent=None):
        super().__init__(parent);self.service=service;root=QVBoxLayout(self)
        root.addWidget(QLabel("JOE v1.5 INTEGRATED QUALIFICATION — SOFTWARE/SIL BASELINE"))
        controls=QHBoxLayout();self.run_btn=QPushButton("Run Integrated Qualification");self.workflow_btn=QPushButton("Qualify End-to-End Scientific Workflow");self.persistence_btn=QPushButton("Qualify Data / Provenance Integrity");self.final_btn=QPushButton("Run JOE v1.5.0 Final Release Gate")
        controls.addWidget(self.run_btn);controls.addWidget(self.workflow_btn);controls.addWidget(self.persistence_btn);controls.addWidget(self.final_btn);controls.addStretch(1);root.addLayout(controls)
        self.table=QTableWidget(0,4);self.table.setHorizontalHeaderLabels(["Check","Category","Status","Message"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.table,1)
        self.output=QPlainTextEdit();self.output.setReadOnly(True);root.addWidget(self.output)
        self.run_btn.clicked.connect(self.run_qualification);self.workflow_btn.clicked.connect(self.run_workflow_qualification);self.persistence_btn.clicked.connect(self.run_persistence_qualification);self.final_btn.clicked.connect(self.run_final_release)
    def run_qualification(self):
        r=self.service.run();self.table.setRowCount(len(r.checks))
        for i,c in enumerate(r.checks):
            for j,v in enumerate((c.check_id,c.category,c.status.value,c.message)):self.table.setItem(i,j,QTableWidgetItem(str(v)))
        lines=[("PASS" if r.passed else "FAIL"),"Build: "+r.software_build,"Report SHA-256: "+r.report_sha256]
        for c in r.checks:
            lines.append("\\n"+c.check_id+" evidence:");lines.extend("- "+x for x in c.evidence)
        self.output.setPlainText("\\n".join(lines))
    def run_workflow_qualification(self):
        r=self.service.qualify_reference_workflow();self.table.setRowCount(len(r.checks))
        for i,c in enumerate(r.checks):
            for j,v in enumerate((c.check_id,c.category,c.status.value,c.message)):self.table.setItem(i,j,QTableWidgetItem(str(v)))
        lines=[("PASS" if r.passed else "FAIL"),"SYNTHETIC QUALIFICATION WORKFLOW — NOT PHYSICAL MEASUREMENT"]
        for c in r.checks:
            lines.append("\\n"+c.check_id+" evidence:");lines.extend("- "+x for x in c.evidence)
        self.output.setPlainText("\\n".join(lines))
    def run_persistence_qualification(self):
        r=self.service.qualify_reference_artifacts();self.table.setRowCount(len(r.checks))
        for i,c in enumerate(r.checks):
            for j,v in enumerate((c.check_id,c.category,c.status.value,c.message)):self.table.setItem(i,j,QTableWidgetItem(str(v)))
        lines=[("PASS" if r.passed else "FAIL"),"SYNTHETIC ARTIFACT QUALIFICATION — NOT PHYSICAL DATA"]
        for c in r.checks:lines.append("\n"+c.check_id+" evidence:");lines.extend("- "+x for x in c.evidence)
        self.output.setPlainText("\n".join(lines))
    def run_final_release(self):
        r=self.service.final_release();self.table.setRowCount(len(r.checks))
        for i,c in enumerate(r.checks):
            for j,v in enumerate((c.check_id,c.category,c.status.value,c.message)):self.table.setItem(i,j,QTableWidgetItem(str(v)))
        lines=[("JOE v1.5.0 RELEASE GATE: PASS" if r.passed else "JOE v1.5.0 RELEASE GATE: FAIL"),
               "Build: "+r.build,"Release SHA-256: "+r.release_sha256,"Manifest SHA-256: "+r.manifest.manifest_sha256,
               "\nDECLARED LIMITATIONS:"]
        lines.extend("- "+x for x in r.manifest.limitations)
        lines.append("\nCOMPONENT INVENTORY:")
        lines.extend("- "+x.component_id+" "+x.version+" | "+x.qualification for x in r.manifest.components)
        self.output.setPlainText("\n".join(lines))


class ScientificReferenceWorkspace(QWidget):
    workspace_kind="scientific-reference"
    def __init__(self,library,evaluator,parent=None):
        super().__init__(parent);self.library=library;self.evaluator=evaluator;root=QVBoxLayout(self)
        root.addWidget(QLabel("SCIENTIFIC REFERENCE / ALGORITHM LIBRARY — READ ONLY"))
        bar=QHBoxLayout();self.query=QLineEdit();self.query.setPlaceholderText("Search models, rules, algorithms, constants…")
        self.search_btn=QPushButton("Search");self.reload_btn=QPushButton("Verify Library");bar.addWidget(self.query,1);bar.addWidget(self.search_btn);bar.addWidget(self.reload_btn);root.addLayout(bar)
        self.table=QTableWidget(0,5);self.table.setHorizontalHeaderLabels(["ID","Version","Schema","Epistemic Class","SHA-256"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.table,1)
        self.detail=QPlainTextEdit();self.detail.setReadOnly(True);root.addWidget(self.detail)
        self.search_btn.clicked.connect(self.search);self.reload_btn.clicked.connect(self.verify);self.table.itemSelectionChanged.connect(self.show_selected);self.refresh(self.library.load_all())
    def refresh(self,docs):
        self.docs=list(docs);self.table.setRowCount(len(self.docs))
        for i,d in enumerate(self.docs):
            vals=(d.document_id,d.version,d.schema,d.data.get("epistemic_class","—"),d.sha256)
            for j,v in enumerate(vals):self.table.setItem(i,j,QTableWidgetItem(str(v)))
    def search(self):
        self.refresh(self.library.search(self.query.text()))
    def verify(self):
        q=self.library.readiness();self.detail.setPlainText(("PASS" if q["passed"] else "FAIL")+"\\n" + "\\n".join(q["failures"] or q["notes"]))
        self.refresh(self.library.load_all())
    def show_selected(self):
        row=self.table.currentRow()
        if row<0 or row>=len(self.docs):return
        import json
        self.detail.setPlainText(json.dumps(self.docs[row].data,indent=2,sort_keys=True))

class ScientificIntelligenceWorkspace(QWidget):
    workspace_kind="scientific-intelligence"
    def __init__(self,service,reference_library,parent=None):
        super().__init__(parent);self.service=service;self.reference_library=reference_library;root=QVBoxLayout(self)
        root.addWidget(QLabel("SCIENTIFIC INTELLIGENCE — CONTROLLED ONLINE LITERATURE WATCH"))
        self.status_label=QLabel();root.addWidget(self.status_label)
        bar=QHBoxLayout();self.update_btn=QPushButton("Update Now");self.pause_btn=QPushButton("Pause Background Research");self.sources_btn=QPushButton("Sources")
        bar.addWidget(self.update_btn);bar.addWidget(self.pause_btn);bar.addWidget(self.sources_btn);bar.addStretch(1);root.addLayout(bar)
        self.table=QTableWidget(0,5);self.table.setHorizontalHeaderLabels(["Stage","Published","Source","Title","SHA-256"]);self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);root.addWidget(self.table,1)
        self.detail=QPlainTextEdit();self.detail.setReadOnly(True);root.addWidget(self.detail)
        self.update_btn.clicked.connect(self.update_now);self.pause_btn.clicked.connect(self.toggle_pause);self.sources_btn.clicked.connect(self.show_sources);self.table.itemSelectionChanged.connect(self.show_selected)
        self.refresh()
    def refresh(self):
        st=self.service.status();self.status_label.setText(f"NETWORK: {st['network']}   |   BACKGROUND RESEARCH: {st['background']}   |   LAST SYNC: {st['last_sync']}   |   CANDIDATES: {st['candidate_findings']}   |   AUTHORITATIVE DB CHANGES: {st['authoritative_db_changes']}")
        self.rows=list(self.service.findings());self.table.setRowCount(len(self.rows))
        for i,r in enumerate(self.rows):
            for j,v in enumerate((r.get('stage',''),r.get('published',''),r.get('source_id',''),r.get('title',''),r.get('sha256',''))):self.table.setItem(i,j,QTableWidgetItem(str(v)))
        self.pause_btn.setText("Resume Background Research" if self.service.paused else "Pause Background Research")
    def update_now(self):
        r=self.service.sync_now();self.refresh();self.detail.setPlainText("SYNC STATUS: "+str(r.get('status'))+"\nNEW ITEMS: "+str(r.get('new',0))+"\nTOTAL: "+str(r.get('total',0))+"\nAUTHORITATIVE DB CHANGES: 0\n"+"\n".join(r.get('errors',())))
    def toggle_pause(self):self.service.set_paused(not self.service.paused);self.refresh()
    def show_sources(self):
        import json;self.detail.setPlainText(json.dumps(self.service.status().get('sources',()),indent=2))
    def show_selected(self):
        row=self.table.currentRow()
        if row<0 or row>=len(self.rows):return
        import json
        item=self.rows[row];cross=self.service.cross_check_candidate(item['finding_id'],self.reference_library)
        self.detail.setPlainText(json.dumps({"finding":item,"cross_check":cross,"truth_boundary":"Internet material is candidate knowledge only; it cannot silently modify JOE authoritative physics."},indent=2))
