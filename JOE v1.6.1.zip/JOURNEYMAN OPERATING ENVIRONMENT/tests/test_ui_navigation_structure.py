from pathlib import Path

def _source():
    return (Path(__file__).parents[1] / "journeyman" / "ui" / "main_window.py").read_text(encoding="utf-8")

def test_top_level_navigation_categories_present():
    src=_source()
    for label in ["&System","&Workspaces","&Physics","&Experiment","&Analyze","&Compute","Sa&fety","&Intelligence","&Qualification","&Help"]:
        assert f'addMenu("{label}")' in src

def test_all_primary_scientific_workspaces_remain_reachable():
    src=_source()
    callbacks=[
        "open_mpr","open_scientific_registry","open_navigation","open_geometry","open_stress_energy",
        "open_traversability","open_qft","open_chronology","open_mouth_dynamics","open_ring_laser",
        "open_verification","open_digital_twin","open_experiment_designer","open_metrology",
        "open_guardian","open_advanced_visualization","open_scientific_data","open_report_generator",
        "open_compute_backends","open_quantum_runtime","open_rt_control","open_integrated_qualification",
        "open_scientific_reference","open_scientific_intelligence"
    ]
    for cb in callbacks:
        assert f"self.{cb}" in src

def test_quick_access_toolbar_present():
    src=_source()
    assert 'QToolBar("JOE Quick Access"' in src
    assert 'launcher.setText("Workspace ▾")' in src
    assert 'compute_button.setText("Compute ▾")' in src
    assert 'qual_button.setText("Qualification ▾")' in src
