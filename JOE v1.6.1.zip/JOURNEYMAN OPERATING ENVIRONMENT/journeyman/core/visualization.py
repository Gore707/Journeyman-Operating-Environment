"""JOE Visualization Engine core models.

The visualization layer consumes the canonical ScientificDataStreamEngine.
It does not acquire, synthesize, or relabel scientific data.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any
import math

from .data_streams import ScientificDataStreamEngine, StreamSample


class PlotKind(str, Enum):
    TIME_SERIES = "TIME_SERIES"


@dataclass(frozen=True)
class PlotTrace:
    stream_id: str
    name: str
    unit: str
    origin: str
    timestamps: tuple[float, ...]
    values: tuple[float, ...]
    sequences: tuple[int, ...]
    gap_detected: bool
    segments: tuple[tuple[int, int], ...]


@dataclass(frozen=True)
class TimeSeriesView:
    title: str
    traces: tuple[PlotTrace, ...]
    common_unit: str | None
    window_start: float | None
    window_end: float | None


@dataclass(frozen=True)
class ScatterView:
    title: str
    x_stream_id: str
    y_stream_id: str
    x_name: str
    y_name: str
    x_unit: str
    y_unit: str
    x_origin: str
    y_origin: str
    x_values: tuple[float, ...]
    y_values: tuple[float, ...]
    timestamps: tuple[float, ...]


@dataclass(frozen=True)
class VisualizationQualification:
    passed: bool
    checks: tuple[str, ...]
    failures: tuple[str, ...]


@dataclass(frozen=True)
class VisualizationReleaseReadiness:
    passed: bool
    qualification: VisualizationQualification
    exercise_frames: int
    exercise_samples: int
    displayed_points: int
    exported_samples: int
    high_rate_samples: int
    high_rate_displayed: int
    notes: tuple[str, ...]


@dataclass(frozen=True)
class VisualizationExport:
    title: str
    columns: tuple[str, ...]
    rows: tuple[tuple[object, ...], ...]
    metadata: dict[str, object]


@dataclass(frozen=True)
class DisplayTrace:
    stream_id: str
    timestamps: tuple[float, ...]
    values: tuple[float, ...]
    sequences: tuple[int, ...]
    segments: tuple[tuple[int, int], ...]
    source_count: int
    displayed_count: int
    decimated: bool


@dataclass(frozen=True)
class FieldPoint:
    x: float
    y: float
    z: float
    timestamp: float
    frame_id: int


@dataclass(frozen=True)
class FieldView:
    title: str
    x_stream_id: str
    y_stream_id: str
    z_stream_id: str
    x_unit: str
    y_unit: str
    z_unit: str
    origins: tuple[str, str, str]
    sources: tuple[str, str, str]
    points: tuple[FieldPoint, ...]


@dataclass(frozen=True)
class MatrixHeatmapView:
    title: str
    stream_ids: tuple[str, ...]
    names: tuple[str, ...]
    units: tuple[str, ...]
    origins: tuple[str, ...]
    sources: tuple[str, ...]
    frame_ids: tuple[int, ...]
    timestamps: tuple[float, ...]
    values: tuple[tuple[float, ...], ...]


@dataclass(frozen=True)
class NumericInstrumentView:
    stream_id: str
    name: str
    unit: str
    origin: str
    source: str
    available: bool
    value: float | None
    timestamp: float | None
    sequence: int | None



@dataclass(frozen=True)
class GaugeView:
    stream_id: str
    name: str
    unit: str
    origin: str
    source: str
    available: bool
    value: float | None
    minimum: float
    maximum: float
    normalized: float | None
    in_range: bool | None
    timestamp: float | None
    sequence: int | None

    @property
    def fraction(self) -> float | None:
        """Display-safe gauge fraction clamped to [0, 1].

        The measured value itself is never clamped or synthesized.
        """
        if self.normalized is None:
            return None
        return min(1.0, max(0.0, self.normalized))


@dataclass(frozen=True)
class ScientificTableRow:
    stream_id: str
    name: str
    unit: str
    origin: str
    source: str
    available: bool
    value: float | None
    timestamp: float | None
    sequence: int | None


@dataclass(frozen=True)
class ScientificTableView:
    title: str
    columns: tuple[str, ...]
    stream_ids: tuple[str, ...]
    origins: tuple[str, ...]
    sources: tuple[str, ...]
    rows: tuple[tuple[object | None, ...], ...]


@dataclass(frozen=True)
class CursorSample:
    stream_id: str
    timestamp: float | None
    value: float | None
    sequence: int | None
    delta_seconds: float | None


@dataclass(frozen=True)
class SynchronizedCursorView:
    requested_timestamp: float
    tolerance_seconds: float | None
    samples: tuple[CursorSample, ...]


@dataclass(frozen=True)
class ContourGridView:
    title: str
    x_stream_id: str
    y_stream_id: str
    z_stream_id: str
    x_values: tuple[float, ...]
    y_values: tuple[float, ...]
    z_matrix: tuple[tuple[float | None, ...], ...]
    occupied_cells: int
    origins: tuple[str, str, str]
    sources: tuple[str, str, str]


class SynchronizedTimeCursor:
    """Small shared cursor state for synchronized visualization workspaces."""
    def __init__(self) -> None:
        self.timestamp: float | None = None

    def set(self, timestamp: float) -> float:
        timestamp=float(timestamp)
        if not math.isfinite(timestamp):
            raise ValueError("timestamp must be finite")
        self.timestamp=timestamp
        return timestamp


@dataclass(frozen=True)
class HistogramView:
    title: str
    stream_id: str
    name: str
    unit: str
    origin: str
    counts: tuple[int, ...]
    bin_edges: tuple[float, ...]
    sample_count: int


class VisualizationEngine:
    """Read-only visualization projection over JOE scientific streams."""
    def __init__(self, streams: ScientificDataStreamEngine) -> None:
        if not isinstance(streams, ScientificDataStreamEngine):
            raise TypeError("streams must be ScientificDataStreamEngine")
        self._streams=streams

    @property
    def streams(self) -> ScientificDataStreamEngine:
        return self._streams

    def numeric_stream_ids(self) -> tuple[str,...]:
        result=[]
        for definition in self._streams.definitions():
            types=definition.value_type if isinstance(definition.value_type,tuple) else (definition.value_type,)
            if any(t in (int,float) for t in types):
                result.append(definition.stream_id)
        return tuple(result)

    def time_series(self, stream_ids: tuple[str,...] | list[str], *,
                    limit: int=600, title: str="Live Time Series",
                    window_seconds: float | None=None,
                    end_timestamp: float | None=None) -> TimeSeriesView:
        if not stream_ids:
            raise ValueError("At least one stream is required")
        if not isinstance(limit,int) or isinstance(limit,bool) or limit < 2:
            raise ValueError("limit must be an integer >= 2")
        if window_seconds is not None:
            if isinstance(window_seconds,bool) or not isinstance(window_seconds,(int,float)):
                raise TypeError("window_seconds must be numeric or None")
            window_seconds=float(window_seconds)
            if not math.isfinite(window_seconds) or window_seconds <= 0:
                raise ValueError("window_seconds must be finite and > 0")
        if end_timestamp is not None:
            if isinstance(end_timestamp,bool) or not isinstance(end_timestamp,(int,float)):
                raise TypeError("end_timestamp must be numeric or None")
            end_timestamp=float(end_timestamp)
            if not math.isfinite(end_timestamp):
                raise ValueError("end_timestamp must be finite")
        traces=[]
        units=set()
        selected_definitions=[self._streams.definition(stream_id) for stream_id in stream_ids]
        effective_end=end_timestamp
        if window_seconds is not None and effective_end is None:
            latest_times=[]
            for definition in selected_definitions:
                latest=self._streams.latest(definition.stream_id)
                if latest is not None:
                    latest_times.append(latest.timestamp)
            effective_end=max(latest_times) if latest_times else None
        effective_start=(effective_end-window_seconds) if (
            window_seconds is not None and effective_end is not None
        ) else None
        for stream_id in stream_ids:
            definition=self._streams.definition(stream_id)
            types=definition.value_type if isinstance(definition.value_type,tuple) else (definition.value_type,)
            if not any(t in (int,float) for t in types):
                raise TypeError(f"{stream_id} is not a numeric stream")
            history=self._streams.history(stream_id,limit=limit)
            if effective_start is not None and effective_end is not None:
                history=tuple(
                    sample for sample in history
                    if effective_start <= sample.timestamp <= effective_end
                )
            values=[]
            timestamps=[]
            sequences=[]
            gap=False
            previous=None
            segment_start=0
            segments=[]
            for sample in history:
                value=float(sample.value)
                if not math.isfinite(value):
                    continue
                if previous is not None and sample.sequence != previous+1:
                    gap=True
                    if len(values) > segment_start:
                        segments.append((segment_start,len(values)))
                    segment_start=len(values)
                previous=sample.sequence
                timestamps.append(sample.timestamp)
                values.append(value)
                sequences.append(sample.sequence)
            if len(values) > segment_start:
                segments.append((segment_start,len(values)))
            traces.append(PlotTrace(
                definition.stream_id,definition.name,definition.unit,
                definition.origin.value,tuple(timestamps),tuple(values),
                tuple(sequences),gap,tuple(segments)
            ))
            units.add(definition.unit)
        return TimeSeriesView(
            str(title).strip() or "Live Time Series",
            tuple(traces),
            next(iter(units)) if len(units)==1 else None,
            effective_start,
            effective_end,
        )

    def scatter(self, x_stream_id: str, y_stream_id: str, *,
                limit: int=600, title: str="Scatter Plot") -> ScatterView:
        if not isinstance(limit,int) or isinstance(limit,bool) or limit < 1:
            raise ValueError("limit must be a positive integer")
        xdef=self._streams.definition(x_stream_id)
        ydef=self._streams.definition(y_stream_id)
        for definition in (xdef,ydef):
            types=definition.value_type if isinstance(definition.value_type,tuple) else (definition.value_type,)
            if not any(t in (int,float) for t in types):
                raise TypeError(f"{definition.stream_id} is not a numeric stream")

        # Pair by exact acquisition timestamp. Coherent JOE frames naturally
        # share timestamps; unrelated asynchronous streams are not interpolated
        # or fabricated into apparent paired measurements.
        xhist=self._streams.history(x_stream_id,limit=limit)
        yhist=self._streams.history(y_stream_id,limit=limit)
        x_by_time={}
        for sample in xhist:
            value=float(sample.value)
            if math.isfinite(value):
                x_by_time[sample.timestamp]=value
        xs=[]; ys=[]; timestamps=[]
        for sample in yhist:
            y=float(sample.value)
            if not math.isfinite(y) or sample.timestamp not in x_by_time:
                continue
            xs.append(x_by_time[sample.timestamp])
            ys.append(y)
            timestamps.append(sample.timestamp)
        return ScatterView(
            str(title).strip() or "Scatter Plot",
            xdef.stream_id,ydef.stream_id,xdef.name,ydef.name,
            xdef.unit,ydef.unit,xdef.origin.value,ydef.origin.value,
            tuple(xs),tuple(ys),tuple(timestamps)
        )

    def histogram(self, stream_id: str, *, bins: int=20,
                  limit: int=600, title: str="Histogram") -> HistogramView:
        if not isinstance(bins,int) or isinstance(bins,bool) or bins < 1 or bins > 1000:
            raise ValueError("bins must be an integer from 1 to 1000")
        if not isinstance(limit,int) or isinstance(limit,bool) or limit < 1:
            raise ValueError("limit must be a positive integer")
        definition=self._streams.definition(stream_id)
        types=definition.value_type if isinstance(definition.value_type,tuple) else (definition.value_type,)
        if not any(t in (int,float) for t in types):
            raise TypeError(f"{stream_id} is not a numeric stream")
        values=[
            float(sample.value) for sample in self._streams.history(stream_id,limit=limit)
            if math.isfinite(float(sample.value))
        ]
        if not values:
            return HistogramView(
                str(title).strip() or "Histogram",definition.stream_id,
                definition.name,definition.unit,definition.origin.value,
                (),(),0
            )
        lo=min(values); hi=max(values)
        if lo == hi:
            half=0.5 if lo == 0 else abs(lo)*0.005
            if half == 0: half=0.5
            lo-=half; hi+=half
        width=(hi-lo)/bins
        edges=tuple(lo+i*width for i in range(bins+1))
        counts=[0]*bins
        for value in values:
            index=int((value-lo)/width)
            if index == bins: index=bins-1
            counts[index]+=1
        return HistogramView(
            str(title).strip() or "Histogram",definition.stream_id,
            definition.name,definition.unit,definition.origin.value,
            tuple(counts),edges,len(values)
        )

    def numeric_instrument(self, stream_id: str) -> NumericInstrumentView:
        definition=self._streams.definition(stream_id)
        types=definition.value_type if isinstance(definition.value_type,tuple) else (definition.value_type,)
        if not any(t in (int,float) for t in types):
            raise TypeError(f"{stream_id} is not a numeric stream")
        latest=self._streams.latest(stream_id)
        if latest is None:
            return NumericInstrumentView(
                definition.stream_id,definition.name,definition.unit,
                definition.origin.value,definition.source,False,None,None,None
            )
        value=float(latest.value)
        if not math.isfinite(value):
            return NumericInstrumentView(
                definition.stream_id,definition.name,definition.unit,
                definition.origin.value,definition.source,False,None,
                latest.timestamp,latest.sequence
            )
        return NumericInstrumentView(
            definition.stream_id,definition.name,definition.unit,
            definition.origin.value,definition.source,True,value,
            latest.timestamp,latest.sequence
        )

    def gauge(self, stream_id: str, minimum: float, maximum: float) -> GaugeView:
        minimum=float(minimum); maximum=float(maximum)
        if not math.isfinite(minimum) or not math.isfinite(maximum) or maximum <= minimum:
            raise ValueError("gauge range must be finite with maximum > minimum")
        instrument=self.numeric_instrument(stream_id)
        if not instrument.available:
            return GaugeView(instrument.stream_id,instrument.name,instrument.unit,instrument.origin,instrument.source,False,None,minimum,maximum,None,None,instrument.timestamp,instrument.sequence)
        value=float(instrument.value)
        normalized=(value-minimum)/(maximum-minimum)
        return GaugeView(instrument.stream_id,instrument.name,instrument.unit,instrument.origin,instrument.source,True,value,minimum,maximum,normalized,minimum <= value <= maximum,instrument.timestamp,instrument.sequence)

    def scientific_table(self, stream_ids: tuple[str,...] | list[str], *, limit: int=600, title: str="Scientific Table") -> ScientificTableView:
        if not stream_ids:
            raise ValueError("At least one stream is required")
        if not isinstance(limit,int) or isinstance(limit,bool) or limit < 1:
            raise ValueError("limit must be a positive integer")
        definitions=[self._streams.definition(stream_id) for stream_id in stream_ids]
        for definition in definitions:
            types=definition.value_type if isinstance(definition.value_type,tuple) else (definition.value_type,)
            if not any(t in (int,float) for t in types):
                raise TypeError(f"{definition.stream_id} is not a numeric stream")
        # Sparse table: union of observed timestamps. Missing observations remain
        # None; values are never interpolated or synthesized.
        maps=[]
        timestamps=set()
        for definition in definitions:
            mapping={}
            for sample in self._streams.history(definition.stream_id,limit=limit):
                try: value=float(sample.value)
                except (TypeError,ValueError): continue
                if not math.isfinite(value): continue
                mapping[sample.timestamp]=value
                timestamps.add(sample.timestamp)
            maps.append(mapping)
        ordered=sorted(timestamps)[-limit:]
        rows=tuple(tuple([ts]+[mapping.get(ts) for mapping in maps]) for ts in ordered)
        return ScientificTableView(
            str(title).strip() or "Scientific Table",
            tuple(["timestamp"]+[d.name for d in definitions]),
            tuple(d.stream_id for d in definitions),
            tuple(d.origin.value for d in definitions),
            tuple(d.source for d in definitions),
            rows,
        )

    def contour_grid(self, x_stream_id: str, y_stream_id: str, z_stream_id: str, *,
                     frame_limit: int=5000, title: str="Contour Grid") -> ContourGridView:
        if not isinstance(frame_limit,int) or isinstance(frame_limit,bool) or frame_limit < 1:
            raise ValueError("frame_limit must be a positive integer")
        definitions=[self._streams.definition(sid) for sid in (x_stream_id,y_stream_id,z_stream_id)]
        mappings=[]
        for definition in definitions:
            types=definition.value_type if isinstance(definition.value_type,tuple) else (definition.value_type,)
            if not any(t in (int,float) for t in types):
                raise TypeError(f"{definition.stream_id} is not a numeric stream")
            m={}
            for sample in self._streams.history(definition.stream_id,limit=frame_limit):
                if sample.frame_id is None: continue
                try: value=float(sample.value)
                except (TypeError,ValueError): continue
                if math.isfinite(value): m[sample.frame_id]=sample
            mappings.append(m)
        common=set(mappings[0])
        for m in mappings[1:]: common.intersection_update(m)
        observed=[]
        for fid in sorted(common)[-frame_limit:]:
            samples=[m[fid] for m in mappings]
            if len({sample.timestamp for sample in samples}) != 1: continue
            observed.append((float(samples[0].value),float(samples[1].value),float(samples[2].value)))
        xs=tuple(sorted({x for x,_,_ in observed})); ys=tuple(sorted({y for _,y,_ in observed}))
        cells={(x,y):z for x,y,z in observed}
        matrix=tuple(tuple(cells.get((x,y)) for x in xs) for y in ys)
        return ContourGridView(
            str(title).strip() or "Contour Grid",x_stream_id,y_stream_id,z_stream_id,
            xs,ys,matrix,len(cells),tuple(d.origin.value for d in definitions),tuple(d.source for d in definitions)
        )

    def synchronized_cursor(self, stream_ids: tuple[str,...] | list[str], *, timestamp: float, tolerance_seconds: float | None=None, limit: int=5000) -> SynchronizedCursorView:
        if not stream_ids:
            raise ValueError("At least one stream is required")
        timestamp=float(timestamp)
        if not math.isfinite(timestamp):
            raise ValueError("timestamp must be finite")
        if tolerance_seconds is not None:
            tolerance_seconds=float(tolerance_seconds)
            if not math.isfinite(tolerance_seconds) or tolerance_seconds < 0:
                raise ValueError("tolerance_seconds must be finite and >= 0")
        samples=[]
        for stream_id in stream_ids:
            self._streams.definition(stream_id)
            finite=[]
            for sample in self._streams.history(stream_id,limit=limit):
                try: value=float(sample.value)
                except (TypeError,ValueError): continue
                if math.isfinite(value):
                    finite.append((abs(sample.timestamp-timestamp),sample,value))
            if not finite:
                samples.append(CursorSample(stream_id,None,None,None,None)); continue
            delta,sample,value=min(finite,key=lambda item:(item[0],item[1].timestamp,item[1].sequence))
            if tolerance_seconds is not None and delta > tolerance_seconds:
                samples.append(CursorSample(stream_id,None,None,None,None))
            else:
                samples.append(CursorSample(stream_id,sample.timestamp,value,sample.sequence,sample.timestamp-timestamp))
        return SynchronizedCursorView(timestamp,tolerance_seconds,tuple(samples))

    def matrix_heatmap(self, stream_ids: tuple[str,...] | list[str], *,
                       frame_limit: int=200,
                       title: str="Matrix / Heatmap") -> MatrixHeatmapView:
        if not stream_ids:
            raise ValueError("At least one stream is required")
        if not isinstance(frame_limit,int) or isinstance(frame_limit,bool) or frame_limit < 1:
            raise ValueError("frame_limit must be a positive integer")
        definitions=[self._streams.definition(stream_id) for stream_id in stream_ids]
        for definition in definitions:
            types=definition.value_type if isinstance(definition.value_type,tuple) else (definition.value_type,)
            if not any(t in (int,float) for t in types):
                raise TypeError(f"{definition.stream_id} is not a numeric stream")

        # Build rows only from frame IDs present in every selected stream.
        # No interpolation or value synthesis is permitted.
        by_stream=[]
        for definition in definitions:
            mapping={}
            for sample in self._streams.history(definition.stream_id):
                if sample.frame_id is None:
                    continue
                value=float(sample.value)
                if math.isfinite(value):
                    mapping[sample.frame_id]=sample
            by_stream.append(mapping)

        common=set(by_stream[0]) if by_stream else set()
        for mapping in by_stream[1:]:
            common.intersection_update(mapping)
        frame_ids=sorted(common)[-frame_limit:]
        rows=[]; timestamps=[]
        for frame_id in frame_ids:
            samples=[mapping[frame_id] for mapping in by_stream]
            # A coherent frame must have one timestamp. Reject malformed
            # retained data instead of presenting it as synchronized.
            frame_times={sample.timestamp for sample in samples}
            if len(frame_times) != 1:
                continue
            timestamps.append(samples[0].timestamp)
            rows.append(tuple(float(sample.value) for sample in samples))
        accepted_ids=tuple(
            frame_id for frame_id in frame_ids
            if all(frame_id in mapping for mapping in by_stream)
            and len({mapping[frame_id].timestamp for mapping in by_stream}) == 1
        )
        return MatrixHeatmapView(
            str(title).strip() or "Matrix / Heatmap",
            tuple(d.stream_id for d in definitions),
            tuple(d.name for d in definitions),
            tuple(d.unit for d in definitions),
            tuple(d.origin.value for d in definitions),
            tuple(d.source for d in definitions),
            accepted_ids,tuple(timestamps),tuple(rows)
        )

    def field_points(self, x_stream_id: str, y_stream_id: str, z_stream_id: str, *,
                     limit: int=1000, title: str="Scientific Field") -> FieldView:
        if not isinstance(limit,int) or isinstance(limit,bool) or limit < 1:
            raise ValueError("limit must be a positive integer")
        definitions=[
            self._streams.definition(x_stream_id),
            self._streams.definition(y_stream_id),
            self._streams.definition(z_stream_id),
        ]
        if len({d.stream_id for d in definitions}) != 3:
            raise ValueError("x, y, and z must be three distinct streams")
        for definition in definitions:
            types=definition.value_type if isinstance(definition.value_type,tuple) else (definition.value_type,)
            if not any(t in (int,float) for t in types):
                raise TypeError(f"{definition.stream_id} is not a numeric stream")

        mappings=[]
        for definition in definitions:
            mapping={}
            for sample in self._streams.history(definition.stream_id,limit=limit):
                if sample.frame_id is None:
                    continue
                value=float(sample.value)
                if math.isfinite(value):
                    mapping[sample.frame_id]=sample
            mappings.append(mapping)
        common=set(mappings[0])
        common.intersection_update(mappings[1])
        common.intersection_update(mappings[2])

        points=[]
        for frame_id in sorted(common):
            samples=[mapping[frame_id] for mapping in mappings]
            timestamps={sample.timestamp for sample in samples}
            if len(timestamps) != 1:
                continue
            points.append(FieldPoint(
                float(samples[0].value),float(samples[1].value),float(samples[2].value),
                samples[0].timestamp,frame_id
            ))
        return FieldView(
            str(title).strip() or "Scientific Field",
            definitions[0].stream_id,definitions[1].stream_id,definitions[2].stream_id,
            definitions[0].unit,definitions[1].unit,definitions[2].unit,
            tuple(d.origin.value for d in definitions),
            tuple(d.source for d in definitions),
            tuple(points)
        )

    def display_trace(self, stream_id: str, *, limit: int=5000,
                      max_points: int=1200,
                      start_timestamp: float | None=None,
                      end_timestamp: float | None=None) -> DisplayTrace:
        if not isinstance(limit,int) or isinstance(limit,bool) or limit < 1:
            raise ValueError("limit must be a positive integer")
        if not isinstance(max_points,int) or isinstance(max_points,bool) or max_points < 2:
            raise ValueError("max_points must be an integer >= 2")
        definition=self._streams.definition(stream_id)
        types=definition.value_type if isinstance(definition.value_type,tuple) else (definition.value_type,)
        if not any(t in (int,float) for t in types):
            raise TypeError(f"{stream_id} is not a numeric stream")
        if start_timestamp is not None:
            start_timestamp=float(start_timestamp)
            if not math.isfinite(start_timestamp):
                raise ValueError("start_timestamp must be finite")
        if end_timestamp is not None:
            end_timestamp=float(end_timestamp)
            if not math.isfinite(end_timestamp):
                raise ValueError("end_timestamp must be finite")
        if start_timestamp is not None and end_timestamp is not None and start_timestamp > end_timestamp:
            raise ValueError("start_timestamp cannot exceed end_timestamp")

        raw=[]
        for sample in self._streams.history(stream_id,limit=limit):
            if start_timestamp is not None and sample.timestamp < start_timestamp:
                continue
            if end_timestamp is not None and sample.timestamp > end_timestamp:
                continue
            value=float(sample.value)
            if math.isfinite(value):
                raw.append(sample)
        source_count=len(raw)
        if source_count <= max_points:
            chosen=raw
        else:
            # Preserve first/last samples and select deterministic evenly spaced
            # retained samples. This is display decimation only; canonical data
            # remains untouched.
            indices=[]
            for i in range(max_points):
                idx=round(i*(source_count-1)/(max_points-1))
                if not indices or idx != indices[-1]:
                    indices.append(idx)
            chosen=[raw[i] for i in indices]

        timestamps=tuple(sample.timestamp for sample in chosen)
        values=tuple(float(sample.value) for sample in chosen)
        sequences=tuple(sample.sequence for sample in chosen)

        # Segment only on gaps that existed in the source data. Decimation itself
        # is not a data-loss event and must not be reported as one.
        source_positions={sample.sequence:i for i,sample in enumerate(raw)}
        segments=[]
        if chosen:
            seg_start=0
            previous=chosen[0]
            for index,current in enumerate(chosen[1:],start=1):
                p0=source_positions[previous.sequence]
                p1=source_positions[current.sequence]
                underlying=raw[p0:p1+1]
                has_gap=any(
                    underlying[j].sequence != underlying[j-1].sequence+1
                    for j in range(1,len(underlying))
                )
                if has_gap:
                    segments.append((seg_start,index))
                    seg_start=index
                previous=current
            segments.append((seg_start,len(chosen)))
        return DisplayTrace(
            definition.stream_id,timestamps,values,sequences,tuple(segments),
            source_count,len(chosen),source_count>len(chosen)
        )

    def export_time_series(self, stream_ids: tuple[str,...] | list[str], *,
                           limit: int=5000,
                           start_timestamp: float | None=None,
                           end_timestamp: float | None=None,
                           title: str="JOE Time-Series Export") -> VisualizationExport:
        if not stream_ids:
            raise ValueError("At least one stream is required")
        definitions=[self._streams.definition(stream_id) for stream_id in stream_ids]
        traces=[
            self.display_trace(
                d.stream_id,limit=limit,max_points=max(2,limit),
                start_timestamp=start_timestamp,end_timestamp=end_timestamp
            ) for d in definitions
        ]
        rows=[]
        for definition,trace in zip(definitions,traces):
            for timestamp,value,sequence in zip(trace.timestamps,trace.values,trace.sequences):
                rows.append((
                    definition.stream_id,definition.name,definition.unit,
                    definition.origin.value,definition.source,
                    sequence,timestamp,value
                ))
        rows.sort(key=lambda row:(row[6],row[0],row[5]))
        return VisualizationExport(
            str(title).strip() or "JOE Time-Series Export",
            ("stream_id","name","unit","origin","source","sequence","timestamp","value"),
            tuple(rows),
            {
                "export_kind":"time_series",
                "stream_count":len(definitions),
                "sample_count":len(rows),
                "start_timestamp":start_timestamp,
                "end_timestamp":end_timestamp,
                "streams":[
                    {"stream_id":d.stream_id,"name":d.name,"unit":d.unit,
                     "origin":d.origin.value,"source":d.source}
                    for d in definitions
                ],
            }
        )

    @staticmethod
    def export_csv_text(export: VisualizationExport) -> str:
        import csv, io
        buffer=io.StringIO(newline="")
        writer=csv.writer(buffer,lineterminator="\n")
        writer.writerow(export.columns)
        writer.writerows(export.rows)
        return buffer.getvalue()

    @staticmethod
    def export_metadata_json(export: VisualizationExport) -> str:
        import json
        return json.dumps(
            {"title":export.title,"columns":list(export.columns),**export.metadata},
            indent=2,sort_keys=True
        ) + "\n"

def qualify_visualization_engine(engine: VisualizationEngine) -> VisualizationQualification:
    checks=[]
    failures=[]
    try:
        stream_ids=engine.numeric_stream_ids()
        checks.append(f"numeric stream discovery operational ({len(stream_ids)} registered numeric stream(s))")
        for stream_id in stream_ids:
            definition=engine.streams.definition(stream_id)
            instrument=engine.numeric_instrument(stream_id)
            if instrument.stream_id != definition.stream_id:
                failures.append(f"{stream_id}: instrument identity mismatch")
            if instrument.origin != definition.origin.value:
                failures.append(f"{stream_id}: instrument origin mismatch")
            if instrument.source != definition.source:
                failures.append(f"{stream_id}: instrument source mismatch")
        checks.append("numeric instrument provenance matches canonical stream definitions")
        if stream_ids:
            export=engine.export_time_series(stream_ids,limit=5000)
            allowed=set(stream_ids)
            if any(row[0] not in allowed for row in export.rows):
                failures.append("export contains an unrequested stream")
            checks.append("time-series export restricted to requested canonical streams")
        else:
            checks.append("no numeric streams present; empty discovery is valid")
    except Exception as exc:
        failures.append(f"qualification exception: {type(exc).__name__}: {exc}")
    return VisualizationQualification(not failures,tuple(checks),tuple(failures))


def joe009_release_readiness(live_engine: VisualizationEngine) -> VisualizationReleaseReadiness:
    """Non-destructive live qualification plus isolated visualization exercise."""
    qualification=qualify_visualization_engine(live_engine)
    notes=list(qualification.failures)
    frames=256
    samples=0
    displayed=0
    exported=0
    high_rate_samples=0
    high_rate_displayed=0
    try:
        from .data_streams import ScientificDataStreamEngine
        from .state_events import DataOrigin
        streams=ScientificDataStreamEngine()
        for sid,name,unit in (
            ("qualification.x","X","m"),
            ("qualification.y","Y","m"),
            ("qualification.z","Field","J"),
        ):
            streams.register(sid,name,unit,float,DataOrigin.SIMULATION,"joe009.qualification")
        for i in range(frames):
            values={
                "qualification.x":float(i),
                "qualification.y":float(i*2),
                "qualification.z":float((i % 17)-8),
            }
            streams.publish_frame(
                values,source="joe009.qualification",timestamp=float(i+1)
            )
        isolated=VisualizationEngine(streams)
        samples=sum(len(streams.history(sid)) for sid in isolated.numeric_stream_ids())

        time_view=isolated.time_series(
            ["qualification.x","qualification.y"],limit=5000
        )
        if len(time_view.traces) != 2:
            notes.append("isolated time-series projection did not return two traces")
        scatter=isolated.scatter("qualification.x","qualification.y",limit=5000)
        if len(scatter.x_values) != frames:
            notes.append("isolated scatter lost coherent timestamp pairs")
        histogram=isolated.histogram("qualification.z",bins=17,limit=5000)
        if sum(histogram.counts) != frames:
            notes.append("isolated histogram count mismatch")
        matrix=isolated.matrix_heatmap(
            ["qualification.x","qualification.y","qualification.z"],frame_limit=frames
        )
        if len(matrix.values) != frames:
            notes.append("isolated matrix/heatmap frame count mismatch")
        field=isolated.field_points(
            "qualification.x","qualification.y","qualification.z",limit=5000
        )
        if len(field.points) != frames:
            notes.append("isolated field-point count mismatch")

        display=isolated.display_trace(
            "qualification.x",limit=5000,max_points=64
        )
        displayed=display.displayed_count
        if displayed != 64 or not display.decimated:
            notes.append("display decimation exercise failed")
        if len(streams.history("qualification.x")) != frames:
            notes.append("display projection mutated canonical retained samples")

        export=isolated.export_time_series(
            ["qualification.x","qualification.y","qualification.z"],limit=5000
        )
        exported=export.metadata["sample_count"]
        if exported != frames*3:
            notes.append("export sample count mismatch")
        if any(row[3] != "SIMULATION" for row in export.rows):
            notes.append("isolated export lost SIMULATION provenance")
        checks=qualify_visualization_engine(isolated)
        if not checks.passed:
            notes.extend(f"isolated: {failure}" for failure in checks.failures)

        # High-rate model exercise: enough retained samples to force display
        # decimation. This validates bounded projection behavior, not GUI FPS.
        fast_streams=ScientificDataStreamEngine()
        fast_streams.register(
            "qualification.fast","Fast Signal","V",float,
            DataOrigin.SIMULATION,"joe009.qualification"
        )
        for i in range(5000):
            fast_streams.publish(
                "qualification.fast",float(i % 101),
                source="joe009.qualification",timestamp=1000.0+i*0.001
            )
        fast_engine=VisualizationEngine(fast_streams)
        high_rate_samples=len(fast_streams.history("qualification.fast",limit=5000))
        fast_display=fast_engine.display_trace(
            "qualification.fast",limit=5000,max_points=1200
        )
        high_rate_displayed=fast_display.displayed_count
        if high_rate_samples <= high_rate_displayed:
            notes.append("high-rate exercise did not activate display decimation")
        if high_rate_displayed > 1200:
            notes.append("high-rate display exceeded configured point budget")
        if len(fast_streams.history("qualification.fast",limit=5000)) != high_rate_samples:
            notes.append("high-rate display projection mutated canonical samples")
    except Exception as exc:
        notes.append(f"isolated exercise exception: {type(exc).__name__}: {exc}")

    passed=qualification.passed and not notes
    return VisualizationReleaseReadiness(
        passed,qualification,frames,samples,displayed,exported,
        high_rate_samples,high_rate_displayed,tuple(notes)
    )

