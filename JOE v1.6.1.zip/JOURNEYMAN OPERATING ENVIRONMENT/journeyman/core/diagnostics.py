from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from datetime import datetime, timezone

class HealthState(str,Enum):
    HEALTHY="HEALTHY"
    DEGRADED="DEGRADED"
    FAILED="FAILED"
    UNAVAILABLE="UNAVAILABLE"

@dataclass(frozen=True)
class HealthEvidence:
    component: str
    state: HealthState
    summary: str
    timestamp: str
    evidence: tuple[str,...]=()

@dataclass(frozen=True)
class SystemHealth:
    state: HealthState
    components: tuple[HealthEvidence,...]
    timestamp: str

def _now(): return datetime.now(timezone.utc).isoformat()

class DiagnosticsService:
    """Read-only aggregation of real JOE component health evidence."""
    REQUIRED_SERVICES=("joe.state-events","joe.storage","joe.jobs","joe.host-telemetry",
                       "joe.host-telemetry-monitor","joe.streams","joe.visualization",
                       "joe.runs","joe.run_review","joe.projects")
    def __init__(self,runtime):
        self.runtime=runtime

    def _service_health(self,capability):
        try:
            service=self.runtime.service(capability)
            if service is None: raise RuntimeError("service returned None")
            return HealthEvidence(capability,HealthState.HEALTHY,"registered and resolvable",_now(),
                                  (f"owner={self.runtime.service_owner(capability) or 'unknown'}",))
        except Exception as exc:
            return HealthEvidence(capability,HealthState.FAILED,"required service is not resolvable",_now(),(str(exc),))

    def _check(self,component,call):
        try:
            result=call()
            passed=getattr(result,"passed",None)
            if passed is False:
                evidence=tuple(str(x) for x in getattr(result,"failures",()) or ("qualification failed",))
                return HealthEvidence(component,HealthState.DEGRADED,"qualification reported failures",_now(),evidence)
            evidence=[]
            for attr in ("checks","failures"):
                values=getattr(result,attr,())
                if values: evidence.extend(str(x) for x in values)
            return HealthEvidence(component,HealthState.HEALTHY,"qualification passed",_now(),tuple(evidence[:8]))
        except Exception as exc:
            return HealthEvidence(component,HealthState.FAILED,"health check could not execute",_now(),(str(exc),))

    def snapshot(self):
        rows=[self._service_health(x) for x in self.REQUIRED_SERVICES]
        from .storage import qualify_storage
        from .data_streams import qualify_scientific_data_streams
        from .run_recorder import qualify_run_recorder
        from .run_review import qualify_run_review
        from .projects_sessions import qualify_projects_sessions
        rows.extend((
            self._check("storage.integrity",lambda: qualify_storage(self.runtime.service("joe.storage"))),
            self._check("streams.integrity",lambda: qualify_scientific_data_streams(self.runtime.service("joe.streams"))),
            self._check("runs.integrity",lambda: qualify_run_recorder(self.runtime.service("joe.runs"))),
            self._check("review.integrity",lambda: qualify_run_review(self.runtime.service("joe.run_review"))),
            self._check("projects.sessions.repository",lambda: qualify_projects_sessions(self.runtime.service("joe.projects"))),
        ))
        # Telemetry monitor freshness is a live runtime condition, not a qualification fixture.
        try:
            status=self.runtime.service("joe.host-telemetry-monitor").status(stale_after_seconds=5.0)
            stale=bool(getattr(status,"stale",False))
            failures=int(getattr(status,"consecutive_failures",0))
            state=HealthState.DEGRADED if stale or failures else HealthState.HEALTHY
            rows.append(HealthEvidence("telemetry.monitor",state,
                "telemetry stale or sampling failures present" if state is HealthState.DEGRADED else "telemetry monitor current",
                _now(),(f"stale={stale}",f"consecutive_failures={failures}")))
        except Exception as exc:
            rows.append(HealthEvidence("telemetry.monitor",HealthState.FAILED,"telemetry monitor status unavailable",_now(),(str(exc),)))
        states={x.state for x in rows}
        overall=(HealthState.FAILED if HealthState.FAILED in states else
                 HealthState.DEGRADED if HealthState.DEGRADED in states else
                 HealthState.UNAVAILABLE if HealthState.UNAVAILABLE in states else HealthState.HEALTHY)
        return SystemHealth(overall,tuple(rows),_now())

@dataclass(frozen=True)
class DiagnosticsQualification:
    passed: bool
    failures: tuple[str,...]

def qualify_diagnostics(service):
    failures=[]
    try:
        snap=service.snapshot()
        if not snap.components: failures.append("health snapshot contained no components")
        names=[x.component for x in snap.components]
        if len(names)!=len(set(names)): failures.append("duplicate component health identity")
        for row in snap.components:
            if not row.summary.strip(): failures.append(f"{row.component}: empty health summary")
    except Exception as exc: failures.append(f"diagnostics snapshot failed: {exc}")
    return DiagnosticsQualification(not failures,tuple(failures))


@dataclass(frozen=True)
class DiagnosticsReleaseReadiness:
    passed: bool
    healthy_snapshot_passed: bool
    fault_detection_passed: bool
    failures: tuple[str,...]

def joe013_release_readiness(service):
    failures=[]
    healthy=False; fault=False
    try:
        q=qualify_diagnostics(service)
        snap=service.snapshot()
        healthy=q.passed and bool(snap.components)
        if not healthy: failures.extend(q.failures or ("normal diagnostics snapshot failed",))
    except Exception as exc: failures.append(f"normal diagnostics exercise failed: {exc}")
    try:
        class BrokenRuntime:
            def service(self,name): raise KeyError(f"intentionally absent: {name}")
            def service_owner(self,name): return None
        broken=DiagnosticsService(BrokenRuntime()).snapshot()
        fault=(broken.state is HealthState.FAILED and any(x.state is HealthState.FAILED for x in broken.components))
        if not fault: failures.append("fault-injection exercise did not produce FAILED health")
    except Exception as exc: failures.append(f"fault-injection exercise failed: {exc}")
    return DiagnosticsReleaseReadiness(not failures,healthy,fault,tuple(failures))
