"""QPU Adapter / Quantum Runtime — QPU-001A typed foundation."""
from __future__ import annotations
from dataclasses import dataclass,asdict
from enum import Enum
from typing import Any
import importlib.util,time,uuid,hashlib,json

class QuantumBackendKind(str,Enum):
    LOCAL_SIMULATOR="LOCAL_SIMULATOR"
    QPU="QPU"

class QuantumBackendStatus(str,Enum):
    AVAILABLE="AVAILABLE"
    UNAVAILABLE="UNAVAILABLE"
    DEGRADED="DEGRADED"

class QuantumJobStatus(str,Enum):
    SUCCEEDED="SUCCEEDED"
    FAILED="FAILED"
    REJECTED="REJECTED"

@dataclass(frozen=True)
class QuantumBackend:
    backend_id:str
    kind:QuantumBackendKind
    status:QuantumBackendStatus
    provider:str
    name:str
    qubit_count:int|None
    capabilities:tuple[str,...]
    provenance:str
    diagnostic:str=""
    def __post_init__(self):
        if not all((self.backend_id.strip(),self.provider.strip(),self.name.strip(),self.provenance.strip())):
            raise ValueError("quantum backend identity/provider/name/provenance required")
        if self.qubit_count is not None and self.qubit_count<1:raise ValueError("qubit count must be positive")

@dataclass(frozen=True)
class QuantumCircuit:
    circuit_id:str
    qubit_count:int
    operations:tuple[tuple[str,tuple[int,...]],...]
    provenance:str
    def __post_init__(self):
        if not self.circuit_id.strip() or not self.provenance.strip():raise ValueError("circuit identity/provenance required")
        if self.qubit_count<1:raise ValueError("qubit count must be positive")
        allowed={"H","X","CX","MEASURE"}
        for op,qs in self.operations:
            if op not in allowed:raise ValueError("unsupported QPU-001A operation: "+op)
            if not qs or any(q<0 or q>=self.qubit_count for q in qs):raise ValueError("circuit qubit index outside declared range")
            if op=="CX" and len(qs)!=2:raise ValueError("CX requires control,target")
            if op!="CX" and len(qs)!=1:raise ValueError(op+" requires one qubit")

@dataclass(frozen=True)
class QuantumJobRequest:
    job_id:str
    backend_id:str
    circuit:QuantumCircuit
    shots:int
    provenance:str
    run_id:str|None=None
    def __post_init__(self):
        if not self.job_id.strip() or not self.backend_id.strip() or not self.provenance.strip():raise ValueError("job identity/backend/provenance required")
        if not 1<=self.shots<=1_000_000:raise ValueError("shots outside governed range")

@dataclass(frozen=True)
class QuantumJobResult:
    job_id:str
    backend_id:str
    status:QuantumJobStatus
    counts:dict[str,int]
    started_at_s:float|None
    finished_at_s:float|None
    provenance:str
    diagnostic:str=""

def discover_quantum_backends()->tuple[QuantumBackend,...]:
    """Discover software runtimes only. Never infer access to physical QPUs from an installed SDK."""
    found=[]
    for module,provider in (("qiskit","Qiskit"),("cirq","Cirq")):
        if importlib.util.find_spec(module):
            found.append(QuantumBackend(f"local.simulator.{module}",QuantumBackendKind.LOCAL_SIMULATOR,
                QuantumBackendStatus.AVAILABLE,provider,f"{provider} local simulator runtime",None,
                ("circuit-simulation","shots"),f"SOFTWARE: installed Python module {module}"))
    # Physical QPU access is intentionally unavailable until an authenticated adapter proves it.
    found.append(QuantumBackend("physical.qpu",QuantumBackendKind.QPU,QuantumBackendStatus.UNAVAILABLE,
        "UNBOUND","Physical QPU",None,(),"SOFTWARE: no authenticated physical-QPU adapter",
        "An installed SDK does not establish credentials, device availability, queue access, or hardware authorization."))
    return tuple(found)

def _basis_simulate(circuit:QuantumCircuit,shots:int)->dict[str,int]:
    """Deterministic exact-basis simulator for X/CX/MEASURE; H is explicitly unsupported here."""
    bits=[0]*circuit.qubit_count
    measured=[]
    for op,qs in circuit.operations:
        if op=="H":raise ValueError("H requires a probabilistic/quantum simulator adapter; basis simulator refuses to fake it")
        if op=="X":bits[qs[0]]^=1
        elif op=="CX":
            if bits[qs[0]]:bits[qs[1]]^=1
        elif op=="MEASURE":measured.append(qs[0])
    if not measured:raise ValueError("circuit contains no measurements")
    key="".join(str(bits[q]) for q in reversed(measured))
    return {key:shots}

def execute_basis_simulation(request:QuantumJobRequest)->QuantumJobResult:
    start=time.time()
    if request.backend_id!="joe.basis-simulator":
        return QuantumJobResult(request.job_id,request.backend_id,QuantumJobStatus.REJECTED,{},None,time.time(),
                                request.provenance,"QPU-001A basis simulator only executes on joe.basis-simulator")
    try:
        counts=_basis_simulate(request.circuit,request.shots)
        return QuantumJobResult(request.job_id,request.backend_id,QuantumJobStatus.SUCCEEDED,counts,start,time.time(),
                                request.provenance)
    except Exception as exc:
        return QuantumJobResult(request.job_id,request.backend_id,QuantumJobStatus.FAILED,{},start,time.time(),
                                request.provenance,f"{type(exc).__name__}: {exc}")

def builtin_basis_backend()->QuantumBackend:
    return QuantumBackend("joe.basis-simulator",QuantumBackendKind.LOCAL_SIMULATOR,QuantumBackendStatus.AVAILABLE,
                          "JOE","JOE exact basis-state qualification simulator",None,
                          ("X","CX","MEASURE","shots"),"SOFTWARE: JOE QPU-001A")

@dataclass(frozen=True)
class QuantumGuardianContract:
    schema:str
    status:str
    facts:dict[str,Any]
    provenance:str
    authority:str="READ_ONLY_ADVISORY"

def quantum_guardian_contract(backends:tuple[QuantumBackend,...])->QuantumGuardianContract:
    physical=[b for b in backends if b.kind==QuantumBackendKind.QPU and b.status==QuantumBackendStatus.AVAILABLE]
    return QuantumGuardianContract("JOE-GUARDIAN-QUANTUM/1","PASS",
        {"backends":tuple(asdict(b) for b in backends),"physical_qpu_available":bool(physical),
         "controller_authority":False,"safety_authority":False},
        "QPU Adapter / Quantum Runtime QPU-001A")

def quantum_job_provenance(request:QuantumJobRequest,result:QuantumJobResult)->dict[str,Any]:
    return {"schema":"JOE-QUANTUM-JOB/1","job_id":request.job_id,"run_id":request.run_id,
            "backend_id":result.backend_id,"status":result.status.value,"shots":request.shots,
            "circuit_id":request.circuit.circuit_id,"circuit_provenance":request.circuit.provenance,
            "request_provenance":request.provenance,"started_at_s":result.started_at_s,
            "finished_at_s":result.finished_at_s,"diagnostic":result.diagnostic}

def quantum_core_readiness():
    circuit=QuantumCircuit("q",(2),(("X",(0,)),("CX",(0,1)),("MEASURE",(0,)),("MEASURE",(1,))),"SIMULATION: qualification")
    req=QuantumJobRequest("j","joe.basis-simulator",circuit,32,"SIMULATION: qualification")
    result=execute_basis_simulation(req)
    bs=(builtin_basis_backend(),)+discover_quantum_backends()
    g=quantum_guardian_contract(bs)
    return {"passed":result.status==QuantumJobStatus.SUCCEEDED and result.counts=={"11":32} and
                     not g.facts["physical_qpu_available"] and g.authority=="READ_ONLY_ADVISORY",
            "checks":("typed circuit contract","governed shot count","JOE exact basis simulator",
                      "installed SDK discovery","physical-QPU no-assumption gate","quantum job provenance","Guardian contract")}

class QuantumProviderAdapter:
    adapter_id="abstract"
    def qualification(self):raise NotImplementedError
    def execute(self,request):raise NotImplementedError

class QiskitSimulatorAdapter(QuantumProviderAdapter):
    adapter_id="qiskit.local"
    def qualification(self):
        try:
            import qiskit
            try:
                import qiskit_aer
                return {"available":True,"provider":"Qiskit Aer","version":getattr(qiskit,"__version__","unknown"),
                        "capabilities":("H","X","CX","MEASURE","shots"),"provenance":"SOFTWARE: qiskit + qiskit_aer imports"}
            except Exception as exc:return {"available":False,"provider":"Qiskit","diagnostic":"qiskit_aer unavailable: "+str(exc),"provenance":"SOFTWARE: qiskit import"}
        except Exception as exc:return {"available":False,"provider":"Qiskit","diagnostic":str(exc),"provenance":"SOFTWARE: import attempt"}
    def execute(self,request):
        q=self.qualification()
        if not q["available"]:return QuantumJobResult(request.job_id,request.backend_id,QuantumJobStatus.REJECTED,{},None,time.time(),request.provenance,q.get("diagnostic","unavailable"))
        start=time.time()
        try:
            from qiskit import QuantumCircuit as QC
            from qiskit_aer import AerSimulator
            qc=QC(request.circuit.qubit_count,request.circuit.qubit_count)
            for op,qs in request.circuit.operations:
                if op=="H":qc.h(qs[0])
                elif op=="X":qc.x(qs[0])
                elif op=="CX":qc.cx(qs[0],qs[1])
                elif op=="MEASURE":qc.measure(qs[0],qs[0])
            counts={str(k).replace(" ",""):int(v) for k,v in AerSimulator().run(qc,shots=request.shots).result().get_counts().items()}
            return QuantumJobResult(request.job_id,request.backend_id,QuantumJobStatus.SUCCEEDED,counts,start,time.time(),request.provenance)
        except Exception as exc:return QuantumJobResult(request.job_id,request.backend_id,QuantumJobStatus.FAILED,{},start,time.time(),request.provenance,f"{type(exc).__name__}: {exc}")

class CirqSimulatorAdapter(QuantumProviderAdapter):
    adapter_id="cirq.local"
    def qualification(self):
        try:
            import cirq
            return {"available":True,"provider":"Cirq","version":getattr(cirq,"__version__","unknown"),
                    "capabilities":("H","X","CX","MEASURE","shots"),"provenance":"SOFTWARE: cirq import"}
        except Exception as exc:return {"available":False,"provider":"Cirq","diagnostic":str(exc),"provenance":"SOFTWARE: import attempt"}
    def execute(self,request):
        q=self.qualification()
        if not q["available"]:return QuantumJobResult(request.job_id,request.backend_id,QuantumJobStatus.REJECTED,{},None,time.time(),request.provenance,q.get("diagnostic","unavailable"))
        start=time.time()
        try:
            import cirq
            qs=cirq.LineQubit.range(request.circuit.qubit_count);ops=[];measured=[]
            for op,ix in request.circuit.operations:
                if op=="H":ops.append(cirq.H(qs[ix[0]]))
                elif op=="X":ops.append(cirq.X(qs[ix[0]]))
                elif op=="CX":ops.append(cirq.CNOT(qs[ix[0]],qs[ix[1]]))
                elif op=="MEASURE":measured.append(ix[0])
            ops.append(cirq.measure(*[qs[i] for i in measured],key="m"))
            hist=cirq.Simulator().run(cirq.Circuit(ops),repetitions=request.shots).histogram(key="m")
            counts={format(int(k),f"0{len(measured)}b"):int(v) for k,v in hist.items()}
            return QuantumJobResult(request.job_id,request.backend_id,QuantumJobStatus.SUCCEEDED,counts,start,time.time(),request.provenance)
        except Exception as exc:return QuantumJobResult(request.job_id,request.backend_id,QuantumJobStatus.FAILED,{},start,time.time(),request.provenance,f"{type(exc).__name__}: {exc}")

def qualified_simulator_adapters():return (QiskitSimulatorAdapter(),CirqSimulatorAdapter())

@dataclass(frozen=True)
class QuantumHistoryEntry:
    sequence:int;job_id:str;backend_id:str;status:str;circuit_id:str;shots:int;run_id:str|None;provenance:str;diagnostic:str

class QuantumJobHistory:
    def __init__(self):self._entries=[]
    def append(self,request,result):
        if any(x.job_id==request.job_id for x in self._entries):raise ValueError("quantum history is append-only by job identity")
        e=QuantumHistoryEntry(len(self._entries)+1,request.job_id,result.backend_id,result.status.value,request.circuit.circuit_id,request.shots,request.run_id,request.provenance,result.diagnostic)
        self._entries.append(e);return e
    def entries(self):return tuple(self._entries)
    def by_run(self,run_id):return tuple(x for x in self._entries if x.run_id==run_id)

class QuantumRuntimeManager:
    def __init__(self):self.history=QuantumJobHistory();self.adapters={a.adapter_id:a for a in qualified_simulator_adapters()}
    def qualifications(self):return {k:a.qualification() for k,a in self.adapters.items()}
    def execute(self,request):
        if request.backend_id=="joe.basis-simulator":result=execute_basis_simulation(request)
        elif request.backend_id in self.adapters:result=self.adapters[request.backend_id].execute(request)
        else:result=QuantumJobResult(request.job_id,request.backend_id,QuantumJobStatus.REJECTED,{},None,time.time(),request.provenance,"no qualified local simulator adapter bound; physical QPU execution is not authorized")
        self.history.append(request,result);return result

def bell_circuit(circuit_id="bell",provenance="SIMULATION: generated Bell-state circuit"):
    return QuantumCircuit(circuit_id,2,(("H",(0,)),("CX",(0,1)),("MEASURE",(0,)),("MEASURE",(1,))),provenance)

def quantum_provider_readiness():
    manager=QuantumRuntimeManager();checks=["provider isolation","append-only quantum job history","Bell-circuit contract"];failures=[]
    for aid,q in manager.qualifications().items():
        if q["available"]:
            r=manager.execute(QuantumJobRequest("qual-"+aid,aid,bell_circuit("bell-"+aid),64,"SIMULATION: provider qualification"))
            if r.status!=QuantumJobStatus.SUCCEEDED:failures.append(aid+" claimed available but execution failed: "+r.diagnostic)
            elif sum(r.counts.values())!=64:failures.append(aid+" shot accounting mismatch")
            else:checks.append(aid+" execution qualified")
        else:checks.append(aid+" explicitly unavailable")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),
            "notes":("Local simulator qualification does not establish physical-QPU access.","Physical credentials/devices remain outside QPU-001B.","Simulation counts are software results, not physical measurements.")}


class RemoteQuantumJobState(str,Enum):
    CREATED="CREATED"
    SUBMITTED="SUBMITTED"
    QUEUED="QUEUED"
    RUNNING="RUNNING"
    COMPLETED="COMPLETED"
    FAILED="FAILED"
    CANCELLED="CANCELLED"
    UNKNOWN="UNKNOWN"

@dataclass(frozen=True)
class PhysicalProviderCapability:
    provider_id:str
    backend_id:str
    qubit_count:int
    supported_operations:tuple[str,...]
    maximum_shots:int
    authenticated:bool
    device_available:bool
    provenance:str
    diagnostic:str=""
    def __post_init__(self):
        if not self.provider_id.strip() or not self.backend_id.strip() or not self.provenance.strip():
            raise ValueError("physical provider identity/backend/provenance required")
        if self.qubit_count<1 or self.maximum_shots<1:raise ValueError("physical capability limits must be positive")

@dataclass(frozen=True)
class PhysicalProviderBinding:
    provider_id:str
    adapter_id:str
    account_reference:str
    credential_source:str
    provenance:str
    def __post_init__(self):
        if not all(x.strip() for x in (self.provider_id,self.adapter_id,self.account_reference,self.credential_source,self.provenance)):
            raise ValueError("complete physical provider binding required")
        forbidden=("token","password","secret","api_key","apikey")
        if any(x in self.account_reference.lower() for x in forbidden):
            raise ValueError("account_reference must not contain credential material")

@dataclass(frozen=True)
class RemoteQuantumJob:
    local_job_id:str
    provider_job_id:str
    provider_id:str
    backend_id:str
    state:RemoteQuantumJobState
    submitted_at_s:float
    updated_at_s:float
    provenance:str
    diagnostic:str=""

class PhysicalQuantumProviderAdapter:
    """Contract only. Implementations must keep credentials outside JOE records."""
    adapter_id="physical.abstract"
    def capability(self,binding:PhysicalProviderBinding)->PhysicalProviderCapability:raise NotImplementedError
    def submit(self,binding:PhysicalProviderBinding,request:QuantumJobRequest)->RemoteQuantumJob:raise NotImplementedError
    def poll(self,binding:PhysicalProviderBinding,job:RemoteQuantumJob)->RemoteQuantumJob:raise NotImplementedError
    def cancel(self,binding:PhysicalProviderBinding,job:RemoteQuantumJob)->RemoteQuantumJob:raise NotImplementedError
    def result(self,binding:PhysicalProviderBinding,job:RemoteQuantumJob)->QuantumJobResult:raise NotImplementedError

def validate_physical_request(request:QuantumJobRequest,cap:PhysicalProviderCapability)->tuple[str,...]:
    failures=[]
    if not cap.authenticated:failures.append("provider authentication not established")
    if not cap.device_available:failures.append("physical backend not reported available")
    if request.backend_id!=cap.backend_id:failures.append("request backend does not match qualified physical backend")
    if request.circuit.qubit_count>cap.qubit_count:failures.append("circuit exceeds physical qubit count")
    if request.shots>cap.maximum_shots:failures.append("shots exceed provider/backend limit")
    supported=set(cap.supported_operations)
    missing=sorted({op for op,_ in request.circuit.operations}-supported)
    if missing:failures.append("unsupported physical operations: "+", ".join(missing))
    return tuple(failures)

@dataclass(frozen=True)
class QuantumResultIntegrity:
    schema:str
    job_id:str
    backend_id:str
    shots_requested:int
    shots_accounted:int
    counts_sha256:str
    valid:bool
    failures:tuple[str,...]
    provenance:str

def verify_quantum_result(request:QuantumJobRequest,result:QuantumJobResult)->QuantumResultIntegrity:
    failures=[]
    if result.job_id!=request.job_id:failures.append("job identity mismatch")
    if result.backend_id!=request.backend_id:failures.append("backend identity mismatch")
    if result.status==QuantumJobStatus.SUCCEEDED:
        if any((not isinstance(k,str) or not isinstance(v,int) or v<0) for k,v in result.counts.items()):
            failures.append("invalid counts structure")
        accounted=sum(v for v in result.counts.values() if isinstance(v,int) and v>=0)
        if accounted!=request.shots:failures.append("shot accounting mismatch")
    else:accounted=sum(v for v in result.counts.values() if isinstance(v,int) and v>=0)
    payload=json.dumps(result.counts,sort_keys=True,separators=(",",":")).encode()
    return QuantumResultIntegrity("JOE-QUANTUM-RESULT-INTEGRITY/1",request.job_id,request.backend_id,request.shots,
                                  accounted,hashlib.sha256(payload).hexdigest(),not failures,tuple(failures),
                                  "JOE quantum result integrity verification")

class PhysicalQuantumRuntime:
    """Credential-safe physical-provider boundary. No adapter means no physical execution."""
    def __init__(self):
        self._adapters={}
        self._bindings={}
        self._remote_jobs={}
    def register_adapter(self,adapter:PhysicalQuantumProviderAdapter):
        if not adapter.adapter_id or adapter.adapter_id=="physical.abstract":raise ValueError("concrete physical adapter id required")
        if adapter.adapter_id in self._adapters:raise ValueError("duplicate physical adapter")
        self._adapters[adapter.adapter_id]=adapter
    def bind(self,binding:PhysicalProviderBinding):
        if binding.adapter_id not in self._adapters:raise ValueError("physical adapter is not registered")
        self._bindings[binding.provider_id]=binding
    def capability(self,provider_id):
        b=self._bindings.get(provider_id)
        if b is None:raise ValueError("provider is not bound")
        return self._adapters[b.adapter_id].capability(b)
    def submit(self,provider_id,request):
        b=self._bindings.get(provider_id)
        if b is None:raise ValueError("provider is not bound")
        a=self._adapters[b.adapter_id];cap=a.capability(b);failures=validate_physical_request(request,cap)
        if failures:raise ValueError("; ".join(failures))
        job=a.submit(b,request)
        if job.local_job_id!=request.job_id or job.provider_id!=provider_id or job.backend_id!=request.backend_id:
            raise ValueError("provider returned inconsistent remote-job identity")
        self._remote_jobs[request.job_id]=job;return job
    def poll(self,local_job_id):
        job=self._remote_jobs[local_job_id];b=self._bindings[job.provider_id]
        updated=self._adapters[b.adapter_id].poll(b,job)
        if updated.local_job_id!=job.local_job_id or updated.provider_job_id!=job.provider_job_id:
            raise ValueError("provider changed remote-job identity")
        self._remote_jobs[local_job_id]=updated;return updated
    def cancel(self,local_job_id):
        job=self._remote_jobs[local_job_id];b=self._bindings[job.provider_id]
        updated=self._adapters[b.adapter_id].cancel(b,job);self._remote_jobs[local_job_id]=updated;return updated
    def result(self,local_job_id,request):
        job=self._remote_jobs[local_job_id]
        if job.state!=RemoteQuantumJobState.COMPLETED:raise ValueError("remote job is not completed")
        b=self._bindings[job.provider_id];result=self._adapters[b.adapter_id].result(b,job)
        integrity=verify_quantum_result(request,result)
        if not integrity.valid:raise ValueError("physical quantum result integrity failure: "+"; ".join(integrity.failures))
        return result,integrity

def quantum_v1_release_readiness():
    failures=[];checks=[]
    for name,fn in (("quantum core",quantum_core_readiness),("local providers",quantum_provider_readiness)):
        try:
            q=fn()
            if q["passed"]:checks.append(name+" passed")
            else:failures.extend(q.get("failures",()) or (name+" failed",))
        except Exception as exc:failures.append(f"{name}: {type(exc).__name__}: {exc}")
    try:
        c=QuantumCircuit("c",1,(("X",(0,)),("MEASURE",(0,))),"SIMULATION:qualification")
        q=QuantumJobRequest("j","physical.test",c,8,"SIMULATION:qualification")
        cap=PhysicalProviderCapability("p","physical.test",1,("X","MEASURE"),8,False,False,"SIMULATION:qualification")
        if validate_physical_request(q,cap):checks.append("unauthenticated/unavailable physical provider rejection passed")
        r=QuantumJobResult("j","physical.test",QuantumJobStatus.SUCCEEDED,{"1":8},1,2,"SIMULATION:qualification")
        if verify_quantum_result(q,r).valid:checks.append("quantum result integrity passed")
        runtime=PhysicalQuantumRuntime()
        try:runtime.submit("unbound",q)
        except ValueError:checks.append("unbound physical provider rejection passed")
    except Exception as exc:failures.append(f"physical boundary: {type(exc).__name__}: {exc}")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),
            "notes":("Physical QPU execution requires a separately implemented, registered and authenticated provider adapter.",
                     "Credential material is not stored in JOE provider bindings or job provenance.",
                     "QPU remains optional/narrow research compute and has no control or BUS-SAFE authority.")}
