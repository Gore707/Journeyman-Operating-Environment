"""JOE Scientific Data Stream Engine.

This is an in-process scientific sample transport with explicit provenance,
typed stream definitions, monotonic per-stream sequence numbers, bounded
history, and subscriber-failure isolation. It is not a deterministic real-time
bus and does not synthesize measurements.
"""
from __future__ import annotations

from dataclasses import dataclass
from threading import RLock
from time import time
from typing import Any, Callable, Iterable
import math
import re

from .state_events import DataOrigin

_STREAM_ID = re.compile(r"^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$")


def _stream_id(value: str) -> str:
    result=str(value).strip()
    if not _STREAM_ID.fullmatch(result):
        raise ValueError(f"Invalid stream id: {value}")
    return result


@dataclass(frozen=True)
class StreamDefinition:
    stream_id: str
    name: str
    unit: str
    value_type: type | tuple[type, ...]
    origin: DataOrigin
    source: str
    description: str = ""


@dataclass(frozen=True)
class StreamSample:
    stream_id: str
    sequence: int
    timestamp: float
    value: Any
    origin: DataOrigin
    source: str
    metadata: tuple[tuple[str, str], ...] = ()
    frame_id: int | None = None


@dataclass(frozen=True)
class StreamCallbackFailure:
    sequence: int
    stream_id: str
    callback_name: str
    error: str


@dataclass(frozen=True)
class StreamFrame:
    frame_id: int
    timestamp: float
    source: str
    samples: tuple[StreamSample, ...]


@dataclass(frozen=True)
class StreamEngineStatus:
    registered_streams: int
    streams_with_samples: int
    retained_samples: int
    callback_failures: int
    latest_timestamp: float | None
    origins: tuple[tuple[str, int], ...]


@dataclass(frozen=True)
class StreamEngineQualification:
    passed: bool
    failures: tuple[str, ...]
    status: StreamEngineStatus


@dataclass(frozen=True)
class StreamRead:
    stream_id: str
    samples: tuple[StreamSample, ...]
    next_sequence: int
    gap_detected: bool
    oldest_available_sequence: int | None
    newest_available_sequence: int | None


@dataclass(frozen=True)
class StreamEngineReleaseReadiness:
    passed: bool
    failures: tuple[str, ...]
    live_qualification: StreamEngineQualification
    exercise_samples: int
    exercise_frames: int


class ScientificDataStreamEngine:
    """Thread-safe bounded scientific stream transport for JOE."""
    def __init__(self, history_limit_per_stream: int = 10000,
                 failure_limit: int = 500) -> None:
        if not isinstance(history_limit_per_stream,int) or isinstance(history_limit_per_stream,bool) or history_limit_per_stream < 1:
            raise ValueError("history_limit_per_stream must be a positive integer")
        if not isinstance(failure_limit,int) or isinstance(failure_limit,bool) or failure_limit < 1:
            raise ValueError("failure_limit must be a positive integer")
        self._history_limit=history_limit_per_stream
        self._failure_limit=failure_limit
        self._definitions: dict[str,StreamDefinition]={}
        self._history: dict[str,list[StreamSample]]={}
        self._subscribers: dict[str,list[Callable[[StreamSample],None]]]={}
        self._frame_subscribers: list[Callable[[StreamFrame],None]]=[]
        self._sequences: dict[str,int]={}
        self._failures: list[StreamCallbackFailure]=[]
        self._failure_sequence=0
        self._frame_sequence=0
        self._lock=RLock()

    def register(self, stream_id: str, name: str, unit: str,
                 value_type: type | tuple[type,...],
                 origin: DataOrigin | str, source: str,
                 description: str="") -> StreamDefinition:
        sid=_stream_id(stream_id)
        source=_stream_id(source)
        name=str(name).strip()
        unit=str(unit).strip()
        description=str(description).strip()
        if not name:
            raise ValueError("Stream name cannot be empty")
        types=value_type if isinstance(value_type,tuple) else (value_type,)
        if not types or not all(isinstance(item,type) for item in types):
            raise TypeError("value_type must be a type or non-empty tuple of types")
        try:
            data_origin=origin if isinstance(origin,DataOrigin) else DataOrigin(str(origin).upper())
        except ValueError as exc:
            raise ValueError(f"Invalid data origin: {origin}") from exc
        definition=StreamDefinition(sid,name,unit,value_type,data_origin,source,description)
        with self._lock:
            if sid in self._definitions:
                raise ValueError(f"Stream already registered: {sid}")
            self._definitions[sid]=definition
            self._history[sid]=[]
            self._subscribers[sid]=[]
            self._sequences[sid]=0
        return definition

    def definition(self, stream_id: str) -> StreamDefinition:
        sid=_stream_id(stream_id)
        with self._lock:
            if sid not in self._definitions:
                raise KeyError(sid)
            return self._definitions[sid]

    def definitions(self) -> tuple[StreamDefinition,...]:
        with self._lock:
            return tuple(self._definitions[key] for key in sorted(self._definitions))

    def publish(self, stream_id: str, value: Any, *,
                source: str, timestamp: float | None=None,
                origin: DataOrigin | str | None=None,
                metadata: dict[str,Any] | None=None,
                frame_id: int | None=None) -> StreamSample:
        sid=_stream_id(stream_id)
        source=_stream_id(source)
        with self._lock:
            if sid not in self._definitions:
                raise KeyError(sid)
            definition=self._definitions[sid]
            if source != definition.source:
                raise PermissionError(
                    f"Stream publish denied for {source}: {sid} is sourced by {definition.source}"
                )
            if not isinstance(value,definition.value_type):
                expected=definition.value_type
                if isinstance(expected,tuple):
                    label=" or ".join(item.__name__ for item in expected)
                else:
                    label=expected.__name__
                raise TypeError(f"Invalid value for {sid}: expected {label}, got {type(value).__name__}")
            data_origin=definition.origin if origin is None else (
                origin if isinstance(origin,DataOrigin) else DataOrigin(str(origin).upper())
            )
            if data_origin != definition.origin:
                raise ValueError(
                    f"Origin mismatch for {sid}: registered {definition.origin.value}, got {data_origin.value}"
                )
            stamp=time() if timestamp is None else float(timestamp)
            if not math.isfinite(stamp) or stamp <= 0:
                raise ValueError("timestamp must be a finite positive number")
            previous=self._history[sid][-1] if self._history[sid] else None
            if previous is not None and stamp < previous.timestamp:
                raise ValueError("stream timestamps cannot move backward")
            pairs=()
            if metadata:
                pairs=tuple(sorted((str(k),str(v)) for k,v in metadata.items()))
            sequence=self._sequences[sid]+1
            self._sequences[sid]=sequence
            sample=StreamSample(sid,sequence,stamp,value,data_origin,source,pairs,frame_id)
            history=self._history[sid]
            history.append(sample)
            if len(history)>self._history_limit:
                del history[:-self._history_limit]
            subscribers=tuple(self._subscribers[sid])
        for callback in subscribers:
            self._invoke_callback(sid,callback,sample)
        return sample

    def publish_frame(self, values: dict[str,Any], *, source: str,
                      timestamp: float | None=None,
                      metadata: dict[str,Any] | None=None) -> tuple[StreamSample,...]:
        """Validate and commit a coherent multi-stream frame atomically.

        Histories and sequence counters are mutated under one lock only after
        every channel has passed validation. Subscriber callbacks run after the
        commit so slow/failing consumers cannot hold the stream-engine lock.
        """
        if not isinstance(values,dict) or not values:
            raise ValueError("values must be a non-empty mapping")
        source=_stream_id(source)
        stamp=time() if timestamp is None else float(timestamp)
        if not math.isfinite(stamp) or stamp <= 0:
            raise ValueError("timestamp must be a finite positive number")
        pairs=()
        if metadata:
            pairs=tuple(sorted((str(k),str(v)) for k,v in metadata.items()))

        with self._lock:
            validated=[]
            for stream_id,value in values.items():
                sid=_stream_id(stream_id)
                if sid not in self._definitions:
                    raise KeyError(sid)
                definition=self._definitions[sid]
                if source != definition.source:
                    raise PermissionError(
                        f"Stream publish denied for {source}: {sid} is sourced by {definition.source}"
                    )
                if not isinstance(value,definition.value_type):
                    raise TypeError(
                        f"Invalid value for {sid}: got {type(value).__name__}"
                    )
                previous=self._history[sid][-1] if self._history[sid] else None
                if previous is not None and stamp < previous.timestamp:
                    raise ValueError(f"stream timestamps cannot move backward: {sid}")
                validated.append((sid,value,definition))

            self._frame_sequence += 1
            frame_id=self._frame_sequence
            samples=[]
            callbacks=[]
            for sid,value,definition in validated:
                sequence=self._sequences[sid]+1
                self._sequences[sid]=sequence
                sample=StreamSample(
                    sid,sequence,stamp,value,definition.origin,source,pairs,frame_id
                )
                history=self._history[sid]
                history.append(sample)
                if len(history)>self._history_limit:
                    del history[:-self._history_limit]
                samples.append(sample)
                callbacks.append((sample,tuple(self._subscribers[sid])))
            frame=StreamFrame(frame_id,stamp,source,tuple(samples))
            frame_callbacks=tuple(self._frame_subscribers)

        for sample,subscribers in callbacks:
            for callback in subscribers:
                self._invoke_callback(sample.stream_id,callback,sample)
        for callback in frame_callbacks:
            self._invoke_callback("<frame>",callback,frame)
        return tuple(samples)

    def subscribe_frames(self, callback: Callable[[StreamFrame],None]) -> None:
        if not callable(callback):
            raise TypeError("frame subscriber must be callable")
        with self._lock:
            if callback not in self._frame_subscribers:
                self._frame_subscribers.append(callback)

    def unsubscribe_frames(self, callback: Callable[[StreamFrame],None]) -> None:
        with self._lock:
            if callback in self._frame_subscribers:
                self._frame_subscribers.remove(callback)

    def _invoke_callback(self, stream_id: str, callback: Callable, payload: Any) -> None:
        try:
            callback(payload)
        except Exception as exc:
            with self._lock:
                self._failure_sequence+=1
                self._failures.append(StreamCallbackFailure(
                    self._failure_sequence,stream_id,
                    getattr(callback,"__qualname__",getattr(callback,"__name__",repr(callback))),
                    f"{type(exc).__name__}: {exc}",
                ))
                if len(self._failures)>self._failure_limit:
                    del self._failures[:-self._failure_limit]

    def latest(self, stream_id: str) -> StreamSample | None:
        sid=_stream_id(stream_id)
        with self._lock:
            if sid not in self._definitions:
                raise KeyError(sid)
            history=self._history[sid]
            return history[-1] if history else None

    def history(self, stream_id: str, limit: int | None=None) -> tuple[StreamSample,...]:
        sid=_stream_id(stream_id)
        if limit is not None and (not isinstance(limit,int) or isinstance(limit,bool) or limit < 1):
            raise ValueError("limit must be a positive integer")
        with self._lock:
            if sid not in self._definitions:
                raise KeyError(sid)
            values=self._history[sid]
            return tuple(values if limit is None else values[-limit:])

    def read_since(self, stream_id: str, after_sequence: int=0,
                   limit: int | None=None) -> StreamRead:
        """Read retained samples after a per-stream sequence cursor.

        A consumer can detect when bounded retention has discarded samples it
        had not yet read. This is essential for honest live visualization and
        recording: a lagging consumer is told that a gap exists rather than
        being handed a deceptively continuous series.
        """
        sid=_stream_id(stream_id)
        if not isinstance(after_sequence,int) or isinstance(after_sequence,bool) or after_sequence < 0:
            raise ValueError("after_sequence must be a non-negative integer")
        if limit is not None and (not isinstance(limit,int) or isinstance(limit,bool) or limit < 1):
            raise ValueError("limit must be a positive integer")
        with self._lock:
            if sid not in self._definitions:
                raise KeyError(sid)
            history=tuple(self._history[sid])
            newest_published=self._sequences[sid]
        oldest=history[0].sequence if history else None
        newest=history[-1].sequence if history else None
        gap=bool(oldest is not None and after_sequence + 1 < oldest)
        samples=tuple(sample for sample in history if sample.sequence > after_sequence)
        if limit is not None:
            samples=samples[:limit]
        next_sequence=samples[-1].sequence if samples else after_sequence
        # If the cursor is beyond the current sequence, preserve caller cursor;
        # publication sequence itself never moves backward.
        return StreamRead(sid,samples,next_sequence,gap,oldest,newest)

    def subscribe(self, stream_id: str, callback: Callable[[StreamSample],None]) -> None:
        sid=_stream_id(stream_id)
        if not callable(callback):
            raise TypeError("stream subscriber must be callable")
        with self._lock:
            if sid not in self._definitions:
                raise KeyError(sid)
            if callback not in self._subscribers[sid]:
                self._subscribers[sid].append(callback)

    def unsubscribe(self, stream_id: str, callback: Callable[[StreamSample],None]) -> None:
        sid=_stream_id(stream_id)
        with self._lock:
            if sid not in self._definitions:
                raise KeyError(sid)
            if callback in self._subscribers[sid]:
                self._subscribers[sid].remove(callback)

    def status(self) -> StreamEngineStatus:
        with self._lock:
            definitions=tuple(self._definitions.values())
            histories=tuple(tuple(items) for items in self._history.values())
            failures=len(self._failures)
        retained=sum(len(items) for items in histories)
        streams_with_samples=sum(1 for items in histories if items)
        timestamps=[items[-1].timestamp for items in histories if items]
        counts={}
        for definition in definitions:
            counts[definition.origin.value]=counts.get(definition.origin.value,0)+1
        return StreamEngineStatus(
            registered_streams=len(definitions),
            streams_with_samples=streams_with_samples,
            retained_samples=retained,
            callback_failures=failures,
            latest_timestamp=max(timestamps) if timestamps else None,
            origins=tuple(sorted(counts.items())),
        )

    def callback_failures(self) -> tuple[StreamCallbackFailure,...]:
        with self._lock:
            return tuple(self._failures)


def qualify_scientific_data_streams(engine: ScientificDataStreamEngine) -> StreamEngineQualification:
    failures: list[str]=[]
    try:
        definitions=engine.definitions()
        status=engine.status()
    except Exception as exc:
        return StreamEngineQualification(
            False,(f"Stream engine inspection failed: {type(exc).__name__}: {exc}",),
            StreamEngineStatus(0,0,0,0,None,()),
        )

    ids=[definition.stream_id for definition in definitions]
    if len(ids) != len(set(ids)):
        failures.append("Duplicate registered stream identities detected.")

    for definition in definitions:
        if not definition.name.strip():
            failures.append(f"{definition.stream_id}: empty human-readable name.")
        if not definition.source.strip():
            failures.append(f"{definition.stream_id}: empty authoritative source.")
        history=engine.history(definition.stream_id)
        last_sequence=0
        last_timestamp=None
        for sample in history:
            if sample.stream_id != definition.stream_id:
                failures.append(f"{definition.stream_id}: retained sample identity mismatch.")
            if sample.origin != definition.origin:
                failures.append(f"{definition.stream_id}: retained sample provenance mismatch.")
            if sample.source != definition.source:
                failures.append(f"{definition.stream_id}: retained sample source mismatch.")
            if sample.sequence <= last_sequence:
                failures.append(f"{definition.stream_id}: non-increasing retained sequence.")
            if last_timestamp is not None and sample.timestamp < last_timestamp:
                failures.append(f"{definition.stream_id}: backward retained timestamp.")
            last_sequence=sample.sequence
            last_timestamp=sample.timestamp

    return StreamEngineQualification(not failures,tuple(failures),status)


def joe008_release_readiness(engine: ScientificDataStreamEngine) -> StreamEngineReleaseReadiness:
    """Final code-level JOE-008 gate.

    The live engine is inspected non-destructively. Functional stress work is
    executed on an isolated temporary engine so qualification does not pollute
    live scientific histories.
    """
    live=qualify_scientific_data_streams(engine)
    failures=list(live.failures)
    exercise_samples=0
    exercise_frames=0
    isolated=ScientificDataStreamEngine(history_limit_per_stream=64)
    try:
        isolated.register("simulation.release.x","Release X","unit",float,
                          DataOrigin.SIMULATION,"qualification.engine")
        isolated.register("simulation.release.y","Release Y","unit",float,
                          DataOrigin.SIMULATION,"qualification.engine")
        frames=[]
        isolated.subscribe_frames(frames.append)
        for index in range(128):
            samples=isolated.publish_frame(
                {
                    "simulation.release.x":float(index),
                    "simulation.release.y":float(index*2),
                },
                source="qualification.engine",
                timestamp=1000.0 + index/1000.0,
                metadata={"purpose":"JOE-008 isolated release qualification"},
            )
            exercise_samples += len(samples)
            exercise_frames += 1

        if len(frames) != 128:
            failures.append(f"Isolated frame delivery mismatch: expected 128, got {len(frames)}.")
        if len(isolated.history("simulation.release.x")) != 64:
            failures.append("Bounded retention did not preserve configured 64-sample history.")
        read=isolated.read_since("simulation.release.x",after_sequence=1)
        if not read.gap_detected:
            failures.append("Retention-gap detection failed during isolated exercise.")
        if read.oldest_available_sequence != 65 or read.newest_available_sequence != 128:
            failures.append("Retention cursor bounds were incorrect during isolated exercise.")

        x_latest=isolated.latest("simulation.release.x")
        y_latest=isolated.latest("simulation.release.y")
        if x_latest is None or y_latest is None:
            failures.append("Isolated exercise did not retain latest samples.")
        elif x_latest.frame_id != y_latest.frame_id or x_latest.timestamp != y_latest.timestamp:
            failures.append("Coherent-frame identity/timestamp diverged during isolated exercise.")

        isolated_result=qualify_scientific_data_streams(isolated)
        if not isolated_result.passed:
            failures.extend(f"Isolated qualification: {item}" for item in isolated_result.failures)
    except Exception as exc:
        failures.append(f"Isolated functional exercise failed: {type(exc).__name__}: {exc}")

    return StreamEngineReleaseReadiness(
        not failures,tuple(failures),live,exercise_samples,exercise_frames
    )
