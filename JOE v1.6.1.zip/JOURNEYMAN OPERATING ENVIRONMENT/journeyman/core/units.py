"""JOE generalized SI units, dimensional analysis, and uncertainty envelopes."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Sequence
import math,re
import numpy as np

@dataclass(frozen=True)
class Dimension:
    length:int=0;mass:int=0;time:int=0;current:int=0;temperature:int=0;amount:int=0;luminous_intensity:int=0
    def signature(self):return (self.length,self.mass,self.time,self.current,self.temperature,self.amount,self.luminous_intensity)
    def __mul__(self,o):return Dimension(*(a+b for a,b in zip(self.signature(),o.signature())))
    def __truediv__(self,o):return Dimension(*(a-b for a,b in zip(self.signature(),o.signature())))
    def __pow__(self,n):return Dimension(*(a*int(n) for a in self.signature()))
DIMENSIONLESS=Dimension()
@dataclass(frozen=True)
class Unit:
    symbol:str;dimension:Dimension;scale_to_si:float=1.0;offset_to_si:float=0.0
    def to_si(self,v):return (float(v)+self.offset_to_si)*self.scale_to_si
    def from_si(self,v):return float(v)/self.scale_to_si-self.offset_to_si

_BASE={
"1":Unit("1",DIMENSIONLESS),"%":Unit("%",DIMENSIONLESS,.01),
"m":Unit("m",Dimension(length=1)),"km":Unit("km",Dimension(length=1),1e3),"cm":Unit("cm",Dimension(length=1),1e-2),"mm":Unit("mm",Dimension(length=1),1e-3),
"s":Unit("s",Dimension(time=1)),"ms":Unit("ms",Dimension(time=1),1e-3),"us":Unit("us",Dimension(time=1),1e-6),"ns":Unit("ns",Dimension(time=1),1e-9),
"kg":Unit("kg",Dimension(mass=1)),"g":Unit("g",Dimension(mass=1),1e-3),
"A":Unit("A",Dimension(current=1)),"K":Unit("K",Dimension(temperature=1)),"mol":Unit("mol",Dimension(amount=1)),"cd":Unit("cd",Dimension(luminous_intensity=1)),
"Hz":Unit("Hz",Dimension(time=-1)),"N":Unit("N",Dimension(length=1,mass=1,time=-2)),
"J":Unit("J",Dimension(length=2,mass=1,time=-2)),"W":Unit("W",Dimension(length=2,mass=1,time=-3)),
"Pa":Unit("Pa",Dimension(length=-1,mass=1,time=-2)),"C":Unit("C",Dimension(time=1,current=1)),
"V":Unit("V",Dimension(length=2,mass=1,time=-3,current=-1)),"T":Unit("T",Dimension(mass=1,time=-2,current=-1)),
"rad":Unit("rad",DIMENSIONLESS),"deg":Unit("deg",DIMENSIONLESS,math.pi/180),
}
_TOKEN=re.compile(r"([A-Za-z%]+)(?:\^(-?\d+))?$")
class UnitRegistry:
    def __init__(self):self._units=dict(_BASE)
    def symbols(self):return tuple(sorted(self._units))
    def register(self,unit:Unit):
        if not unit.symbol or unit.symbol in self._units:raise ValueError("unit symbol must be nonempty and unique")
        if not math.isfinite(unit.scale_to_si) or unit.scale_to_si<=0:raise ValueError("unit scale must be positive finite")
        self._units[unit.symbol]=unit
    def parse(self,expr:str)->Unit:
        expr=str(expr).strip()
        if expr=="":expr="1"
        if expr in self._units:return self._units[expr]
        dim=DIMENSIONLESS;scale=1.0
        parts=re.split(r"([*/])",expr.replace(" ",""));op="*"
        for part in parts:
            if not part:continue
            if part in ("*","/"):op=part;continue
            m=_TOKEN.fullmatch(part)
            if not m or m.group(1) not in self._units:raise ValueError(f"Unsupported unit expression: {expr!r}")
            u=self._units[m.group(1)];power=int(m.group(2) or 1)
            if u.offset_to_si:raise ValueError("offset units cannot be used in compound expressions")
            if op=="/":power=-power
            dim=dim*(u.dimension**power);scale*=u.scale_to_si**power
        return Unit(expr,dim,scale)
    def compatible(self,a,b):return self.parse(a).dimension==self.parse(b).dimension
    def convert(self,value,source,target):
        a=self.parse(source);b=self.parse(target)
        if a.dimension!=b.dimension:raise ValueError(f"Incompatible dimensions: {source} -> {target}")
        return b.from_si(a.to_si(value))
DEFAULT_UNITS=UnitRegistry()

@dataclass(frozen=True)
class UncertainValue:
    value:float;unit:str;standard_uncertainty:float=0.0;quality:str="VALID";provenance:str=""
    def __post_init__(self):
        if not math.isfinite(float(self.value)) or not math.isfinite(float(self.standard_uncertainty)) or self.standard_uncertainty<0:raise ValueError("value/uncertainty must be finite and uncertainty nonnegative")
        DEFAULT_UNITS.parse(self.unit)
    def converted(self,target):
        v=DEFAULT_UNITS.convert(self.value,self.unit,target)
        # uncertainty has no offset; scale via a difference.
        u=abs(DEFAULT_UNITS.convert(self.value+self.standard_uncertainty,self.unit,target)-v)
        return UncertainValue(v,target,u,self.quality,self.provenance)

@dataclass(frozen=True)
class VectorEstimate:
    values:tuple[float,...];unit:str;covariance:tuple[tuple[float,...],...];provenance:str=""
    def __post_init__(self):
        DEFAULT_UNITS.parse(self.unit);n=len(self.values)
        a=np.asarray(self.covariance,dtype=float)
        if n==0 or a.shape!=(n,n) or not np.all(np.isfinite(a)):raise ValueError("covariance must be finite NxN")
        if not np.allclose(a,a.T,rtol=0,atol=1e-12):raise ValueError("covariance must be symmetric")
        if np.min(np.linalg.eigvalsh(a)) < -1e-12:raise ValueError("covariance must be positive semidefinite")
    def standard_uncertainties(self):return tuple(float(math.sqrt(max(0,x))) for x in np.diag(np.asarray(self.covariance)))

def propagate_linear_covariance(jacobian:Sequence[Sequence[float]],covariance:Sequence[Sequence[float]]):
    j=np.asarray(jacobian,dtype=float);c=np.asarray(covariance,dtype=float)
    if j.ndim!=2 or c.ndim!=2 or c.shape[0]!=c.shape[1] or j.shape[1]!=c.shape[0]:raise ValueError("incompatible Jacobian/covariance shapes")
    out=j@c@j.T
    return tuple(tuple(float(x) for x in row) for row in out)

@dataclass(frozen=True)
class UnitsGuardianContract:
    schema:str;registered_units:int;capabilities:tuple[str,...];authority:str
def units_guardian_contract():
    return UnitsGuardianContract("JOE-GUARDIAN-UNITS/1",len(DEFAULT_UNITS.symbols()),
        ("DIMENSION_CHECK","UNIT_CONVERSION","STANDARD_UNCERTAINTY","COVARIANCE_VALIDATION","LINEAR_COVARIANCE_PROPAGATION"),
        "READ_ONLY_ADVISORY; cannot reinterpret stored units silently")
