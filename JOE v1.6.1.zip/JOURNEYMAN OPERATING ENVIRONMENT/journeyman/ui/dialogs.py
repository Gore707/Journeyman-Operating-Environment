from pathlib import Path
from PySide6.QtCore import Qt, qVersion
import PySide6
from PySide6.QtWidgets import (
    QCheckBox, QDialog, QDialogButtonBox, QFormLayout, QLabel, QPlainTextEdit,
    QPushButton, QSpinBox, QTextBrowser, QVBoxLayout
)
from journeyman import __build__, __version__
from journeyman.core.paths import DATA_DIR, LOG_DIR, ROOT
from journeyman.core.system_info import static_system_info
from journeyman.core.startup_checks import run_startup_checks
from .manual import MANUAL_HTML

class ManualDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("JOE User Manual")
        self.resize(820, 680)
        view = QTextBrowser(self)
        view.setHtml(MANUAL_HTML)
        close = QDialogButtonBox(QDialogButtonBox.Close, parent=self)
        close.rejected.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.addWidget(view)
        layout.addWidget(close)

class SettingsDialog(QDialog):
    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.setWindowTitle("JOE Settings")
        self.interval = QSpinBox(self)
        self.interval.setRange(250, 10000)
        self.interval.setSingleStep(250)
        self.interval.setSuffix(" ms")
        self.interval.setValue(settings.telemetry_interval_ms)
        self.confirm_exit = QCheckBox("Confirm before exiting JOE", self)
        self.confirm_exit.setChecked(settings.confirm_exit)
        form = QFormLayout()
        form.addRow("System status refresh:", self.interval)
        form.addRow("", self.confirm_exit)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel, parent=self)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(buttons)

class SystemInfoDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("JOE System Information")
        self.resize(680, 430)
        form = QFormLayout()
        form.addRow("JOE build", QLabel(__build__))
        form.addRow("JOE version", QLabel(__version__))
        info = static_system_info()
        info["Qt"] = qVersion()
        info["PySide"] = PySide6.__version__
        for key, value in info.items():
            label = QLabel(value)
            label.setTextInteractionFlags(label.textInteractionFlags() | Qt.TextSelectableByMouse)
            form.addRow(key, label)
        form.addRow("Project root", QLabel(str(ROOT)))
        form.addRow("Data directory", QLabel(str(DATA_DIR)))
        form.addRow("Log directory", QLabel(str(LOG_DIR)))
        close = QDialogButtonBox(QDialogButtonBox.Close, parent=self)
        close.rejected.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addStretch()
        layout.addWidget(close)

class LogViewerDialog(QDialog):
    def __init__(self, log_file: Path, parent=None):
        super().__init__(parent)
        self.log_file = log_file
        self.setWindowTitle("JOE Log Viewer")
        self.resize(900, 600)
        self.view = QPlainTextEdit(self)
        self.view.setReadOnly(True)
        self.view.setLineWrapMode(QPlainTextEdit.NoWrap)
        refresh = QPushButton("Refresh", self)
        refresh.clicked.connect(self.refresh)
        close = QDialogButtonBox(QDialogButtonBox.Close, parent=self)
        close.rejected.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.addWidget(self.view)
        layout.addWidget(refresh)
        layout.addWidget(close)
        self.refresh()

    def refresh(self):
        try:
            text = self.log_file.read_text(encoding="utf-8", errors="replace") if self.log_file.exists() else "No log has been created yet."
        except OSError as exc:
            text = f"Unable to read log: {exc}"
        self.view.setPlainText(text)
        cursor = self.view.textCursor()
        cursor.movePosition(cursor.End)
        self.view.setTextCursor(cursor)

class StartupDiagnosticsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("JOE Startup Diagnostics")
        self.resize(760, 480)
        self.view = QPlainTextEdit(self)
        self.view.setReadOnly(True)
        self.view.setLineWrapMode(QPlainTextEdit.NoWrap)
        rerun = QPushButton("Run Checks Again", self)
        rerun.clicked.connect(self.refresh)
        close = QDialogButtonBox(QDialogButtonBox.Close, parent=self)
        close.rejected.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.addWidget(self.view)
        layout.addWidget(rerun)
        layout.addWidget(close)
        self.refresh()

    def refresh(self):
        results = run_startup_checks()
        lines = ["JOURNEYMAN OPERATING ENVIRONMENT — STARTUP DIAGNOSTICS", ""]
        for item in results:
            lines.append(f"{'PASS' if item.ok else 'FAIL':4}  {item.name}: {item.detail}")
        lines += ["", "Overall: " + ("PASS" if all(x.ok for x in results) else "ATTENTION REQUIRED")]
        self.view.setPlainText("\n".join(lines))

class WorkspaceManagerDialog(QDialog):
    """Live manager for the workspaces that actually exist in this JOE process."""

    def __init__(self, main_window, parent=None):
        super().__init__(parent or main_window)
        from PySide6.QtWidgets import QHBoxLayout, QTableWidget, QTableWidgetItem, QAbstractItemView, QHeaderView, QInputDialog, QMessageBox
        self._QTableWidgetItem = QTableWidgetItem
        self._QInputDialog = QInputDialog
        self._QMessageBox = QMessageBox
        self.main_window = main_window
        self._rows = []
        self.setWindowTitle("JOE Workspace Manager")
        self.resize(920, 500)
        layout = QVBoxLayout(self)
        intro = QLabel("Manage the workspace windows currently owned by this JOE session.")
        layout.addWidget(intro)
        self.table = QTableWidget(0, 5, self)
        self.table.setHorizontalHeaderLabels(["Title", "Type", "Location", "State", "Workspace ID"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        self.table.doubleClicked.connect(self.focus_selected)
        layout.addWidget(self.table, 1)
        buttons = QHBoxLayout()
        for text, slot in (("Focus", self.focus_selected), ("Rename…", self.rename_selected), ("Detach / Reattach", self.toggle_location_selected), ("Close", self.close_selected), ("Refresh", self.refresh)):
            button = QPushButton(text, self); button.clicked.connect(slot); buttons.addWidget(button)
        buttons.addStretch(1)
        done = QPushButton("Close Manager", self); done.clicked.connect(self.accept); buttons.addWidget(done)
        layout.addLayout(buttons)
        self.refresh()

    def refresh(self):
        self._rows = self.main_window.workspace_records()
        self.table.setRowCount(len(self._rows))
        for row, record in enumerate(self._rows):
            values = (record["title"], record["kind"], record["location"], record["state"], record["workspace_id"])
            for column, value in enumerate(values):
                self.table.setItem(row, column, self._QTableWidgetItem(str(value)))
        if self._rows and self.table.currentRow() < 0:
            self.table.selectRow(0)

    def _selected(self):
        row = self.table.currentRow()
        return self._rows[row] if 0 <= row < len(self._rows) else None

    def focus_selected(self):
        record = self._selected()
        if record:
            self.main_window.focus_workspace_record(record)
            self.refresh()

    def rename_selected(self):
        record = self._selected()
        if not record:
            return
        title, ok = self._QInputDialog.getText(self, "Rename Workspace", "Workspace title:", text=record["title"])
        if not ok:
            return
        try:
            self.main_window.rename_workspace_record(record, title)
        except ValueError as exc:
            self._QMessageBox.warning(self, "Invalid Workspace Title", str(exc))
        self.refresh()

    def toggle_location_selected(self):
        record = self._selected()
        if not record:
            return
        self.main_window.toggle_workspace_record_location(record)
        self.refresh()

    def close_selected(self):
        record = self._selected()
        if record:
            self.main_window.close_workspace_record(record)
            self.refresh()
