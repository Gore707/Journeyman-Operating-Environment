"""RT / Control / BUS-SAFE — RTS-001A deterministic authority foundation."""
from __future__ import annotations
from dataclasses import dataclass,asdict
from enum import Enum
from typing import Any
import time

class AuthorityLevel(int,Enum):
    RESEARCH=10
    OPERATOR=20
    GUARDIAN=30
    RT_CONTROL=40
    BUS_SAFE=50

class ControlState(str,Enum):
    OFF="OFF"
    SAFE="SAFE"
    CALIBRATION="CALIBRATION"
    READY="READY"
    ARMED="ARMED"
    EXPERIMENT="EXPERIMENT"
    RECOVERY="RECOVERY"
    ABORT_TRIP="ABORT_TRIP"

class InterlockState(str,Enum):
    CLEAR="CLEAR"
    BLOCKED="BLOCKED"
    TRIPPED="TRIPPED"
    UNKNOWN="UNKNOWN"

@dataclass(frozen=True)
class AuthorityPrincipal:
    principal_id:str
    level:AuthorityLevel
    provenance:str
    def __post_init__(self):
        if not self.principal_id.strip() or not self.provenance.strip():raise ValueError("principal identity/provenance required")

@dataclass(frozen=True)
class Interlock:
    interlock_id:str
    state:InterlockState
    source:str
    reason:str
    timestamp_s:float
    provenance:str
    def __post_init__(self):
        if not self.interlock_id.strip() or not self.source.strip() or not self.provenance.strip():raise ValueError("interlock identity/source/provenance required")

@dataclass(frozen=True)
class TransitionRequest:
    request_id:str
    principal:AuthorityPrincipal
    target:ControlState
    reason:str
    timestamp_s:float
    provenance:str

@dataclass(frozen=True)
class TransitionDecision:
    request_id:str
    allowed:bool
    previous:ControlState
    target:ControlState
    reasons:tuple[str,...]
    authority:str
    timestamp_s:float
    provenance:str

_ALLOWED={
    ControlState.OFF:{ControlState.SAFE},
    ControlState.SAFE:{ControlState.OFF,ControlState.CALIBRATION,ControlState.READY},
    ControlState.CALIBRATION:{ControlState.SAFE,ControlState.READY},
    ControlState.READY:{ControlState.SAFE,ControlState.ARMED},
    ControlState.ARMED:{ControlState.SAFE,ControlState.EXPERIMENT},
    ControlState.EXPERIMENT:{ControlState.RECOVERY,ControlState.ABORT_TRIP},
    ControlState.RECOVERY:{ControlState.SAFE},
    ControlState.ABORT_TRIP:{ControlState.SAFE},
}

def authority_can_request(principal:AuthorityPrincipal,target:ControlState)->bool:
    if target==ControlState.ABORT_TRIP:return principal.level>=AuthorityLevel.RT_CONTROL
    if target in (ControlState.ARMED,ControlState.EXPERIMENT):return principal.level>=AuthorityLevel.OPERATOR
    return principal.level>=AuthorityLevel.OPERATOR

class DeterministicControlKernel:
    """Software qualification kernel. It is not a hardware BUS-SAFE implementation."""
    def __init__(self):
        self.state=ControlState.OFF
        self.interlocks={}
        self.sequence=0
        self.decisions=[]
    def set_interlock(self,interlock:Interlock):
        self.interlocks[interlock.interlock_id]=interlock
        if interlock.state==InterlockState.TRIPPED:
            self.state=ControlState.ABORT_TRIP
    def active_blocks(self):
        return tuple(x for x in self.interlocks.values() if x.state in (InterlockState.BLOCKED,InterlockState.TRIPPED,InterlockState.UNKNOWN))
    def request_transition(self,request:TransitionRequest)->TransitionDecision:
        reasons=[]
        if request.target not in _ALLOWED[self.state]:reasons.append("transition is not permitted by deterministic state graph")
        if not authority_can_request(request.principal,request.target):reasons.append("principal authority is insufficient")
        blocks=self.active_blocks()
        if request.target in (ControlState.READY,ControlState.ARMED,ControlState.EXPERIMENT) and blocks:
            reasons.append("one or more interlocks are not CLEAR")
        # Guardian can advise HOLD/ABORT, but cannot itself transition the deterministic kernel.
        if request.principal.level==AuthorityLevel.GUARDIAN:
            reasons.append("Guardian is advisory and cannot command deterministic control state")
        allowed=not reasons;previous=self.state
        if allowed:self.state=request.target
        self.sequence+=1
        d=TransitionDecision(request.request_id,allowed,previous,request.target,tuple(reasons),
                             "DETERMINISTIC_RT_CONTROL",time.time(),"SOFTWARE: JOE RTS-001A")
        self.decisions.append(d);return d
    def bus_safe_trip(self,reason:str,provenance="HARDWARE_INTERFACE: BUS-SAFE"):
        previous=self.state;self.state=ControlState.ABORT_TRIP;self.sequence+=1
        d=TransitionDecision("bus-safe-trip-"+str(self.sequence),True,previous,ControlState.ABORT_TRIP,(reason,),
                             "BUS_SAFE",time.time(),provenance);self.decisions.append(d);return d
    def reset_trip(self,principal:AuthorityPrincipal):
        req=TransitionRequest("reset-"+str(self.sequence+1),principal,ControlState.SAFE,"trip reset request",time.time(),principal.provenance)
        if principal.level<AuthorityLevel.BUS_SAFE:
            previous=self.state;self.sequence+=1
            d=TransitionDecision(req.request_id,False,previous,ControlState.SAFE,("only BUS-SAFE authority may reset an ABORT/TRIP state",),
                                 "BUS_SAFE",time.time(),"SOFTWARE: JOE RTS-001A");self.decisions.append(d);return d
        if any(x.state==InterlockState.TRIPPED for x in self.interlocks.values()):
            previous=self.state;self.sequence+=1
            d=TransitionDecision(req.request_id,False,previous,ControlState.SAFE,("a TRIPPED interlock remains active",),
                                 "BUS_SAFE",time.time(),"SOFTWARE: JOE RTS-001A");self.decisions.append(d);return d
        return self.request_transition(req)

@dataclass(frozen=True)
class RTSGuardianContract:
    schema:str
    status:str
    facts:dict[str,Any]
    provenance:str
    authority:str="READ_ONLY_ADVISORY"

def rt_guardian_contract(kernel:DeterministicControlKernel)->RTSGuardianContract:
    return RTSGuardianContract("JOE-GUARDIAN-RT-CONTROL/1","PASS",
        {"control_state":kernel.state.value,"active_interlocks":tuple(asdict(x) for x in kernel.active_blocks()),
         "authority_hierarchy":("BUS_SAFE","RT_CONTROL","GUARDIAN","OPERATOR_RESEARCH"),
         "guardian_can_command":False,"guardian_can_clear_trip":False,"bus_safe_final_authority":True},
        "RT / Control / BUS-SAFE RTS-001A")

def rt_core_readiness():
    k=DeterministicControlKernel()
    op=AuthorityPrincipal("operator",AuthorityLevel.OPERATOR,"SIMULATION: qualification")
    guardian=AuthorityPrincipal("guardian",AuthorityLevel.GUARDIAN,"SOFTWARE: Guardian")
    bus=AuthorityPrincipal("bus",AuthorityLevel.BUS_SAFE,"SIMULATION: BUS-SAFE qualification")
    a=k.request_transition(TransitionRequest("1",op,ControlState.SAFE,"qualify",time.time(),op.provenance))
    g=k.request_transition(TransitionRequest("2",guardian,ControlState.READY,"advise",time.time(),guardian.provenance))
    trip=k.bus_safe_trip("qualification trip","SIMULATION: BUS-SAFE qualification")
    denied=k.reset_trip(op)
    k.interlocks.clear();reset=k.reset_trip(bus)
    return {"passed":a.allowed and not g.allowed and trip.target==ControlState.ABORT_TRIP and not denied.allowed and reset.allowed,
            "checks":("deterministic state graph","authority hierarchy","Guardian command rejection","BUS-SAFE trip",
                      "BUS-SAFE-only trip reset","interlock gating","Guardian RT contract")}


class TimingDomain(str,Enum):
    SAFETY="SAFETY"
    CONTROL="CONTROL"
    RESEARCH="RESEARCH"

@dataclass(frozen=True)
class TimingBudget:
    domain:TimingDomain
    period_s:float
    deadline_s:float
    provenance:str
    def __post_init__(self):
        if self.period_s<=0 or self.deadline_s<=0:raise ValueError("timing values must be positive")
        if self.deadline_s>self.period_s:raise ValueError("deadline cannot exceed period")

def validate_timing_hierarchy(safety:TimingBudget,control:TimingBudget,research:TimingBudget):
    failures=[]
    if not safety.period_s < control.period_s < research.period_s:
        failures.append("required timing ordering tau_safe < tau_control < tau_research is violated")
    if safety.domain!=TimingDomain.SAFETY or control.domain!=TimingDomain.CONTROL or research.domain!=TimingDomain.RESEARCH:
        failures.append("timing budgets are assigned to incorrect domains")
    return tuple(failures)

class FreshnessState(str,Enum):
    FRESH="FRESH"
    STALE="STALE"
    MISSING="MISSING"
    INVALID="INVALID"

@dataclass(frozen=True)
class TelemetryEnvelope:
    source_id:str
    sequence:int
    timestamp_s:float|None
    received_at_s:float
    authenticated:bool
    provenance:str
    def __post_init__(self):
        if not self.source_id.strip() or not self.provenance.strip():raise ValueError("telemetry source/provenance required")
        if self.sequence<0:raise ValueError("telemetry sequence cannot be negative")

@dataclass(frozen=True)
class TelemetryIntegrity:
    source_id:str
    freshness:FreshnessState
    sequence_valid:bool
    authenticated:bool
    age_s:float|None
    failures:tuple[str,...]
    provenance:str

class TelemetryIntegrityMonitor:
    def __init__(self,maximum_age_s:float):
        if maximum_age_s<=0:raise ValueError("maximum telemetry age must be positive")
        self.maximum_age_s=maximum_age_s;self._last_sequence={}
    def inspect(self,envelope:TelemetryEnvelope|None,now_s:float|None=None)->TelemetryIntegrity:
        if envelope is None:return TelemetryIntegrity("UNKNOWN",FreshnessState.MISSING,False,False,None,("telemetry missing",),"SOFTWARE: RTS telemetry integrity")
        now=time.time() if now_s is None else now_s;failures=[]
        if envelope.timestamp_s is None:
            freshness=FreshnessState.INVALID;age=None;failures.append("timestamp missing")
        else:
            age=now-envelope.timestamp_s
            if age<0: freshness=FreshnessState.INVALID;failures.append("telemetry timestamp is in the future")
            elif age>self.maximum_age_s:freshness=FreshnessState.STALE;failures.append("telemetry is stale")
            else:freshness=FreshnessState.FRESH
        previous=self._last_sequence.get(envelope.source_id)
        sequence_valid=previous is None or envelope.sequence>previous
        if not sequence_valid:failures.append("telemetry sequence is replayed or non-increasing")
        else:self._last_sequence[envelope.source_id]=envelope.sequence
        if not envelope.authenticated:failures.append("telemetry source authentication not established")
        return TelemetryIntegrity(envelope.source_id,freshness,sequence_valid,envelope.authenticated,age,tuple(failures),"SOFTWARE: RTS telemetry integrity")

@dataclass(frozen=True)
class Heartbeat:
    source_id:str
    sequence:int
    timestamp_s:float
    provenance:str

@dataclass(frozen=True)
class WatchdogStatus:
    source_id:str
    healthy:bool
    age_s:float|None
    reason:str
    provenance:str

class HeartbeatWatchdog:
    def __init__(self,timeout_s:float):
        if timeout_s<=0:raise ValueError("watchdog timeout must be positive")
        self.timeout_s=timeout_s;self._last={}
    def observe(self,hb:Heartbeat):
        old=self._last.get(hb.source_id)
        if old is not None and hb.sequence<=old.sequence:raise ValueError("heartbeat sequence must increase")
        self._last[hb.source_id]=hb
    def status(self,source_id:str,now_s:float|None=None):
        hb=self._last.get(source_id)
        if hb is None:return WatchdogStatus(source_id,False,None,"heartbeat missing","SOFTWARE: RTS watchdog")
        now=time.time() if now_s is None else now_s;age=now-hb.timestamp_s
        healthy=0<=age<=self.timeout_s
        return WatchdogStatus(source_id,healthy,age,"healthy" if healthy else "heartbeat timeout or invalid timestamp","SOFTWARE: RTS watchdog")

@dataclass(frozen=True)
class Permissive:
    permissive_id:str
    granted:bool
    source:str
    reason:str
    timestamp_s:float
    provenance:str

class CommandDisposition(str,Enum):
    ACCEPT="ACCEPT"
    HOLD="HOLD"
    ABORT="ABORT"
    REJECT="REJECT"

@dataclass(frozen=True)
class CommandEnvelope:
    command_id:str
    principal:AuthorityPrincipal
    command_type:str
    target:str
    issued_at_s:float
    expires_at_s:float
    provenance:str
    def __post_init__(self):
        if not all((self.command_id.strip(),self.command_type.strip(),self.target.strip(),self.provenance.strip())):raise ValueError("complete command envelope required")
        if self.expires_at_s<=self.issued_at_s:raise ValueError("command expiry must follow issue time")

@dataclass(frozen=True)
class CommandDecision:
    command_id:str
    disposition:CommandDisposition
    reasons:tuple[str,...]
    timestamp_s:float
    provenance:str

class RTSupervisor:
    """Fail-safe supervisory logic around the deterministic kernel; no physical I/O driver."""
    def __init__(self,kernel:DeterministicControlKernel,telemetry_max_age_s=1.0,watchdog_timeout_s=1.0):
        self.kernel=kernel
        self.telemetry=TelemetryIntegrityMonitor(telemetry_max_age_s)
        self.watchdog=HeartbeatWatchdog(watchdog_timeout_s)
        self.permissives={}
    def set_permissive(self,p:Permissive):self.permissives[p.permissive_id]=p
    def evaluate_command(self,cmd:CommandEnvelope,telemetry:TelemetryEnvelope|None,heartbeat_source:str,now_s:float|None=None):
        now=time.time() if now_s is None else now_s;reasons=[]
        if now>cmd.expires_at_s:reasons.append("command envelope expired")
        if cmd.principal.level<AuthorityLevel.RT_CONTROL:reasons.append("command authority below deterministic RT control")
        integrity=self.telemetry.inspect(telemetry,now)
        if integrity.failures:reasons.extend(integrity.failures)
        wd=self.watchdog.status(heartbeat_source,now)
        if not wd.healthy:reasons.append(wd.reason)
        denied=[p for p in self.permissives.values() if not p.granted]
        if denied:reasons.append("one or more required permissives are denied")
        if self.kernel.active_blocks():reasons.append("deterministic interlock block is active")
        critical=any("authentication" in r or "heartbeat" in r or "interlock" in r for r in reasons)
        if critical and self.kernel.state==ControlState.EXPERIMENT:
            disposition=CommandDisposition.ABORT
        elif reasons:disposition=CommandDisposition.HOLD
        else:disposition=CommandDisposition.ACCEPT
        return CommandDecision(cmd.command_id,disposition,tuple(reasons),now,"SOFTWARE: JOE RTS-001B")

def rt_supervision_readiness():
    now=time.time();k=DeterministicControlKernel();sup=RTSupervisor(k,.5,.5)
    rt=AuthorityPrincipal("rt",AuthorityLevel.RT_CONTROL,"SIMULATION:qualification")
    sup.watchdog.observe(Heartbeat("controller",1,now,"SIMULATION:qualification"))
    sup.set_permissive(Permissive("p",True,"qualification","clear",now,"SIMULATION:qualification"))
    tel=TelemetryEnvelope("sensor",1,now,now,True,"SIMULATION:qualification")
    cmd=CommandEnvelope("c",rt,"SETPOINT","qualification",now,now+1,"SIMULATION:qualification")
    accepted=sup.evaluate_command(cmd,tel,"controller",now)
    stale=TelemetryEnvelope("stale",1,now-2,now,True,"SIMULATION:qualification")
    held=sup.evaluate_command(CommandEnvelope("c2",rt,"SETPOINT","qualification",now,now+1,"SIMULATION:qualification"),stale,"controller",now)
    timing=validate_timing_hierarchy(TimingBudget(TimingDomain.SAFETY,.001,.0005,"test"),TimingBudget(TimingDomain.CONTROL,.01,.005,"test"),TimingBudget(TimingDomain.RESEARCH,1,.5,"test"))
    return {"passed":accepted.disposition==CommandDisposition.ACCEPT and held.disposition==CommandDisposition.HOLD and not timing,
            "checks":("timing-domain hierarchy","heartbeat/watchdog","telemetry freshness","sequence integrity","source authentication",
                      "permissive gating","command expiry","HOLD/ABORT disposition","fail-safe missing-data behavior"),
            "notes":("RTS-001B remains a software qualification/supervisory interface, not physical BUS-SAFE hardware.",
                     "No missing telemetry, heartbeat, permissive or authentication state is synthesized as healthy.")}


class QualificationMode(str,Enum):
    SIL="SIL"
    HIL="HIL"
    LIVE="LIVE"

class SourceClass(str,Enum):
    SOFTWARE="SOFTWARE"
    SIMULATION="SIMULATION"
    REPLAY="REPLAY"
    HARDWARE="HARDWARE"

@dataclass(frozen=True)
class HardwareSourceQualification:
    source_id:str
    source_class:SourceClass
    authenticated:bool
    integrity_verified:bool
    qualified_for_live:bool
    provenance:str
    diagnostic:str=""
    def __post_init__(self):
        if not self.source_id.strip() or not self.provenance.strip():raise ValueError("hardware-source identity/provenance required")
        if self.qualified_for_live and self.source_class!=SourceClass.HARDWARE:
            raise ValueError("only HARDWARE sources may be qualified for LIVE")
        if self.qualified_for_live and (not self.authenticated or not self.integrity_verified):
            raise ValueError("LIVE-qualified hardware must be authenticated and integrity-verified")

@dataclass(frozen=True)
class ActuatorCommand:
    command_id:str
    actuator_id:str
    value:float
    unit:str
    issued_at_s:float
    expires_at_s:float
    principal:AuthorityPrincipal
    source_class:SourceClass
    qualification_mode:QualificationMode
    provenance:str
    def __post_init__(self):
        if not all((self.command_id.strip(),self.actuator_id.strip(),self.unit.strip(),self.provenance.strip())):raise ValueError("complete actuator command required")
        if self.expires_at_s<=self.issued_at_s:raise ValueError("actuator command expiry must follow issue time")

@dataclass(frozen=True)
class ActuatorCapability:
    actuator_id:str
    minimum:float
    maximum:float
    unit:str
    live_enabled:bool
    provenance:str
    def __post_init__(self):
        if self.maximum<=self.minimum:raise ValueError("actuator capability range invalid")

@dataclass(frozen=True)
class ActuatorDecision:
    command_id:str
    accepted:bool
    reasons:tuple[str,...]
    mode:QualificationMode
    provenance:str

def validate_actuator_command(command:ActuatorCommand,capability:ActuatorCapability,source:HardwareSourceQualification,now_s=None):
    now=time.time() if now_s is None else now_s;reasons=[]
    if command.actuator_id!=capability.actuator_id:reasons.append("actuator identity mismatch")
    if command.unit!=capability.unit:reasons.append("actuator unit mismatch")
    if not capability.minimum<=command.value<=capability.maximum:reasons.append("actuator value outside qualified range")
    if now>command.expires_at_s:reasons.append("actuator command expired")
    if command.principal.level<AuthorityLevel.RT_CONTROL:reasons.append("actuator command authority below RT_CONTROL")
    if command.qualification_mode==QualificationMode.LIVE:
        if not capability.live_enabled:reasons.append("actuator capability is not LIVE-enabled")
        if command.source_class in (SourceClass.SIMULATION,SourceClass.REPLAY,SourceClass.SOFTWARE):
            reasons.append("simulation/replay/software command source cannot bind LIVE actuator")
        if not source.qualified_for_live:reasons.append("hardware source is not qualified for LIVE")
        if source.source_class!=SourceClass.HARDWARE:reasons.append("LIVE requires HARDWARE source")
    elif command.qualification_mode==QualificationMode.HIL:
        if source.source_class not in (SourceClass.HARDWARE,SourceClass.SOFTWARE):reasons.append("HIL source class invalid")
    return ActuatorDecision(command.command_id,not reasons,tuple(reasons),command.qualification_mode,"SOFTWARE: JOE RTS-001C")

@dataclass(frozen=True)
class TripAuditEntry:
    sequence:int
    event:str
    state:str
    reason:str
    authority:str
    timestamp_s:float
    provenance:str

class LatchedTripController:
    def __init__(self,kernel:DeterministicControlKernel):
        self.kernel=kernel;self.latched=False;self.audit=[]
    def trip(self,reason,provenance="HARDWARE_INTERFACE: BUS-SAFE"):
        self.latched=True;d=self.kernel.bus_safe_trip(reason,provenance)
        self.audit.append(TripAuditEntry(len(self.audit)+1,"TRIP",self.kernel.state.value,reason,"BUS_SAFE",d.timestamp_s,provenance));return d
    def reset(self,principal:AuthorityPrincipal,reason="authorized reset"):
        if not self.latched:return False,"no latched trip"
        d=self.kernel.reset_trip(principal)
        if not d.allowed:return False,"; ".join(d.reasons)
        self.latched=False
        self.audit.append(TripAuditEntry(len(self.audit)+1,"RESET",self.kernel.state.value,reason,principal.level.name,time.time(),principal.provenance))
        return True,"reset accepted"

@dataclass(frozen=True)
class BusSafeInterfaceStatus:
    bound:bool
    hardware_identity:str|None
    authenticated:bool
    heartbeat_healthy:bool
    trip_line_verified:bool
    reset_line_verified:bool
    provenance:str
    diagnostic:str=""

def bus_safe_interface_permissive(status:BusSafeInterfaceStatus)->tuple[bool,tuple[str,...]]:
    failures=[]
    if not status.bound:failures.append("BUS-SAFE hardware interface is not bound")
    if not status.hardware_identity:failures.append("BUS-SAFE hardware identity unavailable")
    if not status.authenticated:failures.append("BUS-SAFE interface authentication not established")
    if not status.heartbeat_healthy:failures.append("BUS-SAFE heartbeat unhealthy")
    if not status.trip_line_verified:failures.append("BUS-SAFE trip path not verified")
    if not status.reset_line_verified:failures.append("BUS-SAFE reset path not verified")
    return not failures,tuple(failures)

def rt_hardware_boundary_readiness():
    failures=[];checks=[];now=time.time()
    try:
        op=AuthorityPrincipal("rt",AuthorityLevel.RT_CONTROL,"SIMULATION:qualification")
        cap=ActuatorCapability("a",-1,1,"V",False,"SIMULATION:qualification")
        replay=HardwareSourceQualification("replay",SourceClass.REPLAY,True,True,False,"REPLAY:qualification")
        cmd=ActuatorCommand("c","a",0,"V",now,now+1,op,SourceClass.REPLAY,QualificationMode.LIVE,"REPLAY:qualification")
        if not validate_actuator_command(cmd,cap,replay,now).accepted:checks.append("replay-to-LIVE isolation passed")
        unbound=BusSafeInterfaceStatus(False,None,False,False,False,False,"SOFTWARE: qualification")
        if not bus_safe_interface_permissive(unbound)[0]:checks.append("unbound BUS-SAFE fail-closed passed")
        k=DeterministicControlKernel();latched=LatchedTripController(k);latched.trip("qualification","SIMULATION:qualification")
        if latched.latched and k.state==ControlState.ABORT_TRIP:checks.append("latched trip passed")
        if not latched.reset(AuthorityPrincipal("operator",AuthorityLevel.OPERATOR,"SIMULATION:qualification"))[0]:
            checks.append("unauthorized reset rejection passed")
    except Exception as exc:failures.append(f"hardware boundary: {type(exc).__name__}: {exc}")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),
            "notes":("No physical actuator driver or BUS-SAFE hardware is supplied by RTS-001C.",
                     "SIL/HIL/replay data cannot silently become LIVE hardware authority.",
                     "LIVE remains fail-closed until a real authenticated and qualified hardware binding exists.")}


class FaultSeverity(int,Enum):
    INFO=10
    WARNING=20
    HOLD=30
    ABORT=40
    TRIP=50

@dataclass(frozen=True)
class RTAuditEvent:
    sequence:int
    event_type:str
    source:str
    severity:FaultSeverity
    message:str
    timestamp_s:float
    provenance:str
    previous_hash:str
    event_hash:str

def _rt_event_hash(sequence,event_type,source,severity,message,timestamp_s,provenance,previous_hash):
    import hashlib,json
    payload=json.dumps({"sequence":sequence,"event_type":event_type,"source":source,"severity":int(severity),
                        "message":message,"timestamp_s":timestamp_s,"provenance":provenance,
                        "previous_hash":previous_hash},sort_keys=True,separators=(",",":")).encode()
    return hashlib.sha256(payload).hexdigest()

class RTAuditChain:
    def __init__(self):self._events=[]
    def append(self,event_type,source,severity,message,provenance,timestamp_s=None):
        ts=time.time() if timestamp_s is None else timestamp_s;seq=len(self._events)+1
        previous=self._events[-1].event_hash if self._events else "GENESIS"
        h=_rt_event_hash(seq,event_type,source,severity,message,ts,provenance,previous)
        e=RTAuditEvent(seq,event_type,source,severity,message,ts,provenance,previous,h);self._events.append(e);return e
    def events(self):return tuple(self._events)
    def verify(self):
        previous="GENESIS"
        for i,e in enumerate(self._events,1):
            if e.sequence!=i or e.previous_hash!=previous:return False
            if e.event_hash!=_rt_event_hash(e.sequence,e.event_type,e.source,e.severity,e.message,e.timestamp_s,e.provenance,e.previous_hash):return False
            previous=e.event_hash
        return True

@dataclass(frozen=True)
class FaultEvent:
    fault_id:str
    source:str
    severity:FaultSeverity
    reason:str
    timestamp_s:float
    provenance:str

class FaultEscalator:
    def __init__(self,kernel:DeterministicControlKernel,trip_controller:LatchedTripController,audit:RTAuditChain):
        self.kernel=kernel;self.trip_controller=trip_controller;self.audit=audit
    def apply(self,fault:FaultEvent):
        self.audit.append("FAULT",fault.source,fault.severity,fault.reason,fault.provenance,fault.timestamp_s)
        if fault.severity>=FaultSeverity.TRIP:
            self.trip_controller.trip(fault.reason,fault.provenance);return CommandDisposition.ABORT
        if fault.severity>=FaultSeverity.ABORT:
            self.kernel.state=ControlState.ABORT_TRIP
            self.audit.append("ABORT",fault.source,FaultSeverity.ABORT,fault.reason,fault.provenance)
            return CommandDisposition.ABORT
        if fault.severity>=FaultSeverity.HOLD:return CommandDisposition.HOLD
        return CommandDisposition.ACCEPT

class AcknowledgementState(str,Enum):
    PENDING="PENDING"
    ACKNOWLEDGED="ACKNOWLEDGED"
    REJECTED="REJECTED"

@dataclass(frozen=True)
class CommandAcknowledgement:
    command_id:str
    state:AcknowledgementState
    source:str
    timestamp_s:float
    message:str
    provenance:str

class CommandAcknowledgementRegistry:
    def __init__(self):self._acks={}
    def record(self,ack:CommandAcknowledgement):
        if ack.command_id in self._acks:raise ValueError("command acknowledgement is immutable once recorded")
        self._acks[ack.command_id]=ack;return ack
    def get(self,command_id):return self._acks.get(command_id)
    def pending(self,command_ids):return tuple(x for x in command_ids if x not in self._acks)

class DeterministicHardwareAdapter:
    """Interface contract only; implementations must be separately qualified for LIVE."""
    adapter_id="hardware.abstract"
    qualification_mode=QualificationMode.SIL
    def source_qualification(self)->HardwareSourceQualification:raise NotImplementedError
    def capabilities(self)->tuple[ActuatorCapability,...]:raise NotImplementedError
    def write(self,command:ActuatorCommand)->CommandAcknowledgement:raise NotImplementedError
    def read_bus_safe_status(self)->BusSafeInterfaceStatus:raise NotImplementedError

class SILQualificationAdapter(DeterministicHardwareAdapter):
    adapter_id="joe.sil"
    qualification_mode=QualificationMode.SIL
    def __init__(self):
        self._caps=(ActuatorCapability("sil.channel",-10,10,"V",False,"SIMULATION: JOE SIL"),)
    def source_qualification(self):
        return HardwareSourceQualification("joe.sil",SourceClass.SIMULATION,True,True,False,"SIMULATION: JOE SIL")
    def capabilities(self):return self._caps
    def write(self,command):
        cap=next((x for x in self._caps if x.actuator_id==command.actuator_id),None)
        if cap is None:return CommandAcknowledgement(command.command_id,AcknowledgementState.REJECTED,self.adapter_id,time.time(),"unknown SIL actuator","SIMULATION: JOE SIL")
        src=self.source_qualification()
        # SIL deliberately evaluates as SIL, never upgrades to LIVE.
        sil=ActuatorCommand(command.command_id,command.actuator_id,command.value,command.unit,command.issued_at_s,
                            command.expires_at_s,command.principal,SourceClass.SIMULATION,QualificationMode.SIL,command.provenance)
        d=validate_actuator_command(sil,cap,src,time.time())
        return CommandAcknowledgement(command.command_id,AcknowledgementState.ACKNOWLEDGED if d.accepted else AcknowledgementState.REJECTED,
                                      self.adapter_id,time.time(),"; ".join(d.reasons) if d.reasons else "SIL command accepted","SIMULATION: JOE SIL")
    def read_bus_safe_status(self):
        return BusSafeInterfaceStatus(False,None,False,False,False,False,"SIMULATION: JOE SIL","SIL cannot qualify physical BUS-SAFE")

def guardian_fault_recommendation(fault:FaultEvent):
    """Guardian may recommend; deterministic escalation remains outside Guardian authority."""
    if fault.severity>=FaultSeverity.ABORT:recommendation="RECOMMEND_ABORT"
    elif fault.severity>=FaultSeverity.HOLD:recommendation="RECOMMEND_HOLD"
    else:recommendation="OBSERVE"
    return {"schema":"JOE-GUARDIAN-RT-FAULT/1","fault_id":fault.fault_id,"severity":fault.severity.name,
            "recommendation":recommendation,"authority":"READ_ONLY_ADVISORY","may_execute":False,
            "evidence":{"source":fault.source,"reason":fault.reason,"timestamp_s":fault.timestamp_s,"provenance":fault.provenance}}

def rt_v1_release_readiness():
    failures=[];checks=[]
    for name,fn in (("deterministic core",rt_core_readiness),("supervision",rt_supervision_readiness),("hardware boundary",rt_hardware_boundary_readiness)):
        try:
            q=fn()
            if q["passed"]:checks.append(name+" passed")
            else:failures.extend(q.get("failures",()) or (name+" failed",))
        except Exception as exc:failures.append(f"{name}: {type(exc).__name__}: {exc}")
    try:
        audit=RTAuditChain();k=DeterministicControlKernel();tc=LatchedTripController(k);esc=FaultEscalator(k,tc,audit)
        f=FaultEvent("f","qualification",FaultSeverity.TRIP,"qualification trip",time.time(),"SIMULATION:qualification")
        esc.apply(f)
        if tc.latched and audit.verify():checks.append("fault escalation and audit chain passed")
        sil=SILQualificationAdapter();now=time.time();rt=AuthorityPrincipal("rt",AuthorityLevel.RT_CONTROL,"SIMULATION:qualification")
        ack=sil.write(ActuatorCommand("sil-c","sil.channel",1,"V",now,now+1,rt,SourceClass.SIMULATION,QualificationMode.SIL,"SIMULATION:qualification"))
        if ack.state==AcknowledgementState.ACKNOWLEDGED:checks.append("SIL command acknowledgement passed")
        if not bus_safe_interface_permissive(sil.read_bus_safe_status())[0]:checks.append("SIL cannot qualify BUS-SAFE passed")
        g=guardian_fault_recommendation(f)
        if not g["may_execute"] and g["authority"]=="READ_ONLY_ADVISORY":checks.append("Guardian fault authority boundary passed")
    except Exception as exc:failures.append(f"v1 integration: {type(exc).__name__}: {exc}")
    return {"passed":not failures,"checks":tuple(checks),"failures":tuple(failures),
            "notes":("RT / Control / BUS-SAFE v1.0 is a software architecture and SIL qualification release.",
                     "No physical BUS-SAFE, PLC/FPGA, actuator driver or HIL rig is claimed connected.",
                     "LIVE remains unavailable until separately qualified hardware adapters satisfy the fail-closed interface.")}
