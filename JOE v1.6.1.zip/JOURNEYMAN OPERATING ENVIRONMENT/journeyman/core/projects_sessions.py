"""JOE-012 persistent Projects & Sessions."""
from dataclasses import dataclass, asdict
from pathlib import Path
from threading import RLock
from datetime import datetime, timezone
import json, os, uuid

def _now():
    return datetime.now(timezone.utc).isoformat()

def _clean(value,name):
    value=str(value).strip()
    if not value: raise ValueError(f"{name} is required")
    return value

@dataclass(frozen=True)
class ProjectRecord:
    project_id: str
    name: str
    description: str
    created_at: str
    updated_at: str
    archived: bool = False

@dataclass(frozen=True)
class SessionRecord:
    session_id: str
    project_id: str
    name: str
    created_at: str
    updated_at: str
    closed_at: str | None = None
    active: bool = True

@dataclass(frozen=True)
class SessionContext:
    session: SessionRecord
    project: ProjectRecord
    run_ids: tuple[str, ...]
    workspace_saved: bool
    workspace_saved_at: str | None
    config_namespaces: tuple[str, ...]

@dataclass(frozen=True)
class ProjectSessionQualification:
    passed: bool
    checks: tuple[str, ...]
    failures: tuple[str, ...]

@dataclass(frozen=True)
class ProjectSessionReleaseReadiness:
    passed: bool
    qualification_passed: bool
    isolated_exercise_passed: bool
    checks: tuple[str, ...]
    failures: tuple[str, ...]

@dataclass(frozen=True)
class ProjectSessionStatus:
    projects: int
    active_projects: int
    archived_projects: int
    sessions: int
    active_sessions: int
    closed_sessions: int

class ProjectSessionService:
    """Persistent organizational layer. It does not invent or duplicate run data."""
    SCHEMA_VERSION=1
    def __init__(self,root:Path,run_recorder=None):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
        self._run_recorder=run_recorder
        self.path=self.root/"projects_sessions.json"; self._lock=RLock()
        if not self.path.exists(): self._save({"schema_version":1,"projects":[],"sessions":[],"workspace_snapshots":{},"config_refs":{}})

    def _load(self):
        payload=json.loads(self.path.read_text(encoding="utf-8"))
        if payload.get("schema_version")!=self.SCHEMA_VERSION: raise ValueError("unsupported projects/sessions schema")
        if not isinstance(payload.get("projects"),list) or not isinstance(payload.get("sessions"),list):
            raise ValueError("invalid projects/sessions document")
        snapshots=payload.setdefault("workspace_snapshots",{})
        refs=payload.setdefault("config_refs",{})
        if not isinstance(snapshots,dict): raise ValueError("invalid workspace snapshots")
        if not isinstance(refs,dict): raise ValueError("invalid configuration references")
        return payload

    def _save(self,payload):
        tmp=self.path.with_suffix(".tmp")
        with tmp.open("w",encoding="utf-8",newline="\n") as fh:
            json.dump(payload,fh,sort_keys=True,indent=2); fh.write("\n"); fh.flush(); os.fsync(fh.fileno())
        os.replace(tmp,self.path)

    def create_project(self,name,description=""):
        with self._lock:
            data=self._load(); now=_now()
            record=ProjectRecord(str(uuid.uuid4()),_clean(name,"project name"),str(description).strip(),now,now,False)
            data["projects"].append(asdict(record)); self._save(data); return record

    def projects(self,include_archived=True):
        with self._lock:
            rows=[ProjectRecord(**x) for x in self._load()["projects"]]
            if not include_archived: rows=[x for x in rows if not x.archived]
            return tuple(rows)

    def project(self,project_id):
        pid=_clean(project_id,"project_id")
        for row in self.projects():
            if row.project_id==pid:return row
        raise KeyError(pid)

    def archive_project(self,project_id):
        with self._lock:
            data=self._load(); pid=_clean(project_id,"project_id"); now=_now(); found=None
            for row in data["projects"]:
                if row["project_id"]==pid:
                    row["archived"]=True; row["updated_at"]=now; found=ProjectRecord(**row); break
            if found is None: raise KeyError(pid)
            if any(x["project_id"]==pid and x["active"] for x in data["sessions"]):
                raise RuntimeError("cannot archive a project with an active session")
            self._save(data); return found

    def create_session(self,project_id,name):
        with self._lock:
            data=self._load(); pid=_clean(project_id,"project_id")
            project=next((x for x in data["projects"] if x["project_id"]==pid),None)
            if project is None: raise KeyError(pid)
            if project["archived"]: raise RuntimeError("cannot create a session in an archived project")
            now=_now(); record=SessionRecord(str(uuid.uuid4()),pid,_clean(name,"session name"),now,now,None,True)
            data["sessions"].append(asdict(record)); self._save(data); return record

    def sessions(self,project_id=None,include_closed=True):
        with self._lock:
            rows=[SessionRecord(**x) for x in self._load()["sessions"]]
            if project_id is not None: rows=[x for x in rows if x.project_id==project_id]
            if not include_closed: rows=[x for x in rows if x.active]
            return tuple(rows)

    def close_session(self,session_id):
        with self._lock:
            data=self._load(); sid=_clean(session_id,"session_id"); now=_now(); found=None
            for row in data["sessions"]:
                if row["session_id"]==sid:
                    if not row["active"]: raise RuntimeError("session is already closed")
                    row["active"]=False; row["closed_at"]=now; row["updated_at"]=now
                    found=SessionRecord(**row); break
            if found is None: raise KeyError(sid)
            self._save(data); return found

    def status(self):
        projects=self.projects(); sessions=self.sessions()
        return ProjectSessionStatus(len(projects),sum(not x.archived for x in projects),sum(x.archived for x in projects),
                                    len(sessions),sum(x.active for x in sessions),sum(not x.active for x in sessions))

    def bind_run(self,run_id,project_id,session_id):
        """Attach canonical PROJECT and SESSION provenance links to an ACTIVE run."""
        if self._run_recorder is None:
            raise RuntimeError("run recorder is not connected")
        project=self.project(project_id)
        session=next((x for x in self.sessions(project.project_id) if x.session_id==session_id),None)
        if session is None: raise KeyError(session_id)
        if not session.active: raise RuntimeError("cannot bind a run to a closed session")
        run=self._run_recorder.get(run_id)
        if getattr(run.state,"value",str(run.state))!="ACTIVE":
            raise RuntimeError("only ACTIVE runs can be bound")
        existing=self._run_recorder.associations(run_id)
        if any(x.get("type") in ("PROJECT","SESSION") for x in existing):
            raise RuntimeError("run already has project/session organization")
        source="joe.projects"
        self._run_recorder.associate(run_id,"PROJECT",project.project_id,source=source,
                                     metadata={"name":project.name})
        try:
            self._run_recorder.associate(run_id,"SESSION",session.session_id,source=source,
                                         metadata={"name":session.name,"project_id":project.project_id})
        except Exception:
            # The recorder API is append-only. A partial PROJECT link is explicit evidence,
            # so never hide it; surface failure rather than fabricating rollback.
            raise
        return self.run_context(run_id)

    def run_context(self,run_id):
        if self._run_recorder is None: raise RuntimeError("run recorder is not connected")
        associations=self._run_recorder.associations(run_id)
        project_link=next((x for x in associations if x.get("type")=="PROJECT"),None)
        session_link=next((x for x in associations if x.get("type")=="SESSION"),None)
        if project_link is None and session_link is None:return None
        if project_link is None or session_link is None:
            raise RuntimeError("run has incomplete project/session provenance")
        project=self.project(project_link["identifier"])
        session=next((x for x in self.sessions(project.project_id) if x.session_id==session_link["identifier"]),None)
        if session is None: raise RuntimeError("run references an unknown session")
        if session.project_id!=project.project_id: raise RuntimeError("run project/session provenance mismatch")
        return {"project":project,"session":session,"project_link":project_link,"session_link":session_link}

    def runs_for_session(self,session_id):
        if self._run_recorder is None: raise RuntimeError("run recorder is not connected")
        result=[]
        for run in self._run_recorder.list_runs():
            try: context=self.run_context(run.run_id)
            except RuntimeError: continue
            if context is not None and context["session"].session_id==session_id: result.append(run)
        return tuple(result)

    def runs_for_project(self,project_id):
        if self._run_recorder is None: raise RuntimeError("run recorder is not connected")
        self.project(project_id)
        result=[]
        for run in self._run_recorder.list_runs():
            try: context=self.run_context(run.run_id)
            except RuntimeError: continue
            if context is not None and context["project"].project_id==project_id: result.append(run)
        return tuple(result)

    def save_workspace_snapshot(self,session_id,entries):
        """Persist a JSON-safe JOE workspace layout snapshot for an existing session."""
        with self._lock:
            data=self._load()
            session=next((x for x in data["sessions"] if x["session_id"]==session_id),None)
            if session is None: raise KeyError(session_id)
            if not session["active"]: raise RuntimeError("cannot update workspace state for a closed session")
            rows=[]
            for entry in entries:
                if hasattr(entry,"__dataclass_fields__"):
                    from dataclasses import asdict as _asdict
                    row=_asdict(entry)
                elif isinstance(entry,dict): row=dict(entry)
                else: raise TypeError("workspace entries must be layout entries or dictionaries")
                json.dumps(row,allow_nan=False)
                rows.append(row)
            data["workspace_snapshots"][session_id]={"schema":6,"saved_at":_now(),"workspaces":rows}
            session["updated_at"]=_now()
            self._save(data)
            return self.workspace_snapshot(session_id)

    def workspace_snapshot(self,session_id):
        with self._lock:
            data=self._load()
            if not any(x["session_id"]==session_id for x in data["sessions"]): raise KeyError(session_id)
            snap=data["workspace_snapshots"].get(session_id)
            if snap is None:return None
            return json.loads(json.dumps(snap))

    def clear_workspace_snapshot(self,session_id):
        with self._lock:
            data=self._load()
            if not any(x["session_id"]==session_id for x in data["sessions"]): raise KeyError(session_id)
            existed=data["workspace_snapshots"].pop(session_id,None) is not None
            if existed:self._save(data)
            return existed

    def capture_config_reference(self,session_id,document):
        """Record authoritative config identity/revision/checksum without copying config values."""
        with self._lock:
            data=self._load()
            session=next((x for x in data["sessions"] if x["session_id"]==session_id),None)
            if session is None: raise KeyError(session_id)
            if not session["active"]: raise RuntimeError("cannot update configuration context for a closed session")
            namespace=_clean(getattr(document,"namespace",""),"configuration namespace")
            revision=getattr(document,"revision",None)
            if not isinstance(revision,int) or isinstance(revision,bool) or revision < 0:
                raise ValueError("configuration revision must be a non-negative integer")
            schema_version=getattr(document,"schema_version",None)
            checksum=getattr(document,"checksum",None)
            row={"namespace":namespace,"revision":revision,"schema_version":schema_version,
                 "checksum":checksum,"captured_at":_now()}
            refs=data["config_refs"].setdefault(session_id,{})
            refs[namespace]=row
            session["updated_at"]=_now();self._save(data)
            return dict(row)

    def config_references(self,session_id):
        with self._lock:
            data=self._load()
            if not any(x["session_id"]==session_id for x in data["sessions"]): raise KeyError(session_id)
            refs=data["config_refs"].get(session_id,{})
            return tuple(dict(refs[k]) for k in sorted(refs))

    def session_context(self,session_id):
        session=next((x for x in self.sessions() if x.session_id==session_id),None)
        if session is None: raise KeyError(session_id)
        project=self.project(session.project_id)
        runs=self.runs_for_session(session_id) if self._run_recorder is not None else ()
        workspace=self.workspace_snapshot(session_id)
        refs=self.config_references(session_id)
        return SessionContext(session,project,tuple(x.run_id for x in runs),workspace is not None,
                              workspace.get("saved_at") if workspace else None,
                              tuple(x["namespace"] for x in refs))

    def verify_config_references(self,session_id,config_store):
        """Compare captured identities to current authoritative documents; never mutates them."""
        results=[]
        for ref in self.config_references(session_id):
            try:
                config_path=config_store._path(ref["namespace"])
                if not config_path.exists():
                    results.append({"reference":ref,"status":"UNAVAILABLE","error":"canonical configuration document is absent"})
                    continue
                current=config_store.load(ref["namespace"])
                status=("MATCH" if current.revision==ref["revision"] and
                        current.schema_version==ref["schema_version"] and
                        current.checksum==ref["checksum"] else "CHANGED")
                results.append({"reference":ref,"status":status,"current_revision":current.revision,
                                "current_schema_version":current.schema_version,"current_checksum":current.checksum})
            except Exception as exc:
                results.append({"reference":ref,"status":"UNAVAILABLE","error":str(exc)})
        return tuple(results)


def qualify_projects_sessions(service):
    checks=[]; failures=[]
    try:
        projects=service.projects(); sessions=service.sessions()
        project_ids={p.project_id for p in projects}
        if len(project_ids)!=len(projects): failures.append("duplicate project identity")
        session_ids={x.session_id for x in sessions}
        if len(session_ids)!=len(sessions): failures.append("duplicate session identity")
        raw=service._load()
        orphan_workspaces=set(raw.get("workspace_snapshots",{}))-session_ids
        orphan_configs=set(raw.get("config_refs",{}))-session_ids
        for sid in sorted(orphan_workspaces):
            failures.append(f"workspace snapshot references unknown session: {sid}")
        for sid in sorted(orphan_configs):
            failures.append(f"configuration references unknown session: {sid}")
        for session in sessions:
            if session.project_id not in project_ids:
                failures.append(f"session {session.session_id} references unknown project")
                continue
            try:
                context=service.session_context(session.session_id)
                if context.session.session_id!=session.session_id:
                    failures.append(f"session context identity mismatch: {session.session_id}")
                if service._run_recorder is not None:
                    for run_id in context.run_ids:
                        rc=service.run_context(run_id)
                        if rc is None or rc["session"].session_id!=session.session_id or rc["project"].project_id!=session.project_id:
                            failures.append(f"run organization mismatch: {run_id}")
            except Exception as exc:
                failures.append(f"session context unreadable {session.session_id}: {exc}")
        if not failures:
            checks.extend(("project/session identities valid",
                           "session ownership and context projections valid",
                           "workspace/configuration references have valid session owners",
                           "canonical run organization associations are consistent"))
    except Exception as exc:
        failures.append(f"projects/sessions repository unreadable: {exc}")
    return ProjectSessionQualification(not failures,tuple(checks),tuple(failures))

def joe012_release_readiness():
    import tempfile
    from .run_recorder import RunRecorder
    from .storage import ConfigStore
    from .workspace_layout import WorkspaceLayoutEntry, entries_from_snapshot
    checks=[]; failures=[]; qualification_passed=False; isolated=False
    try:
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); recorder=RunRecorder(root/"runs")
            service=ProjectSessionService(root/"projects",recorder)
            config=ConfigStore(root/"config"); config.register_schema("qualification",1)
            document=config.save("qualification",{"mode":"SIMULATION"})
            project=service.create_project("Qualification Project","JOE-012 isolated exercise")
            session=service.create_session(project.project_id,"Qualification Session")
            run=recorder.start("Qualification Run",mode="SIMULATION",source="joe012.qualification")
            service.bind_run(run.run_id,project.project_id,session.session_id)
            entry=WorkspaceLayoutEntry("overview","Overview",False,"")
            service.save_workspace_snapshot(session.session_id,[entry])
            service.capture_config_reference(session.session_id,document)
            context=service.session_context(session.session_id)
            qualification=qualify_projects_sessions(service); qualification_passed=qualification.passed
            verify=service.verify_config_references(session.session_id,config)
            snap=service.workspace_snapshot(session.session_id)
            recorder.finish(run.run_id)
            service.close_session(session.session_id)
            service.archive_project(project.project_id)
            reopened=ProjectSessionService(root/"projects",recorder)
            persisted=reopened.session_context(session.session_id)
            isolated=(qualification.passed and context.project.project_id==project.project_id and
                      context.run_ids==(run.run_id,) and context.workspace_saved and
                      context.config_namespaces==("qualification",) and verify[0]["status"]=="MATCH" and
                      len(entries_from_snapshot(snap))==1 and not persisted.session.active and
                      persisted.project.archived and persisted.run_ids==(run.run_id,))
            if qualification_passed: checks.append("isolated repository qualification passed")
            else: failures.extend(qualification.failures)
            if isolated: checks.append("project→session→run/workspace/config persistence and lifecycle exercise passed")
            else: failures.append("isolated session-context exercise was inconsistent")
    except Exception as exc:
        failures.append(f"JOE-012 isolated release exercise failed: {exc}")
    return ProjectSessionReleaseReadiness(not failures,qualification_passed,isolated,tuple(checks),tuple(failures))
