"""JOE controlled shared-state and event backbone.

This foundation is deliberately synchronous and in-process. It provides real
software state/event behavior without pretending to be a real-time hardware bus.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable
from enum import Enum
import re

_KEY = re.compile(r"^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$")

def _valid(name: str, label: str) -> str:
    value = str(name).strip()
    if not _KEY.fullmatch(value):
        raise ValueError(f"Invalid {label}: {name}")
    return value



class DataOrigin(str, Enum):
    SOFTWARE = "SOFTWARE"
    HOST = "HOST"
    IMPORTED = "IMPORTED"
    SIMULATION = "SIMULATION"
    HARDWARE = "HARDWARE"



def _origin(value: DataOrigin | str) -> DataOrigin:
    if isinstance(value, DataOrigin):
        return value
    try:
        return DataOrigin(str(value).upper())
    except ValueError as exc:
        raise ValueError(f"Invalid data origin: {value}") from exc

@dataclass(frozen=True)
class StateChange:
    sequence: int
    key: str
    previous: Any
    current: Any
    source: str
    revision: int = 0
    origin: DataOrigin = DataOrigin.SOFTWARE



@dataclass(frozen=True)
class StateUpdate:
    key: str
    value: Any
    expected_revision: int | None = None
    origin: DataOrigin = DataOrigin.SOFTWARE

@dataclass(frozen=True)
class StateTransaction:
    transaction_id: int
    changes: tuple[StateChange, ...]

@dataclass(frozen=True)
class Event:
    sequence: int
    topic: str
    payload: Any
    source: str
    origin: DataOrigin = DataOrigin.SOFTWARE

@dataclass(frozen=True)
class CallbackFailure:
    sequence: int
    channel: str
    name: str
    callback_name: str
    error: str

@dataclass(frozen=True)
class StateDefinition:
    key: str
    owner: str
    writable_by: tuple[str, ...]
    value_type: type | tuple[type, ...] | None = None
    allow_none: bool = False

class StateStore:
    """Authoritative in-process JOE state with ordered change records and ownership."""
    def __init__(self, history_limit: int = 1000) -> None:
        if history_limit < 1:
            raise ValueError("history_limit must be positive")
        self._values: dict[str, Any] = {}
        self._revisions: dict[str, int] = {}
        self._history: list[StateChange] = []
        self._sequence = 0
        self._history_limit = history_limit
        self._watchers: dict[str, list[Callable[[StateChange], None]]] = {}
        self._definitions: dict[str, StateDefinition] = {}
        self._callback_failures: list[CallbackFailure] = []
        self._failure_sequence = 0
        self._transaction_sequence = 0

    def register(self, key: str, owner: str, writable_by: tuple[str, ...] = (),
                 value_type: type | tuple[type, ...] | None = None,
                 allow_none: bool = False) -> StateDefinition:
        key = _valid(key, "state key")
        owner = _valid(owner, "state owner")
        writers = tuple(_valid(item, "state writer") for item in writable_by)
        if value_type is not None:
            types = value_type if isinstance(value_type, tuple) else (value_type,)
            if not types or not all(isinstance(item, type) for item in types):
                raise TypeError("value_type must be a type or non-empty tuple of types")
        if not isinstance(allow_none, bool):
            raise TypeError("allow_none must be bool")
        if len(set(writers)) != len(writers):
            raise ValueError("State writer list contains duplicates")
        if key in self._definitions:
            raise ValueError(f"State key already registered: {key}")
        definition = StateDefinition(key, owner, writers, value_type, allow_none)
        self._definitions[key] = definition
        return definition

    def definition(self, key: str) -> StateDefinition | None:
        return self._definitions.get(_valid(key, "state key"))

    def definitions(self) -> tuple[StateDefinition, ...]:
        return tuple(self._definitions[key] for key in sorted(self._definitions))

    def can_write(self, key: str, source: str) -> bool:
        key = _valid(key, "state key")
        source = _valid(source, "state source")
        definition = self._definitions.get(key)
        if definition is None:
            return True
        return source == definition.owner or source in definition.writable_by

    def _validate_value(self, key: str, value: Any) -> None:
        definition = self._definitions.get(key)
        if definition is None or definition.value_type is None:
            return
        if value is None and definition.allow_none:
            return
        if not isinstance(value, definition.value_type):
            expected = definition.value_type
            if isinstance(expected, tuple):
                expected_name = " or ".join(item.__name__ for item in expected)
            else:
                expected_name = expected.__name__
            raise TypeError(
                f"Invalid value for {key}: expected {expected_name}, "
                f"got {type(value).__name__}"
            )

    def set(self, key: str, value: Any, source: str,
            expected_revision: int | None = None,
            origin: DataOrigin | str = DataOrigin.SOFTWARE) -> StateChange:
        key = _valid(key, "state key")
        source = _valid(source, "state source")
        origin = _origin(origin)
        if not self.can_write(key, source):
            definition = self._definitions[key]
            raise PermissionError(
                f"State write denied for {source}: {key} is owned by {definition.owner}"
            )
        self._validate_value(key, value)
        current_revision = self._revisions.get(key, 0)
        if expected_revision is not None:
            if not isinstance(expected_revision, int) or isinstance(expected_revision, bool) or expected_revision < 0:
                raise ValueError("expected_revision must be a non-negative integer")
            if expected_revision != current_revision:
                raise RuntimeError(
                    f"Stale state write for {key}: expected revision "
                    f"{expected_revision}, current revision {current_revision}"
                )
        previous = self._values.get(key)
        self._values[key] = value
        revision = current_revision + 1
        self._revisions[key] = revision
        self._sequence += 1
        change = StateChange(self._sequence, key, previous, value, source, revision, origin)
        self._history.append(change)
        if len(self._history) > self._history_limit:
            del self._history[:-self._history_limit]
        for callback in tuple(self._watchers.get(key, ())):
            try:
                callback(change)
            except Exception as exc:
                self._failure_sequence += 1
                self._callback_failures.append(
                    CallbackFailure(
                        self._failure_sequence,
                        "state",
                        key,
                        getattr(callback, "__qualname__", getattr(callback, "__name__", repr(callback))),
                        str(exc) or exc.__class__.__name__,
                    )
                )
                if len(self._callback_failures) > self._history_limit:
                    del self._callback_failures[:-self._history_limit]
        return change

    def transact(self, updates: tuple[StateUpdate, ...], source: str) -> StateTransaction:
        source = _valid(source, "state source")
        if not updates:
            raise ValueError("State transaction requires at least one update")

        normalized: list[tuple[str, Any, int | None, DataOrigin]] = []
        seen: set[str] = set()
        for update in updates:
            if not isinstance(update, StateUpdate):
                raise TypeError("State transaction entries must be StateUpdate instances")
            key = _valid(update.key, "state key")
            if key in seen:
                raise ValueError(f"Duplicate state key in transaction: {key}")
            seen.add(key)
            if not self.can_write(key, source):
                definition = self._definitions[key]
                raise PermissionError(
                    f"State write denied for {source}: {key} is owned by {definition.owner}"
                )
            self._validate_value(key, update.value)
            expected = update.expected_revision
            if expected is not None:
                if not isinstance(expected, int) or isinstance(expected, bool) or expected < 0:
                    raise ValueError("expected_revision must be a non-negative integer")
                current = self._revisions.get(key, 0)
                if expected != current:
                    raise RuntimeError(
                        f"Stale state write for {key}: expected revision {expected}, "
                        f"current revision {current}"
                    )
            normalized.append((key, update.value, expected, _origin(update.origin)))

        # Commit only after every update has passed validation.
        self._transaction_sequence += 1
        transaction_id = self._transaction_sequence
        changes: list[StateChange] = []
        for key, value, _expected, origin in normalized:
            previous = self._values.get(key)
            revision = self._revisions.get(key, 0) + 1
            self._values[key] = value
            self._revisions[key] = revision
            self._sequence += 1
            change = StateChange(self._sequence, key, previous, value, source, revision, origin)
            self._history.append(change)
            if len(self._history) > self._history_limit:
                del self._history[:-self._history_limit]
            changes.append(change)

        # Notify after the complete transaction is committed so every observer
        # sees a coherent post-transaction snapshot.
        for change in changes:
            for callback in tuple(self._watchers.get(change.key, ())):
                try:
                    callback(change)
                except Exception as exc:
                    self._failure_sequence += 1
                    self._callback_failures.append(
                        CallbackFailure(
                            self._failure_sequence,
                            "state",
                            change.key,
                            getattr(callback, "__qualname__", getattr(callback, "__name__", repr(callback))),
                            str(exc) or exc.__class__.__name__,
                        )
                    )
                    if len(self._callback_failures) > self._history_limit:
                        del self._callback_failures[:-self._history_limit]
        return StateTransaction(transaction_id, tuple(changes))

    def callback_failures(self) -> tuple[CallbackFailure, ...]:
        return tuple(self._callback_failures)

    def get(self, key: str, default: Any = None) -> Any:
        return self._values.get(_valid(key, "state key"), default)

    def revision(self, key: str) -> int:
        return self._revisions.get(_valid(key, "state key"), 0)

    def read(self, key: str, default: Any = None) -> tuple[Any, int]:
        key = _valid(key, "state key")
        return self._values.get(key, default), self._revisions.get(key, 0)

    def require(self, key: str) -> Any:
        key = _valid(key, "state key")
        if key not in self._values:
            raise KeyError(f"State key not present: {key}")
        return self._values[key]

    def snapshot(self) -> dict[str, Any]:
        return dict(self._values)

    def history(self) -> tuple[StateChange, ...]:
        return tuple(self._history)

    def watch(self, key: str, callback: Callable[[StateChange], None]) -> None:
        key = _valid(key, "state key")
        if not callable(callback):
            raise TypeError("State watcher must be callable")
        callbacks = self._watchers.setdefault(key, [])
        if callback not in callbacks:
            callbacks.append(callback)

    def unwatch(self, key: str, callback: Callable[[StateChange], None]) -> None:
        key = _valid(key, "state key")
        callbacks = self._watchers.get(key)
        if not callbacks:
            return
        if callback in callbacks:
            callbacks.remove(callback)
        if not callbacks:
            self._watchers.pop(key, None)

@dataclass(frozen=True)
class EventTopicDefinition:
    topic: str
    publishers: tuple[str, ...]

class EventBus:
    """Ordered synchronous event publication with explicit publisher policy."""
    def __init__(self, history_limit: int = 1000) -> None:
        if history_limit < 1:
            raise ValueError("history_limit must be positive")
        self._subscribers: dict[str, list[Callable[[Event], None]]] = {}
        self._history: list[Event] = []
        self._sequence = 0
        self._history_limit = history_limit
        self._topics: dict[str, EventTopicDefinition] = {}
        self._callback_failures: list[CallbackFailure] = []
        self._failure_sequence = 0

    def register_topic(self, topic: str, publishers: tuple[str, ...]) -> EventTopicDefinition:
        topic = _valid(topic, "event topic")
        validated = tuple(_valid(item, "event publisher") for item in publishers)
        if not validated:
            raise ValueError("Registered event topic requires at least one publisher")
        if len(set(validated)) != len(validated):
            raise ValueError("Event publisher list contains duplicates")
        if topic in self._topics:
            raise ValueError(f"Event topic already registered: {topic}")
        definition = EventTopicDefinition(topic, validated)
        self._topics[topic] = definition
        return definition

    def topic_definition(self, topic: str) -> EventTopicDefinition | None:
        return self._topics.get(_valid(topic, "event topic"))

    def topic_definitions(self) -> tuple[EventTopicDefinition, ...]:
        return tuple(self._topics[key] for key in sorted(self._topics))

    def can_publish(self, topic: str, source: str) -> bool:
        topic = _valid(topic, "event topic")
        source = _valid(source, "event source")
        definition = self._topics.get(topic)
        return definition is None or source in definition.publishers

    def subscribe(self, topic: str, callback: Callable[[Event], None]) -> None:
        topic = _valid(topic, "event topic")
        if not callable(callback):
            raise TypeError("Event subscriber must be callable")
        callbacks = self._subscribers.setdefault(topic, [])
        if callback not in callbacks:
            callbacks.append(callback)

    def unsubscribe(self, topic: str, callback: Callable[[Event], None]) -> None:
        topic = _valid(topic, "event topic")
        callbacks = self._subscribers.get(topic)
        if not callbacks:
            return
        if callback in callbacks:
            callbacks.remove(callback)
        if not callbacks:
            self._subscribers.pop(topic, None)

    def publish(self, topic: str, payload: Any, source: str,
                origin: DataOrigin | str = DataOrigin.SOFTWARE) -> Event:
        topic = _valid(topic, "event topic")
        source = _valid(source, "event source")
        origin = _origin(origin)
        if not self.can_publish(topic, source):
            raise PermissionError(f"Event publication denied for {source}: {topic}")
        self._sequence += 1
        event = Event(self._sequence, topic, payload, source, origin)
        self._history.append(event)
        if len(self._history) > self._history_limit:
            del self._history[:-self._history_limit]
        for callback in tuple(self._subscribers.get(topic, ())):
            try:
                callback(event)
            except Exception as exc:
                self._failure_sequence += 1
                self._callback_failures.append(
                    CallbackFailure(
                        self._failure_sequence,
                        "event",
                        topic,
                        getattr(callback, "__qualname__", getattr(callback, "__name__", repr(callback))),
                        str(exc) or exc.__class__.__name__,
                    )
                )
                if len(self._callback_failures) > self._history_limit:
                    del self._callback_failures[:-self._history_limit]
        return event

    def callback_failures(self) -> tuple[CallbackFailure, ...]:
        return tuple(self._callback_failures)

    def history(self) -> tuple[Event, ...]:
        return tuple(self._history)

    def subscriber_count(self, topic: str) -> int:
        return len(self._subscribers.get(_valid(topic, "event topic"), ()))



class StateEventClient:
    """Source-bound module-facing view of the JOE state/event backbone."""
    def __init__(self, backbone: "StateEventBackbone", source: str) -> None:
        self._backbone = backbone
        self.source = _valid(source, "client source")

    def get_state(self, key: str, default: Any = None) -> Any:
        return self._backbone.state.get(key, default)

    def require_state(self, key: str) -> Any:
        return self._backbone.state.require(key)

    def read_state(self, key: str, default: Any = None) -> tuple[Any, int]:
        return self._backbone.state.read(key, default)

    def state_revision(self, key: str) -> int:
        return self._backbone.state.revision(key)

    def state_snapshot(self) -> dict[str, Any]:
        return self._backbone.state.snapshot()

    def set_state(self, key: str, value: Any,
                  expected_revision: int | None = None,
                  origin: DataOrigin | str = DataOrigin.SOFTWARE) -> StateChange:
        return self._backbone.state.set(
            key, value, self.source, expected_revision, origin
        )

    def transact_state(self, updates: tuple[StateUpdate, ...]) -> StateTransaction:
        return self._backbone.state.transact(updates, self.source)

    def watch_state(self, key: str, callback: Callable[[StateChange], None]) -> None:
        self._backbone.state.watch(key, callback)

    def unwatch_state(self, key: str, callback: Callable[[StateChange], None]) -> None:
        self._backbone.state.unwatch(key, callback)

    def publish(self, topic: str, payload: Any,
                origin: DataOrigin | str = DataOrigin.SOFTWARE) -> Event:
        return self._backbone.events.publish(topic, payload, self.source, origin)

    def subscribe(self, topic: str, callback: Callable[[Event], None]) -> None:
        self._backbone.events.subscribe(topic, callback)

    def unsubscribe(self, topic: str, callback: Callable[[Event], None]) -> None:
        self._backbone.events.unsubscribe(topic, callback)

class StateEventBackbone:
    """Single JOE-owned container for authoritative state and ordered events."""
    def __init__(self, history_limit: int = 1000) -> None:
        self.state = StateStore(history_limit)
        self.events = EventBus(history_limit)
        self._clients: dict[str, StateEventClient] = {}

    def client(self, source: str) -> StateEventClient:
        source = _valid(source, "client source")
        client = self._clients.get(source)
        if client is None:
            client = StateEventClient(self, source)
            self._clients[source] = client
        return client


@dataclass(frozen=True)
class StateEventQualification:
    passed: bool
    failures: tuple[str, ...]
    state_definition_count: int
    event_topic_count: int
    state_history_count: int
    event_history_count: int

def qualify_state_event_backbone(backbone: "StateEventBackbone") -> StateEventQualification:
    failures: list[str] = []

    definitions = backbone.state.definitions()
    topics = backbone.events.topic_definitions()
    state_history = backbone.state.history()
    event_history = backbone.events.history()

    # Definitions must remain internally coherent.
    for definition in definitions:
        if not definition.owner:
            failures.append(f"State {definition.key} has no owner.")
        if definition.owner in definition.writable_by:
            failures.append(
                f"State {definition.key} redundantly lists its owner as an additional writer."
            )
        if len(definition.writable_by) != len(set(definition.writable_by)):
            failures.append(f"State {definition.key} has duplicate writers.")

    for topic in topics:
        if not topic.publishers:
            failures.append(f"Event topic {topic.topic} has no publishers.")
        if len(topic.publishers) != len(set(topic.publishers)):
            failures.append(f"Event topic {topic.topic} has duplicate publishers.")

    # Histories must be strictly monotonic in retained order.
    state_sequences = [item.sequence for item in state_history]
    if state_sequences != sorted(state_sequences) or len(state_sequences) != len(set(state_sequences)):
        failures.append("State history sequence is not strictly ordered and unique.")
    event_sequences = [item.sequence for item in event_history]
    if event_sequences != sorted(event_sequences) or len(event_sequences) != len(set(event_sequences)):
        failures.append("Event history sequence is not strictly ordered and unique.")

    # Every retained state revision must be positive and must not exceed current revision.
    for change in state_history:
        if change.revision < 1:
            failures.append(f"State history entry {change.sequence} has invalid revision.")
        if change.revision > backbone.state.revision(change.key):
            failures.append(
                f"State history entry {change.sequence} exceeds current revision for {change.key}."
            )

    # Current registered values must satisfy their declared type contracts.
    snapshot = backbone.state.snapshot()
    for definition in definitions:
        if definition.key not in snapshot:
            continue
        value = snapshot[definition.key]
        if value is None and definition.allow_none:
            continue
        if definition.value_type is not None and not isinstance(value, definition.value_type):
            failures.append(f"Current value for {definition.key} violates its type contract.")

    # Callback failures are real diagnostics and therefore make qualification fail.
    if backbone.state.callback_failures():
        failures.append(
            f"State watcher failures recorded: {len(backbone.state.callback_failures())}."
        )
    if backbone.events.callback_failures():
        failures.append(
            f"Event subscriber failures recorded: {len(backbone.events.callback_failures())}."
        )

    return StateEventQualification(
        passed=not failures,
        failures=tuple(failures),
        state_definition_count=len(definitions),
        event_topic_count=len(topics),
        state_history_count=len(state_history),
        event_history_count=len(event_history),
    )


@dataclass(frozen=True)
class StateEventReleaseReadiness:
    passed: bool
    failures: tuple[str, ...]
    qualification: StateEventQualification
    required_states: tuple[str, ...]
    required_topics: tuple[str, ...]

def joe004_release_readiness(backbone: "StateEventBackbone") -> StateEventReleaseReadiness:
    """Final code-level release gate for JOE-004 State & Event Backbone."""
    qualification = qualify_state_event_backbone(backbone)
    failures = list(qualification.failures)

    required_states = ("joe.runtime.module-count", "joe.runtime.status")
    required_topics = ("joe.runtime.lifecycle",)

    for key in required_states:
        definition = backbone.state.definition(key)
        if definition is None:
            failures.append(f"Required JOE state is not registered: {key}.")
            continue
        if definition.owner != "joe.core":
            failures.append(f"Required JOE state {key} is not owned by joe.core.")
        if backbone.state.revision(key) < 1:
            failures.append(f"Required JOE state {key} has never been initialized.")

    topic = backbone.events.topic_definition("joe.runtime.lifecycle")
    if topic is None:
        failures.append("Required JOE event topic is not registered: joe.runtime.lifecycle.")
    elif "joe.core" not in topic.publishers:
        failures.append("joe.runtime.lifecycle does not authorize joe.core.")

    # Verify origin/source integrity of the live foundation records.
    for change in backbone.state.history():
        if change.key in required_states:
            if change.source != "joe.core":
                failures.append(
                    f"Required state {change.key} contains a non-core source record."
                )
            if change.origin is not DataOrigin.SOFTWARE:
                failures.append(
                    f"Required runtime state {change.key} has unexpected origin {change.origin.value}."
                )

    lifecycle = [
        event for event in backbone.events.history()
        if event.topic == "joe.runtime.lifecycle"
    ]
    if not lifecycle:
        failures.append("No joe.runtime.lifecycle event has been published.")
    else:
        if any(event.source != "joe.core" for event in lifecycle):
            failures.append("Runtime lifecycle history contains a non-core publisher.")
        if any(event.origin is not DataOrigin.SOFTWARE for event in lifecycle):
            failures.append("Runtime lifecycle history contains a non-SOFTWARE origin.")

    # Exercise source-bound identity and stale-write rejection without mutating
    # the required live state. This uses an isolated probe key.
    probe = StateEventBackbone()
    probe.state.register("joe.release.probe", "joe.core", value_type=int)
    core = probe.client("joe.core")
    other = probe.client("other.module")
    first = core.set_state("joe.release.probe", 1)
    try:
        other.set_state("joe.release.probe", 2)
        failures.append("Source-bound state authority probe unexpectedly allowed impersonation.")
    except PermissionError:
        pass
    try:
        core.set_state("joe.release.probe", 3, expected_revision=0)
        failures.append("Stale-write probe unexpectedly accepted an obsolete revision.")
    except RuntimeError:
        pass
    if first.revision != 1 or probe.state.require("joe.release.probe") != 1:
        failures.append("State revision probe produced inconsistent authoritative state.")

    return StateEventReleaseReadiness(
        passed=not failures,
        failures=tuple(failures),
        qualification=qualification,
        required_states=required_states,
        required_topics=required_topics,
    )
