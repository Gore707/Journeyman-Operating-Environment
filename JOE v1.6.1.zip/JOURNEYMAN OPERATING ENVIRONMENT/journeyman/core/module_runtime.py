"""JOE module runtime.

The runtime owns module registration and lifecycle state.  It does not discover
or advertise future modules: only concrete descriptors explicitly registered by
the running build exist here.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import re

_ID = re.compile(r"^[a-z][a-z0-9_.-]{1,63}$")

class ModuleState(str, Enum):
    REGISTERED = "registered"
    ACTIVE = "active"
    STOPPED = "stopped"
    FAILED = "failed"


class ModuleInstance:
    """Lifecycle interface for a concrete runtime-owned module instance."""

    def start(self) -> None:
        """Acquire module resources. Raise on failure."""

    def stop(self) -> None:
        """Release module resources. Raise on failure."""


@dataclass(frozen=True)
class ModuleTransition:
    sequence: int
    module_id: str
    previous: ModuleState | None
    current: ModuleState
    reason: str = ""

@dataclass(frozen=True)
class ModuleDescriptor:
    module_id: str
    name: str
    version: str
    description: str = ""
    requires: tuple[str, ...] = ()
    provides: tuple[str, ...] = ()
    consumes: tuple[str, ...] = ()

    def validate(self) -> None:
        if not _ID.fullmatch(self.module_id):
            raise ValueError("Invalid JOE module ID.")
        if not self.name.strip():
            raise ValueError("Module name cannot be empty.")
        if not self.version.strip():
            raise ValueError("Module version cannot be empty.")
        if len(set(self.requires)) != len(self.requires):
            raise ValueError("Module dependency list contains duplicates.")
        for dependency in self.requires:
            if not _ID.fullmatch(dependency):
                raise ValueError(f"Invalid module dependency ID: {dependency}")
            if dependency == self.module_id:
                raise ValueError("Module cannot depend on itself.")
        if len(set(self.provides)) != len(self.provides):
            raise ValueError("Module capability list contains duplicates.")
        for capability in self.provides:
            if not _ID.fullmatch(capability):
                raise ValueError(f"Invalid module capability ID: {capability}")
        if len(set(self.consumes)) != len(self.consumes):
            raise ValueError("Module consumption list contains duplicates.")
        for capability in self.consumes:
            if not _ID.fullmatch(capability):
                raise ValueError(f"Invalid consumed capability ID: {capability}")

@dataclass(frozen=True)
class ModuleRecord:
    descriptor: ModuleDescriptor
    state: ModuleState
    error: str = ""

class ModuleRuntime:
    def __init__(self) -> None:
        self._records: dict[str, ModuleRecord] = {}
        self._instances: dict[str, ModuleInstance] = {}
        self._services: dict[str, tuple[str, object]] = {}
        self._transitions: list[ModuleTransition] = []
        self._transition_sequence = 0

    def _record_transition(self, module_id: str, previous: ModuleState | None,
                           current: ModuleState, reason: str = "") -> None:
        self._transition_sequence += 1
        self._transitions.append(
            ModuleTransition(self._transition_sequence, module_id, previous, current, reason)
        )
        if len(self._transitions) > 1000:
            del self._transitions[:-1000]

    def transitions(self) -> tuple[ModuleTransition, ...]:
        return tuple(self._transitions)

    def dependency_order(self, module_ids: tuple[str, ...] | None = None) -> tuple[str, ...]:
        """Return dependencies before dependents; reject missing dependencies/cycles."""
        targets = set(module_ids) if module_ids is not None else set(self._records)
        for module_id in targets:
            self.require(module_id)

        # Include transitive dependencies of requested targets.
        pending = list(targets)
        while pending:
            module_id = pending.pop()
            for dep in self.require(module_id).descriptor.requires:
                if dep not in self._records:
                    raise RuntimeError(f"Missing module dependency: {dep}")
                if dep not in targets:
                    targets.add(dep)
                    pending.append(dep)

        temporary: set[str] = set()
        permanent: set[str] = set()
        ordered: list[str] = []

        def visit(module_id: str) -> None:
            if module_id in permanent:
                return
            if module_id in temporary:
                raise RuntimeError(f"Module dependency cycle detected at: {module_id}")
            temporary.add(module_id)
            for dep in sorted(self.require(module_id).descriptor.requires):
                if dep in targets:
                    visit(dep)
            temporary.remove(module_id)
            permanent.add(module_id)
            ordered.append(module_id)

        for module_id in sorted(targets):
            visit(module_id)
        return tuple(ordered)

    def activate_with_dependencies(self, module_id: str) -> tuple[str, ...]:
        """Activate a module and all required modules in dependency-safe order."""
        order = self.dependency_order((module_id,))
        activated: list[str] = []
        for current in order:
            record = self.require(current)
            if record.state is ModuleState.ACTIVE:
                continue
            self.activate(current)
            activated.append(current)
        return tuple(activated)

    def register(self, descriptor: ModuleDescriptor,
                 instance: ModuleInstance | None = None) -> ModuleRecord:
        descriptor.validate()
        if descriptor.module_id in self._records:
            raise ValueError(f"Module already registered: {descriptor.module_id}")
        declared = {
            capability for record in self._records.values()
            for capability in record.descriptor.provides
        }
        conflicts = sorted(set(descriptor.provides) & declared)
        if conflicts:
            raise ValueError("Capability already declared by another module: " + ", ".join(conflicts))
        record = ModuleRecord(descriptor, ModuleState.REGISTERED)
        self._records[descriptor.module_id] = record
        self._record_transition(descriptor.module_id, None, ModuleState.REGISTERED, "registered")
        if instance is not None:
            self._instances[descriptor.module_id] = instance
        return record

    def activate(self, module_id: str) -> ModuleRecord:
        record = self.require(module_id)
        if record.state is ModuleState.FAILED:
            raise RuntimeError("Failed module must be reset before activation.")
        missing = [dep for dep in record.descriptor.requires if dep not in self._records]
        if missing:
            raise RuntimeError("Missing module dependencies: " + ", ".join(missing))
        inactive = [
            dep for dep in record.descriptor.requires
            if self._records[dep].state is not ModuleState.ACTIVE
        ]
        if inactive:
            raise RuntimeError("Inactive module dependencies: " + ", ".join(inactive))
        instance = self._instances.get(module_id)
        if instance is not None:
            try:
                instance.start()
            except Exception as exc:
                self.withdraw_services(module_id)
                failed = ModuleRecord(record.descriptor, ModuleState.FAILED, str(exc) or exc.__class__.__name__)
                self._records[module_id] = failed
                self._record_transition(module_id, record.state, ModuleState.FAILED,
                                        str(exc) or exc.__class__.__name__)
                raise RuntimeError(f"Module activation failed: {module_id}") from exc
        updated = ModuleRecord(record.descriptor, ModuleState.ACTIVE)
        self._records[module_id] = updated
        self._record_transition(module_id, record.state, ModuleState.ACTIVE, "activated")
        return updated

    def stop(self, module_id: str) -> ModuleRecord:
        record = self.require(module_id)
        dependents = [
            other.descriptor.module_id for other in self._records.values()
            if module_id in other.descriptor.requires and other.state is ModuleState.ACTIVE
        ]
        if dependents:
            raise RuntimeError(
                "Cannot stop module while active dependents exist: " + ", ".join(sorted(dependents))
            )
        instance = self._instances.get(module_id)
        if instance is not None and record.state is ModuleState.ACTIVE:
            try:
                instance.stop()
            except Exception as exc:
                self.withdraw_services(module_id)
                failed = ModuleRecord(record.descriptor, ModuleState.FAILED, str(exc) or exc.__class__.__name__)
                self._records[module_id] = failed
                self._record_transition(module_id, record.state, ModuleState.FAILED,
                                        str(exc) or exc.__class__.__name__)
                raise RuntimeError(f"Module shutdown failed: {module_id}") from exc
        self.withdraw_services(module_id)
        updated = ModuleRecord(record.descriptor, ModuleState.STOPPED)
        self._records[module_id] = updated
        self._record_transition(module_id, record.state, ModuleState.STOPPED, "stopped")
        return updated

    def fail(self, module_id: str, error: str) -> ModuleRecord:
        record = self.require(module_id)
        message = str(error).strip() or "Unspecified module failure"
        self.withdraw_services(module_id)
        updated = ModuleRecord(record.descriptor, ModuleState.FAILED, message)
        self._records[module_id] = updated
        self._record_transition(module_id, record.state, ModuleState.FAILED, message)
        return updated

    def reset(self, module_id: str) -> ModuleRecord:
        record = self.require(module_id)
        updated = ModuleRecord(record.descriptor, ModuleState.REGISTERED)
        self._records[module_id] = updated
        self._record_transition(module_id, record.state, ModuleState.REGISTERED, "reset")
        return updated

    def require(self, module_id: str) -> ModuleRecord:
        try:
            return self._records[module_id]
        except KeyError as exc:
            raise KeyError(f"Unknown JOE module: {module_id}") from exc

    def records(self) -> tuple[ModuleRecord, ...]:
        return tuple(self._records[key] for key in sorted(self._records))

    def publish_service(self, module_id: str, capability: str, service: object) -> None:
        record = self.require(module_id)
        if record.state is not ModuleState.ACTIVE:
            raise RuntimeError("Only an active module may publish a service.")
        if capability not in record.descriptor.provides:
            raise RuntimeError(f"Module did not declare capability: {capability}")
        owner = self._services.get(capability)
        if owner is not None and owner[0] != module_id:
            raise RuntimeError(f"Capability service already published: {capability}")
        self._services[capability] = (module_id, service)

    def withdraw_services(self, module_id: str) -> None:
        for capability, (owner, _service) in tuple(self._services.items()):
            if owner == module_id:
                del self._services[capability]

    def resolve_service(self, consumer_module_id: str, capability: str) -> object:
        consumer = self.require(consumer_module_id)
        if consumer.state is not ModuleState.ACTIVE:
            raise RuntimeError("Only an active module may resolve services.")
        if capability not in consumer.descriptor.consumes:
            raise RuntimeError(
                f"Module did not declare consumption of capability: {capability}"
            )
        return self.service(capability)

    def available_capabilities(self) -> tuple[str, ...]:
        return tuple(sorted(
            capability for capability, (owner, _service) in self._services.items()
            if self.require(owner).state is ModuleState.ACTIVE
        ))

    def service(self, capability: str) -> object:
        try:
            owner, service = self._services[capability]
        except KeyError as exc:
            raise KeyError(f"No active service for capability: {capability}") from exc
        if self.require(owner).state is not ModuleState.ACTIVE:
            raise RuntimeError(f"Service owner is not active: {owner}")
        return service

    def service_owner(self, capability: str) -> str | None:
        item = self._services.get(capability)
        return item[0] if item else None

    def counts(self) -> dict[ModuleState, int]:
        return {state: sum(r.state is state for r in self._records.values())
                for state in ModuleState}


    def shutdown_all(self) -> tuple[str, ...]:
        """Stop active modules in dependency-safe order.

        Dependents are stopped before dependencies. Failures are recorded and
        shutdown continues so one module cannot prevent cleanup of the rest.
        """
        stopped: list[str] = []
        pending = {r.descriptor.module_id for r in self._records.values()
                   if r.state is ModuleState.ACTIVE}
        while pending:
            progress = False
            for module_id in sorted(tuple(pending)):
                active_dependents = [
                    other_id for other_id in pending
                    if module_id in self._records[other_id].descriptor.requires
                ]
                if active_dependents:
                    continue
                try:
                    self.stop(module_id)
                except RuntimeError:
                    pass
                stopped.append(module_id)
                pending.remove(module_id)
                progress = True
            if not progress:
                # Defensive cycle containment. Descriptor validation prevents
                # self-dependency; a multi-module cycle can still be registered.
                for module_id in sorted(pending):
                    self.fail(module_id, "Dependency cycle prevented orderly shutdown.")
                    stopped.append(module_id)
                break
        return tuple(stopped)


@dataclass(frozen=True)
class ModuleContract:
    module_id: str
    requires: tuple[str, ...]
    provides: tuple[str, ...]
    consumes: tuple[str, ...]
    state: ModuleState

def contracts(runtime: ModuleRuntime) -> tuple[ModuleContract, ...]:
    """Return immutable runtime dependency/lifecycle contracts."""
    return tuple(
        ModuleContract(r.descriptor.module_id, r.descriptor.requires, r.descriptor.provides, r.descriptor.consumes, r.state)
        for r in runtime.records()
    )


@dataclass(frozen=True)
class ModuleRuntimeQualification:
    passed: bool
    failures: tuple[str, ...]
    activation_order: tuple[str, ...]

def qualify_module_runtime(runtime: ModuleRuntime) -> ModuleRuntimeQualification:
    """Code-level structural qualification of the live module graph."""
    failures: list[str] = []
    try:
        order = runtime.dependency_order()
    except RuntimeError as exc:
        return ModuleRuntimeQualification(False, (str(exc),), ())

    providers: dict[str, str] = {}
    for record in runtime.records():
        descriptor = record.descriptor
        for capability in descriptor.provides:
            previous = providers.get(capability)
            if previous is not None and previous != descriptor.module_id:
                failures.append(
                    f"Capability {capability} declared by both {previous} and {descriptor.module_id}."
                )
            providers[capability] = descriptor.module_id
        if record.state is ModuleState.ACTIVE:
            for dep in descriptor.requires:
                if runtime.require(dep).state is not ModuleState.ACTIVE:
                    failures.append(
                        f"Active module {descriptor.module_id} has inactive dependency {dep}."
                    )
    return ModuleRuntimeQualification(not failures, tuple(failures), order)


@dataclass(frozen=True)
class ModuleRuntimeReleaseReadiness:
    passed: bool
    failures: tuple[str, ...]
    module_count: int
    active_count: int
    published_capabilities: tuple[str, ...]
    activation_order: tuple[str, ...]

def joe003_release_readiness(runtime: ModuleRuntime) -> ModuleRuntimeReleaseReadiness:
    """Final code-level release gate for the JOE-003 module runtime subsystem."""
    failures: list[str] = []
    qualification = qualify_module_runtime(runtime)
    failures.extend(qualification.failures)

    records = runtime.records()
    ids = [record.descriptor.module_id for record in records]
    if len(ids) != len(set(ids)):
        failures.append("Duplicate module identities are present.")

    active_count = 0
    for record in records:
        descriptor = record.descriptor
        if record.state is ModuleState.ACTIVE:
            active_count += 1
        if record.state is ModuleState.FAILED and not record.error:
            failures.append(f"Failed module {descriptor.module_id} has no recorded error.")
        for capability in descriptor.provides:
            owner = runtime.service_owner(capability)
            if record.state is ModuleState.ACTIVE and owner is None:
                failures.append(
                    f"Active provider {descriptor.module_id} has not published {capability}."
                )
            if owner is not None and owner != descriptor.module_id:
                failures.append(
                    f"Capability {capability} is owned by {owner}, not declared provider "
                    f"{descriptor.module_id}."
                )

    # Every published capability must belong to a live, declared provider.
    for capability in runtime.available_capabilities():
        owner = runtime.service_owner(capability)
        if owner is None:
            failures.append(f"Published capability {capability} has no owner.")
            continue
        owner_record = runtime.require(owner)
        if capability not in owner_record.descriptor.provides:
            failures.append(
                f"Published capability {capability} is undeclared by owner {owner}."
            )
        if owner_record.state is not ModuleState.ACTIVE:
            failures.append(
                f"Published capability {capability} belongs to inactive module {owner}."
            )

    return ModuleRuntimeReleaseReadiness(
        passed=not failures,
        failures=tuple(failures),
        module_count=len(records),
        active_count=active_count,
        published_capabilities=runtime.available_capabilities(),
        activation_order=qualification.activation_order,
    )
