"""Q-1 QFT / Semiclassical / Quantum Inequality Workbench module."""
from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.qft import (ford_roman_lorentzian_massless_scalar_bound,qi_sampling_sweep,
 qft_guardian_contract,unsupported_semiclassical_request,negative_energy_exposure,qi_feasibility_margin,
 maximum_reference_sampling_time,account_pulses,qi_magnitude_duration_curve,ideal_parallel_plate_casimir,
 single_mode_squeezed_vacuum_reference,compare_reference_mechanisms,validate_qft_request_consistency,
 local_curvature_scale_from_riemann_covariant,local_flatness_diagnostic,compare_required_stress_energy_to_qi,
 semiclassical_consistency,qi_sampling_sensitivity,propagate_qi_sampling_time_uncertainty,expanded_qft_guardian_contract,
 lorentzian_sampling_profile,integrate_sampling_profile,sample_energy_density,verify_qi_reference_numerically,q1_model_comparison,
 q1_release_readiness)
from journeyman.core.advanced_physics import ideal_parallel_plate_casimir_reference,single_mode_squeezed_state_reference
Q1_MODULE=ModuleDescriptor(module_id="journeyman.qft",name="QFT / Semiclassical / Quantum Inequality Workbench [Q-1]",
 version="1.0.0",description="Typed semiclassical-QFT requests and domain-limited quantum-inequality reference solvers.",
 requires=("joe.core","journeyman.mpr","journeyman.registry","journeyman.geometry","journeyman.stress-energy"),
 provides=("joe.qft",),consumes=("joe.mpr","joe.units","joe.geometry","joe.stress-energy","joe.state-events"))
class QFTService:
    evaluate_reference_qi=staticmethod(ford_roman_lorentzian_massless_scalar_bound)
    sampling_sweep=staticmethod(qi_sampling_sweep)
    guardian_contract=staticmethod(qft_guardian_contract)
    unsupported=staticmethod(unsupported_semiclassical_request)
    exposure=staticmethod(negative_energy_exposure)
    feasibility_margin=staticmethod(qi_feasibility_margin)
    maximum_sampling_time=staticmethod(maximum_reference_sampling_time)
    pulse_accounting=staticmethod(account_pulses)
    magnitude_duration_curve=staticmethod(qi_magnitude_duration_curve)
    casimir_reference=staticmethod(ideal_parallel_plate_casimir)
    squeezed_reference=staticmethod(single_mode_squeezed_vacuum_reference)
    compare_mechanisms=staticmethod(compare_reference_mechanisms)
    validate_request=staticmethod(validate_qft_request_consistency)
    curvature_scale=staticmethod(local_curvature_scale_from_riemann_covariant)
    local_flatness=staticmethod(local_flatness_diagnostic)
    stress_energy_comparison=staticmethod(compare_required_stress_energy_to_qi)
    consistency=staticmethod(semiclassical_consistency)
    sensitivity=staticmethod(qi_sampling_sensitivity)
    uncertainty=staticmethod(propagate_qi_sampling_time_uncertainty)
    expanded_guardian_contract=staticmethod(expanded_qft_guardian_contract)
    lorentzian_profile=staticmethod(lorentzian_sampling_profile)
    integrate_sampling=staticmethod(integrate_sampling_profile)
    sample_energy=staticmethod(sample_energy_density)
    numerical_verification=staticmethod(verify_qi_reference_numerically)
    model_comparison=staticmethod(q1_model_comparison)
    release_readiness=staticmethod(q1_release_readiness)
    casimir_advanced_reference=staticmethod(ideal_parallel_plate_casimir_reference)
    squeezed_state_advanced_reference=staticmethod(single_mode_squeezed_state_reference)
class QFTInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_qft_module(runtime:ModuleRuntime):
    svc=QFTService();runtime.register(Q1_MODULE,QFTInstance(svc));runtime.activate("journeyman.qft")
    runtime.publish_service("journeyman.qft","joe.qft",svc);return svc
