"""JOE 005B operational auto-configuration and external-compute admission gates.

Local scientific capability is never restricted by host class. External HPC/QPU
selection is fail-closed until a concrete discovered backend passes a capability
handshake. No credentials or hardware are inferred.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from enum import Enum
import hashlib,json,time
from pathlib import Path
from journeyman.core.paths import CONFIG_DIR

STATE_FILE=CONFIG_DIR/"operational_compute_state.json"

class ExternalAdmission(str,Enum):
    LOCAL="LOCAL"
    VERIFIED="VERIFIED"
    REJECTED="REJECTED"
    REVALIDATION_REQUIRED="REVALIDATION_REQUIRED"

@dataclass(frozen=True)
class HostFingerprint:
    logical_cpus:int
    memory_bytes:int
    gpu_ids:tuple[str,...]
    sha256:str

@dataclass(frozen=True)
class StartupComputeConfiguration:
    operating_environment:str
    local_profile:str
    maximum_workers:int
    maximum_joe_memory_bytes:int
    fingerprint_sha256:str
    hardware_changed:bool
    external_admission:ExternalAdmission
    provenance:str

@dataclass(frozen=True)
class CapabilityHandshake:
    requested_kind:str
    backend_id:str|None
    admitted:bool
    status:ExternalAdmission
    reasons:tuple[str,...]
    provenance:str


def fingerprint_host(sample,gpu_ids=())->HostFingerprint:
    logical=max(1,int(sample.cpu_logical_count or 1));mem=max(0,int(sample.memory_total_bytes or 0))
    ids=tuple(sorted(str(x) for x in gpu_ids))
    raw=json.dumps({"logical_cpus":logical,"memory_bytes":mem,"gpu_ids":ids},sort_keys=True,separators=(",",":")).encode()
    return HostFingerprint(logical,mem,ids,hashlib.sha256(raw).hexdigest())

def _load_previous():
    try:return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:return None

def configure_startup(sample,envelope,gpu_ids=(),persist=True)->StartupComputeConfiguration:
    fp=fingerprint_host(sample,gpu_ids);old=_load_previous();changed=bool(old and old.get("fingerprint_sha256")!=fp.sha256)
    cfg=StartupComputeConfiguration("DEVELOPMENT / SIMULATION",envelope.profile.value,envelope.maximum_workers,
        envelope.maximum_joe_memory_bytes,fp.sha256,changed,
        ExternalAdmission.REVALIDATION_REQUIRED if changed else ExternalAdmission.LOCAL,
        "HOST/SOFTWARE: detected local resources + JOE governed policy")
    if persist:
        CONFIG_DIR.mkdir(parents=True,exist_ok=True)
        STATE_FILE.write_text(json.dumps({**asdict(cfg),"external_admission":cfg.external_admission.value,"saved_at":time.time()},indent=2,sort_keys=True),encoding="utf-8")
    return cfg

def external_compute_handshake(requested_kind:str,compute_backends=(),quantum_backends=())->CapabilityHandshake:
    kind=requested_kind.strip().upper();reasons=[]
    if kind in ("LOCAL","AUTO","CPU","GPU"):
        return CapabilityHandshake(kind,"local",True,ExternalAdmission.LOCAL,("local governed compute remains active",),"SOFTWARE/HOST: JOE local admission")
    if kind in ("HPC","CLUSTER","HPC / CLUSTER"):
        candidates=[b for b in compute_backends if getattr(getattr(b,"kind",None),"value","")=="HPC" and getattr(getattr(b,"status",None),"value","")=="AVAILABLE"]
        if not candidates:return CapabilityHandshake(kind,None,False,ExternalAdmission.REJECTED,("no HPC scheduler/backend was discovered as AVAILABLE","local compute remains unchanged"),"SOFTWARE: fail-closed external admission")
        b=candidates[0]
        # Discovery is not an authenticated execution adapter. Current JOE intentionally has no such adapter.
        reasons=(f"discovered {b.backend_id}","no authenticated/qualified HPC execution adapter is bound","local compute remains unchanged")
        return CapabilityHandshake(kind,b.backend_id,False,ExternalAdmission.REJECTED,reasons,"HOST/SOFTWARE: discovery without authority")
    if kind in ("QPU","PHYSICAL QPU","HYBRID","HYBRID / PHYSICAL QPU"):
        candidates=[b for b in quantum_backends if getattr(getattr(b,"kind",None),"value","")=="QPU" and getattr(getattr(b,"status",None),"value","")=="AVAILABLE"]
        if not candidates:return CapabilityHandshake(kind,None,False,ExternalAdmission.REJECTED,("no authenticated physical QPU is AVAILABLE","installed SDKs/local simulators do not establish QPU access","local compute remains unchanged"),"SOFTWARE: fail-closed external admission")
        b=candidates[0]
        return CapabilityHandshake(kind,b.backend_id,True,ExternalAdmission.VERIFIED,("backend reports authenticated AVAILABLE state","capability identity present"),b.provenance)
    return CapabilityHandshake(kind,None,False,ExternalAdmission.REJECTED,("unknown external compute request","local compute remains unchanged"),"SOFTWARE: fail-closed external admission")

def workload_admission(assessment,requested_workers:int,estimated_memory_bytes:int,envelope):
    reasons=[]
    if requested_workers<1 or estimated_memory_bytes<0:return {"admitted":False,"status":"REJECTED","reasons":("invalid workload resource declaration",)}
    if requested_workers>assessment.recommended_workers:reasons.append("requested workers exceed current governed recommendation")
    if estimated_memory_bytes>envelope.maximum_joe_memory_bytes:reasons.append("estimated memory exceeds JOE host envelope")
    if assessment.disposition.value in ("PAUSE_JOBS","CANCEL_JOBS"):reasons.append("host resource governor currently blocks new workload admission")
    return {"admitted":not reasons,"status":"ADMITTED" if not reasons else "REJECTED","reasons":tuple(reasons) or ("workload fits current governed host envelope",)}

def guardian_operational_contract(cfg,handshake=None):
    return {"schema":"JOE-GUARDIAN-OPERATIONAL-AUTOCONFIG/1","authority":"READ_ONLY_ADVISORY","may_command":False,
            "configuration":{**asdict(cfg),"external_admission":cfg.external_admission.value},
            "handshake":None if handshake is None else {**asdict(handshake),"status":handshake.status.value},
            "truth_boundary":"Hardware selection never creates hardware capability. External execution requires verified adapters; local simulation remains available."}

def operational_autoconfig_readiness():
    from types import SimpleNamespace
    from journeyman.core.resource_governor import derive_local_envelope,assess_resources
    s=SimpleNamespace(cpu_logical_count=8,cpu_percent=20,memory_total_bytes=16*1024**3,memory_percent=40,gpu_available=False,temperature_available=False,temperatures=(),gpus=(),timestamp=1.0)
    e=derive_local_envelope(s);a=assess_resources(s,e);cfg=configure_startup(s,e,persist=False)
    h=external_compute_handshake("QPU",(),());w=workload_admission(a,1,1024,e)
    passed=(cfg.operating_environment=="DEVELOPMENT / SIMULATION" and not h.admitted and w["admitted"] and cfg.maximum_workers<cfg.fingerprint_sha256.__len__())
    return {"passed":passed,"checks":("startup host fingerprint","automatic DEVELOPMENT/SIMULATION local profile","hardware-change revalidation flag","fail-closed HPC/QPU selection","local fallback","workload admission","Guardian read-only contract"),"failures":() if passed else ("operational auto-configuration qualification failed",)}
