"""Geometry / Metric Workbench application module."""
from journeyman.core.module_runtime import ModuleDescriptor,ModuleInstance,ModuleRuntime
from journeyman.core.geometry import minkowski_metric,curvature,stress_energy_from_geometry,assess_nec,morris_thorne_metric,morris_thorne_radial_profile,geometry_guardian_contract
from journeyman.core.advanced_physics import curvature_invariants, electromagnetic_stress_energy, einstein_source_from_stress_energy, verify_minkowski_curvature, verify_morris_thorne_phi0, advanced_physics_guardian_contract, advanced_physics_release_readiness

GEOMETRY_MODULE=ModuleDescriptor(
    module_id="journeyman.geometry",name="Geometry / Metric Workbench",version="1.0.0",
    description="Numerical spacetime metric and tensor foundation.",
    requires=("joe.core","journeyman.mpr"),provides=("joe.geometry",),
    consumes=("joe.mpr","joe.state-events"),
)
class GeometryService:
    def __init__(self,mpr):
        self.mpr=mpr
        self._models={"geometry.minkowski":minkowski_metric()}
    def register_model(self,model):
        if model.model_id in self._models:raise ValueError(f"Metric model already registered: {model.model_id}")
        self._models[model.model_id]=model
    def model(self,model_id):return self._models[model_id]
    def models(self):return tuple(self._models[k] for k in sorted(self._models))
    def evaluate_curvature(self,model_id,coordinates,*,relative_step=2e-5):
        return curvature(self.model(model_id),coordinates,relative_step=relative_step)
    def evaluate_stress_energy(self,model_id,coordinates,*,relative_step=2e-5,c=None,G=None):
        kwargs={"relative_step":relative_step}
        if c is not None:kwargs["c"]=c
        if G is not None:kwargs["G"]=G
        return stress_energy_from_geometry(self.model(model_id),coordinates,**kwargs)
    def evaluate_nec(self,model_id,coordinates,*,relative_step=2e-5,c=None,G=None):
        return assess_nec(self.evaluate_stress_energy(model_id,coordinates,relative_step=relative_step,c=c,G=G))
    def morris_thorne_from_mpr(self,parameter_id="design.throat-radius"):
        record=self.mpr.get(parameter_id)
        if record.unit!="m":raise ValueError("Morris-Thorne throat-radius MPR parameter must currently be expressed in meters")
        return morris_thorne_metric(throat_radius=record.value,model_revision=f"MPR:{record.parameter_id}@{record.revision}")
    def morris_thorne_profile_from_mpr(self,radii,parameter_id="design.throat-radius"):
        record=self.mpr.get(parameter_id)
        if record.unit!="m":raise ValueError("Morris-Thorne throat-radius MPR parameter must currently be expressed in meters")
        return morris_thorne_radial_profile(throat_radius=record.value,radii=radii)
    def guardian_contract(self,model_id,coordinates,*,relative_step=5e-5):
        return geometry_guardian_contract(self.model(model_id),coordinates,relative_step=relative_step)
    def curvature_invariants(self,model_id,coordinates,*,relative_step=2e-5):
        return curvature_invariants(self.model(model_id),coordinates,relative_step=relative_step)
    electromagnetic_stress_energy=staticmethod(electromagnetic_stress_energy)
    einstein_source=staticmethod(einstein_source_from_stress_energy)
    verify_minkowski=staticmethod(verify_minkowski_curvature)
    verify_morris_thorne=staticmethod(verify_morris_thorne_phi0)
    advanced_guardian_contract=staticmethod(advanced_physics_guardian_contract)
    advanced_release_readiness=staticmethod(advanced_physics_release_readiness)
class GeometryInstance(ModuleInstance):
    def __init__(self,service):self.service=service;self.running=False
    def start(self):self.running=True
    def stop(self):self.running=False
def register_geometry_module(runtime:ModuleRuntime):
    service=GeometryService(runtime.service("joe.mpr"))
    runtime.register(GEOMETRY_MODULE,GeometryInstance(service));runtime.activate("journeyman.geometry")
    runtime.publish_service("journeyman.geometry","joe.geometry",service);return service
